<?php session_start();
    require_once('php/config.php');

    //Code for Registration 
    if(isset($_POST['submit'])) {
        $fname=$_POST['fname'];
        $lname=$_POST['lname'];
        $email=$_POST['email'];
        $password=$_POST['password'];
        $contact=$_POST['contact'];
        $toEmail ="m.hareesh2504@gmail.com";

        $mailBody = "Name : " . $fname . " " . $lname .
                    "\r\r Email : " . $email . 
                    "\r\r Phone : " . $contact . "\r\r";
                
            if (mail($toEmail, $email, $mailBody)) {
                $mailMsg = " you are Registered successfully";
            }
    


        $sql=mysqli_query($con,"select id from empreg where email='$email'");
        $row=mysqli_num_rows($sql);
        if($row>0) {
            echo "<script>alert('Email id already exist with another account. Please try with other email id');</script>";
        } else{
            $msg=mysqli_query($con,"insert into empreg(fname,lname,email,password,phone) values('$fname','$lname','$email','$password','$contact')");

            if($msg) {
                // echo "<script>alert($mailMsg);</script>";
                // echo "<script>alert($mailBody);</script>";
                // echo $fname;
                // echo "<script>alert($toEmail);</script>";
                echo "<script>alert('You are Registered successfully');</script>";
                // echo "<script type='text/javascript'> document.location = 'login.php'; </script>";
            }
        }
    }
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <title>ASE User Signup</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" 
            rel="stylesheet"
            integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" 
            crossorigin="anonymous"
        >
        <link rel="stylesheet" href="css/styles.css">
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js" crossorigin="anonymous"></script>
        <script type="text/javascript">
            function checkpass() {
                if(document.signup.password.value!=document.signup.confirmpassword.value) {
                    alert(' Password and Confirm Password field does not match');
                    document.signup.confirmpassword.focus();
                    return false;
                }
                return true;
            } 
        </script>
    </head>
    <body class="bg-light">
        <div id="layoutAuthentication">
            <div id="layoutAuthentication_content">
                <main>
                    <div class="container">
                        <div class="row justify-content-center">
                            <div class="col-lg-7">
                                <div class="card shadow-lg border-0 rounded-lg mt-5">
                                    <div class="card-header bg-primary">
                                        <h2 align="center">Registration and Login System</h2>
                                        <hr />
                                        <h3 class="text-center font-weight-light my-4">Create Account</h3></div>
                                    <div class="card-body bg-info">
                                        <form method="post" name="signup" onsubmit="return checkpass();">

                                            <div class="row mb-3">
                                                <div class="col-md-6">
                                                    <div class="form-floating mb-3 mb-md-0">
                                                        <input class="form-control" id="fname" name="fname" type="text" placeholder="Enter your first name" required />
                                                        <label for="inputFirstName">First name</label>
                                                    </div>
                                                </div>

                                                <div class="col-md-6">
                                                    <div class="form-floating">
                                                        <input class="form-control" id="lname" name="lname" type="text" placeholder="Enter your last name" required />
                                                        <label for="inputLastName">Last name</label>
                                                    </div>
                                                </div>
                                            </div>


                                            <div class="form-floating mb-3">
                                                <input class="form-control" id="email" name="email" type="email" placeholder="phpgurukulteam@gmail.com" required />
                                                <label for="inputEmail">Email address</label>
                                            </div>
                                        

                                            <div class="form-floating mb-3">
                                                <input class="form-control" id="contact" name="contact" type="text" placeholder="1234567890" required pattern="[0-9]{10}" title="10 numeric characters only"  maxlength="10" required />
                                                <label for="inputcontact">Contact Number</label>
                                            </div>
                                                


                                            <div class="row mb-3">
                                                <div class="col-md-6">
                                                    <div class="form-floating mb-3 mb-md-0">
                                                        <input class="form-control" id="password" name="password" type="password" placeholder="Create a password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}" title="at least one number and one uppercase and lowercase letter, and at least 6 or more characters" required/>
                                                        <label for="inputPassword">Password</label>
                                                    </div>
                                                </div>
                                                                                        

                                                <div class="col-md-6">
                                                    <div class="form-floating mb-3 mb-md-0">
                                                        <input class="form-control" id="confirmpassword" name="confirmpassword" type="password" placeholder="Confirm password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}" title="at least one number and one uppercase and lowercase letter, and at least 6 or more characters" required />
                                                        <label for="inputPasswordConfirm">Confirm Password</label>
                                                    </div>
                                                </div>
                                            </div>
                                                                                    
                                            <div class="mt-4 mb-0">
                                                <div class="d-grid"><button type="submit" class="btn btn-primary btn-block" name="submit">Create Account</button></div>
                                            </div>

                                            <?php if(!empty($mailMsg)) { ?>
                                            
                                                <div class="success">
                                                    <strong><?php echo $mailBody; ?></strong>

                                                </div>
                                            <?php } ?>

                                        </form>
                                    </div>
                                    <div class="card-footer text-center py-3 bg-primary ">
                                        <div class="small"><a class="text-light" href="login.php">Have an account? Go to login</a></div>
                                        <div class="small"><a class="text-light" href="index.php">Back to Home</a></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </main>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
    </body>
</html>
