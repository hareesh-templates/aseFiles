<?php 

    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\Exception;
    use PHPMailer\PHPMailer\SMTP;

    require 'folder/src/exception.php';
    require 'folder/src/PHPMailer.php';
    require 'folder/src/SMTP.php';


    if(isset($_POST["submit"])) {
        $mail = new PHPMailer(true);


        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $name->email = 'herambh250496@gmail.com';
        $mail->Password = 'acbmnuelyzmvdgxa';
        $mail->SMTPSecure = 'ssl';
        $mail->Port = 25;

        $mail->setFrom('herambh250496@gmail.com');

        $mail->addAddress($_POST["email"]);

        $mail->isHTML(true);

        $mail->Subject = $_POST["subject"];
        $mail->Body = $_POST["comment"];

        $mail->send();

        echo "
        <script>
            alert('email sent successfully');
            document.location.href = 'index.php';
        </script>
        ";
    }

?>