<?php
include_once('config.php');
 $email = $_GET['email'];
 $query = "delete from contact_info where email='".$email."'";

$conn->exec($query);
  echo "Record deleted successfully";
 
?>
 