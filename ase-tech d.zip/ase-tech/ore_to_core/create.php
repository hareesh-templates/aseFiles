
<?php
include("config.php");
if (isset($_POST['submit'])) {
    $name = $_POST['name'];
    $number = $_POST['phone_number'];
    $email = $_POST['email'];
    $textarea = $_POST['description'];
}
$sql = "insert into contact_info (name,phone_number,email,description) values(?,?,?,?)";
$stmt = $conn->prepare($sql);
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$data = array($name, $number, $email, $textarea);
// var_dump($data);
$stmt->execute($data);

echo "
    <script>
        alert('form submitted successfully');
        document.location.href = '../ore_to_core';
    </script>";
?>
