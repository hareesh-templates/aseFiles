<?php include 'header.php'; ?>
<section class="ftco-section ftco-project" id="projects-section">
		<div class="container-fluid px-md-4">
			<div class="row justify-content-center pb-5">
				<div class="col-md-12 heading-section text-center ftco-animate">
					<span class="subheading">Our</span>
					<h2 class="mb-4">Videos</h2>
					<!-- <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia</p> -->
				</div>
			</div>
			<div class="row">
				<div class="col-md-3">
					<div class="project img shadow ftco-animate d-flex justify-content-center align-items-center">
						<iframe width="420" height="345" src="https://www.youtube.com/embed/cdWrpG5yh5k" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
					</div>
				</div>
				<!--<div class="col-md-3">-->
				<!--	<div class="project img shadow ftco-animate d-flex justify-content-center align-items-center">-->
				<!--		<iframe width="4200" height="345" src="https://www.youtube.com/embed/WAYPLHgV2yg" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>-->
				<!--	</div>-->
				<!--</div>-->
				<!--<div class="col-md-3">-->
				<!--	<div class="project img shadow ftco-animate d-flex justify-content-center align-items-center">-->
				<!--		<iframe width="420" height="345" src="https://www.youtube.com/embed/8prAtMVCEMo" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>-->
				<!--	</div>-->
				<!--</div>-->
				<!--<div class="col-md-3">-->
				<!--	<div class="project img shadow ftco-animate d-flex justify-content-center align-items-center">-->
				<!--		<iframe width="4200" height="345" src="https://www.youtube.com/embed/WAYPLHgV2yg" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>-->
				<!--	</div>-->
				<!--</div>-->
				<!--<div class="col-md-3">-->
				<!--	<div class="project img shadow ftco-animate d-flex justify-content-center align-items-center">-->
				<!--		<iframe width="420" height="345" src="https://www.youtube.com/embed/8prAtMVCEMo" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>-->
				<!--	</div>-->
				<!--</div>-->
				<!--<div class="col-md-3">-->
				<!--	<div class="project img shadow ftco-animate d-flex justify-content-center align-items-center">-->
				<!--		<iframe width="4200" height="345" src="https://www.youtube.com/embed/WAYPLHgV2yg" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>-->
				<!--	</div>-->
				<!--</div>-->
				<!--<div class="col-md-3">-->
				<!--	<div class="project img shadow ftco-animate d-flex justify-content-center align-items-center">-->
				<!--		<iframe width="420" height="345" src="https://www.youtube.com/embed/8prAtMVCEMo" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>-->
				<!--	</div>-->
				<!--</div>-->
				<!--<div class="col-md-3">-->
				<!--	<div class="project img shadow ftco-animate d-flex justify-content-center align-items-center">-->
				<!--		<iframe width="4200" height="345" src="https://www.youtube.com/embed/WAYPLHgV2yg" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>-->
				<!--	</div>-->
				<!--</div>-->
				
			</div>
		</div>
	</section>
	<?php include 'footer.php'; ?>