<?php include 'header.php'; ?>
<section class="ftco-section ftco-project" id="projects-section">
		<div class="container-fluid px-md-4">
			<div class="row justify-content-center pb-5">
				<div class="col-md-12 heading-section text-center ftco-animate">
					<span class="subheading">Our</span>
					<h2 class="mb-4">Services</h2>
					<!-- <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia</p> -->
				</div>
			</div>
			<div class="row">
				<div class="col-md-3">
					<div class="project img shadow ftco-animate d-flex justify-content-center align-items-center" style="background-image: url(images/services/1.jpg);">
						<div class="overlay"></div>
						<div class="text text-center p-4">
							<h3><a href="#">Breast Diseases</a></h3>
							<span>Treatment & Surgeries</span>
						</div>
					</div>
				</div>
				<div class="col-md-3">
					<div class="project img shadow ftco-animate d-flex justify-content-center align-items-center" style="background-image: url(images/services/2.jpeg);">
						<div class="overlay"></div>
						<div class="text text-center p-4">
							<h3><a href="#">Piles Fissure </a></h3>
							<span>Fistula</span>
						</div>
					</div>
				</div>
				<div class="col-md-3">
					<div class="project img shadow ftco-animate d-flex justify-content-center align-items-center" style="background-image: url(images/services/3.png);">
						<div class="overlay"></div>
						<div class="text text-center p-4">
							<h3><a href="#">Hernia </a></h3>
							<span>Surgeries</span>
						</div>
					</div>
				</div>
				<div class="col-md-3">
					<div class="project img shadow ftco-animate d-flex justify-content-center align-items-center" style="background-image: url(images/services/4.gif);">
						<div class="overlay"></div>
						<div class="text text-center p-4">
							<h3><a href="#">Laparoscopy </a></h3>
							<span>Appendectomy</span>
						</div>
					</div>
				</div>
				<div class="col-md-3">
					<div class="project img shadow ftco-animate d-flex justify-content-center align-items-center" style="background-image: url(images/services/5.jpg);">
						<div class="overlay"></div>
						<div class="text text-center p-4">
							<h3><a href="#">Cysts &amp; Swellings</a></h3>
							<!-- <span>Web Design</span> -->
						</div>
					</div>
				</div>
				<div class="col-md-3">
					<div class="project img shadow ftco-animate d-flex justify-content-center align-items-center" style="background-image: url(images/services/6.jpg);">
						<div class="overlay"></div>
						<div class="text text-center p-4">
							<h3><a href="#">Thyroid Diseases</a></h3>
							<span>Treatments</span>
						</div>
					</div>
				</div>
				<div class="col-md-3">
					<div class="project img shadow ftco-animate d-flex justify-content-center align-items-center" style="background-image: url(images/services/7.jpg);">
						<div class="overlay"></div>
						<div class="text text-center p-4">
							<h3><a href="#">Pain Abdomen</a></h3>
							<span>Emergencies</span>
						</div>
					</div>
				</div>
				<div class="col-md-3">
					<div class="project img shadow ftco-animate d-flex justify-content-center align-items-center" style="background-image: url(images/services/8.jfif);">
						<div class="overlay"></div>
						<div class="text text-center p-4">
							<h3><a href="#">Gastric Diseases</a></h3>
							<span>Endoscopy</span>
						</div>
					</div>
				</div>
				<div class="col-md-3">
					<div class="project img shadow ftco-animate d-flex justify-content-center align-items-center" style="background-image: url(images/services/9.png);">
						<div class="overlay"></div>
						<div class="text text-center p-4">
							<h3><a href="#">Stitches</a></h3>
							<span>Trauma</span>
						</div>
					</div>
				</div>
				<div class="col-md-3">
					<div class="project img shadow ftco-animate d-flex justify-content-center align-items-center" style="background-image: url(images/services/10.jpg);">
						<div class="overlay"></div>
						<div class="text text-center p-4">
							<h3><a href="#">Advanced Treatment</a></h3>
							<span>Dressings for Burns</span>
						</div>
					</div>
				</div>
				<div class="col-md-3">
					<div class="project img shadow ftco-animate d-flex justify-content-center align-items-center" style="background-image: url(images/services/11.png);">
						<div class="overlay"></div>
						<div class="text text-center p-4">
							<h3><a href="#">Laparoscopic Hysterectomy</a></h3>
							<span>Uterun removal surgery</span>
						</div>
					</div>
				</div>
				<div class="col-md-3">
					<div class="project img shadow ftco-animate d-flex justify-content-center align-items-center" style="background-image: url(images/services/12.jpg);">
						<div class="overlay"></div>
						<div class="text text-center p-4">
							<h3><a href="#">Cancer</a></h3>
							<span>Surgeries</span>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<?php include 'footer.php'; ?>