	<?php include 'header.php'; ?>
<<section class="ftco-section testimony-section bg-primary" style="background-color: #fff!important;">
		<div class="container">
			<div class="row justify-content-center pb-5">
				<div class="col-md-12 heading-section heading-section-white text-center ftco-animate">
					<span class="subheading" style="color:deeppink!important;">Testimonies</span>
					<h2 class="mb-4" style="color:deeppink;">What patient says about?</h2>
					<!-- <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia</p> -->
				</div>
			</div>
			<div class="row ftco-animate">
				<div class="col-md-12">
					<div class="carousel-testimony owl-carousel">
						<div class="item">
							<div class="testimony-wrap py-4">
								<div class="text">
									<span class="fa fa-quote-left"></span>
									<p class="mb-4 pl-5">Doctor Shalini is very professional at her work and very committed to the treatment. She takes every pain of the patient and gives them moral support for the patient which seriously a patient requires at that time of the illness. Available at any time to the query of the patient. Simply a Doctor who determines herself for the service at 100% towards the recovery of the patient in a short time.</p>
								
										<p style="float:right;!imporant"><b>--S. Puspavathi</b></p>
									
									
								</div>
							</div>
						</div>
						<div class="item">
							<div class="testimony-wrap py-4">
								<div class="text">
									<span class="fa fa-quote-left"></span>
									<p class="mb-4 pl-5">I’m happy with Doctor explanation of my health issue and she gave me good prescription and diet. She explained everything clearly.Good patient listener, Will suggest this doctor to all. Thank you mam.</p>
									<p style="float:right;!imporant"><b>--Yellapu Satish</b> </p>
								</div>
							</div>
						</div>
						<div class="item">
							<div class="testimony-wrap py-4">
								<div class="text">
									<span class="fa fa-quote-left"></span>
									<p class="mb-4 pl-5">She is very friendly. Explain everything clearly. Good patient listener. Will suggest this doctor to all. Tq..</p>
									<p style="float:right;!imporant"><b>--Pawan.G</b></p>
								</div>
							</div>
						</div>
						<div class="item">
							<div class="testimony-wrap py-4">
								<div class="text">
									<span class="fa fa-quote-left"></span>
									<p class="mb-4 pl-5">I have consulted her for treatment of hand swelling post hospitalization. She patiently listened to whatever we have said to understand the complete medical history and suggested the right medication. After using the medication prescribed by her, swelling has been reduced.</p>
									<p style="float:right;!imporant"><b>--Verified patient</b></p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

		<?php include 'footer.php'; ?>