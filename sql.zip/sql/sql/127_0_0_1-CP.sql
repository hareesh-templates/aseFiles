-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 07, 2023 at 07:01 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `blog_3`
--
CREATE DATABASE IF NOT EXISTS `blog_3` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `blog_3`;

-- --------------------------------------------------------

--
-- Table structure for table `cat_tbl`
--
-- Error reading structure for table blog_3.cat_tbl: #1932 - Table &#039;blog_3.cat_tbl&#039; doesn&#039;t exist in engine
-- Error reading data for table blog_3.cat_tbl: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `blog_3`.`cat_tbl`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `posts_tbl`
--
-- Error reading structure for table blog_3.posts_tbl: #1932 - Table &#039;blog_3.posts_tbl&#039; doesn&#039;t exist in engine
-- Error reading data for table blog_3.posts_tbl: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `blog_3`.`posts_tbl`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `quote`
--
-- Error reading structure for table blog_3.quote: #1932 - Table &#039;blog_3.quote&#039; doesn&#039;t exist in engine
-- Error reading data for table blog_3.quote: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `blog_3`.`quote`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--
-- Error reading structure for table blog_3.settings: #1932 - Table &#039;blog_3.settings&#039; doesn&#039;t exist in engine
-- Error reading data for table blog_3.settings: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `blog_3`.`settings`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `table_admin`
--
-- Error reading structure for table blog_3.table_admin: #1932 - Table &#039;blog_3.table_admin&#039; doesn&#039;t exist in engine
-- Error reading data for table blog_3.table_admin: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `blog_3`.`table_admin`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `table_ads`
--
-- Error reading structure for table blog_3.table_ads: #1932 - Table &#039;blog_3.table_ads&#039; doesn&#039;t exist in engine
-- Error reading data for table blog_3.table_ads: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `blog_3`.`table_ads`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tbl_about`
--
-- Error reading structure for table blog_3.tbl_about: #1932 - Table &#039;blog_3.tbl_about&#039; doesn&#039;t exist in engine
-- Error reading data for table blog_3.tbl_about: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `blog_3`.`tbl_about`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tbl_resources`
--
-- Error reading structure for table blog_3.tbl_resources: #1932 - Table &#039;blog_3.tbl_resources&#039; doesn&#039;t exist in engine
-- Error reading data for table blog_3.tbl_resources: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `blog_3`.`tbl_resources`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `user_online`
--
-- Error reading structure for table blog_3.user_online: #1932 - Table &#039;blog_3.user_online&#039; doesn&#039;t exist in engine
-- Error reading data for table blog_3.user_online: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `blog_3`.`user_online`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `youtube`
--
-- Error reading structure for table blog_3.youtube: #1932 - Table &#039;blog_3.youtube&#039; doesn&#039;t exist in engine
-- Error reading data for table blog_3.youtube: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `blog_3`.`youtube`&#039; at line 1
--
-- Database: `blog_4`
--
CREATE DATABASE IF NOT EXISTS `blog_4` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `blog_4`;

-- --------------------------------------------------------

--
-- Table structure for table `category`
--
-- Error reading structure for table blog_4.category: #1932 - Table &#039;blog_4.category&#039; doesn&#039;t exist in engine
-- Error reading data for table blog_4.category: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `blog_4`.`category`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--
-- Error reading structure for table blog_4.posts: #1932 - Table &#039;blog_4.posts&#039; doesn&#039;t exist in engine
-- Error reading data for table blog_4.posts: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `blog_4`.`posts`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `post_img`
--
-- Error reading structure for table blog_4.post_img: #1932 - Table &#039;blog_4.post_img&#039; doesn&#039;t exist in engine
-- Error reading data for table blog_4.post_img: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `blog_4`.`post_img`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `site_settings`
--
-- Error reading structure for table blog_4.site_settings: #1932 - Table &#039;blog_4.site_settings&#039; doesn&#039;t exist in engine
-- Error reading data for table blog_4.site_settings: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `blog_4`.`site_settings`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `users`
--
-- Error reading structure for table blog_4.users: #1932 - Table &#039;blog_4.users&#039; doesn&#039;t exist in engine
-- Error reading data for table blog_4.users: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `blog_4`.`users`&#039; at line 1
--
-- Database: `blog_5`
--
CREATE DATABASE IF NOT EXISTS `blog_5` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `blog_5`;

-- --------------------------------------------------------

--
-- Table structure for table `banner_posts`
--
-- Error reading structure for table blog_5.banner_posts: #1932 - Table &#039;blog_5.banner_posts&#039; doesn&#039;t exist in engine
-- Error reading data for table blog_5.banner_posts: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `blog_5`.`banner_posts`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `blogs`
--
-- Error reading structure for table blog_5.blogs: #1932 - Table &#039;blog_5.blogs&#039; doesn&#039;t exist in engine
-- Error reading data for table blog_5.blogs: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `blog_5`.`blogs`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `blog_categories`
--
-- Error reading structure for table blog_5.blog_categories: #1932 - Table &#039;blog_5.blog_categories&#039; doesn&#039;t exist in engine
-- Error reading data for table blog_5.blog_categories: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `blog_5`.`blog_categories`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `editors_choice`
--
-- Error reading structure for table blog_5.editors_choice: #1932 - Table &#039;blog_5.editors_choice&#039; doesn&#039;t exist in engine
-- Error reading data for table blog_5.editors_choice: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `blog_5`.`editors_choice`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `links`
--
-- Error reading structure for table blog_5.links: #1932 - Table &#039;blog_5.links&#039; doesn&#039;t exist in engine
-- Error reading data for table blog_5.links: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `blog_5`.`links`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `membership_grouppermissions`
--
-- Error reading structure for table blog_5.membership_grouppermissions: #1932 - Table &#039;blog_5.membership_grouppermissions&#039; doesn&#039;t exist in engine
-- Error reading data for table blog_5.membership_grouppermissions: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `blog_5`.`membership_grouppermissions`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `membership_groups`
--
-- Error reading structure for table blog_5.membership_groups: #1932 - Table &#039;blog_5.membership_groups&#039; doesn&#039;t exist in engine
-- Error reading data for table blog_5.membership_groups: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `blog_5`.`membership_groups`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `membership_userpermissions`
--
-- Error reading structure for table blog_5.membership_userpermissions: #1932 - Table &#039;blog_5.membership_userpermissions&#039; doesn&#039;t exist in engine
-- Error reading data for table blog_5.membership_userpermissions: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `blog_5`.`membership_userpermissions`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `membership_userrecords`
--
-- Error reading structure for table blog_5.membership_userrecords: #1932 - Table &#039;blog_5.membership_userrecords&#039; doesn&#039;t exist in engine
-- Error reading data for table blog_5.membership_userrecords: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `blog_5`.`membership_userrecords`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `membership_users`
--
-- Error reading structure for table blog_5.membership_users: #1932 - Table &#039;blog_5.membership_users&#039; doesn&#039;t exist in engine
-- Error reading data for table blog_5.membership_users: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `blog_5`.`membership_users`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `page_hits`
--
-- Error reading structure for table blog_5.page_hits: #1932 - Table &#039;blog_5.page_hits&#039; doesn&#039;t exist in engine
-- Error reading data for table blog_5.page_hits: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `blog_5`.`page_hits`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `titles`
--
-- Error reading structure for table blog_5.titles: #1932 - Table &#039;blog_5.titles&#039; doesn&#039;t exist in engine
-- Error reading data for table blog_5.titles: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `blog_5`.`titles`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `visitor_info`
--
-- Error reading structure for table blog_5.visitor_info: #1932 - Table &#039;blog_5.visitor_info&#039; doesn&#039;t exist in engine
-- Error reading data for table blog_5.visitor_info: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `blog_5`.`visitor_info`&#039; at line 1
--
-- Database: `blog_6`
--
CREATE DATABASE IF NOT EXISTS `blog_6` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `blog_6`;

-- --------------------------------------------------------

--
-- Table structure for table `blog`
--
-- Error reading structure for table blog_6.blog: #1932 - Table &#039;blog_6.blog&#039; doesn&#039;t exist in engine
-- Error reading data for table blog_6.blog: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `blog_6`.`blog`&#039; at line 1
--
-- Database: `blog_8`
--
CREATE DATABASE IF NOT EXISTS `blog_8` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `blog_8`;

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--
-- Error reading structure for table blog_8.admin: #1932 - Table &#039;blog_8.admin&#039; doesn&#039;t exist in engine
-- Error reading data for table blog_8.admin: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `blog_8`.`admin`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--
-- Error reading structure for table blog_8.comments: #1932 - Table &#039;blog_8.comments&#039; doesn&#039;t exist in engine
-- Error reading data for table blog_8.comments: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `blog_8`.`comments`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--
-- Error reading structure for table blog_8.contacts: #1932 - Table &#039;blog_8.contacts&#039; doesn&#039;t exist in engine
-- Error reading data for table blog_8.contacts: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `blog_8`.`contacts`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--
-- Error reading structure for table blog_8.posts: #1932 - Table &#039;blog_8.posts&#039; doesn&#039;t exist in engine
-- Error reading data for table blog_8.posts: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `blog_8`.`posts`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `subscribers`
--
-- Error reading structure for table blog_8.subscribers: #1932 - Table &#039;blog_8.subscribers&#039; doesn&#039;t exist in engine
-- Error reading data for table blog_8.subscribers: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `blog_8`.`subscribers`&#039; at line 1
--
-- Database: `blog_10`
--
CREATE DATABASE IF NOT EXISTS `blog_10` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `blog_10`;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(3) NOT NULL,
  `name` text NOT NULL,
  `date` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `date`) VALUES
(1, 'General', '2018-08-06 05:45:57'),
(2, 'Unclassified', '2018-08-06 06:00:48'),
(3, 'qwerty', '2023-02-08 07:52:53');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(6) NOT NULL,
  `cat_id` int(3) NOT NULL,
  `title` varchar(255) NOT NULL,
  `text` text NOT NULL,
  `date` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `cat_id`, `title`, `text`, `date`) VALUES
(1, 2, 'Sample Title', '<p>Contrary to popular belief, <strong>Lorem Ipsum</strong> is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of \"de Finibus Bonorum et Malorum\" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, \"Lorem ipsum dolor sit amet..\", comes from a line in section 1.10.32.</p><p><br></p><p>The standard chunk of Lorem Ipsum used since the <em>1500s</em> is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from \"de Finibus Bonorum et Malorum\" by Cicero are also reproduced in their exact original form, accompanied by English versions from the 1914 translation by H. Rackham.</p>', '2018-08-06 07:59:45'),
(4, 2, 'Lorem ipsum', '<p class=\"ql-align-justify\">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p><p class=\"ql-align-justify\">Sed ut perspiciatis, unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam eaque ipsa, quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt, explicabo. Nemo enim ipsam voluptatem, quia voluptas sit, aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos, qui ratione voluptatem sequi nesciunt, neque porro quisquam est, qui dolorem ipsum, quia dolor sit amet consectetur adipisci[ng] velit, sed quia non-numquam [do] eius modi tempora inci[di]dunt, ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit, qui in ea voluptate velit esse, quam nihil molestiae consequatur, vel illum, qui dolorem eum fugiat, quo voluptas nulla pariatur?</p><p class=\"ql-align-justify\">At vero eos et accusamus et iusto odio dignissimos ducimus, qui blanditiis praesentium voluptatum deleniti atque corrupti, quos dolores et quas molestias excepturi sint, obcaecati cupiditate non-provident, similique sunt in culpa, qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio, cumque nihil impedit, quo minus id, quod maxime placeat, facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet, ut et voluptates repudiandae sint et molestiae non-recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat…</p>', '2018-08-06 08:24:19'),
(5, 1, 'asdf', '<p>asdf <a href=\"https://www.google.com/search?rlz=1C1CHZN_enIN1029IN1029&amp;q=molleti+hareesh&amp;spell=1&amp;sa=X&amp;ved=2ahUKEwjV96fApIX9AhUI9XMBHSx8CIwQBSgAegQICBAB&amp;biw=1536&amp;bih=714&amp;dpr=1.25\" target=\"_blank\">Hareesh </a>qwerty</p>', '2023-02-08 08:07:05');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- Database: `blog_admin_db`
--
CREATE DATABASE IF NOT EXISTS `blog_admin_db` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `blog_admin_db`;

-- --------------------------------------------------------

--
-- Table structure for table `banner_posts`
--
-- Error reading structure for table blog_admin_db.banner_posts: #1932 - Table &#039;blog_admin_db.banner_posts&#039; doesn&#039;t exist in engine
-- Error reading data for table blog_admin_db.banner_posts: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `blog_admin_db`.`banner_posts`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `blogs`
--
-- Error reading structure for table blog_admin_db.blogs: #1932 - Table &#039;blog_admin_db.blogs&#039; doesn&#039;t exist in engine
-- Error reading data for table blog_admin_db.blogs: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `blog_admin_db`.`blogs`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `blog_categories`
--
-- Error reading structure for table blog_admin_db.blog_categories: #1932 - Table &#039;blog_admin_db.blog_categories&#039; doesn&#039;t exist in engine
-- Error reading data for table blog_admin_db.blog_categories: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `blog_admin_db`.`blog_categories`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `editors_choice`
--
-- Error reading structure for table blog_admin_db.editors_choice: #1932 - Table &#039;blog_admin_db.editors_choice&#039; doesn&#039;t exist in engine
-- Error reading data for table blog_admin_db.editors_choice: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `blog_admin_db`.`editors_choice`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `links`
--
-- Error reading structure for table blog_admin_db.links: #1932 - Table &#039;blog_admin_db.links&#039; doesn&#039;t exist in engine
-- Error reading data for table blog_admin_db.links: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `blog_admin_db`.`links`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `membership_grouppermissions`
--
-- Error reading structure for table blog_admin_db.membership_grouppermissions: #1932 - Table &#039;blog_admin_db.membership_grouppermissions&#039; doesn&#039;t exist in engine
-- Error reading data for table blog_admin_db.membership_grouppermissions: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `blog_admin_db`.`membership_grouppermissions`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `membership_groups`
--
-- Error reading structure for table blog_admin_db.membership_groups: #1932 - Table &#039;blog_admin_db.membership_groups&#039; doesn&#039;t exist in engine
-- Error reading data for table blog_admin_db.membership_groups: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `blog_admin_db`.`membership_groups`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `membership_userpermissions`
--
-- Error reading structure for table blog_admin_db.membership_userpermissions: #1932 - Table &#039;blog_admin_db.membership_userpermissions&#039; doesn&#039;t exist in engine
-- Error reading data for table blog_admin_db.membership_userpermissions: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `blog_admin_db`.`membership_userpermissions`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `membership_userrecords`
--
-- Error reading structure for table blog_admin_db.membership_userrecords: #1932 - Table &#039;blog_admin_db.membership_userrecords&#039; doesn&#039;t exist in engine
-- Error reading data for table blog_admin_db.membership_userrecords: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `blog_admin_db`.`membership_userrecords`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `membership_users`
--
-- Error reading structure for table blog_admin_db.membership_users: #1932 - Table &#039;blog_admin_db.membership_users&#039; doesn&#039;t exist in engine
-- Error reading data for table blog_admin_db.membership_users: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `blog_admin_db`.`membership_users`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `page_hits`
--
-- Error reading structure for table blog_admin_db.page_hits: #1932 - Table &#039;blog_admin_db.page_hits&#039; doesn&#039;t exist in engine
-- Error reading data for table blog_admin_db.page_hits: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `blog_admin_db`.`page_hits`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `titles`
--
-- Error reading structure for table blog_admin_db.titles: #1932 - Table &#039;blog_admin_db.titles&#039; doesn&#039;t exist in engine
-- Error reading data for table blog_admin_db.titles: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `blog_admin_db`.`titles`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `visitor_info`
--
-- Error reading structure for table blog_admin_db.visitor_info: #1932 - Table &#039;blog_admin_db.visitor_info&#039; doesn&#039;t exist in engine
-- Error reading data for table blog_admin_db.visitor_info: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `blog_admin_db`.`visitor_info`&#039; at line 1
--
-- Database: `blog_db`
--
CREATE DATABASE IF NOT EXISTS `blog_db` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `blog_db`;

-- --------------------------------------------------------

--
-- Table structure for table `category`
--
-- Error reading structure for table blog_db.category: #1932 - Table &#039;blog_db.category&#039; doesn&#039;t exist in engine
-- Error reading data for table blog_db.category: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `blog_db`.`category`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--
-- Error reading structure for table blog_db.posts: #1932 - Table &#039;blog_db.posts&#039; doesn&#039;t exist in engine
-- Error reading data for table blog_db.posts: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `blog_db`.`posts`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `post_img`
--
-- Error reading structure for table blog_db.post_img: #1932 - Table &#039;blog_db.post_img&#039; doesn&#039;t exist in engine
-- Error reading data for table blog_db.post_img: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `blog_db`.`post_img`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `site_settings`
--
-- Error reading structure for table blog_db.site_settings: #1932 - Table &#039;blog_db.site_settings&#039; doesn&#039;t exist in engine
-- Error reading data for table blog_db.site_settings: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `blog_db`.`site_settings`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `users`
--
-- Error reading structure for table blog_db.users: #1932 - Table &#039;blog_db.users&#039; doesn&#039;t exist in engine
-- Error reading data for table blog_db.users: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `blog_db`.`users`&#039; at line 1
--
-- Database: `blog_db_2`
--
CREATE DATABASE IF NOT EXISTS `blog_db_2` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `blog_db_2`;

-- --------------------------------------------------------

--
-- Table structure for table `blog`
--
-- Error reading structure for table blog_db_2.blog: #1932 - Table &#039;blog_db_2.blog&#039; doesn&#039;t exist in engine
-- Error reading data for table blog_db_2.blog: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `blog_db_2`.`blog`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `login`
--
-- Error reading structure for table blog_db_2.login: #1932 - Table &#039;blog_db_2.login&#039; doesn&#039;t exist in engine
-- Error reading data for table blog_db_2.login: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `blog_db_2`.`login`&#039; at line 1
--
-- Database: `buspassdb`
--
CREATE DATABASE IF NOT EXISTS `buspassdb` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `buspassdb`;

-- --------------------------------------------------------

--
-- Table structure for table `tbladmin`
--

CREATE TABLE `tbladmin` (
  `ID` int(10) NOT NULL,
  `AdminName` varchar(120) DEFAULT NULL,
  `UserName` varchar(120) DEFAULT NULL,
  `MobileNumber` bigint(10) DEFAULT NULL,
  `Email` varchar(120) DEFAULT NULL,
  `Password` varchar(200) DEFAULT NULL,
  `AdminRegdate` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbladmin`
--

INSERT INTO `tbladmin` (`ID`, `AdminName`, `UserName`, `MobileNumber`, `Email`, `Password`, `AdminRegdate`) VALUES
(1, 'Admin', 'admin', 1234567891, 'adminuser@gmail.com', 'f925916e2754e5e03f75dd58a5733251', '2020-04-14 06:44:27');

-- --------------------------------------------------------

--
-- Table structure for table `tblcategory`
--

CREATE TABLE `tblcategory` (
  `ID` int(10) NOT NULL,
  `CategoryName` varchar(200) DEFAULT NULL,
  `CreationDate` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblcategory`
--

INSERT INTO `tblcategory` (`ID`, `CategoryName`, `CreationDate`) VALUES
(8, 'AC Bus', '2021-07-04 14:27:53'),
(9, 'Non AC Bus', '2021-07-04 14:28:32'),
(10, 'Volvo Bus', '2021-07-04 14:28:47'),
(11, 'Delux Bus', '2021-07-04 14:29:01');

-- --------------------------------------------------------

--
-- Table structure for table `tblcontact`
--

CREATE TABLE `tblcontact` (
  `ID` int(10) NOT NULL,
  `Name` varchar(200) DEFAULT NULL,
  `Email` varchar(200) DEFAULT NULL,
  `Message` mediumtext DEFAULT NULL,
  `EnquiryDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `IsRead` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblcontact`
--

INSERT INTO `tblcontact` (`ID`, `Name`, `Email`, `Message`, `EnquiryDate`, `IsRead`) VALUES
(1, 'Kiran', 'kran@gmail.com', 'cost of volvo place pritampura to dwarka', '2021-07-05 07:26:24', 1),
(2, 'Anuj', 'AKKK@GMAIL.COM', 'This is for testing.', '2021-07-11 08:55:16', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tblpage`
--

CREATE TABLE `tblpage` (
  `ID` int(10) NOT NULL,
  `PageType` varchar(200) DEFAULT NULL,
  `PageTitle` varchar(200) DEFAULT NULL,
  `PageDescription` mediumtext DEFAULT NULL,
  `Email` varchar(200) DEFAULT NULL,
  `MobileNumber` bigint(10) DEFAULT NULL,
  `UpdationDate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblpage`
--

INSERT INTO `tblpage` (`ID`, `PageType`, `PageTitle`, `PageDescription`, `Email`, `MobileNumber`, `UpdationDate`) VALUES
(1, 'aboutus', 'About us', '<font color=\"#747474\" face=\"Roboto, sans-serif, arial\"><span style=\"font-size: 13px;\"><b>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</b></span></font><br>', NULL, NULL, '2021-07-11 08:54:33'),
(2, 'contactus', 'Contact Us', '                #890 CFG Apartment, Mayur Vihar, Delhi-India.', 'infotest@gmail.com', 4654789799, '2021-07-11 08:54:50');

-- --------------------------------------------------------

--
-- Table structure for table `tblpass`
--

CREATE TABLE `tblpass` (
  `ID` int(10) NOT NULL,
  `PassNumber` varchar(200) DEFAULT NULL,
  `FullName` varchar(200) DEFAULT NULL,
  `ProfileImage` varchar(200) DEFAULT NULL,
  `ContactNumber` bigint(10) DEFAULT NULL,
  `Email` varchar(200) DEFAULT NULL,
  `IdentityType` varchar(200) DEFAULT NULL,
  `IdentityCardno` varchar(200) DEFAULT NULL,
  `Category` varchar(100) DEFAULT NULL,
  `Source` varchar(200) DEFAULT NULL,
  `Destination` varchar(200) DEFAULT NULL,
  `FromDate` varchar(200) DEFAULT NULL,
  `ToDate` varchar(200) DEFAULT NULL,
  `Cost` decimal(10,0) DEFAULT NULL,
  `PasscreationDate` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblpass`
--

INSERT INTO `tblpass` (`ID`, `PassNumber`, `FullName`, `ProfileImage`, `ContactNumber`, `Email`, `IdentityType`, `IdentityCardno`, `Category`, `Source`, `Destination`, `FromDate`, `ToDate`, `Cost`, `PasscreationDate`) VALUES
(1, '286529906', 'Yogesh Kumar', '779b7513263ef185b6d094af290ef5401625471444.png', 4654464646, 'yogi@gmail.com', 'Adhar Card', 'AD-122346', 'Delux Bus', 'dfg', 'kgf', '2020-04-14', '2020-05-14', '900', '2020-04-14 11:47:03'),
(2, '915773340', 'Suresh Khanna', '779b7513263ef185b6d094af290ef5401625471444.png', 9879878978, 'suresh@gmail.com', 'Any Other Govt Issued Doc', 'KTI-896567', 'Delux Bus', NULL, NULL, '2020-04-14', '2020-07-31', '900', '2020-04-13 11:50:15'),
(3, '884595667', 'Anuj kumar', '779b7513263ef185b6d094af290ef5401625471444.png', 1234567890, 'phpgurukulofficial@Gmail.com', 'Voter Card', '5235252', 'Delux Bus', 'Pritampura', 'Dwarka', '2020-04-16', '2020-04-19', '600', '2020-04-16 02:38:27'),
(4, '210712236', 'Abir Singh', 'e76de47f621d84adbab3266e3239baee1625460898.png', 4654646546, 'abir@gmail.com', 'Voter Card', '5646465', 'Non AC Bus', 'abc', 'dbc', '2021-07-05', '2021-07-16', '900', '2021-07-04 15:01:38'),
(5, '474965545', 'Augustya', '779b7513263ef185b6d094af290ef5401625471444.png', 6546465464, 'aug@gmail.com', 'Student Card', '789456', 'Delux Bus', 'Delhi', 'Meerut', '2021-07-05', '2021-07-31', '1800', '2021-07-05 07:50:44'),
(6, '681924385', 'Anuj kumar', 'ea3dc39ca0b2f6b5f17abddec1f0e9a41625993624.png', 1234569870, 'ak@test.com', 'Driving License', 'GGGGGGHGH2423423432', 'Delux Bus', 'Laxmi Nagar', 'Central Secretariat', '2021-07-15', '2021-07-30', '500', '2021-07-11 08:53:44');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbladmin`
--
ALTER TABLE `tbladmin`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tblcategory`
--
ALTER TABLE `tblcategory`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tblcontact`
--
ALTER TABLE `tblcontact`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tblpage`
--
ALTER TABLE `tblpage`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tblpass`
--
ALTER TABLE `tblpass`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbladmin`
--
ALTER TABLE `tbladmin`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tblcategory`
--
ALTER TABLE `tblcategory`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `tblcontact`
--
ALTER TABLE `tblcontact`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tblpage`
--
ALTER TABLE `tblpage`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tblpass`
--
ALTER TABLE `tblpass`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- Database: `construction_monitering-systems`
--
CREATE DATABASE IF NOT EXISTS `construction_monitering-systems` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `construction_monitering-systems`;

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--
-- Error reading structure for table construction_monitering-systems.admin: #1932 - Table &#039;construction_monitering-systems.admin&#039; doesn&#039;t exist in engine
-- Error reading data for table construction_monitering-systems.admin: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `construction_monitering-systems`.`admin`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `auto`
--
-- Error reading structure for table construction_monitering-systems.auto: #1932 - Table &#039;construction_monitering-systems.auto&#039; doesn&#039;t exist in engine
-- Error reading data for table construction_monitering-systems.auto: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `construction_monitering-systems`.`auto`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `borrowed_tools`
--
-- Error reading structure for table construction_monitering-systems.borrowed_tools: #1932 - Table &#039;construction_monitering-systems.borrowed_tools&#039; doesn&#039;t exist in engine
-- Error reading data for table construction_monitering-systems.borrowed_tools: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `construction_monitering-systems`.`borrowed_tools`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--
-- Error reading structure for table construction_monitering-systems.employees: #1932 - Table &#039;construction_monitering-systems.employees&#039; doesn&#039;t exist in engine
-- Error reading data for table construction_monitering-systems.employees: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `construction_monitering-systems`.`employees`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `equipments`
--
-- Error reading structure for table construction_monitering-systems.equipments: #1932 - Table &#039;construction_monitering-systems.equipments&#039; doesn&#039;t exist in engine
-- Error reading data for table construction_monitering-systems.equipments: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `construction_monitering-systems`.`equipments`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `equip_mapping`
--
-- Error reading structure for table construction_monitering-systems.equip_mapping: #1932 - Table &#039;construction_monitering-systems.equip_mapping&#039; doesn&#039;t exist in engine
-- Error reading data for table construction_monitering-systems.equip_mapping: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `construction_monitering-systems`.`equip_mapping`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `location`
--
-- Error reading structure for table construction_monitering-systems.location: #1932 - Table &#039;construction_monitering-systems.location&#039; doesn&#039;t exist in engine
-- Error reading data for table construction_monitering-systems.location: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `construction_monitering-systems`.`location`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--
-- Error reading structure for table construction_monitering-systems.logs: #1932 - Table &#039;construction_monitering-systems.logs&#039; doesn&#039;t exist in engine
-- Error reading data for table construction_monitering-systems.logs: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `construction_monitering-systems`.`logs`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `outsourcing`
--
-- Error reading structure for table construction_monitering-systems.outsourcing: #1932 - Table &#039;construction_monitering-systems.outsourcing&#039; doesn&#039;t exist in engine
-- Error reading data for table construction_monitering-systems.outsourcing: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `construction_monitering-systems`.`outsourcing`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `outsourcing_tools`
--
-- Error reading structure for table construction_monitering-systems.outsourcing_tools: #1932 - Table &#039;construction_monitering-systems.outsourcing_tools&#039; doesn&#039;t exist in engine
-- Error reading data for table construction_monitering-systems.outsourcing_tools: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `construction_monitering-systems`.`outsourcing_tools`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `temp`
--
-- Error reading structure for table construction_monitering-systems.temp: #1932 - Table &#039;construction_monitering-systems.temp&#039; doesn&#039;t exist in engine
-- Error reading data for table construction_monitering-systems.temp: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `construction_monitering-systems`.`temp`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `temp1`
--
-- Error reading structure for table construction_monitering-systems.temp1: #1932 - Table &#039;construction_monitering-systems.temp1&#039; doesn&#039;t exist in engine
-- Error reading data for table construction_monitering-systems.temp1: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `construction_monitering-systems`.`temp1`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tools`
--
-- Error reading structure for table construction_monitering-systems.tools: #1932 - Table &#039;construction_monitering-systems.tools&#039; doesn&#039;t exist in engine
-- Error reading data for table construction_monitering-systems.tools: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `construction_monitering-systems`.`tools`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `transfered_equipment`
--
-- Error reading structure for table construction_monitering-systems.transfered_equipment: #1932 - Table &#039;construction_monitering-systems.transfered_equipment&#039; doesn&#039;t exist in engine
-- Error reading data for table construction_monitering-systems.transfered_equipment: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `construction_monitering-systems`.`transfered_equipment`&#039; at line 1
--
-- Database: `construction_real-estate`
--
CREATE DATABASE IF NOT EXISTS `construction_real-estate` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `construction_real-estate`;

-- --------------------------------------------------------

--
-- Table structure for table `agent`
--

CREATE TABLE `agent` (
  `agent_id` int(10) NOT NULL,
  `agent_name` varchar(150) NOT NULL,
  `agent_address` varchar(250) NOT NULL,
  `agent_contact` varchar(20) NOT NULL,
  `agent_email` varchar(25) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `agent`
--

INSERT INTO `agent` (`agent_id`, `agent_name`, `agent_address`, `agent_contact`, `agent_email`) VALUES
(1, 'Samuel A Waldey', '95, Henry Street, Indented Head, Victoria', '03 5321 1053', 'samuel@gmail.com'),
(2, 'Mrs Eden Battarbee', '25 Main Streat, Beaumonts', '08 8762 5308', 'eden@gmail.com'),
(3, 'Tyson A Salvado', '15 Ghost Hill Road, ST Marys South', '02 4728 5284', 'tyson@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `properties`
--

CREATE TABLE `properties` (
  `property_id` int(10) NOT NULL,
  `property_title` varchar(150) DEFAULT NULL,
  `property_details` text DEFAULT NULL,
  `delivery_type` varchar(20) DEFAULT NULL,
  `availablility` int(5) DEFAULT NULL,
  `price` float DEFAULT NULL,
  `property_address` varchar(200) DEFAULT NULL,
  `property_img` varchar(200) DEFAULT NULL,
  `bed_room` int(5) DEFAULT NULL,
  `liv_room` int(5) DEFAULT NULL,
  `parking` int(5) DEFAULT NULL,
  `kitchen` int(5) DEFAULT NULL,
  `utility` varchar(100) DEFAULT NULL,
  `property_type` varchar(20) DEFAULT NULL,
  `floor_space` varchar(20) DEFAULT NULL,
  `agent_id` int(10) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `properties`
--

INSERT INTO `properties` (`property_id`, `property_title`, `property_details`, `delivery_type`, `availablility`, `price`, `property_address`, `property_img`, `bed_room`, `liv_room`, `parking`, `kitchen`, `utility`, `property_type`, `floor_space`, `agent_id`) VALUES
(1, 'Apartment', 'Efficiently unleash cross-media information without cross-media value. Quickly maximize timely deliverables for real-time schemas. Dramatically maintain clicks-and-mortar solutions without functional solutions. <br> <br>\r\n\r\nCompletely synergize resource sucking relationships via premier niche markets. Professionally cultivate one-to-one customer service with robust ideas. Dynamically innovate resource-leveling customer service for state of the art customer service', 'Sale', 0, 150000, '11 Ghost Hill Road', 'images/properties/bed-1-1.jpg', 3, 2, 1, 1, 'Electricity, Gas, Water', 'Apartment', '1600 X 1400', 3),
(2, 'Apartment For Rent', 'Efficiently unleash cross-media information without cross-media value. Quickly maximize timely deliverables for real-time schemas. Dramatically maintain clicks-and-mortar solutions without functional solutions. <br> <br>\r\n\r\nCompletely synergize resource sucking relationships via premier niche markets. Professionally cultivate one-to-one customer service with robust ideas. Dynamically innovate resource-leveling customer service for state of the art customer service', 'Rent', 0, 7000, '28 Ghost Hill Road', 'images/properties/bed-2-1.jpg', 3, 2, 1, 1, 'Electricity, Gas, Water', 'Apartment', '1650 X 1350', 3),
(3, 'Apartment For Sale', 'Efficiently unleash cross-media information without cross-media value. Quickly maximize timely deliverables for real-time schemas. Dramatically maintain clicks-and-mortar solutions without functional solutions. <br> <br>\r\n\r\nCompletely synergize resource sucking relationships via premier niche markets. Professionally cultivate one-to-one customer service with robust ideas. Dynamically innovate resource-leveling customer service for state of the art customer service', 'Sale', 1, 80000, '77 Ghost Hill Road', 'images/properties/bed-3-1.jpg', 3, 2, 1, 1, 'Electricity, Gas, Water', 'Apartment', '1500 X 1300', 3),
(4, 'Office-Space for Sale', 'Efficiently unleash cross-media information without cross-media value. Quickly maximize timely deliverables for real-time schemas. Dramatically maintain clicks-and-mortar solutions without functional solutions. <br> <br>\r\n\r\nCompletely synergize resource sucking relationships via premier niche markets. Professionally cultivate one-to-one customer service with robust ideas. Dynamically innovate resource-leveling customer service for state of the art customer service', 'Sale', 0, 100000, '15 Main Streat, Beaumonts', 'images/properties/liv-4-1.jpg', 2, 3, 1, 1, 'Electricity, Gas, Water, Internet', 'Office-Space', '1650 X 1350', 2),
(5, 'Office-Space for Rent', 'Efficiently unleash cross-media information without cross-media value. Quickly maximize timely deliverables for real-time schemas. Dramatically maintain clicks-and-mortar solutions without functional solutions. <br> <br>\r\n\r\nCompletely synergize resource sucking relationships via premier niche markets. Professionally cultivate one-to-one customer service with robust ideas. Dynamically innovate resource-leveling customer service for state of the art customer service', 'Rent', 0, 7500, '91 Main Streat, Beaumonts', 'images/properties/liv-5-1.jpg', 2, 2, 1, 1, 'Electricity, Gas, Water, Internet', 'Office-Space', '1650 X 1350', 2),
(6, 'Office-Space for Rent', 'Efficiently unleash cross-media information without cross-media value. Quickly maximize timely deliverables for real-time schemas. Dramatically maintain clicks-and-mortar solutions without functional solutions. <br> <br>\r\n\r\nCompletely synergize resource sucking relationships via premier niche markets. Professionally cultivate one-to-one customer service with robust ideas. Dynamically innovate resource-leveling customer service for state of the art customer service', 'Rent', 1, 6000, '93 Main Streat, Beaumonts', 'images/properties/liv-6-1.jpg', 2, 2, 1, 1, 'Electricity, Gas, Water, Internet', 'Office-Space', '1450 X 1250', 1),
(7, 'Building for Sale', 'Efficiently unleash cross-media information without cross-media value. Quickly maximize timely deliverables for real-time schemas. Dramatically maintain clicks-and-mortar solutions without functional solutions. <br> <br>\r\n\r\nCompletely synergize resource sucking relationships via premier niche markets. Professionally cultivate one-to-one customer service with robust ideas. Dynamically innovate resource-leveling customer service for state of the art customer service', 'Sale', 0, 1750000, '65, Henry Street, Indented Head, Victoria', 'images/properties/bed-7-1.jpg', 3, 2, 1, 1, 'Electricity, Gas, Water', 'Building', '1650 X 1350', 2);

-- --------------------------------------------------------

--
-- Table structure for table `property_image`
--

CREATE TABLE `property_image` (
  `property_images` varchar(200) DEFAULT NULL,
  `property_id` int(10) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `property_image`
--

INSERT INTO `property_image` (`property_images`, `property_id`) VALUES
('images/properties/bed-1-1.jpg', 1),
('images/properties/bed-1-2.jpg', 1),
('images/properties/liv-1-1.jpg', 1),
('images/properties/liv-1-2.jpg', 1),
('images/properties/kitchen-1-1.jpg', 1),
('images/properties/bed-1-1.jpg', 2),
('images/properties/bed-1-2.jpg', 2),
('images/properties/liv-1-1.jpg', 2),
('images/properties/liv-1-2.jpg', 2),
('images/properties/kitchen-1-1.jpg', 2),
('images/properties/bed-2-1.jpg', 2),
('images/properties/bed-2-2.jpg', 2),
('images/properties/liv-2-1.jpg', 2),
('images/properties/liv-2-2.jpg', 2),
('images/properties/kitchen-2-1.jpg', 2),
('images/properties/bed-3-1.jpg', 3),
('images/properties/bed-3-2.jpg', 3),
('images/properties/liv-3-1.jpg', 3),
('images/properties/liv-3-2.jpg', 3),
('images/properties/kitchen-3-1.jpg', 3),
('images/properties/bed-4-1.jpg', 4),
('images/properties/bed-4-2.jpg', 4),
('images/properties/liv-4-1.jpg', 4),
('images/properties/liv-4-2.jpg', 4),
('images/properties/kitchen-4-1.jpg', 4),
('images/properties/bed-5-1.jpg', 5),
('images/properties/bed-5-2.jpg', 5),
('images/properties/liv-5-1.jpg', 5),
('images/properties/liv-5-2.jpg', 5),
('images/properties/kitchen-5-1.jpg', 5),
('images/properties/bed-6-1.jpg', 6),
('images/properties/bed-6-2.jpg', 6),
('images/properties/liv-6-1.jpg', 6),
('images/properties/liv-6-2.jpg', 6),
('images/properties/kitchen-6-1.jpg', 6),
('images/properties/bed-7-1.jpg', 7),
('images/properties/bed-7-2.jpg', 7),
('images/properties/liv-7-1.jpg', 7),
('images/properties/liv-7-2.jpg', 7),
('images/properties/kitchen-7-1.jpg', 7);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `agent`
--
ALTER TABLE `agent`
  ADD PRIMARY KEY (`agent_id`);

--
-- Indexes for table `properties`
--
ALTER TABLE `properties`
  ADD PRIMARY KEY (`property_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `agent`
--
ALTER TABLE `agent`
  MODIFY `agent_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `properties`
--
ALTER TABLE `properties`
  MODIFY `property_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- Database: `construction_real-estate_sales_inventory-system`
--
CREATE DATABASE IF NOT EXISTS `construction_real-estate_sales_inventory-system` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `construction_real-estate_sales_inventory-system`;

-- --------------------------------------------------------

--
-- Table structure for table `category`
--
-- Error reading structure for table construction_real-estate_sales_inventory-system.category: #1932 - Table &#039;construction_real-estate_sales_inventory-system.category&#039; doesn&#039;t exist in engine
-- Error reading data for table construction_real-estate_sales_inventory-system.category: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `construction_real-estate_sales_inventory-system`.`category`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--
-- Error reading structure for table construction_real-estate_sales_inventory-system.customer: #1932 - Table &#039;construction_real-estate_sales_inventory-system.customer&#039; doesn&#039;t exist in engine
-- Error reading data for table construction_real-estate_sales_inventory-system.customer: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `construction_real-estate_sales_inventory-system`.`customer`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--
-- Error reading structure for table construction_real-estate_sales_inventory-system.employee: #1932 - Table &#039;construction_real-estate_sales_inventory-system.employee&#039; doesn&#039;t exist in engine
-- Error reading data for table construction_real-estate_sales_inventory-system.employee: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `construction_real-estate_sales_inventory-system`.`employee`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `job`
--
-- Error reading structure for table construction_real-estate_sales_inventory-system.job: #1932 - Table &#039;construction_real-estate_sales_inventory-system.job&#039; doesn&#039;t exist in engine
-- Error reading data for table construction_real-estate_sales_inventory-system.job: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `construction_real-estate_sales_inventory-system`.`job`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `location`
--
-- Error reading structure for table construction_real-estate_sales_inventory-system.location: #1932 - Table &#039;construction_real-estate_sales_inventory-system.location&#039; doesn&#039;t exist in engine
-- Error reading data for table construction_real-estate_sales_inventory-system.location: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `construction_real-estate_sales_inventory-system`.`location`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `manager`
--
-- Error reading structure for table construction_real-estate_sales_inventory-system.manager: #1932 - Table &#039;construction_real-estate_sales_inventory-system.manager&#039; doesn&#039;t exist in engine
-- Error reading data for table construction_real-estate_sales_inventory-system.manager: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `construction_real-estate_sales_inventory-system`.`manager`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `product`
--
-- Error reading structure for table construction_real-estate_sales_inventory-system.product: #1932 - Table &#039;construction_real-estate_sales_inventory-system.product&#039; doesn&#039;t exist in engine
-- Error reading data for table construction_real-estate_sales_inventory-system.product: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `construction_real-estate_sales_inventory-system`.`product`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `supplier`
--
-- Error reading structure for table construction_real-estate_sales_inventory-system.supplier: #1932 - Table &#039;construction_real-estate_sales_inventory-system.supplier&#039; doesn&#039;t exist in engine
-- Error reading data for table construction_real-estate_sales_inventory-system.supplier: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `construction_real-estate_sales_inventory-system`.`supplier`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `transaction`
--
-- Error reading structure for table construction_real-estate_sales_inventory-system.transaction: #1932 - Table &#039;construction_real-estate_sales_inventory-system.transaction&#039; doesn&#039;t exist in engine
-- Error reading data for table construction_real-estate_sales_inventory-system.transaction: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `construction_real-estate_sales_inventory-system`.`transaction`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `transaction_details`
--
-- Error reading structure for table construction_real-estate_sales_inventory-system.transaction_details: #1932 - Table &#039;construction_real-estate_sales_inventory-system.transaction_details&#039; doesn&#039;t exist in engine
-- Error reading data for table construction_real-estate_sales_inventory-system.transaction_details: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `construction_real-estate_sales_inventory-system`.`transaction_details`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `type`
--
-- Error reading structure for table construction_real-estate_sales_inventory-system.type: #1932 - Table &#039;construction_real-estate_sales_inventory-system.type&#039; doesn&#039;t exist in engine
-- Error reading data for table construction_real-estate_sales_inventory-system.type: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `construction_real-estate_sales_inventory-system`.`type`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `users`
--
-- Error reading structure for table construction_real-estate_sales_inventory-system.users: #1932 - Table &#039;construction_real-estate_sales_inventory-system.users&#039; doesn&#039;t exist in engine
-- Error reading data for table construction_real-estate_sales_inventory-system.users: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `construction_real-estate_sales_inventory-system`.`users`&#039; at line 1
--
-- Database: `contact_db`
--
CREATE DATABASE IF NOT EXISTS `contact_db` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `contact_db`;

-- --------------------------------------------------------

--
-- Table structure for table `contact_form`
--
-- Error reading structure for table contact_db.contact_form: #1932 - Table &#039;contact_db.contact_form&#039; doesn&#039;t exist in engine
-- Error reading data for table contact_db.contact_form: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `contact_db`.`contact_form`&#039; at line 1
--
-- Database: `dental_clinic`
--
CREATE DATABASE IF NOT EXISTS `dental_clinic` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `dental_clinic`;

-- --------------------------------------------------------

--
-- Table structure for table `contact_form`
--
-- Error reading structure for table dental_clinic.contact_form: #1932 - Table &#039;dental_clinic.contact_form&#039; doesn&#039;t exist in engine
-- Error reading data for table dental_clinic.contact_form: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `dental_clinic`.`contact_form`&#039; at line 1
--
-- Database: `dental_clinic2`
--
CREATE DATABASE IF NOT EXISTS `dental_clinic2` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `dental_clinic2`;

-- --------------------------------------------------------

--
-- Table structure for table `adminreg`
--
-- Error reading structure for table dental_clinic2.adminreg: #1932 - Table &#039;dental_clinic2.adminreg&#039; doesn&#039;t exist in engine
-- Error reading data for table dental_clinic2.adminreg: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `dental_clinic2`.`adminreg`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `appo`
--
-- Error reading structure for table dental_clinic2.appo: #1932 - Table &#039;dental_clinic2.appo&#039; doesn&#039;t exist in engine
-- Error reading data for table dental_clinic2.appo: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `dental_clinic2`.`appo`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `appointement`
--
-- Error reading structure for table dental_clinic2.appointement: #1932 - Table &#039;dental_clinic2.appointement&#039; doesn&#039;t exist in engine
-- Error reading data for table dental_clinic2.appointement: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `dental_clinic2`.`appointement`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `clinic`
--
-- Error reading structure for table dental_clinic2.clinic: #1932 - Table &#039;dental_clinic2.clinic&#039; doesn&#039;t exist in engine
-- Error reading data for table dental_clinic2.clinic: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `dental_clinic2`.`clinic`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `dentalcode`
--
-- Error reading structure for table dental_clinic2.dentalcode: #1932 - Table &#039;dental_clinic2.dentalcode&#039; doesn&#039;t exist in engine
-- Error reading data for table dental_clinic2.dentalcode: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `dental_clinic2`.`dentalcode`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `dentist`
--
-- Error reading structure for table dental_clinic2.dentist: #1932 - Table &#039;dental_clinic2.dentist&#039; doesn&#039;t exist in engine
-- Error reading data for table dental_clinic2.dentist: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `dental_clinic2`.`dentist`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `signup`
--
-- Error reading structure for table dental_clinic2.signup: #1932 - Table &#039;dental_clinic2.signup&#039; doesn&#039;t exist in engine
-- Error reading data for table dental_clinic2.signup: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `dental_clinic2`.`signup`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--
-- Error reading structure for table dental_clinic2.staff: #1932 - Table &#039;dental_clinic2.staff&#039; doesn&#039;t exist in engine
-- Error reading data for table dental_clinic2.staff: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `dental_clinic2`.`staff`&#039; at line 1
--
-- Database: `e-commerce_bookstoredb`
--
CREATE DATABASE IF NOT EXISTS `e-commerce_bookstoredb` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `e-commerce_bookstoredb`;

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--
-- Error reading structure for table e-commerce_bookstoredb.admin: #1932 - Table &#039;e-commerce_bookstoredb.admin&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_bookstoredb.admin: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_bookstoredb`.`admin`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `books`
--
-- Error reading structure for table e-commerce_bookstoredb.books: #1932 - Table &#039;e-commerce_bookstoredb.books&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_bookstoredb.books: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_bookstoredb`.`books`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--
-- Error reading structure for table e-commerce_bookstoredb.customers: #1932 - Table &#039;e-commerce_bookstoredb.customers&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_bookstoredb.customers: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_bookstoredb`.`customers`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--
-- Error reading structure for table e-commerce_bookstoredb.orders: #1932 - Table &#039;e-commerce_bookstoredb.orders&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_bookstoredb.orders: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_bookstoredb`.`orders`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--
-- Error reading structure for table e-commerce_bookstoredb.order_items: #1932 - Table &#039;e-commerce_bookstoredb.order_items&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_bookstoredb.order_items: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_bookstoredb`.`order_items`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `publisher`
--
-- Error reading structure for table e-commerce_bookstoredb.publisher: #1932 - Table &#039;e-commerce_bookstoredb.publisher&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_bookstoredb.publisher: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_bookstoredb`.`publisher`&#039; at line 1
--
-- Database: `e-commerce_dairyfarmshop-mng-sys`
--
CREATE DATABASE IF NOT EXISTS `e-commerce_dairyfarmshop-mng-sys` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `e-commerce_dairyfarmshop-mng-sys`;

-- --------------------------------------------------------

--
-- Table structure for table `tbladmin`
--
-- Error reading structure for table e-commerce_dairyfarmshop-mng-sys.tbladmin: #1932 - Table &#039;e-commerce_dairyfarmshop-mng-sys.tbladmin&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_dairyfarmshop-mng-sys.tbladmin: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_dairyfarmshop-mng-sys`.`tbladmin`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tblcategory`
--
-- Error reading structure for table e-commerce_dairyfarmshop-mng-sys.tblcategory: #1932 - Table &#039;e-commerce_dairyfarmshop-mng-sys.tblcategory&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_dairyfarmshop-mng-sys.tblcategory: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_dairyfarmshop-mng-sys`.`tblcategory`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tblcompany`
--
-- Error reading structure for table e-commerce_dairyfarmshop-mng-sys.tblcompany: #1932 - Table &#039;e-commerce_dairyfarmshop-mng-sys.tblcompany&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_dairyfarmshop-mng-sys.tblcompany: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_dairyfarmshop-mng-sys`.`tblcompany`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tblorders`
--
-- Error reading structure for table e-commerce_dairyfarmshop-mng-sys.tblorders: #1932 - Table &#039;e-commerce_dairyfarmshop-mng-sys.tblorders&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_dairyfarmshop-mng-sys.tblorders: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_dairyfarmshop-mng-sys`.`tblorders`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tblproducts`
--
-- Error reading structure for table e-commerce_dairyfarmshop-mng-sys.tblproducts: #1932 - Table &#039;e-commerce_dairyfarmshop-mng-sys.tblproducts&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_dairyfarmshop-mng-sys.tblproducts: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_dairyfarmshop-mng-sys`.`tblproducts`&#039; at line 1
--
-- Database: `e-commerce_shopping`
--
CREATE DATABASE IF NOT EXISTS `e-commerce_shopping` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `e-commerce_shopping`;

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--
-- Error reading structure for table e-commerce_shopping.admin: #1932 - Table &#039;e-commerce_shopping.admin&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_shopping.admin: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_shopping`.`admin`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `category`
--
-- Error reading structure for table e-commerce_shopping.category: #1932 - Table &#039;e-commerce_shopping.category&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_shopping.category: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_shopping`.`category`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--
-- Error reading structure for table e-commerce_shopping.orders: #1932 - Table &#039;e-commerce_shopping.orders&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_shopping.orders: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_shopping`.`orders`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `ordertrackhistory`
--
-- Error reading structure for table e-commerce_shopping.ordertrackhistory: #1932 - Table &#039;e-commerce_shopping.ordertrackhistory&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_shopping.ordertrackhistory: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_shopping`.`ordertrackhistory`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `productreviews`
--
-- Error reading structure for table e-commerce_shopping.productreviews: #1932 - Table &#039;e-commerce_shopping.productreviews&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_shopping.productreviews: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_shopping`.`productreviews`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `products`
--
-- Error reading structure for table e-commerce_shopping.products: #1932 - Table &#039;e-commerce_shopping.products&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_shopping.products: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_shopping`.`products`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `subcategory`
--
-- Error reading structure for table e-commerce_shopping.subcategory: #1932 - Table &#039;e-commerce_shopping.subcategory&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_shopping.subcategory: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_shopping`.`subcategory`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `userlog`
--
-- Error reading structure for table e-commerce_shopping.userlog: #1932 - Table &#039;e-commerce_shopping.userlog&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_shopping.userlog: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_shopping`.`userlog`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `users`
--
-- Error reading structure for table e-commerce_shopping.users: #1932 - Table &#039;e-commerce_shopping.users&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_shopping.users: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_shopping`.`users`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `wishlist`
--
-- Error reading structure for table e-commerce_shopping.wishlist: #1932 - Table &#039;e-commerce_shopping.wishlist&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_shopping.wishlist: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_shopping`.`wishlist`&#039; at line 1
--
-- Database: `e-commerce_test_ecommerce`
--
CREATE DATABASE IF NOT EXISTS `e-commerce_test_ecommerce` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `e-commerce_test_ecommerce`;

-- --------------------------------------------------------

--
-- Table structure for table `messagein`
--
-- Error reading structure for table e-commerce_test_ecommerce.messagein: #1932 - Table &#039;e-commerce_test_ecommerce.messagein&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_test_ecommerce.messagein: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_test_ecommerce`.`messagein`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `messagelog`
--
-- Error reading structure for table e-commerce_test_ecommerce.messagelog: #1932 - Table &#039;e-commerce_test_ecommerce.messagelog&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_test_ecommerce.messagelog: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_test_ecommerce`.`messagelog`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `messageout`
--
-- Error reading structure for table e-commerce_test_ecommerce.messageout: #1932 - Table &#039;e-commerce_test_ecommerce.messageout&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_test_ecommerce.messageout: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_test_ecommerce`.`messageout`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tblautonumber`
--
-- Error reading structure for table e-commerce_test_ecommerce.tblautonumber: #1932 - Table &#039;e-commerce_test_ecommerce.tblautonumber&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_test_ecommerce.tblautonumber: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_test_ecommerce`.`tblautonumber`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tblcategory`
--
-- Error reading structure for table e-commerce_test_ecommerce.tblcategory: #1932 - Table &#039;e-commerce_test_ecommerce.tblcategory&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_test_ecommerce.tblcategory: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_test_ecommerce`.`tblcategory`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tblcustomer`
--
-- Error reading structure for table e-commerce_test_ecommerce.tblcustomer: #1932 - Table &#039;e-commerce_test_ecommerce.tblcustomer&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_test_ecommerce.tblcustomer: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_test_ecommerce`.`tblcustomer`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tblorder`
--
-- Error reading structure for table e-commerce_test_ecommerce.tblorder: #1932 - Table &#039;e-commerce_test_ecommerce.tblorder&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_test_ecommerce.tblorder: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_test_ecommerce`.`tblorder`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tblproduct`
--
-- Error reading structure for table e-commerce_test_ecommerce.tblproduct: #1932 - Table &#039;e-commerce_test_ecommerce.tblproduct&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_test_ecommerce.tblproduct: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_test_ecommerce`.`tblproduct`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tblpromopro`
--
-- Error reading structure for table e-commerce_test_ecommerce.tblpromopro: #1932 - Table &#039;e-commerce_test_ecommerce.tblpromopro&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_test_ecommerce.tblpromopro: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_test_ecommerce`.`tblpromopro`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tblsetting`
--
-- Error reading structure for table e-commerce_test_ecommerce.tblsetting: #1932 - Table &#039;e-commerce_test_ecommerce.tblsetting&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_test_ecommerce.tblsetting: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_test_ecommerce`.`tblsetting`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tblstockin`
--
-- Error reading structure for table e-commerce_test_ecommerce.tblstockin: #1932 - Table &#039;e-commerce_test_ecommerce.tblstockin&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_test_ecommerce.tblstockin: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_test_ecommerce`.`tblstockin`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tblsummary`
--
-- Error reading structure for table e-commerce_test_ecommerce.tblsummary: #1932 - Table &#039;e-commerce_test_ecommerce.tblsummary&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_test_ecommerce.tblsummary: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_test_ecommerce`.`tblsummary`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tbluseraccount`
--
-- Error reading structure for table e-commerce_test_ecommerce.tbluseraccount: #1932 - Table &#039;e-commerce_test_ecommerce.tbluseraccount&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_test_ecommerce.tbluseraccount: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_test_ecommerce`.`tbluseraccount`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tblwishlist`
--
-- Error reading structure for table e-commerce_test_ecommerce.tblwishlist: #1932 - Table &#039;e-commerce_test_ecommerce.tblwishlist&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_test_ecommerce.tblwishlist: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_test_ecommerce`.`tblwishlist`&#039; at line 1
--
-- Database: `e-commerce_test_ecommerceweb`
--
CREATE DATABASE IF NOT EXISTS `e-commerce_test_ecommerceweb` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `e-commerce_test_ecommerceweb`;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_color`
--
-- Error reading structure for table e-commerce_test_ecommerceweb.tbl_color: #1932 - Table &#039;e-commerce_test_ecommerceweb.tbl_color&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_test_ecommerceweb.tbl_color: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_test_ecommerceweb`.`tbl_color`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tbl_country`
--

CREATE TABLE `tbl_country` (
  `country_id` int(11) NOT NULL,
  `country_name` varchar(100) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `tbl_country`
--

INSERT INTO `tbl_country` (`country_id`, `country_name`) VALUES
(1, 'Afghanistan'),
(2, 'Albania'),
(3, 'Algeria'),
(4, 'American Samoa'),
(5, 'Andorra'),
(6, 'Angola'),
(7, 'Anguilla'),
(8, 'Antarctica'),
(9, 'Antigua and Barbuda'),
(10, 'Argentina'),
(11, 'Armenia'),
(12, 'Aruba'),
(13, 'Australia'),
(14, 'Austria'),
(15, 'Azerbaijan'),
(16, 'Bahamas'),
(17, 'Bahrain'),
(18, 'Bangladesh'),
(19, 'Barbados'),
(20, 'Belarus'),
(21, 'Belgium'),
(22, 'Belize'),
(23, 'Benin'),
(24, 'Bermuda'),
(25, 'Bhutan'),
(26, 'Bolivia'),
(27, 'Bosnia and Herzegovina'),
(28, 'Botswana'),
(29, 'Bouvet Island'),
(30, 'Brazil'),
(31, 'British Indian Ocean Territory'),
(32, 'Brunei Darussalam'),
(33, 'Bulgaria'),
(34, 'Burkina Faso'),
(35, 'Burundi'),
(36, 'Cambodia'),
(37, 'Cameroon'),
(38, 'Canada'),
(39, 'Cape Verde'),
(40, 'Cayman Islands'),
(41, 'Central African Republic'),
(42, 'Chad'),
(43, 'Chile'),
(44, 'China'),
(45, 'Christmas Island'),
(46, 'Cocos (Keeling) Islands'),
(47, 'Colombia'),
(48, 'Comoros'),
(49, 'Congo'),
(50, 'Cook Islands'),
(51, 'Costa Rica'),
(52, 'Croatia (Hrvatska)'),
(53, 'Cuba'),
(54, 'Cyprus'),
(55, 'Czech Republic'),
(56, 'Denmark'),
(57, 'Djibouti'),
(58, 'Dominica'),
(59, 'Dominican Republic'),
(60, 'East Timor'),
(61, 'Ecuador'),
(62, 'Egypt'),
(63, 'El Salvador'),
(64, 'Equatorial Guinea'),
(65, 'Eritrea'),
(66, 'Estonia'),
(67, 'Ethiopia'),
(68, 'Falkland Islands (Malvinas)'),
(69, 'Faroe Islands'),
(70, 'Fiji'),
(71, 'Finland'),
(72, 'France'),
(73, 'France, Metropolitan'),
(74, 'French Guiana'),
(75, 'French Polynesia'),
(76, 'French Southern Territories'),
(77, 'Gabon'),
(78, 'Gambia'),
(79, 'Georgia'),
(80, 'Germany'),
(81, 'Ghana'),
(82, 'Gibraltar'),
(83, 'Guernsey'),
(84, 'Greece'),
(85, 'Greenland'),
(86, 'Grenada'),
(87, 'Guadeloupe'),
(88, 'Guam'),
(89, 'Guatemala'),
(90, 'Guinea'),
(91, 'Guinea-Bissau'),
(92, 'Guyana'),
(93, 'Haiti'),
(94, 'Heard and Mc Donald Islands'),
(95, 'Honduras'),
(96, 'Hong Kong'),
(97, 'Hungary'),
(98, 'Iceland'),
(99, 'India'),
(100, 'Isle of Man'),
(101, 'Indonesia'),
(102, 'Iran (Islamic Republic of)'),
(103, 'Iraq'),
(104, 'Ireland'),
(105, 'Israel'),
(106, 'Italy'),
(107, 'Ivory Coast'),
(108, 'Jersey'),
(109, 'Jamaica'),
(110, 'Japan'),
(111, 'Jordan'),
(112, 'Kazakhstan'),
(113, 'Kenya'),
(114, 'Kiribati'),
(115, 'Korea, Democratic People\'s Republic of'),
(116, 'Korea, Republic of'),
(117, 'Kosovo'),
(118, 'Kuwait'),
(119, 'Kyrgyzstan'),
(120, 'Lao People\'s Democratic Republic'),
(121, 'Latvia'),
(122, 'Lebanon'),
(123, 'Lesotho'),
(124, 'Liberia'),
(125, 'Libyan Arab Jamahiriya'),
(126, 'Liechtenstein'),
(127, 'Lithuania'),
(128, 'Luxembourg'),
(129, 'Macau'),
(130, 'Macedonia'),
(131, 'Madagascar'),
(132, 'Malawi'),
(133, 'Malaysia'),
(134, 'Maldives'),
(135, 'Mali'),
(136, 'Malta'),
(137, 'Marshall Islands'),
(138, 'Martinique'),
(139, 'Mauritania'),
(140, 'Mauritius'),
(141, 'Mayotte'),
(142, 'Mexico'),
(143, 'Micronesia, Federated States of'),
(144, 'Moldova, Republic of'),
(145, 'Monaco'),
(146, 'Mongolia'),
(147, 'Montenegro'),
(148, 'Montserrat'),
(149, 'Morocco'),
(150, 'Mozambique'),
(151, 'Myanmar'),
(152, 'Namibia'),
(153, 'Nauru'),
(154, 'Nepal'),
(155, 'Netherlands'),
(156, 'Netherlands Antilles'),
(157, 'New Caledonia'),
(158, 'New Zealand'),
(159, 'Nicaragua'),
(160, 'Niger'),
(161, 'Nigeria'),
(162, 'Niue'),
(163, 'Norfolk Island'),
(164, 'Northern Mariana Islands'),
(165, 'Norway'),
(166, 'Oman'),
(167, 'Pakistan'),
(168, 'Palau'),
(169, 'Palestine'),
(170, 'Panama'),
(171, 'Papua New Guinea'),
(172, 'Paraguay'),
(173, 'Peru'),
(174, 'Philippines'),
(175, 'Pitcairn'),
(176, 'Poland'),
(177, 'Portugal'),
(178, 'Puerto Rico'),
(179, 'Qatar'),
(180, 'Reunion'),
(181, 'Romania'),
(182, 'Russian Federation'),
(183, 'Rwanda'),
(184, 'Saint Kitts and Nevis'),
(185, 'Saint Lucia'),
(186, 'Saint Vincent and the Grenadines'),
(187, 'Samoa'),
(188, 'San Marino'),
(189, 'Sao Tome and Principe'),
(190, 'Saudi Arabia'),
(191, 'Senegal'),
(192, 'Serbia'),
(193, 'Seychelles'),
(194, 'Sierra Leone'),
(195, 'Singapore'),
(196, 'Slovakia'),
(197, 'Slovenia'),
(198, 'Solomon Islands'),
(199, 'Somalia'),
(200, 'South Africa'),
(201, 'South Georgia South Sandwich Islands'),
(202, 'Spain'),
(203, 'Sri Lanka'),
(204, 'St. Helena'),
(205, 'St. Pierre and Miquelon'),
(206, 'Sudan'),
(207, 'Suriname'),
(208, 'Svalbard and Jan Mayen Islands'),
(209, 'Swaziland'),
(210, 'Sweden'),
(211, 'Switzerland'),
(212, 'Syrian Arab Republic'),
(213, 'Taiwan'),
(214, 'Tajikistan'),
(215, 'Tanzania, United Republic of'),
(216, 'Thailand'),
(217, 'Togo'),
(218, 'Tokelau'),
(219, 'Tonga'),
(220, 'Trinidad and Tobago'),
(221, 'Tunisia'),
(222, 'Turkey'),
(223, 'Turkmenistan'),
(224, 'Turks and Caicos Islands'),
(225, 'Tuvalu'),
(226, 'Uganda'),
(227, 'Ukraine'),
(228, 'United Arab Emirates'),
(229, 'United Kingdom'),
(230, 'United States'),
(231, 'United States minor outlying islands'),
(232, 'Uruguay'),
(233, 'Uzbekistan'),
(234, 'Vanuatu'),
(235, 'Vatican City State'),
(236, 'Venezuela'),
(237, 'Vietnam'),
(238, 'Virgin Islands (British)'),
(239, 'Virgin Islands (U.S.)'),
(240, 'Wallis and Futuna Islands'),
(241, 'Western Sahara'),
(242, 'Yemen'),
(243, 'Zaire'),
(244, 'Zambia'),
(245, 'Zimbabwe');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_customer`
--
-- Error reading structure for table e-commerce_test_ecommerceweb.tbl_customer: #1932 - Table &#039;e-commerce_test_ecommerceweb.tbl_customer&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_test_ecommerceweb.tbl_customer: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_test_ecommerceweb`.`tbl_customer`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tbl_customer_message`
--

CREATE TABLE `tbl_customer_message` (
  `customer_message_id` int(11) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `order_detail` text NOT NULL,
  `cust_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_end_category`
--
-- Error reading structure for table e-commerce_test_ecommerceweb.tbl_end_category: #1932 - Table &#039;e-commerce_test_ecommerceweb.tbl_end_category&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_test_ecommerceweb.tbl_end_category: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_test_ecommerceweb`.`tbl_end_category`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tbl_faq`
--
-- Error reading structure for table e-commerce_test_ecommerceweb.tbl_faq: #1932 - Table &#039;e-commerce_test_ecommerceweb.tbl_faq&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_test_ecommerceweb.tbl_faq: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_test_ecommerceweb`.`tbl_faq`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tbl_language`
--

CREATE TABLE `tbl_language` (
  `lang_id` int(11) NOT NULL,
  `lang_name` varchar(255) NOT NULL,
  `lang_value` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tbl_language`
--

INSERT INTO `tbl_language` (`lang_id`, `lang_name`, `lang_value`) VALUES
(1, 'Currency', '$'),
(2, 'Search Product', 'Search Product'),
(3, 'Search', 'Search'),
(4, 'Submit', 'Submit'),
(5, 'Update', 'Update'),
(6, 'Read More', 'Read More'),
(7, 'Serial', 'Serial'),
(8, 'Photo', 'Photo'),
(9, 'Login', 'Login'),
(10, 'Customer Login', 'Customer Login'),
(11, 'Click here to login', 'Click here to login'),
(12, 'Back to Login Page', 'Back to Login Page'),
(13, 'Logged in as', 'Logged in as'),
(14, 'Logout', 'Logout'),
(15, 'Register', 'Register'),
(16, 'Customer Registration', 'Customer Registration'),
(17, 'Registration Successful', 'Registration Successful'),
(18, 'Cart', 'Cart'),
(19, 'View Cart', 'View Cart'),
(20, 'Update Cart', 'Update Cart'),
(21, 'Back to Cart', 'Back to Cart'),
(22, 'Checkout', 'Checkout'),
(23, 'Proceed to Checkout', 'Proceed to Checkout'),
(24, 'Orders', 'Orders'),
(25, 'Order History', 'Order History'),
(26, 'Order Details', 'Order Details'),
(27, 'Payment Date and Time', 'Payment Date and Time'),
(28, 'Transaction ID', 'Transaction ID'),
(29, 'Paid Amount', 'Paid Amount'),
(30, 'Payment Status', 'Payment Status'),
(31, 'Payment Method', 'Payment Method'),
(32, 'Payment ID', 'Payment ID'),
(33, 'Payment Section', 'Payment Section'),
(34, 'Select Payment Method', 'Select Payment Method'),
(35, 'Select a Method', 'Select a Method'),
(36, 'PayPal', 'PayPal'),
(37, 'Stripe', 'Stripe'),
(38, 'Bank Deposit', 'Bank Deposit'),
(39, 'Card Number', 'Card Number'),
(40, 'CVV', 'CVV'),
(41, 'Month', 'Month'),
(42, 'Year', 'Year'),
(43, 'Send to this Details', 'Send to this Details'),
(44, 'Transaction Information', 'Transaction Information'),
(45, 'Include transaction id and other information correctly', 'Include transaction id and other information correctly'),
(46, 'Pay Now', 'Pay Now'),
(47, 'Product Name', 'Product Name'),
(48, 'Product Details', 'Product Details'),
(49, 'Categories', 'Categories'),
(50, 'Category:', 'Category:'),
(51, 'All Products Under', 'All Products Under'),
(52, 'Select Size', 'Select Size'),
(53, 'Select Color', 'Select Color'),
(54, 'Product Price', 'Product Price'),
(55, 'Quantity', 'Quantity'),
(56, 'Out of Stock', 'Out of Stock'),
(57, 'Share This', 'Share This'),
(58, 'Share This Product', 'Share This Product'),
(59, 'Product Description', 'Product Description'),
(60, 'Features', 'Features'),
(61, 'Conditions', 'Conditions'),
(62, 'Return Policy', 'Return Policy'),
(63, 'Reviews', 'Reviews'),
(64, 'Review', 'Review'),
(65, 'Give a Review', 'Give a Review'),
(66, 'Write your comment (Optional)', 'Write your comment (Optional)'),
(67, 'Submit Review', 'Submit Review'),
(68, 'You already have given a rating!', 'You already have given a rating!'),
(69, 'You must have to login to give a review', 'You must have to login to give a review'),
(70, 'No description found', 'No description found'),
(71, 'No feature found', 'No feature found'),
(72, 'No condition found', 'No condition found'),
(73, 'No return policy found', 'No return policy found'),
(74, 'Review not found', 'Review not found'),
(75, 'Customer Name', 'Customer Name'),
(76, 'Comment', 'Comment'),
(77, 'Comments', 'Comments'),
(78, 'Rating', 'Rating'),
(79, 'Previous', 'Previous'),
(80, 'Next', 'Next'),
(81, 'Sub Total', 'Sub Total'),
(82, 'Total', 'Total'),
(83, 'Action', 'Action'),
(84, 'Shipping Cost', 'Shipping Cost'),
(85, 'Continue Shopping', 'Continue Shopping'),
(86, 'Update Billing Address', 'Update Billing Address'),
(87, 'Update Shipping Address', 'Update Shipping Address'),
(88, 'Update Billing and Shipping Info', 'Update Billing and Shipping Info'),
(89, 'Dashboard', 'Dashboard'),
(90, 'Welcome to the Dashboard', 'Welcome to the Dashboard'),
(91, 'Back to Dashboard', 'Back to Dashboard'),
(92, 'Subscribe', 'Subscribe'),
(93, 'Subscribe To Our Newsletter', 'Subscribe To Our Newsletter'),
(94, 'Email Address', 'Email Address'),
(95, 'Enter Your Email Address', 'Enter Your Email Address'),
(96, 'Password', 'Password'),
(97, 'Forget Password', 'Forget Password'),
(98, 'Retype Password', 'Retype Password'),
(99, 'Update Password', 'Update Password'),
(100, 'New Password', 'New Password'),
(101, 'Retype New Password', 'Retype New Password'),
(102, 'Full Name', 'Full Name'),
(103, 'Company Name', 'Company Name'),
(104, 'Phone Number', 'Phone Number'),
(105, 'Address', 'Address'),
(106, 'Country', 'Country'),
(107, 'City', 'City'),
(108, 'State', 'State'),
(109, 'Zip Code', 'Zip Code'),
(110, 'About Us', 'About Us'),
(111, 'Featured Posts', 'Featured Posts'),
(112, 'Popular Posts', 'Popular Posts'),
(113, 'Recent Posts', 'Recent Posts'),
(114, 'Contact Information', 'Contact Information'),
(115, 'Contact Form', 'Contact Form'),
(116, 'Our Office', 'Our Office'),
(117, 'Update Profile', 'Update Profile'),
(118, 'Send Message', 'Send Message'),
(119, 'Message', 'Message'),
(120, 'Find Us On Map', 'Find Us On Map'),
(121, 'Congratulation! Payment is successful.', 'Congratulation! Payment is successful.'),
(122, 'Billing and Shipping Information is updated successfully.', 'Billing and Shipping Information is updated successfully.'),
(123, 'Customer Name can not be empty.', 'Customer Name can not be empty.'),
(124, 'Phone Number can not be empty.', 'Phone Number can not be empty.'),
(125, 'Address can not be empty.', 'Address can not be empty.'),
(126, 'You must have to select a country.', 'You must have to select a country.'),
(127, 'City can not be empty.', 'City can not be empty.'),
(128, 'State can not be empty.', 'State can not be empty.'),
(129, 'Zip Code can not be empty.', 'Zip Code can not be empty.'),
(130, 'Profile Information is updated successfully.', 'Profile Information is updated successfully.'),
(131, 'Email Address can not be empty', 'Email Address can not be empty'),
(132, 'Email and/or Password can not be empty.', 'Email and/or Password can not be empty.'),
(133, 'Email Address does not match.', 'Email Address does not match.'),
(134, 'Email address must be valid.', 'Email address must be valid.'),
(135, 'You email address is not found in our system.', 'You email address is not found in our system.'),
(136, 'Please check your email and confirm your subscription.', 'Please check your email and confirm your subscription.'),
(137, 'Your email is verified successfully. You can now login to our website.', 'Your email is verified successfully. You can now login to our website.'),
(138, 'Password can not be empty.', 'Password can not be empty.'),
(139, 'Passwords do not match.', 'Passwords do not match.'),
(140, 'Please enter new and retype passwords.', 'Please enter new and retype passwords.'),
(141, 'Password is updated successfully.', 'Password is updated successfully.'),
(142, 'To reset your password, please click on the link below.', 'To reset your password, please click on the link below.'),
(143, 'PASSWORD RESET REQUEST - YOUR WEBSITE.COM', 'PASSWORD RESET REQUEST - YOUR WEBSITE.COM'),
(144, 'The password reset email time (24 hours) has expired. Please again try to reset your password.', 'The password reset email time (24 hours) has expired. Please again try to reset your password.'),
(145, 'A confirmation link is sent to your email address. You will get the password reset information in there.', 'A confirmation link is sent to your email address. You will get the password reset information in there.'),
(146, 'Password is reset successfully. You can now login.', 'Password is reset successfully. You can now login.'),
(147, 'Email Address Already Exists', 'Email Address Already Exists.'),
(148, 'Sorry! Your account is inactive. Please contact to the administrator.', 'Sorry! Your account is inactive. Please contact to the administrator.'),
(149, 'Change Password', 'Change Password'),
(150, 'Registration Email Confirmation for YOUR WEBSITE', 'Registration Email Confirmation for YOUR WEBSITE.'),
(151, 'Thank you for your registration! Your account has been created. To active your account click on the link below:', 'Thank you for your registration! Your account has been created. To active your account click on the link below:'),
(152, 'Your registration is completed. Please check your email address to follow the process to confirm your registration.', 'Your registration is completed. Please check your email address to follow the process to confirm your registration.'),
(153, 'No Product Found', 'No Product Found'),
(154, 'Add to Cart', 'Add to Cart'),
(155, 'Related Products', 'Related Products'),
(156, 'See all related products from below', 'See all the related products from below'),
(157, 'Size', 'Size'),
(158, 'Color', 'Color'),
(159, 'Price', 'Price'),
(160, 'Please login as customer to checkout', 'Please login as customer to checkout'),
(161, 'Billing Address', 'Billing Address'),
(162, 'Shipping Address', 'Shipping Address'),
(163, 'Rating is Submitted Successfully!', 'Rating is Submitted Successfully!');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_mid_category`
--
-- Error reading structure for table e-commerce_test_ecommerceweb.tbl_mid_category: #1932 - Table &#039;e-commerce_test_ecommerceweb.tbl_mid_category&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_test_ecommerceweb.tbl_mid_category: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_test_ecommerceweb`.`tbl_mid_category`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order`
--
-- Error reading structure for table e-commerce_test_ecommerceweb.tbl_order: #1932 - Table &#039;e-commerce_test_ecommerceweb.tbl_order&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_test_ecommerceweb.tbl_order: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_test_ecommerceweb`.`tbl_order`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tbl_page`
--
-- Error reading structure for table e-commerce_test_ecommerceweb.tbl_page: #1932 - Table &#039;e-commerce_test_ecommerceweb.tbl_page&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_test_ecommerceweb.tbl_page: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_test_ecommerceweb`.`tbl_page`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tbl_payment`
--

CREATE TABLE `tbl_payment` (
  `id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `customer_name` varchar(255) NOT NULL,
  `customer_email` varchar(255) NOT NULL,
  `payment_date` varchar(50) NOT NULL,
  `txnid` varchar(255) NOT NULL,
  `paid_amount` int(11) NOT NULL,
  `card_number` varchar(50) NOT NULL,
  `card_cvv` varchar(10) NOT NULL,
  `card_month` varchar(10) NOT NULL,
  `card_year` varchar(10) NOT NULL,
  `bank_transaction_info` text NOT NULL,
  `payment_method` varchar(20) NOT NULL,
  `payment_status` varchar(25) NOT NULL,
  `shipping_status` varchar(20) NOT NULL,
  `payment_id` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tbl_payment`
--

INSERT INTO `tbl_payment` (`id`, `customer_id`, `customer_name`, `customer_email`, `payment_date`, `txnid`, `paid_amount`, `card_number`, `card_cvv`, `card_month`, `card_year`, `bank_transaction_info`, `payment_method`, `payment_status`, `shipping_status`, `payment_id`) VALUES
(51, 2, 'Chad N. Carney', 'chad@mail.com', '2022-03-18 22:48:49', '', 19, '', '', '', '', 'Transaction Id: CA01010158967840\r\nTransaction Date: 3/19/2022\r\nBank: WestView Bank, CA Branch\r\nSender A/C: 102458965WV', 'Bank Deposit', 'Completed', 'Completed', '1647629329'),
(52, 3, 'Jean Collins', 'jean@mail.com', '2022-03-20 10:49:53', '', 91, '', '', '', '', '', 'PayPal', 'Completed', 'Completed', '1647798593'),
(54, 6, 'August F. Freels', 'august@mail.com', '2022-03-20 10:59:34', '', 70, '', '', '', '', 'Transaction Id: CA01101198945600\nTransaction Date: 3/20/2022 \nBank: WestView Bank, CA Branch \nSender A/C: 1100047860WV', 'Bank Deposit', 'Completed', 'Pending', '1647799174'),
(55, 10, 'Will Williams', 'williams@mail.com', '2022-03-20 11:28:22', '', 149, '', '', '', '', 'Transaction Id: CA01003177945009\r\nTransaction Date: 3/20/2022 \r\nBank: WestView Bank, CA Branch \r\nSender A/C: NQ1011050160WV', 'Bank Deposit', 'Completed', 'Completed', '1647800902');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_photo`
--
-- Error reading structure for table e-commerce_test_ecommerceweb.tbl_photo: #1932 - Table &#039;e-commerce_test_ecommerceweb.tbl_photo&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_test_ecommerceweb.tbl_photo: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_test_ecommerceweb`.`tbl_photo`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tbl_post`
--
-- Error reading structure for table e-commerce_test_ecommerceweb.tbl_post: #1932 - Table &#039;e-commerce_test_ecommerceweb.tbl_post&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_test_ecommerceweb.tbl_post: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_test_ecommerceweb`.`tbl_post`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product`
--
-- Error reading structure for table e-commerce_test_ecommerceweb.tbl_product: #1932 - Table &#039;e-commerce_test_ecommerceweb.tbl_product&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_test_ecommerceweb.tbl_product: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_test_ecommerceweb`.`tbl_product`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product_color`
--
-- Error reading structure for table e-commerce_test_ecommerceweb.tbl_product_color: #1932 - Table &#039;e-commerce_test_ecommerceweb.tbl_product_color&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_test_ecommerceweb.tbl_product_color: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_test_ecommerceweb`.`tbl_product_color`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product_photo`
--
-- Error reading structure for table e-commerce_test_ecommerceweb.tbl_product_photo: #1932 - Table &#039;e-commerce_test_ecommerceweb.tbl_product_photo&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_test_ecommerceweb.tbl_product_photo: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_test_ecommerceweb`.`tbl_product_photo`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product_size`
--
-- Error reading structure for table e-commerce_test_ecommerceweb.tbl_product_size: #1932 - Table &#039;e-commerce_test_ecommerceweb.tbl_product_size&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_test_ecommerceweb.tbl_product_size: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_test_ecommerceweb`.`tbl_product_size`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tbl_rating`
--
-- Error reading structure for table e-commerce_test_ecommerceweb.tbl_rating: #1932 - Table &#039;e-commerce_test_ecommerceweb.tbl_rating&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_test_ecommerceweb.tbl_rating: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_test_ecommerceweb`.`tbl_rating`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tbl_service`
--
-- Error reading structure for table e-commerce_test_ecommerceweb.tbl_service: #1932 - Table &#039;e-commerce_test_ecommerceweb.tbl_service&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_test_ecommerceweb.tbl_service: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_test_ecommerceweb`.`tbl_service`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tbl_settings`
--
-- Error reading structure for table e-commerce_test_ecommerceweb.tbl_settings: #1932 - Table &#039;e-commerce_test_ecommerceweb.tbl_settings&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_test_ecommerceweb.tbl_settings: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_test_ecommerceweb`.`tbl_settings`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tbl_shipping_cost`
--
-- Error reading structure for table e-commerce_test_ecommerceweb.tbl_shipping_cost: #1932 - Table &#039;e-commerce_test_ecommerceweb.tbl_shipping_cost&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_test_ecommerceweb.tbl_shipping_cost: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_test_ecommerceweb`.`tbl_shipping_cost`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tbl_shipping_cost_all`
--
-- Error reading structure for table e-commerce_test_ecommerceweb.tbl_shipping_cost_all: #1932 - Table &#039;e-commerce_test_ecommerceweb.tbl_shipping_cost_all&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_test_ecommerceweb.tbl_shipping_cost_all: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_test_ecommerceweb`.`tbl_shipping_cost_all`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tbl_size`
--
-- Error reading structure for table e-commerce_test_ecommerceweb.tbl_size: #1932 - Table &#039;e-commerce_test_ecommerceweb.tbl_size&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_test_ecommerceweb.tbl_size: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_test_ecommerceweb`.`tbl_size`&#039; at line 1
--
-- Database: `e-commerce_test_obbs`
--
CREATE DATABASE IF NOT EXISTS `e-commerce_test_obbs` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `e-commerce_test_obbs`;

-- --------------------------------------------------------

--
-- Table structure for table `tbladmin`
--
-- Error reading structure for table e-commerce_test_obbs.tbladmin: #1932 - Table &#039;e-commerce_test_obbs.tbladmin&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_test_obbs.tbladmin: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_test_obbs`.`tbladmin`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tblbooking`
--
-- Error reading structure for table e-commerce_test_obbs.tblbooking: #1932 - Table &#039;e-commerce_test_obbs.tblbooking&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_test_obbs.tblbooking: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_test_obbs`.`tblbooking`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tblcontact`
--
-- Error reading structure for table e-commerce_test_obbs.tblcontact: #1932 - Table &#039;e-commerce_test_obbs.tblcontact&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_test_obbs.tblcontact: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_test_obbs`.`tblcontact`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tbleventtype`
--
-- Error reading structure for table e-commerce_test_obbs.tbleventtype: #1932 - Table &#039;e-commerce_test_obbs.tbleventtype&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_test_obbs.tbleventtype: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_test_obbs`.`tbleventtype`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tblpage`
--
-- Error reading structure for table e-commerce_test_obbs.tblpage: #1932 - Table &#039;e-commerce_test_obbs.tblpage&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_test_obbs.tblpage: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_test_obbs`.`tblpage`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tblservice`
--
-- Error reading structure for table e-commerce_test_obbs.tblservice: #1932 - Table &#039;e-commerce_test_obbs.tblservice&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_test_obbs.tblservice: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_test_obbs`.`tblservice`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tbluser`
--
-- Error reading structure for table e-commerce_test_obbs.tbluser: #1932 - Table &#039;e-commerce_test_obbs.tbluser&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_test_obbs.tbluser: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_test_obbs`.`tbluser`&#039; at line 1
--
-- Database: `e-commerce_test_petshop`
--
CREATE DATABASE IF NOT EXISTS `e-commerce_test_petshop` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `e-commerce_test_petshop`;

-- --------------------------------------------------------

--
-- Table structure for table `admininfo`
--
-- Error reading structure for table e-commerce_test_petshop.admininfo: #1932 - Table &#039;e-commerce_test_petshop.admininfo&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_test_petshop.admininfo: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_test_petshop`.`admininfo`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tblcnp`
--
-- Error reading structure for table e-commerce_test_petshop.tblcnp: #1932 - Table &#039;e-commerce_test_petshop.tblcnp&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_test_petshop.tblcnp: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_test_petshop`.`tblcnp`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tblorders`
--
-- Error reading structure for table e-commerce_test_petshop.tblorders: #1932 - Table &#039;e-commerce_test_petshop.tblorders&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_test_petshop.tblorders: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_test_petshop`.`tblorders`&#039; at line 1
--
-- Database: `edu_columbandb`
--
CREATE DATABASE IF NOT EXISTS `edu_columbandb` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `edu_columbandb`;

-- --------------------------------------------------------

--
-- Table structure for table `ay`
--
-- Error reading structure for table edu_columbandb.ay: #1932 - Table &#039;edu_columbandb.ay&#039; doesn&#039;t exist in engine
-- Error reading data for table edu_columbandb.ay: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `edu_columbandb`.`ay`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `class`
--
-- Error reading structure for table edu_columbandb.class: #1932 - Table &#039;edu_columbandb.class&#039; doesn&#039;t exist in engine
-- Error reading data for table edu_columbandb.class: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `edu_columbandb`.`class`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `course`
--
-- Error reading structure for table edu_columbandb.course: #1932 - Table &#039;edu_columbandb.course&#039; doesn&#039;t exist in engine
-- Error reading data for table edu_columbandb.course: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `edu_columbandb`.`course`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `department`
--
-- Error reading structure for table edu_columbandb.department: #1932 - Table &#039;edu_columbandb.department&#039; doesn&#039;t exist in engine
-- Error reading data for table edu_columbandb.department: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `edu_columbandb`.`department`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `grades`
--
-- Error reading structure for table edu_columbandb.grades: #1932 - Table &#039;edu_columbandb.grades&#039; doesn&#039;t exist in engine
-- Error reading data for table edu_columbandb.grades: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `edu_columbandb`.`grades`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `instructor`
--
-- Error reading structure for table edu_columbandb.instructor: #1932 - Table &#039;edu_columbandb.instructor&#039; doesn&#039;t exist in engine
-- Error reading data for table edu_columbandb.instructor: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `edu_columbandb`.`instructor`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `level`
--
-- Error reading structure for table edu_columbandb.level: #1932 - Table &#039;edu_columbandb.level&#039; doesn&#039;t exist in engine
-- Error reading data for table edu_columbandb.level: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `edu_columbandb`.`level`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `major`
--
-- Error reading structure for table edu_columbandb.major: #1932 - Table &#039;edu_columbandb.major&#039; doesn&#039;t exist in engine
-- Error reading data for table edu_columbandb.major: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `edu_columbandb`.`major`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `photo`
--
-- Error reading structure for table edu_columbandb.photo: #1932 - Table &#039;edu_columbandb.photo&#039; doesn&#039;t exist in engine
-- Error reading data for table edu_columbandb.photo: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `edu_columbandb`.`photo`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `room`
--
-- Error reading structure for table edu_columbandb.room: #1932 - Table &#039;edu_columbandb.room&#039; doesn&#039;t exist in engine
-- Error reading data for table edu_columbandb.room: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `edu_columbandb`.`room`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `schoolyr`
--
-- Error reading structure for table edu_columbandb.schoolyr: #1932 - Table &#039;edu_columbandb.schoolyr&#039; doesn&#039;t exist in engine
-- Error reading data for table edu_columbandb.schoolyr: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `edu_columbandb`.`schoolyr`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `semester`
--
-- Error reading structure for table edu_columbandb.semester: #1932 - Table &#039;edu_columbandb.semester&#039; doesn&#039;t exist in engine
-- Error reading data for table edu_columbandb.semester: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `edu_columbandb`.`semester`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `studentsubjects`
--
-- Error reading structure for table edu_columbandb.studentsubjects: #1932 - Table &#039;edu_columbandb.studentsubjects&#039; doesn&#039;t exist in engine
-- Error reading data for table edu_columbandb.studentsubjects: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `edu_columbandb`.`studentsubjects`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `subject`
--
-- Error reading structure for table edu_columbandb.subject: #1932 - Table &#039;edu_columbandb.subject&#039; doesn&#039;t exist in engine
-- Error reading data for table edu_columbandb.subject: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `edu_columbandb`.`subject`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tblrequirements`
--
-- Error reading structure for table edu_columbandb.tblrequirements: #1932 - Table &#039;edu_columbandb.tblrequirements&#039; doesn&#039;t exist in engine
-- Error reading data for table edu_columbandb.tblrequirements: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `edu_columbandb`.`tblrequirements`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tblstuddetails`
--
-- Error reading structure for table edu_columbandb.tblstuddetails: #1932 - Table &#039;edu_columbandb.tblstuddetails&#039; doesn&#039;t exist in engine
-- Error reading data for table edu_columbandb.tblstuddetails: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `edu_columbandb`.`tblstuddetails`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tblstudent`
--
-- Error reading structure for table edu_columbandb.tblstudent: #1932 - Table &#039;edu_columbandb.tblstudent&#039; doesn&#039;t exist in engine
-- Error reading data for table edu_columbandb.tblstudent: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `edu_columbandb`.`tblstudent`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `useraccounts`
--
-- Error reading structure for table edu_columbandb.useraccounts: #1932 - Table &#039;edu_columbandb.useraccounts&#039; doesn&#039;t exist in engine
-- Error reading data for table edu_columbandb.useraccounts: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `edu_columbandb`.`useraccounts`&#039; at line 1
--
-- Database: `edu_fieldatc`
--
CREATE DATABASE IF NOT EXISTS `edu_fieldatc` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `edu_fieldatc`;

-- --------------------------------------------------------

--
-- Table structure for table `application`
--
-- Error reading structure for table edu_fieldatc.application: #1932 - Table &#039;edu_fieldatc.application&#039; doesn&#039;t exist in engine
-- Error reading data for table edu_fieldatc.application: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `edu_fieldatc`.`application`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `contents`
--
-- Error reading structure for table edu_fieldatc.contents: #1932 - Table &#039;edu_fieldatc.contents&#039; doesn&#039;t exist in engine
-- Error reading data for table edu_fieldatc.contents: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `edu_fieldatc`.`contents`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `news`
--
-- Error reading structure for table edu_fieldatc.news: #1932 - Table &#039;edu_fieldatc.news&#039; doesn&#039;t exist in engine
-- Error reading data for table edu_fieldatc.news: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `edu_fieldatc`.`news`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `users`
--
-- Error reading structure for table edu_fieldatc.users: #1932 - Table &#039;edu_fieldatc.users&#039; doesn&#039;t exist in engine
-- Error reading data for table edu_fieldatc.users: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `edu_fieldatc`.`users`&#039; at line 1
--
-- Database: `edu_grading`
--
CREATE DATABASE IF NOT EXISTS `edu_grading` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `edu_grading`;

-- --------------------------------------------------------

--
-- Table structure for table `advisers`
--
-- Error reading structure for table edu_grading.advisers: #1932 - Table &#039;edu_grading.advisers&#039; doesn&#039;t exist in engine
-- Error reading data for table edu_grading.advisers: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `edu_grading`.`advisers`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--
-- Error reading structure for table edu_grading.attendance: #1932 - Table &#039;edu_grading.attendance&#039; doesn&#039;t exist in engine
-- Error reading data for table edu_grading.attendance: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `edu_grading`.`attendance`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `awss`
--
-- Error reading structure for table edu_grading.awss: #1932 - Table &#039;edu_grading.awss&#039; doesn&#039;t exist in engine
-- Error reading data for table edu_grading.awss: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `edu_grading`.`awss`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `data_b`
--
-- Error reading structure for table edu_grading.data_b: #1932 - Table &#039;edu_grading.data_b&#039; doesn&#039;t exist in engine
-- Error reading data for table edu_grading.data_b: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `edu_grading`.`data_b`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `data_base`
--
-- Error reading structure for table edu_grading.data_base: #1932 - Table &#039;edu_grading.data_base&#039; doesn&#039;t exist in engine
-- Error reading data for table edu_grading.data_base: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `edu_grading`.`data_base`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `grade`
--
-- Error reading structure for table edu_grading.grade: #1932 - Table &#039;edu_grading.grade&#039; doesn&#039;t exist in engine
-- Error reading data for table edu_grading.grade: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `edu_grading`.`grade`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `grades_per_subject`
--
-- Error reading structure for table edu_grading.grades_per_subject: #1932 - Table &#039;edu_grading.grades_per_subject&#039; doesn&#039;t exist in engine
-- Error reading data for table edu_grading.grades_per_subject: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `edu_grading`.`grades_per_subject`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `history_log`
--
-- Error reading structure for table edu_grading.history_log: #1932 - Table &#039;edu_grading.history_log&#039; doesn&#039;t exist in engine
-- Error reading data for table edu_grading.history_log: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `edu_grading`.`history_log`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `program`
--
-- Error reading structure for table edu_grading.program: #1932 - Table &#039;edu_grading.program&#039; doesn&#039;t exist in engine
-- Error reading data for table edu_grading.program: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `edu_grading`.`program`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `promotion_candidates`
--
-- Error reading structure for table edu_grading.promotion_candidates: #1932 - Table &#039;edu_grading.promotion_candidates&#039; doesn&#039;t exist in engine
-- Error reading data for table edu_grading.promotion_candidates: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `edu_grading`.`promotion_candidates`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `school_year`
--
-- Error reading structure for table edu_grading.school_year: #1932 - Table &#039;edu_grading.school_year&#039; doesn&#039;t exist in engine
-- Error reading data for table edu_grading.school_year: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `edu_grading`.`school_year`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `students`
--
-- Error reading structure for table edu_grading.students: #1932 - Table &#039;edu_grading.students&#039; doesn&#039;t exist in engine
-- Error reading data for table edu_grading.students: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `edu_grading`.`students`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `student_info`
--
-- Error reading structure for table edu_grading.student_info: #1932 - Table &#039;edu_grading.student_info&#039; doesn&#039;t exist in engine
-- Error reading data for table edu_grading.student_info: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `edu_grading`.`student_info`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `student_int_info`
--
-- Error reading structure for table edu_grading.student_int_info: #1932 - Table &#039;edu_grading.student_int_info&#039; doesn&#039;t exist in engine
-- Error reading data for table edu_grading.student_int_info: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `edu_grading`.`student_int_info`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `student_year_info`
--
-- Error reading structure for table edu_grading.student_year_info: #1932 - Table &#039;edu_grading.student_year_info&#039; doesn&#039;t exist in engine
-- Error reading data for table edu_grading.student_year_info: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `edu_grading`.`student_year_info`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--
-- Error reading structure for table edu_grading.subjects: #1932 - Table &#039;edu_grading.subjects&#039; doesn&#039;t exist in engine
-- Error reading data for table edu_grading.subjects: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `edu_grading`.`subjects`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `total_grades_subjects`
--
-- Error reading structure for table edu_grading.total_grades_subjects: #1932 - Table &#039;edu_grading.total_grades_subjects&#039; doesn&#039;t exist in engine
-- Error reading data for table edu_grading.total_grades_subjects: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `edu_grading`.`total_grades_subjects`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `user`
--
-- Error reading structure for table edu_grading.user: #1932 - Table &#039;edu_grading.user&#039; doesn&#039;t exist in engine
-- Error reading data for table edu_grading.user: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `edu_grading`.`user`&#039; at line 1
--
-- Database: `edu_imperial_college`
--
CREATE DATABASE IF NOT EXISTS `edu_imperial_college` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `edu_imperial_college`;

-- --------------------------------------------------------

--
-- Table structure for table `class_result`
--
-- Error reading structure for table edu_imperial_college.class_result: #1932 - Table &#039;edu_imperial_college.class_result&#039; doesn&#039;t exist in engine
-- Error reading data for table edu_imperial_college.class_result: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `edu_imperial_college`.`class_result`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--
-- Error reading structure for table edu_imperial_college.courses: #1932 - Table &#039;edu_imperial_college.courses&#039; doesn&#039;t exist in engine
-- Error reading data for table edu_imperial_college.courses: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `edu_imperial_college`.`courses`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `course_subjects`
--
-- Error reading structure for table edu_imperial_college.course_subjects: #1932 - Table &#039;edu_imperial_college.course_subjects&#039; doesn&#039;t exist in engine
-- Error reading data for table edu_imperial_college.course_subjects: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `edu_imperial_college`.`course_subjects`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `login`
--
-- Error reading structure for table edu_imperial_college.login: #1932 - Table &#039;edu_imperial_college.login&#039; doesn&#039;t exist in engine
-- Error reading data for table edu_imperial_college.login: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `edu_imperial_college`.`login`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `mytable`
--
-- Error reading structure for table edu_imperial_college.mytable: #1932 - Table &#039;edu_imperial_college.mytable&#039; doesn&#039;t exist in engine
-- Error reading data for table edu_imperial_college.mytable: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `edu_imperial_college`.`mytable`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--
-- Error reading structure for table edu_imperial_college.sessions: #1932 - Table &#039;edu_imperial_college.sessions&#039; doesn&#039;t exist in engine
-- Error reading data for table edu_imperial_college.sessions: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `edu_imperial_college`.`sessions`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `student_attendance`
--
-- Error reading structure for table edu_imperial_college.student_attendance: #1932 - Table &#039;edu_imperial_college.student_attendance&#039; doesn&#039;t exist in engine
-- Error reading data for table edu_imperial_college.student_attendance: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `edu_imperial_college`.`student_attendance`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `student_courses`
--
-- Error reading structure for table edu_imperial_college.student_courses: #1932 - Table &#039;edu_imperial_college.student_courses&#039; doesn&#039;t exist in engine
-- Error reading data for table edu_imperial_college.student_courses: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `edu_imperial_college`.`student_courses`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `student_fee`
--
-- Error reading structure for table edu_imperial_college.student_fee: #1932 - Table &#039;edu_imperial_college.student_fee&#039; doesn&#039;t exist in engine
-- Error reading data for table edu_imperial_college.student_fee: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `edu_imperial_college`.`student_fee`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `student_info`
--
-- Error reading structure for table edu_imperial_college.student_info: #1932 - Table &#039;edu_imperial_college.student_info&#039; doesn&#039;t exist in engine
-- Error reading data for table edu_imperial_college.student_info: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `edu_imperial_college`.`student_info`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `teacher_attendance`
--
-- Error reading structure for table edu_imperial_college.teacher_attendance: #1932 - Table &#039;edu_imperial_college.teacher_attendance&#039; doesn&#039;t exist in engine
-- Error reading data for table edu_imperial_college.teacher_attendance: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `edu_imperial_college`.`teacher_attendance`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `teacher_courses`
--
-- Error reading structure for table edu_imperial_college.teacher_courses: #1932 - Table &#039;edu_imperial_college.teacher_courses&#039; doesn&#039;t exist in engine
-- Error reading data for table edu_imperial_college.teacher_courses: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `edu_imperial_college`.`teacher_courses`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `teacher_info`
--
-- Error reading structure for table edu_imperial_college.teacher_info: #1932 - Table &#039;edu_imperial_college.teacher_info&#039; doesn&#039;t exist in engine
-- Error reading data for table edu_imperial_college.teacher_info: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `edu_imperial_college`.`teacher_info`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `teacher_salary_allowances`
--
-- Error reading structure for table edu_imperial_college.teacher_salary_allowances: #1932 - Table &#039;edu_imperial_college.teacher_salary_allowances&#039; doesn&#039;t exist in engine
-- Error reading data for table edu_imperial_college.teacher_salary_allowances: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `edu_imperial_college`.`teacher_salary_allowances`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `teacher_salary_report`
--
-- Error reading structure for table edu_imperial_college.teacher_salary_report: #1932 - Table &#039;edu_imperial_college.teacher_salary_report&#039; doesn&#039;t exist in engine
-- Error reading data for table edu_imperial_college.teacher_salary_report: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `edu_imperial_college`.`teacher_salary_report`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `time_table`
--
-- Error reading structure for table edu_imperial_college.time_table: #1932 - Table &#039;edu_imperial_college.time_table&#039; doesn&#039;t exist in engine
-- Error reading data for table edu_imperial_college.time_table: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `edu_imperial_college`.`time_table`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `weekdays`
--
-- Error reading structure for table edu_imperial_college.weekdays: #1932 - Table &#039;edu_imperial_college.weekdays&#039; doesn&#039;t exist in engine
-- Error reading data for table edu_imperial_college.weekdays: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `edu_imperial_college`.`weekdays`&#039; at line 1
--
-- Database: `eswarigroup_aseinfra`
--
CREATE DATABASE IF NOT EXISTS `eswarigroup_aseinfra` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `eswarigroup_aseinfra`;

-- --------------------------------------------------------

--
-- Table structure for table `aboutus`
--

CREATE TABLE `aboutus` (
  `id` int(11) NOT NULL,
  `title` text NOT NULL,
  `content` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `aboutus`
--

INSERT INTO `aboutus` (`id`, `title`, `content`) VALUES
(1, 'We are the expert on this field better solution.', 'Ours is a group of devoted constructors, enthralled upon ushering you to ecstatic results. We are obliged towards adding bonafide styles to your apartment. Our passion and enthusiasm sustained by the team united efforts, are directed towards sublime results. Raising the bar high is what we immensely love doing.'),
(2, 'Professional Liability', 'Building you reliable future with our lifelong, professional and positive spirit.'),
(3, 'Dedicated To Our Clients', 'Turning indecisive minds into prospective clients with no with authentic claims.'),
(4, 'Outstanding Services', 'Exceptional services carved out keeping our clients best interest in mind.'),
(5, 'Offering the most complete integrated package!', 'One company intact with diversified options, that are not just normal but idiosyncratic, delivered with great professionalism, focused towards harmonious outcomes.');

-- --------------------------------------------------------

--
-- Table structure for table `blog`
--
-- Error reading structure for table eswarigroup_aseinfra.blog: #1932 - Table &#039;eswarigroup_aseinfra.blog&#039; doesn&#039;t exist in engine
-- Error reading data for table eswarigroup_aseinfra.blog: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `eswarigroup_aseinfra`.`blog`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `blog_images`
--
-- Error reading structure for table eswarigroup_aseinfra.blog_images: #1932 - Table &#039;eswarigroup_aseinfra.blog_images&#039; doesn&#039;t exist in engine
-- Error reading data for table eswarigroup_aseinfra.blog_images: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `eswarigroup_aseinfra`.`blog_images`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `login`
--
-- Error reading structure for table eswarigroup_aseinfra.login: #1932 - Table &#039;eswarigroup_aseinfra.login&#039; doesn&#039;t exist in engine
-- Error reading data for table eswarigroup_aseinfra.login: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `eswarigroup_aseinfra`.`login`&#039; at line 1

--
-- Indexes for dumped tables
--

--
-- Indexes for table `aboutus`
--
ALTER TABLE `aboutus`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `aboutus`
--
ALTER TABLE `aboutus`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- Database: `eswarigroup_aseinteriors`
--
CREATE DATABASE IF NOT EXISTS `eswarigroup_aseinteriors` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `eswarigroup_aseinteriors`;

-- --------------------------------------------------------

--
-- Table structure for table `blog`
--
-- Error reading structure for table eswarigroup_aseinteriors.blog: #1932 - Table &#039;eswarigroup_aseinteriors.blog&#039; doesn&#039;t exist in engine
-- Error reading data for table eswarigroup_aseinteriors.blog: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `eswarigroup_aseinteriors`.`blog`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `contact_form`
--
-- Error reading structure for table eswarigroup_aseinteriors.contact_form: #1932 - Table &#039;eswarigroup_aseinteriors.contact_form&#039; doesn&#039;t exist in engine
-- Error reading data for table eswarigroup_aseinteriors.contact_form: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `eswarigroup_aseinteriors`.`contact_form`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `newsletter`
--
-- Error reading structure for table eswarigroup_aseinteriors.newsletter: #1932 - Table &#039;eswarigroup_aseinteriors.newsletter&#039; doesn&#039;t exist in engine
-- Error reading data for table eswarigroup_aseinteriors.newsletter: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `eswarigroup_aseinteriors`.`newsletter`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--
-- Error reading structure for table eswarigroup_aseinteriors.registration: #1932 - Table &#039;eswarigroup_aseinteriors.registration&#039; doesn&#039;t exist in engine
-- Error reading data for table eswarigroup_aseinteriors.registration: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `eswarigroup_aseinteriors`.`registration`&#039; at line 1
--
-- Database: `eswarigroup_eswarigroup`
--
CREATE DATABASE IF NOT EXISTS `eswarigroup_eswarigroup` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `eswarigroup_eswarigroup`;

-- --------------------------------------------------------

--
-- Table structure for table `enquiry_form`
--
-- Error reading structure for table eswarigroup_eswarigroup.enquiry_form: #1932 - Table &#039;eswarigroup_eswarigroup.enquiry_form&#039; doesn&#039;t exist in engine
-- Error reading data for table eswarigroup_eswarigroup.enquiry_form: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `eswarigroup_eswarigroup`.`enquiry_form`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `gallery`
--

CREATE TABLE `gallery` (
  `id` int(11) NOT NULL,
  `title` text NOT NULL,
  `sub_title` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `gallery`
--

INSERT INTO `gallery` (`id`, `title`, `sub_title`) VALUES
(1, 'Bhoomi Pooja-14th October 2021', 'Aganampudi'),
(2, 'Review Meeting 2021', 'Vizag');

-- --------------------------------------------------------

--
-- Table structure for table `gallery_images`
--

CREATE TABLE `gallery_images` (
  `id` int(11) NOT NULL,
  `gallery_id` int(11) NOT NULL,
  `image` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `gallery_images`
--

INSERT INTO `gallery_images` (`id`, `gallery_id`, `image`) VALUES
(1, 1, '1.jpeg'),
(2, 1, '2.jpeg'),
(3, 1, '3.jpeg'),
(4, 1, '4.jpeg'),
(5, 1, '5.jpeg'),
(6, 1, '6.jpeg'),
(7, 1, '7.jpeg'),
(8, 1, '8.jpeg'),
(9, 2, '1_1.jpeg'),
(10, 2, '2_2.jpeg'),
(11, 2, '3_3.jpeg'),
(12, 2, '4_4.jpeg'),
(13, 2, '5_5.jpeg'),
(14, 2, '6_6.jpeg'),
(15, 2, '7_7.jpeg'),
(16, 2, '8_8.jpeg'),
(17, 2, '9.jpeg'),
(18, 2, '10.jpeg'),
(19, 2, '11.jpeg'),
(20, 2, '12.jpeg'),
(21, 2, '13.jpeg'),
(22, 2, '14.jpeg'),
(23, 2, '15.jpeg'),
(24, 2, '16.jpeg'),
(25, 2, '17.jpeg'),
(26, 2, '18.jpeg'),
(27, 2, '19.jpeg'),
(28, 2, '424.jpeg'),
(29, 2, '425.jpeg'),
(30, 2, '426.jpeg'),
(31, 2, '427.jpeg'),
(32, 2, '422.jpeg'),
(33, 2, '421.jpeg'),
(34, 2, '428.jpeg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `gallery`
--
ALTER TABLE `gallery`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gallery_images`
--
ALTER TABLE `gallery_images`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `gallery`
--
ALTER TABLE `gallery`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `gallery_images`
--
ALTER TABLE `gallery_images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;
--
-- Database: `eswarigroup_eswarihomes`
--
CREATE DATABASE IF NOT EXISTS `eswarigroup_eswarihomes` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `eswarigroup_eswarihomes`;

-- --------------------------------------------------------

--
-- Table structure for table `adminusers`
--
-- Error reading structure for table eswarigroup_eswarihomes.adminusers: #1932 - Table &#039;eswarigroup_eswarihomes.adminusers&#039; doesn&#039;t exist in engine
-- Error reading data for table eswarigroup_eswarihomes.adminusers: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `eswarigroup_eswarihomes`.`adminusers`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `blog`
--
-- Error reading structure for table eswarigroup_eswarihomes.blog: #1932 - Table &#039;eswarigroup_eswarihomes.blog&#039; doesn&#039;t exist in engine
-- Error reading data for table eswarigroup_eswarihomes.blog: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `eswarigroup_eswarihomes`.`blog`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `blog_images`
--
-- Error reading structure for table eswarigroup_eswarihomes.blog_images: #1932 - Table &#039;eswarigroup_eswarihomes.blog_images&#039; doesn&#039;t exist in engine
-- Error reading data for table eswarigroup_eswarihomes.blog_images: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `eswarigroup_eswarihomes`.`blog_images`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `bookingproject`
--
-- Error reading structure for table eswarigroup_eswarihomes.bookingproject: #1932 - Table &#039;eswarigroup_eswarihomes.bookingproject&#039; doesn&#039;t exist in engine
-- Error reading data for table eswarigroup_eswarihomes.bookingproject: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `eswarigroup_eswarihomes`.`bookingproject`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `careers`
--
-- Error reading structure for table eswarigroup_eswarihomes.careers: #1932 - Table &#039;eswarigroup_eswarihomes.careers&#039; doesn&#039;t exist in engine
-- Error reading data for table eswarigroup_eswarihomes.careers: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `eswarigroup_eswarihomes`.`careers`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `cities`
--
-- Error reading structure for table eswarigroup_eswarihomes.cities: #1932 - Table &#039;eswarigroup_eswarihomes.cities&#039; doesn&#039;t exist in engine
-- Error reading data for table eswarigroup_eswarihomes.cities: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `eswarigroup_eswarihomes`.`cities`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `contactus`
--
-- Error reading structure for table eswarigroup_eswarihomes.contactus: #1932 - Table &#039;eswarigroup_eswarihomes.contactus&#039; doesn&#039;t exist in engine
-- Error reading data for table eswarigroup_eswarihomes.contactus: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `eswarigroup_eswarihomes`.`contactus`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `credai`
--
-- Error reading structure for table eswarigroup_eswarihomes.credai: #1932 - Table &#039;eswarigroup_eswarihomes.credai&#039; doesn&#039;t exist in engine
-- Error reading data for table eswarigroup_eswarihomes.credai: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `eswarigroup_eswarihomes`.`credai`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `enquiry_form`
--
-- Error reading structure for table eswarigroup_eswarihomes.enquiry_form: #1932 - Table &#039;eswarigroup_eswarihomes.enquiry_form&#039; doesn&#039;t exist in engine
-- Error reading data for table eswarigroup_eswarihomes.enquiry_form: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `eswarigroup_eswarihomes`.`enquiry_form`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `event`
--
-- Error reading structure for table eswarigroup_eswarihomes.event: #1932 - Table &#039;eswarigroup_eswarihomes.event&#039; doesn&#039;t exist in engine
-- Error reading data for table eswarigroup_eswarihomes.event: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `eswarigroup_eswarihomes`.`event`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `event_images`
--
-- Error reading structure for table eswarigroup_eswarihomes.event_images: #1932 - Table &#039;eswarigroup_eswarihomes.event_images&#039; doesn&#039;t exist in engine
-- Error reading data for table eswarigroup_eswarihomes.event_images: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `eswarigroup_eswarihomes`.`event_images`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--
-- Error reading structure for table eswarigroup_eswarihomes.feedback: #1932 - Table &#039;eswarigroup_eswarihomes.feedback&#039; doesn&#039;t exist in engine
-- Error reading data for table eswarigroup_eswarihomes.feedback: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `eswarigroup_eswarihomes`.`feedback`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `feedbackresult`
--
-- Error reading structure for table eswarigroup_eswarihomes.feedbackresult: #1932 - Table &#039;eswarigroup_eswarihomes.feedbackresult&#039; doesn&#039;t exist in engine
-- Error reading data for table eswarigroup_eswarihomes.feedbackresult: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `eswarigroup_eswarihomes`.`feedbackresult`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `login`
--
-- Error reading structure for table eswarigroup_eswarihomes.login: #1932 - Table &#039;eswarigroup_eswarihomes.login&#039; doesn&#039;t exist in engine
-- Error reading data for table eswarigroup_eswarihomes.login: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `eswarigroup_eswarihomes`.`login`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `plot_booking_form`
--
-- Error reading structure for table eswarigroup_eswarihomes.plot_booking_form: #1932 - Table &#039;eswarigroup_eswarihomes.plot_booking_form&#039; doesn&#039;t exist in engine
-- Error reading data for table eswarigroup_eswarihomes.plot_booking_form: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `eswarigroup_eswarihomes`.`plot_booking_form`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `property`
--
-- Error reading structure for table eswarigroup_eswarihomes.property: #1932 - Table &#039;eswarigroup_eswarihomes.property&#039; doesn&#039;t exist in engine
-- Error reading data for table eswarigroup_eswarihomes.property: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `eswarigroup_eswarihomes`.`property`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `property_bkp_21102020`
--
-- Error reading structure for table eswarigroup_eswarihomes.property_bkp_21102020: #1932 - Table &#039;eswarigroup_eswarihomes.property_bkp_21102020&#039; doesn&#039;t exist in engine
-- Error reading data for table eswarigroup_eswarihomes.property_bkp_21102020: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `eswarigroup_eswarihomes`.`property_bkp_21102020`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `property_comments`
--
-- Error reading structure for table eswarigroup_eswarihomes.property_comments: #1932 - Table &#039;eswarigroup_eswarihomes.property_comments&#039; doesn&#039;t exist in engine
-- Error reading data for table eswarigroup_eswarihomes.property_comments: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `eswarigroup_eswarihomes`.`property_comments`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `property_details`
--
-- Error reading structure for table eswarigroup_eswarihomes.property_details: #1932 - Table &#039;eswarigroup_eswarihomes.property_details&#039; doesn&#039;t exist in engine
-- Error reading data for table eswarigroup_eswarihomes.property_details: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `eswarigroup_eswarihomes`.`property_details`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `property_images`
--
-- Error reading structure for table eswarigroup_eswarihomes.property_images: #1932 - Table &#039;eswarigroup_eswarihomes.property_images&#039; doesn&#039;t exist in engine
-- Error reading data for table eswarigroup_eswarihomes.property_images: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `eswarigroup_eswarihomes`.`property_images`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `sales_link_to_customer`
--
-- Error reading structure for table eswarigroup_eswarihomes.sales_link_to_customer: #1932 - Table &#039;eswarigroup_eswarihomes.sales_link_to_customer&#039; doesn&#039;t exist in engine
-- Error reading data for table eswarigroup_eswarihomes.sales_link_to_customer: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `eswarigroup_eswarihomes`.`sales_link_to_customer`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `selfie_pic`
--
-- Error reading structure for table eswarigroup_eswarihomes.selfie_pic: #1932 - Table &#039;eswarigroup_eswarihomes.selfie_pic&#039; doesn&#039;t exist in engine
-- Error reading data for table eswarigroup_eswarihomes.selfie_pic: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `eswarigroup_eswarihomes`.`selfie_pic`&#039; at line 1
--
-- Database: `eswarigroup_visitordata`
--
CREATE DATABASE IF NOT EXISTS `eswarigroup_visitordata` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `eswarigroup_visitordata`;

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--
-- Error reading structure for table eswarigroup_visitordata.registration: #1932 - Table &#039;eswarigroup_visitordata.registration&#039; doesn&#039;t exist in engine
-- Error reading data for table eswarigroup_visitordata.registration: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `eswarigroup_visitordata`.`registration`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `visitordata`
--
-- Error reading structure for table eswarigroup_visitordata.visitordata: #1932 - Table &#039;eswarigroup_visitordata.visitordata&#039; doesn&#039;t exist in engine
-- Error reading data for table eswarigroup_visitordata.visitordata: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `eswarigroup_visitordata`.`visitordata`&#039; at line 1
--
-- Database: `eswarigr_ase`
--
CREATE DATABASE IF NOT EXISTS `eswarigr_ase` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `eswarigr_ase`;

-- --------------------------------------------------------

--
-- Table structure for table `blog`
--
-- Error reading structure for table eswarigr_ase.blog: #1932 - Table &#039;eswarigr_ase.blog&#039; doesn&#039;t exist in engine
-- Error reading data for table eswarigr_ase.blog: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `eswarigr_ase`.`blog`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `blog_images`
--
-- Error reading structure for table eswarigr_ase.blog_images: #1932 - Table &#039;eswarigr_ase.blog_images&#039; doesn&#039;t exist in engine
-- Error reading data for table eswarigr_ase.blog_images: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `eswarigr_ase`.`blog_images`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `demo_form`
--

CREATE TABLE `demo_form` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `company_name` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `website_type` varchar(20) NOT NULL,
  `logo` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `demo_form`
--

INSERT INTO `demo_form` (`id`, `name`, `company_name`, `email`, `phone`, `website_type`, `logo`) VALUES
(1, 'chandu', 'ase tech', 'chandhu418@gmail.com', '9010402324', 'Restaurant', '6.png'),
(2, 'Test', 'ase tech', 'chandhu418@gmail.com', '9010402324', 'School', 'specials-2.jpg'),
(3, 'Test', 'Eswarihomes', 'chandhu418@gmail.com', '9010402324', 'RealEstae', 'E.png'),
(4, 'chandu', 'aseinfra', 'info@eswarigroup.com', '9010402324', 'Interior', 'aseinfralogo.jpg'),
(5, 'chandu', 'Eswarihomes', 'info@eswarigroup.com', '9010402324', 'School', '4.png'),
(6, 'chandu', 'Eswarihomes', 'info@eswarigroup.com', '9010402324', 'School', '4.png'),
(7, 'chandu', 'ase tech', 'info@eswarigroup.com', '9010402324', 'Consultancy', 'demo_websitelogo.png'),
(8, 'chandu', 'Ase Tech', 'chandhu418@gmail.com', '9010402324', 'Software', 'demo_websitelogo.png'),
(9, 'chandu', 'Eswarihomes', 'chandhu418@gmail.com', '9010402324', 'carrent', '7.png'),
(10, 'chandu', 'ase tech', 'info@eswarigroup.com', '9010402324', 'job-consultancy', '7.png'),
(11, '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `enquiry_form`
--

CREATE TABLE `enquiry_form` (
  `id` int(11) NOT NULL,
  `first_name` varchar(55) NOT NULL,
  `last_name` varchar(55) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `comments` text NOT NULL,
  `business_name` varchar(100) NOT NULL,
  `business_category` varchar(255) NOT NULL,
  `requirement` varchar(55) NOT NULL,
  `added_on` timestamp(6) NOT NULL DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `enquiry_form`
--

INSERT INTO `enquiry_form` (`id`, `first_name`, `last_name`, `email`, `phone`, `comments`, `business_name`, `business_category`, `requirement`, `added_on`) VALUES
(1, 'Chandu', 'V', 'chandhu418@gmail.com', '9010402324', 'hiiiiiiiiiiii', 'realestae', 'realestate', 'Website design', '2022-06-11 04:21:46.326158'),
(2, 'Test by Chandra', 'Shekher', 'chandhu418@gmail.com', '9010402324', 'hi this is test', 'realestae', 'realestate', 'Logo Designings', '2022-06-11 04:21:46.326158'),
(3, 'Mohit', 'Tiwari', 'dinkisinelogix@gmail.com', '9979553686', 'Hello,\nI hope you are doing well.\nI came to know from various resources that you are planning to hire website developers.\n\nWe Sinelogix Technologies is a Website Design and Development company based out in Bangalore, India. We have been working in the website business from the last 10 years and supporting various technologies like Magento, WordPress, Laravel, Codeigniter, PHP, HTML etc.\n\nPlease check our LinkedIn profile: https://www.linkedin.com/company/sinelogix-technology/?originalSubdomain=in\nWebsite : https://www.sinelogix.com/\n\n\nHere is our cost:\n1. Sr.PHP developer with 3-5 years of experience : 65000 INR per month\n2. Sr. Laravel developer with more than 3-5 years of experience : 70000 INR per month\n3. Sr. WordPress/Woo-Commerce developer with 3-5 years of experience: 60000 INR per month\n4. Magento developer with 3-5 years of experience: 65000 INR per month\n5. SEO Engineer with 3-5 Experience : 25000 INR per month (Can Handle 4 projects at a time).\n\n\nAll the senior developers we will assign will have very good experience in Theme Development, API development, Plugin Development, Customization, Payment customization or integration, etc, with the Developer, we will also assign one Project Manager and tester.\n\nWe can manage all the tasks on Jira, Trello, Slack so that we both are on the same page.\n\nPayment Term:\nThere is no advance, we can sign monthly contracts and you can pay every month.\n\nIf you are looking for any help please email me at mohit.tiwari@sinelogix.com or whatsapp me at +15105139121 or +91 8980898451 / +91 9979553686 My Skype is: itsdennismiller', 'Sinelogix Technologies', 'Sinelogix Technologies', 'Website design', '2023-01-25 06:16:47.489598'),
(4, 'Jose', 'Jose', 'jose@autoprensa.com', '632555033', 'Buenas tardes, encantado de saludarte. Soy Jose\nQuerÃ­a escribirte porque me ha parecido interesante comentar contigo la posibilidad de que tu negocio aparezca cada mes en periÃ³dicos digitales como noticia para posicionar en los primeros lugares de internet, es decir, con artÃ­culos reales dentro del periÃ³dico que no se marcan como publicidad y que no se borran.\nLa noticia es publicada por mÃ¡s de cuarenta periÃ³dicos de gran autoridad para mejorar el posicionamiento de tu web y la reputaciÃ³n.\n\nÂ¿PodrÃ­as facilitarme un telÃ©fono para ofrecerte un mes gratuito?\nGracias', 'Jose', 'AutoPrensa', 'Website design', '2023-02-06 02:44:53.904571'),
(5, 'Ava', 'Carter', 'Ava@yourguestblogger.com', '2032868663', '\nHello,\nI just saw your article https://www.articleted.com/article/617994/199237/Content-writing-services-in-Visakhapatnam\n\nsigns/ and would like to know if you are looking for some more guest posts like that one. You could\nalso forward this email to your current SEO company We&#39;ll partner to get the best results for your\nwebsite.\nWe are looking forward to hearing from you.\n\nThanks\nAva Carter\nWeb Site: www.guest-post-service.com/\n\nDon&#39;t want to receive any more email from us? Reply NO.', 'Guest Post Service', 'Guest Post Service', 'Mobile Apps', '2023-04-14 11:26:05.848837'),
(6, 'Ava', 'Carter', 'Ava@yourguestblogger.com', '2032868663', '\nHello,\nI just saw your article https://www.articleted.com/article/617994/199237/Content-writing-services-in-Visakhapatnam\n\nsigns/ and would like to know if you are looking for some more guest posts like that one. You could\nalso forward this email to your current SEO company We&#39;ll partner to get the best results for your\nwebsite.\nWe are looking forward to hearing from you.\n\nThanks\nAva Carter\nWeb Site: www.guest-post-service.com/\n\nDon&#39;t want to receive any more email from us? Reply NO.', 'Guest Post Service', 'Guest Post Service', 'Mobile Apps', '2023-04-14 11:26:05.853398'),
(7, 'Ava', 'Carter', 'Ava@yourguestblogger.com', '2032868663', '\nHello,\nI just saw your article https://www.articleted.com/article/617994/199237/Content-writing-services-in-Visakhapatnam\n\nsigns/ and would like to know if you are looking for some more guest posts like that one. You could\nalso forward this email to your current SEO company We&#39;ll partner to get the best results for your\nwebsite.\nWe are looking forward to hearing from you.\n\nThanks\nAva Carter\nWeb Site: www.guest-post-service.com/\n\nDon&#39;t want to receive any more email from us? Reply NO.', 'Guest Post Service', 'Guest Post Service', 'Mobile Apps', '2023-04-14 11:26:05.859693');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--
-- Error reading structure for table eswarigr_ase.login: #1932 - Table &#039;eswarigr_ase.login&#039; doesn&#039;t exist in engine
-- Error reading data for table eswarigr_ase.login: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `eswarigr_ase`.`login`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--
-- Error reading structure for table eswarigr_ase.registration: #1932 - Table &#039;eswarigr_ase.registration&#039; doesn&#039;t exist in engine
-- Error reading data for table eswarigr_ase.registration: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `eswarigr_ase`.`registration`&#039; at line 1

--
-- Indexes for dumped tables
--

--
-- Indexes for table `demo_form`
--
ALTER TABLE `demo_form`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `enquiry_form`
--
ALTER TABLE `enquiry_form`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `demo_form`
--
ALTER TABLE `demo_form`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `enquiry_form`
--
ALTER TABLE `enquiry_form`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- Database: `eswarigr_eswarigr_group`
--
CREATE DATABASE IF NOT EXISTS `eswarigr_eswarigr_group` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `eswarigr_eswarigr_group`;

-- --------------------------------------------------------

--
-- Table structure for table `activities`
--
-- Error reading structure for table eswarigr_eswarigr_group.activities: #1932 - Table &#039;eswarigr_eswarigr_group.activities&#039; doesn&#039;t exist in engine
-- Error reading data for table eswarigr_eswarigr_group.activities: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `eswarigr_eswarigr_group`.`activities`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `activity_images`
--
-- Error reading structure for table eswarigr_eswarigr_group.activity_images: #1932 - Table &#039;eswarigr_eswarigr_group.activity_images&#039; doesn&#039;t exist in engine
-- Error reading data for table eswarigr_eswarigr_group.activity_images: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `eswarigr_eswarigr_group`.`activity_images`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `contact_form`
--
-- Error reading structure for table eswarigr_eswarigr_group.contact_form: #1932 - Table &#039;eswarigr_eswarigr_group.contact_form&#039; doesn&#039;t exist in engine
-- Error reading data for table eswarigr_eswarigr_group.contact_form: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `eswarigr_eswarigr_group`.`contact_form`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `enquiry_form`
--
-- Error reading structure for table eswarigr_eswarigr_group.enquiry_form: #1932 - Table &#039;eswarigr_eswarigr_group.enquiry_form&#039; doesn&#039;t exist in engine
-- Error reading data for table eswarigr_eswarigr_group.enquiry_form: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `eswarigr_eswarigr_group`.`enquiry_form`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `gallery`
--

CREATE TABLE `gallery` (
  `id` int(11) NOT NULL,
  `title` text NOT NULL,
  `sub_title` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `gallery`
--

INSERT INTO `gallery` (`id`, `title`, `sub_title`) VALUES
(1, 'Bhoomi Pooja-14th October 2021', 'Aganampudi'),
(2, 'Review Meeting 2021', 'Vizag'),
(3, 'Activities & Vistis', 'Vizag'),
(4, 'Diwali  Celebrations 2022', 'Vizag'),
(5, 'New Year Celebrations 2023', 'Vizag'),
(6, 'Pongal Celebrations 2023', 'Vizag'),
(7, 'Republic Day Celebrations 2023', 'Vizag'),
(8, 'Sports meet 2022', 'Vizag');

-- --------------------------------------------------------

--
-- Table structure for table `gallery_image`
--

CREATE TABLE `gallery_image` (
  `id` int(11) NOT NULL,
  `gallery_id` int(11) NOT NULL,
  `image` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `gallery_image`
--

INSERT INTO `gallery_image` (`id`, `gallery_id`, `image`) VALUES
(1, 1, '1.jpeg'),
(2, 1, '2.jpeg'),
(3, 1, '3.jpeg'),
(4, 1, '4.jpeg'),
(5, 1, '5.jpeg'),
(6, 1, '6.jpeg'),
(7, 1, '7.jpeg'),
(8, 1, '8.jpeg'),
(9, 2, '1_1.jpeg'),
(10, 2, '2_2.jpeg'),
(11, 2, '3_3.jpeg'),
(12, 2, '4_4.jpeg'),
(13, 2, '5_5.jpeg'),
(14, 2, '6_6.jpeg'),
(15, 2, '7_7.jpeg'),
(16, 2, '8_8.jpeg'),
(17, 2, '9.jpeg'),
(18, 2, '10.jpeg'),
(19, 2, '11.jpeg'),
(20, 2, '12.jpeg'),
(21, 2, '13.jpeg'),
(22, 2, '14.jpeg'),
(23, 2, '15.jpeg'),
(24, 2, '16.jpeg'),
(25, 2, '17.jpeg'),
(26, 2, '18.jpeg'),
(27, 2, '19.jpeg'),
(28, 2, '424.jpeg'),
(29, 2, '425.jpeg'),
(30, 2, '426.jpeg'),
(31, 2, '427.jpeg'),
(32, 2, '422.jpeg'),
(33, 2, '421.jpeg'),
(34, 2, '428.jpeg'),
(35, 3, '301.jpg'),
(36, 3, '302.jpg'),
(37, 3, '303.jpg'),
(38, 3, '304.jpg'),
(39, 3, '305.jpg'),
(40, 3, '306.jpg'),
(41, 3, '307.jpg'),
(42, 3, '308.jpg'),
(43, 3, '309.jpg'),
(44, 4, '4001.jpg'),
(45, 4, '4002.jpg'),
(46, 4, '4003.jpg'),
(47, 4, '4004.jpg'),
(48, 4, '4005.jpg'),
(49, 4, '4006.jpg'),
(50, 4, '4007.jpg'),
(51, 4, '4008.jpg'),
(52, 4, '4009.jpg'),
(53, 4, '4010.jpg'),
(54, 4, '4011.jpg'),
(55, 5, '5001.jpg'),
(56, 5, '5002.jpg'),
(57, 5, '5003.jpg'),
(58, 5, '5004.jpg'),
(59, 5, '5005.jpg'),
(60, 5, '5006.jpg'),
(61, 5, '5007.jpg'),
(62, 5, '5008.jpg'),
(63, 5, '5009.jpg'),
(64, 5, '5010.jpg'),
(65, 6, '6001.jpg'),
(66, 6, '6002.jpg'),
(67, 6, '6003.jpg'),
(68, 6, '6004.jpg'),
(69, 6, '6005.jpg'),
(70, 6, '6006.jpg'),
(71, 6, '6007.jpg'),
(72, 6, '6008.jpg'),
(73, 6, '6009.jpg'),
(74, 6, '6010.jpg'),
(75, 7, '7001.jpg'),
(76, 7, '7002.jpg'),
(77, 7, '7003.jpg'),
(78, 7, '7004.jpg'),
(79, 7, '7005.jpg'),
(80, 7, '7006.jpg'),
(81, 7, '7007.jpg'),
(82, 7, '7008.jpg'),
(83, 7, '7009.jpg'),
(84, 8, '8001.jpg'),
(85, 8, '8002.jpg'),
(86, 8, '8003.jpg'),
(87, 8, '8004.jpg'),
(88, 8, '8005.jpg'),
(89, 8, '8006.jpg'),
(90, 8, '8007.jpg'),
(91, 8, '8008.jpg'),
(92, 8, '8009.jpg'),
(93, 8, '8010.jpg'),
(94, 8, '8011.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `gallery_images`
--

CREATE TABLE `gallery_images` (
  `id` int(11) NOT NULL,
  `gallery_id` int(11) NOT NULL,
  `image` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `gallery_images`
--

INSERT INTO `gallery_images` (`id`, `gallery_id`, `image`) VALUES
(1, 1, '1.jpeg'),
(2, 1, '2.jpeg'),
(3, 1, '3.jpeg'),
(4, 1, '4.jpeg'),
(5, 1, '5.jpeg'),
(6, 1, '6.jpeg'),
(7, 1, '7.jpeg'),
(8, 1, '8.jpeg'),
(9, 2, '1_1.jpeg'),
(10, 2, '2_2.jpeg'),
(11, 2, '3_3.jpeg'),
(12, 2, '4_4.jpeg'),
(13, 2, '5_5.jpeg'),
(14, 2, '6_6.jpeg'),
(15, 2, '7_7.jpeg'),
(16, 2, '8_8.jpeg'),
(17, 2, '9.jpeg'),
(18, 2, '10.jpeg'),
(19, 2, '11.jpeg'),
(20, 2, '12.jpeg'),
(21, 2, '13.jpeg'),
(22, 2, '14.jpeg'),
(23, 2, '15.jpeg'),
(24, 2, '16.jpeg'),
(25, 2, '17.jpeg'),
(26, 2, '18.jpeg'),
(27, 2, '19.jpeg'),
(28, 2, '424.jpeg'),
(29, 2, '425.jpeg'),
(30, 2, '426.jpeg'),
(31, 2, '427.jpeg'),
(32, 2, '422.jpeg'),
(33, 2, '421.jpeg'),
(34, 2, '428.jpeg'),
(35, 3, '301.jpg'),
(36, 3, '302.jpg'),
(37, 3, '303.jpg'),
(38, 3, '304.jpg'),
(39, 3, '305.jpg'),
(40, 3, '306.jpg'),
(41, 3, '307.jpg'),
(42, 3, '308.jpg'),
(43, 3, '309.jpg'),
(44, 4, '4001.jpg'),
(45, 4, '4002.jpg'),
(46, 4, '4003.jpg'),
(47, 4, '4004.jpg'),
(48, 4, '4005.jpg'),
(49, 4, '4006.jpg'),
(50, 4, '4007.jpg'),
(51, 4, '4008.jpg'),
(52, 4, '4009.jpg'),
(53, 4, '4010.jpg'),
(54, 4, '4011.jpg'),
(55, 5, '5001.jpg'),
(56, 5, '5002.jpg'),
(57, 5, '5003.jpg'),
(58, 5, '5004.jpg'),
(59, 5, '5005.jpg'),
(60, 5, '5006.jpg'),
(61, 5, '5007.jpg'),
(62, 5, '5008.jpg'),
(63, 5, '5009.jpg'),
(64, 5, '5010.jpg'),
(65, 6, '6001.jpg'),
(66, 6, '6002.jpg'),
(67, 6, '6003.jpg'),
(68, 6, '6004.jpg'),
(69, 6, '6005.jpg'),
(70, 6, '6006.jpg'),
(71, 6, '6007.jpg'),
(72, 6, '6008.jpg'),
(73, 6, '6009.jpg'),
(74, 6, '6010.jpg'),
(75, 7, '7001.jpg'),
(76, 7, '7002.jpg'),
(77, 7, '7003.jpg'),
(78, 7, '7004.jpg'),
(79, 7, '7005.jpg'),
(80, 7, '7006.jpg'),
(81, 7, '7007.jpg'),
(82, 7, '7008.jpg'),
(83, 7, '7009.jpg'),
(84, 8, '8001.jpg'),
(85, 8, '8002.jpg'),
(86, 8, '8003.jpg'),
(87, 8, '8004.jpg'),
(88, 8, '8005.jpg'),
(89, 8, '8006.jpg'),
(90, 8, '8007.jpg'),
(91, 8, '8008.jpg'),
(92, 8, '8009.jpg'),
(93, 8, '8010.jpg'),
(94, 8, '8011.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `gallery_images_test`
--
-- Error reading structure for table eswarigr_eswarigr_group.gallery_images_test: #1932 - Table &#039;eswarigr_eswarigr_group.gallery_images_test&#039; doesn&#039;t exist in engine
-- Error reading data for table eswarigr_eswarigr_group.gallery_images_test: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `eswarigr_eswarigr_group`.`gallery_images_test`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--
-- Error reading structure for table eswarigr_eswarigr_group.registration: #1932 - Table &#039;eswarigr_eswarigr_group.registration&#039; doesn&#039;t exist in engine
-- Error reading data for table eswarigr_eswarigr_group.registration: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `eswarigr_eswarigr_group`.`registration`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `users`
--
-- Error reading structure for table eswarigr_eswarigr_group.users: #1932 - Table &#039;eswarigr_eswarigr_group.users&#039; doesn&#039;t exist in engine
-- Error reading data for table eswarigr_eswarigr_group.users: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `eswarigr_eswarigr_group`.`users`&#039; at line 1

--
-- Indexes for dumped tables
--

--
-- Indexes for table `gallery`
--
ALTER TABLE `gallery`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gallery_image`
--
ALTER TABLE `gallery_image`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gallery_images`
--
ALTER TABLE `gallery_images`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `gallery`
--
ALTER TABLE `gallery`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `gallery_image`
--
ALTER TABLE `gallery_image`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=95;

--
-- AUTO_INCREMENT for table `gallery_images`
--
ALTER TABLE `gallery_images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=95;
--
-- Database: `eswarigr_parimidentalcare`
--
CREATE DATABASE IF NOT EXISTS `eswarigr_parimidentalcare` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `eswarigr_parimidentalcare`;

-- --------------------------------------------------------

--
-- Table structure for table `blog`
--
-- Error reading structure for table eswarigr_parimidentalcare.blog: #1932 - Table &#039;eswarigr_parimidentalcare.blog&#039; doesn&#039;t exist in engine
-- Error reading data for table eswarigr_parimidentalcare.blog: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `eswarigr_parimidentalcare`.`blog`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `contact_form`
--
-- Error reading structure for table eswarigr_parimidentalcare.contact_form: #1932 - Table &#039;eswarigr_parimidentalcare.contact_form&#039; doesn&#039;t exist in engine
-- Error reading data for table eswarigr_parimidentalcare.contact_form: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `eswarigr_parimidentalcare`.`contact_form`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `gallery`
--
-- Error reading structure for table eswarigr_parimidentalcare.gallery: #1932 - Table &#039;eswarigr_parimidentalcare.gallery&#039; doesn&#039;t exist in engine
-- Error reading data for table eswarigr_parimidentalcare.gallery: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `eswarigr_parimidentalcare`.`gallery`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--
-- Error reading structure for table eswarigr_parimidentalcare.registration: #1932 - Table &#039;eswarigr_parimidentalcare.registration&#039; doesn&#039;t exist in engine
-- Error reading data for table eswarigr_parimidentalcare.registration: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `eswarigr_parimidentalcare`.`registration`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `testimonials`
--
-- Error reading structure for table eswarigr_parimidentalcare.testimonials: #1932 - Table &#039;eswarigr_parimidentalcare.testimonials&#039; doesn&#039;t exist in engine
-- Error reading data for table eswarigr_parimidentalcare.testimonials: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `eswarigr_parimidentalcare`.`testimonials`&#039; at line 1
--
-- Database: `hii`
--
CREATE DATABASE IF NOT EXISTS `hii` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `hii`;

-- --------------------------------------------------------

--
-- Table structure for table `comment_box`
--
-- Error reading structure for table hii.comment_box: #1932 - Table &#039;hii.comment_box&#039; doesn&#039;t exist in engine
-- Error reading data for table hii.comment_box: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `hii`.`comment_box`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--
-- Error reading structure for table hii.registration: #1932 - Table &#039;hii.registration&#039; doesn&#039;t exist in engine
-- Error reading data for table hii.registration: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `hii`.`registration`&#039; at line 1
--
-- Database: `phpmyadmin`
--
CREATE DATABASE IF NOT EXISTS `phpmyadmin` DEFAULT CHARACTER SET utf8 COLLATE utf8_bin;
USE `phpmyadmin`;

-- --------------------------------------------------------

--
-- Table structure for table `pma__bookmark`
--

CREATE TABLE `pma__bookmark` (
  `id` int(10) UNSIGNED NOT NULL,
  `dbase` varchar(255) NOT NULL DEFAULT '',
  `user` varchar(255) NOT NULL DEFAULT '',
  `label` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `query` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Bookmarks';

-- --------------------------------------------------------

--
-- Table structure for table `pma__central_columns`
--

CREATE TABLE `pma__central_columns` (
  `db_name` varchar(64) NOT NULL,
  `col_name` varchar(64) NOT NULL,
  `col_type` varchar(64) NOT NULL,
  `col_length` text DEFAULT NULL,
  `col_collation` varchar(64) NOT NULL,
  `col_isNull` tinyint(1) NOT NULL,
  `col_extra` varchar(255) DEFAULT '',
  `col_default` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Central list of columns';

-- --------------------------------------------------------

--
-- Table structure for table `pma__column_info`
--

CREATE TABLE `pma__column_info` (
  `id` int(5) UNSIGNED NOT NULL,
  `db_name` varchar(64) NOT NULL DEFAULT '',
  `table_name` varchar(64) NOT NULL DEFAULT '',
  `column_name` varchar(64) NOT NULL DEFAULT '',
  `comment` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `mimetype` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `transformation` varchar(255) NOT NULL DEFAULT '',
  `transformation_options` varchar(255) NOT NULL DEFAULT '',
  `input_transformation` varchar(255) NOT NULL DEFAULT '',
  `input_transformation_options` varchar(255) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Column information for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__designer_settings`
--

CREATE TABLE `pma__designer_settings` (
  `username` varchar(64) NOT NULL,
  `settings_data` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Settings related to Designer';

-- --------------------------------------------------------

--
-- Table structure for table `pma__export_templates`
--

CREATE TABLE `pma__export_templates` (
  `id` int(5) UNSIGNED NOT NULL,
  `username` varchar(64) NOT NULL,
  `export_type` varchar(10) NOT NULL,
  `template_name` varchar(64) NOT NULL,
  `template_data` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Saved export templates';

-- --------------------------------------------------------

--
-- Table structure for table `pma__favorite`
--

CREATE TABLE `pma__favorite` (
  `username` varchar(64) NOT NULL,
  `tables` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Favorite tables';

-- --------------------------------------------------------

--
-- Table structure for table `pma__history`
--

CREATE TABLE `pma__history` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `username` varchar(64) NOT NULL DEFAULT '',
  `db` varchar(64) NOT NULL DEFAULT '',
  `table` varchar(64) NOT NULL DEFAULT '',
  `timevalue` timestamp NOT NULL DEFAULT current_timestamp(),
  `sqlquery` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='SQL history for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__navigationhiding`
--

CREATE TABLE `pma__navigationhiding` (
  `username` varchar(64) NOT NULL,
  `item_name` varchar(64) NOT NULL,
  `item_type` varchar(64) NOT NULL,
  `db_name` varchar(64) NOT NULL,
  `table_name` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Hidden items of navigation tree';

-- --------------------------------------------------------

--
-- Table structure for table `pma__pdf_pages`
--

CREATE TABLE `pma__pdf_pages` (
  `db_name` varchar(64) NOT NULL DEFAULT '',
  `page_nr` int(10) UNSIGNED NOT NULL,
  `page_descr` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='PDF relation pages for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__recent`
--

CREATE TABLE `pma__recent` (
  `username` varchar(64) NOT NULL,
  `tables` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Recently accessed tables';

-- --------------------------------------------------------

--
-- Table structure for table `pma__relation`
--

CREATE TABLE `pma__relation` (
  `master_db` varchar(64) NOT NULL DEFAULT '',
  `master_table` varchar(64) NOT NULL DEFAULT '',
  `master_field` varchar(64) NOT NULL DEFAULT '',
  `foreign_db` varchar(64) NOT NULL DEFAULT '',
  `foreign_table` varchar(64) NOT NULL DEFAULT '',
  `foreign_field` varchar(64) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Relation table';

-- --------------------------------------------------------

--
-- Table structure for table `pma__savedsearches`
--

CREATE TABLE `pma__savedsearches` (
  `id` int(5) UNSIGNED NOT NULL,
  `username` varchar(64) NOT NULL DEFAULT '',
  `db_name` varchar(64) NOT NULL DEFAULT '',
  `search_name` varchar(64) NOT NULL DEFAULT '',
  `search_data` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Saved searches';

-- --------------------------------------------------------

--
-- Table structure for table `pma__table_coords`
--

CREATE TABLE `pma__table_coords` (
  `db_name` varchar(64) NOT NULL DEFAULT '',
  `table_name` varchar(64) NOT NULL DEFAULT '',
  `pdf_page_number` int(11) NOT NULL DEFAULT 0,
  `x` float UNSIGNED NOT NULL DEFAULT 0,
  `y` float UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Table coordinates for phpMyAdmin PDF output';

-- --------------------------------------------------------

--
-- Table structure for table `pma__table_info`
--

CREATE TABLE `pma__table_info` (
  `db_name` varchar(64) NOT NULL DEFAULT '',
  `table_name` varchar(64) NOT NULL DEFAULT '',
  `display_field` varchar(64) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Table information for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__table_uiprefs`
--

CREATE TABLE `pma__table_uiprefs` (
  `username` varchar(64) NOT NULL,
  `db_name` varchar(64) NOT NULL,
  `table_name` varchar(64) NOT NULL,
  `prefs` text NOT NULL,
  `last_update` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Tables'' UI preferences';

-- --------------------------------------------------------

--
-- Table structure for table `pma__tracking`
--

CREATE TABLE `pma__tracking` (
  `db_name` varchar(64) NOT NULL,
  `table_name` varchar(64) NOT NULL,
  `version` int(10) UNSIGNED NOT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` datetime NOT NULL,
  `schema_snapshot` text NOT NULL,
  `schema_sql` text DEFAULT NULL,
  `data_sql` longtext DEFAULT NULL,
  `tracking` set('UPDATE','REPLACE','INSERT','DELETE','TRUNCATE','CREATE DATABASE','ALTER DATABASE','DROP DATABASE','CREATE TABLE','ALTER TABLE','RENAME TABLE','DROP TABLE','CREATE INDEX','DROP INDEX','CREATE VIEW','ALTER VIEW','DROP VIEW') DEFAULT NULL,
  `tracking_active` int(1) UNSIGNED NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Database changes tracking for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__userconfig`
--

CREATE TABLE `pma__userconfig` (
  `username` varchar(64) NOT NULL,
  `timevalue` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `config_data` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='User preferences storage for phpMyAdmin';

--
-- Dumping data for table `pma__userconfig`
--

INSERT INTO `pma__userconfig` (`username`, `timevalue`, `config_data`) VALUES
('root', '2023-07-31 12:27:45', '{\"Console\\/Mode\":\"collapse\"}');

-- --------------------------------------------------------

--
-- Table structure for table `pma__usergroups`
--

CREATE TABLE `pma__usergroups` (
  `usergroup` varchar(64) NOT NULL,
  `tab` varchar(64) NOT NULL,
  `allowed` enum('Y','N') NOT NULL DEFAULT 'N'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='User groups with configured menu items';

-- --------------------------------------------------------

--
-- Table structure for table `pma__users`
--

CREATE TABLE `pma__users` (
  `username` varchar(64) NOT NULL,
  `usergroup` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Users and their assignments to user groups';

--
-- Indexes for dumped tables
--

--
-- Indexes for table `pma__bookmark`
--
ALTER TABLE `pma__bookmark`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pma__central_columns`
--
ALTER TABLE `pma__central_columns`
  ADD PRIMARY KEY (`db_name`,`col_name`);

--
-- Indexes for table `pma__column_info`
--
ALTER TABLE `pma__column_info`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `db_name` (`db_name`,`table_name`,`column_name`);

--
-- Indexes for table `pma__designer_settings`
--
ALTER TABLE `pma__designer_settings`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `pma__export_templates`
--
ALTER TABLE `pma__export_templates`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `u_user_type_template` (`username`,`export_type`,`template_name`);

--
-- Indexes for table `pma__favorite`
--
ALTER TABLE `pma__favorite`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `pma__history`
--
ALTER TABLE `pma__history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `username` (`username`,`db`,`table`,`timevalue`);

--
-- Indexes for table `pma__navigationhiding`
--
ALTER TABLE `pma__navigationhiding`
  ADD PRIMARY KEY (`username`,`item_name`,`item_type`,`db_name`,`table_name`);

--
-- Indexes for table `pma__pdf_pages`
--
ALTER TABLE `pma__pdf_pages`
  ADD PRIMARY KEY (`page_nr`),
  ADD KEY `db_name` (`db_name`);

--
-- Indexes for table `pma__recent`
--
ALTER TABLE `pma__recent`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `pma__relation`
--
ALTER TABLE `pma__relation`
  ADD PRIMARY KEY (`master_db`,`master_table`,`master_field`),
  ADD KEY `foreign_field` (`foreign_db`,`foreign_table`);

--
-- Indexes for table `pma__savedsearches`
--
ALTER TABLE `pma__savedsearches`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `u_savedsearches_username_dbname` (`username`,`db_name`,`search_name`);

--
-- Indexes for table `pma__table_coords`
--
ALTER TABLE `pma__table_coords`
  ADD PRIMARY KEY (`db_name`,`table_name`,`pdf_page_number`);

--
-- Indexes for table `pma__table_info`
--
ALTER TABLE `pma__table_info`
  ADD PRIMARY KEY (`db_name`,`table_name`);

--
-- Indexes for table `pma__table_uiprefs`
--
ALTER TABLE `pma__table_uiprefs`
  ADD PRIMARY KEY (`username`,`db_name`,`table_name`);

--
-- Indexes for table `pma__tracking`
--
ALTER TABLE `pma__tracking`
  ADD PRIMARY KEY (`db_name`,`table_name`,`version`);

--
-- Indexes for table `pma__userconfig`
--
ALTER TABLE `pma__userconfig`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `pma__usergroups`
--
ALTER TABLE `pma__usergroups`
  ADD PRIMARY KEY (`usergroup`,`tab`,`allowed`);

--
-- Indexes for table `pma__users`
--
ALTER TABLE `pma__users`
  ADD PRIMARY KEY (`username`,`usergroup`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `pma__bookmark`
--
ALTER TABLE `pma__bookmark`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pma__column_info`
--
ALTER TABLE `pma__column_info`
  MODIFY `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pma__export_templates`
--
ALTER TABLE `pma__export_templates`
  MODIFY `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pma__history`
--
ALTER TABLE `pma__history`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pma__pdf_pages`
--
ALTER TABLE `pma__pdf_pages`
  MODIFY `page_nr` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pma__savedsearches`
--
ALTER TABLE `pma__savedsearches`
  MODIFY `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- Database: `project_applei`
--
CREATE DATABASE IF NOT EXISTS `project_applei` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `project_applei`;

-- --------------------------------------------------------

--
-- Table structure for table `form`
--
-- Error reading structure for table project_applei.form: #1932 - Table &#039;project_applei.form&#039; doesn&#039;t exist in engine
-- Error reading data for table project_applei.form: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `project_applei`.`form`&#039; at line 1
--
-- Database: `project_parimisdentalcare`
--
CREATE DATABASE IF NOT EXISTS `project_parimisdentalcare` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `project_parimisdentalcare`;

-- --------------------------------------------------------

--
-- Table structure for table `blog`
--
-- Error reading structure for table project_parimisdentalcare.blog: #1932 - Table &#039;project_parimisdentalcare.blog&#039; doesn&#039;t exist in engine
-- Error reading data for table project_parimisdentalcare.blog: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `project_parimisdentalcare`.`blog`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `contact_form`
--
-- Error reading structure for table project_parimisdentalcare.contact_form: #1932 - Table &#039;project_parimisdentalcare.contact_form&#039; doesn&#039;t exist in engine
-- Error reading data for table project_parimisdentalcare.contact_form: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `project_parimisdentalcare`.`contact_form`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `gallery`
--
-- Error reading structure for table project_parimisdentalcare.gallery: #1932 - Table &#039;project_parimisdentalcare.gallery&#039; doesn&#039;t exist in engine
-- Error reading data for table project_parimisdentalcare.gallery: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `project_parimisdentalcare`.`gallery`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--
-- Error reading structure for table project_parimisdentalcare.registration: #1932 - Table &#039;project_parimisdentalcare.registration&#039; doesn&#039;t exist in engine
-- Error reading data for table project_parimisdentalcare.registration: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `project_parimisdentalcare`.`registration`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `testimonials`
--
-- Error reading structure for table project_parimisdentalcare.testimonials: #1932 - Table &#039;project_parimisdentalcare.testimonials&#039; doesn&#039;t exist in engine
-- Error reading data for table project_parimisdentalcare.testimonials: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `project_parimisdentalcare`.`testimonials`&#039; at line 1
--
-- Database: `project_rootsdentalclinic`
--
CREATE DATABASE IF NOT EXISTS `project_rootsdentalclinic` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `project_rootsdentalclinic`;

-- --------------------------------------------------------

--
-- Table structure for table `blog`
--
-- Error reading structure for table project_rootsdentalclinic.blog: #1932 - Table &#039;project_rootsdentalclinic.blog&#039; doesn&#039;t exist in engine
-- Error reading data for table project_rootsdentalclinic.blog: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `project_rootsdentalclinic`.`blog`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `contact_form`
--
-- Error reading structure for table project_rootsdentalclinic.contact_form: #1932 - Table &#039;project_rootsdentalclinic.contact_form&#039; doesn&#039;t exist in engine
-- Error reading data for table project_rootsdentalclinic.contact_form: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `project_rootsdentalclinic`.`contact_form`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `gallery`
--
-- Error reading structure for table project_rootsdentalclinic.gallery: #1932 - Table &#039;project_rootsdentalclinic.gallery&#039; doesn&#039;t exist in engine
-- Error reading data for table project_rootsdentalclinic.gallery: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `project_rootsdentalclinic`.`gallery`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--
-- Error reading structure for table project_rootsdentalclinic.registration: #1932 - Table &#039;project_rootsdentalclinic.registration&#039; doesn&#039;t exist in engine
-- Error reading data for table project_rootsdentalclinic.registration: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `project_rootsdentalclinic`.`registration`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `testimonials`
--
-- Error reading structure for table project_rootsdentalclinic.testimonials: #1932 - Table &#039;project_rootsdentalclinic.testimonials&#039; doesn&#039;t exist in engine
-- Error reading data for table project_rootsdentalclinic.testimonials: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `project_rootsdentalclinic`.`testimonials`&#039; at line 1
--
-- Database: `qrcodegen`
--
CREATE DATABASE IF NOT EXISTS `qrcodegen` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `qrcodegen`;

-- --------------------------------------------------------

--
-- Table structure for table `pref_event`
--
-- Error reading structure for table qrcodegen.pref_event: #1932 - Table &#039;qrcodegen.pref_event&#039; doesn&#039;t exist in engine
-- Error reading data for table qrcodegen.pref_event: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `qrcodegen`.`pref_event`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `pref_seat`
--
-- Error reading structure for table qrcodegen.pref_seat: #1932 - Table &#039;qrcodegen.pref_seat&#039; doesn&#039;t exist in engine
-- Error reading data for table qrcodegen.pref_seat: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `qrcodegen`.`pref_seat`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `sold_tickets`
--
-- Error reading structure for table qrcodegen.sold_tickets: #1932 - Table &#039;qrcodegen.sold_tickets&#039; doesn&#039;t exist in engine
-- Error reading data for table qrcodegen.sold_tickets: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `qrcodegen`.`sold_tickets`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `useraccounts`
--
-- Error reading structure for table qrcodegen.useraccounts: #1932 - Table &#039;qrcodegen.useraccounts&#039; doesn&#039;t exist in engine
-- Error reading data for table qrcodegen.useraccounts: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `qrcodegen`.`useraccounts`&#039; at line 1
--
-- Database: `test`
--
CREATE DATABASE IF NOT EXISTS `test` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `test`;
--
-- Database: `test_blog`
--
CREATE DATABASE IF NOT EXISTS `test_blog` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `test_blog`;

-- --------------------------------------------------------

--
-- Table structure for table `blog`
--
-- Error reading structure for table test_blog.blog: #1932 - Table &#039;test_blog.blog&#039; doesn&#039;t exist in engine
-- Error reading data for table test_blog.blog: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `test_blog`.`blog`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--
-- Error reading structure for table test_blog.registration: #1932 - Table &#039;test_blog.registration&#039; doesn&#039;t exist in engine
-- Error reading data for table test_blog.registration: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `test_blog`.`registration`&#039; at line 1
--
-- Database: `test_blog_img`
--
CREATE DATABASE IF NOT EXISTS `test_blog_img` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `test_blog_img`;

-- --------------------------------------------------------

--
-- Table structure for table `images`
--
-- Error reading structure for table test_blog_img.images: #1932 - Table &#039;test_blog_img.images&#039; doesn&#039;t exist in engine
-- Error reading data for table test_blog_img.images: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `test_blog_img`.`images`&#039; at line 1
--
-- Database: `test_dental_dentalclinic`
--
CREATE DATABASE IF NOT EXISTS `test_dental_dentalclinic` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `test_dental_dentalclinic`;

-- --------------------------------------------------------

--
-- Table structure for table `events`
--
-- Error reading structure for table test_dental_dentalclinic.events: #1932 - Table &#039;test_dental_dentalclinic.events&#039; doesn&#039;t exist in engine
-- Error reading data for table test_dental_dentalclinic.events: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `test_dental_dentalclinic`.`events`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tblappointments`
--
-- Error reading structure for table test_dental_dentalclinic.tblappointments: #1932 - Table &#039;test_dental_dentalclinic.tblappointments&#039; doesn&#039;t exist in engine
-- Error reading data for table test_dental_dentalclinic.tblappointments: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `test_dental_dentalclinic`.`tblappointments`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tblautonumbers`
--
-- Error reading structure for table test_dental_dentalclinic.tblautonumbers: #1932 - Table &#039;test_dental_dentalclinic.tblautonumbers&#039; doesn&#039;t exist in engine
-- Error reading data for table test_dental_dentalclinic.tblautonumbers: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `test_dental_dentalclinic`.`tblautonumbers`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tblbulkpricing`
--
-- Error reading structure for table test_dental_dentalclinic.tblbulkpricing: #1932 - Table &#039;test_dental_dentalclinic.tblbulkpricing&#039; doesn&#039;t exist in engine
-- Error reading data for table test_dental_dentalclinic.tblbulkpricing: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `test_dental_dentalclinic`.`tblbulkpricing`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tblcurrency`
--
-- Error reading structure for table test_dental_dentalclinic.tblcurrency: #1932 - Table &#039;test_dental_dentalclinic.tblcurrency&#039; doesn&#039;t exist in engine
-- Error reading data for table test_dental_dentalclinic.tblcurrency: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `test_dental_dentalclinic`.`tblcurrency`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tbldiscountrate`
--
-- Error reading structure for table test_dental_dentalclinic.tbldiscountrate: #1932 - Table &#039;test_dental_dentalclinic.tbldiscountrate&#039; doesn&#039;t exist in engine
-- Error reading data for table test_dental_dentalclinic.tbldiscountrate: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `test_dental_dentalclinic`.`tbldiscountrate`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tblinvoice`
--
-- Error reading structure for table test_dental_dentalclinic.tblinvoice: #1932 - Table &#039;test_dental_dentalclinic.tblinvoice&#039; doesn&#039;t exist in engine
-- Error reading data for table test_dental_dentalclinic.tblinvoice: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `test_dental_dentalclinic`.`tblinvoice`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tblpatients`
--
-- Error reading structure for table test_dental_dentalclinic.tblpatients: #1932 - Table &#039;test_dental_dentalclinic.tblpatients&#039; doesn&#039;t exist in engine
-- Error reading data for table test_dental_dentalclinic.tblpatients: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `test_dental_dentalclinic`.`tblpatients`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tblpayments`
--
-- Error reading structure for table test_dental_dentalclinic.tblpayments: #1932 - Table &#039;test_dental_dentalclinic.tblpayments&#039; doesn&#039;t exist in engine
-- Error reading data for table test_dental_dentalclinic.tblpayments: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `test_dental_dentalclinic`.`tblpayments`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tblprintfooter`
--
-- Error reading structure for table test_dental_dentalclinic.tblprintfooter: #1932 - Table &#039;test_dental_dentalclinic.tblprintfooter&#039; doesn&#039;t exist in engine
-- Error reading data for table test_dental_dentalclinic.tblprintfooter: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `test_dental_dentalclinic`.`tblprintfooter`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tblprintheader`
--
-- Error reading structure for table test_dental_dentalclinic.tblprintheader: #1932 - Table &#039;test_dental_dentalclinic.tblprintheader&#039; doesn&#039;t exist in engine
-- Error reading data for table test_dental_dentalclinic.tblprintheader: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `test_dental_dentalclinic`.`tblprintheader`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tblservices`
--
-- Error reading structure for table test_dental_dentalclinic.tblservices: #1932 - Table &#039;test_dental_dentalclinic.tblservices&#039; doesn&#039;t exist in engine
-- Error reading data for table test_dental_dentalclinic.tblservices: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `test_dental_dentalclinic`.`tblservices`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tblstocks`
--
-- Error reading structure for table test_dental_dentalclinic.tblstocks: #1932 - Table &#039;test_dental_dentalclinic.tblstocks&#039; doesn&#039;t exist in engine
-- Error reading data for table test_dental_dentalclinic.tblstocks: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `test_dental_dentalclinic`.`tblstocks`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tbltaxrate`
--
-- Error reading structure for table test_dental_dentalclinic.tbltaxrate: #1932 - Table &#039;test_dental_dentalclinic.tbltaxrate&#039; doesn&#039;t exist in engine
-- Error reading data for table test_dental_dentalclinic.tbltaxrate: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `test_dental_dentalclinic`.`tbltaxrate`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tblunit`
--
-- Error reading structure for table test_dental_dentalclinic.tblunit: #1932 - Table &#039;test_dental_dentalclinic.tblunit&#039; doesn&#039;t exist in engine
-- Error reading data for table test_dental_dentalclinic.tblunit: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `test_dental_dentalclinic`.`tblunit`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tblusers`
--
-- Error reading structure for table test_dental_dentalclinic.tblusers: #1932 - Table &#039;test_dental_dentalclinic.tblusers&#039; doesn&#039;t exist in engine
-- Error reading data for table test_dental_dentalclinic.tblusers: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `test_dental_dentalclinic`.`tblusers`&#039; at line 1
--
-- Database: `test_dental_dentist`
--
CREATE DATABASE IF NOT EXISTS `test_dental_dentist` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `test_dental_dentist`;

-- --------------------------------------------------------

--
-- Table structure for table `contact_form`
--
-- Error reading structure for table test_dental_dentist.contact_form: #1932 - Table &#039;test_dental_dentist.contact_form&#039; doesn&#039;t exist in engine
-- Error reading data for table test_dental_dentist.contact_form: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `test_dental_dentist`.`contact_form`&#039; at line 1
--
-- Database: `test_dental_parimis`
--
CREATE DATABASE IF NOT EXISTS `test_dental_parimis` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `test_dental_parimis`;

-- --------------------------------------------------------

--
-- Table structure for table `images`
--
-- Error reading structure for table test_dental_parimis.images: #1932 - Table &#039;test_dental_parimis.images&#039; doesn&#039;t exist in engine
-- Error reading data for table test_dental_parimis.images: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `test_dental_parimis`.`images`&#039; at line 1
--
-- Database: `test_dental_parimis2`
--
CREATE DATABASE IF NOT EXISTS `test_dental_parimis2` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `test_dental_parimis2`;

-- --------------------------------------------------------

--
-- Table structure for table `banner`
--
-- Error reading structure for table test_dental_parimis2.banner: #1932 - Table &#039;test_dental_parimis2.banner&#039; doesn&#039;t exist in engine
-- Error reading data for table test_dental_parimis2.banner: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `test_dental_parimis2`.`banner`&#039; at line 1
--
-- Database: `test_file-management`
--
CREATE DATABASE IF NOT EXISTS `test_file-management` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `test_file-management`;

-- --------------------------------------------------------

--
-- Table structure for table `files`
--
-- Error reading structure for table test_file-management.files: #1932 - Table &#039;test_file-management.files&#039; doesn&#039;t exist in engine
-- Error reading data for table test_file-management.files: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `test_file-management`.`files`&#039; at line 1
--
-- Database: `tms`
--
CREATE DATABASE IF NOT EXISTS `tms` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `tms`;

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--
-- Error reading structure for table tms.admin: #1932 - Table &#039;tms.admin&#039; doesn&#039;t exist in engine
-- Error reading data for table tms.admin: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `tms`.`admin`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tblbooking`
--
-- Error reading structure for table tms.tblbooking: #1932 - Table &#039;tms.tblbooking&#039; doesn&#039;t exist in engine
-- Error reading data for table tms.tblbooking: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `tms`.`tblbooking`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tblenquiry`
--
-- Error reading structure for table tms.tblenquiry: #1932 - Table &#039;tms.tblenquiry&#039; doesn&#039;t exist in engine
-- Error reading data for table tms.tblenquiry: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `tms`.`tblenquiry`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tblissues`
--
-- Error reading structure for table tms.tblissues: #1932 - Table &#039;tms.tblissues&#039; doesn&#039;t exist in engine
-- Error reading data for table tms.tblissues: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `tms`.`tblissues`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tblpages`
--

CREATE TABLE `tblpages` (
  `id` int(11) NOT NULL,
  `type` varchar(255) DEFAULT '',
  `detail` longtext DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblpages`
--

INSERT INTO `tblpages` (`id`, `type`, `detail`) VALUES
(1, 'terms', '										<p align=\"justify\"><font size=\"2\"><strong><font color=\"#990000\">(1) ACCEPTANCE OF TERMS</font><br><br></strong>Welcome to Yahoo! India. 1Yahoo Web Services India Private Limited Yahoo\", \"we\" or \"us\" as the case may be) provides the Service (defined below) to you, subject to the following Terms of Service (\"TOS\"), which may be updated by us from time to time without notice to you. You can review the most current version of the TOS at any time at: <a href=\"http://in.docs.yahoo.com/info/terms/\">http://in.docs.yahoo.com/info/terms/</a>. In addition, when using particular Yahoo services or third party services, you and Yahoo shall be subject to any posted guidelines or rules applicable to such services which may be posted from time to time. All such guidelines or rules, which maybe subject to change, are hereby incorporated by reference into the TOS. In most cases the guides and rules are specific to a particular part of the Service and will assist you in applying the TOS to that part, but to the extent of any inconsistency between the TOS and any guide or rule, the TOS will prevail. We may also offer other services from time to time that are governed by different Terms of Services, in which case the TOS do not apply to such other services if and to the extent expressly excluded by such different Terms of Services. Yahoo also may offer other services from time to time that are governed by different Terms of Services. These TOS do not apply to such other services that are governed by different Terms of Service. </font></p>\r\n<p align=\"justify\"><font size=\"2\">Welcome to Yahoo! India. Yahoo Web Services India Private Limited Yahoo\", \"we\" or \"us\" as the case may be) provides the Service (defined below) to you, subject to the following Terms of Service (\"TOS\"), which may be updated by us from time to time without notice to you. You can review the most current version of the TOS at any time at: </font><a href=\"http://in.docs.yahoo.com/info/terms/\"><font size=\"2\">http://in.docs.yahoo.com/info/terms/</font></a><font size=\"2\">. In addition, when using particular Yahoo services or third party services, you and Yahoo shall be subject to any posted guidelines or rules applicable to such services which may be posted from time to time. All such guidelines or rules, which maybe subject to change, are hereby incorporated by reference into the TOS. In most cases the guides and rules are specific to a particular part of the Service and will assist you in applying the TOS to that part, but to the extent of any inconsistency between the TOS and any guide or rule, the TOS will prevail. We may also offer other services from time to time that are governed by different Terms of Services, in which case the TOS do not apply to such other services if and to the extent expressly excluded by such different Terms of Services. Yahoo also may offer other services from time to time that are governed by different Terms of Services. These TOS do not apply to such other services that are governed by different Terms of Service. </font></p>\r\n<p align=\"justify\"><font size=\"2\">Welcome to Yahoo! India. Yahoo Web Services India Private Limited Yahoo\", \"we\" or \"us\" as the case may be) provides the Service (defined below) to you, subject to the following Terms of Service (\"TOS\"), which may be updated by us from time to time without notice to you. You can review the most current version of the TOS at any time at: </font><a href=\"http://in.docs.yahoo.com/info/terms/\"><font size=\"2\">http://in.docs.yahoo.com/info/terms/</font></a><font size=\"2\">. In addition, when using particular Yahoo services or third party services, you and Yahoo shall be subject to any posted guidelines or rules applicable to such services which may be posted from time to time. All such guidelines or rules, which maybe subject to change, are hereby incorporated by reference into the TOS. In most cases the guides and rules are specific to a particular part of the Service and will assist you in applying the TOS to that part, but to the extent of any inconsistency between the TOS and any guide or rule, the TOS will prevail. We may also offer other services from time to time that are governed by different Terms of Services, in which case the TOS do not apply to such other services if and to the extent expressly excluded by such different Terms of Services. Yahoo also may offer other services from time to time that are governed by different Terms of Services. These TOS do not apply to such other services that are governed by different Terms of Service. </font></p>\r\n										'),
(2, 'privacy', '										<span style=\"color: rgb(0, 0, 0); font-family: &quot;Open Sans&quot;, Arial, sans-serif; font-size: 14px; text-align: justify;\">At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat</span>\r\n										'),
(3, 'aboutus', '<div><span style=\"color: rgb(0, 0, 0); font-family: Georgia; font-size: 15px; text-align: justify; font-weight: bold;\">Welcome to Tourism Management System!!!</span></div><span style=\"font-family: &quot;courier new&quot;;\"><span style=\"color: rgb(0, 0, 0); font-size: 15px; text-align: justify;\">Since then, our courteous and committed team members have always ensured a pleasant and enjoyable tour for the clients. This arduous effort has enabled Shreya Tour &amp; Travels to be recognized as a dependable Travel Solutions provider with three offices Delhi.</span><span style=\"color: rgb(80, 80, 80); font-size: 13px;\">&nbsp;We have got packages to suit the discerning traveler\'s budget and savor. Book your dream vacation online. Supported quality and proposals of our travel consultants, we have a tendency to welcome you to decide on from holidays packages and customize them according to your plan.</span></span>'),
(11, 'contact', '																				<span style=\"color: rgb(0, 0, 0); font-family: &quot;Open Sans&quot;, Arial, sans-serif; font-size: 14px; text-align: justify;\">Address------J-890 Dwarka House New Delhi-110096</span>');

-- --------------------------------------------------------

--
-- Table structure for table `tbltourpackages`
--
-- Error reading structure for table tms.tbltourpackages: #1932 - Table &#039;tms.tbltourpackages&#039; doesn&#039;t exist in engine
-- Error reading data for table tms.tbltourpackages: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `tms`.`tbltourpackages`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tblusers`
--
-- Error reading structure for table tms.tblusers: #1932 - Table &#039;tms.tblusers&#039; doesn&#039;t exist in engine
-- Error reading data for table tms.tblusers: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `tms`.`tblusers`&#039; at line 1

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tblpages`
--
ALTER TABLE `tblpages`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tblpages`
--
ALTER TABLE `tblpages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
--
-- Database: `tourism_db`
--
CREATE DATABASE IF NOT EXISTS `tourism_db` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `tourism_db`;

-- --------------------------------------------------------

--
-- Table structure for table `book_list`
--
-- Error reading structure for table tourism_db.book_list: #1932 - Table &#039;tourism_db.book_list&#039; doesn&#039;t exist in engine
-- Error reading data for table tourism_db.book_list: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `tourism_db`.`book_list`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `inquiry`
--
-- Error reading structure for table tourism_db.inquiry: #1932 - Table &#039;tourism_db.inquiry&#039; doesn&#039;t exist in engine
-- Error reading data for table tourism_db.inquiry: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `tourism_db`.`inquiry`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `packages`
--
-- Error reading structure for table tourism_db.packages: #1932 - Table &#039;tourism_db.packages&#039; doesn&#039;t exist in engine
-- Error reading data for table tourism_db.packages: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `tourism_db`.`packages`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `rate_review`
--
-- Error reading structure for table tourism_db.rate_review: #1932 - Table &#039;tourism_db.rate_review&#039; doesn&#039;t exist in engine
-- Error reading data for table tourism_db.rate_review: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `tourism_db`.`rate_review`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `system_info`
--
-- Error reading structure for table tourism_db.system_info: #1932 - Table &#039;tourism_db.system_info&#039; doesn&#039;t exist in engine
-- Error reading data for table tourism_db.system_info: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `tourism_db`.`system_info`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `users`
--
-- Error reading structure for table tourism_db.users: #1932 - Table &#039;tourism_db.users&#039; doesn&#039;t exist in engine
-- Error reading data for table tourism_db.users: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `tourism_db`.`users`&#039; at line 1
--
-- Database: `travel`
--
CREATE DATABASE IF NOT EXISTS `travel` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `travel`;

-- --------------------------------------------------------

--
-- Table structure for table `category`
--
-- Error reading structure for table travel.category: #1932 - Table &#039;travel.category&#039; doesn&#039;t exist in engine
-- Error reading data for table travel.category: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `travel`.`category`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `contactus`
--
-- Error reading structure for table travel.contactus: #1932 - Table &#039;travel.contactus&#039; doesn&#039;t exist in engine
-- Error reading data for table travel.contactus: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `travel`.`contactus`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `enquiry`
--
-- Error reading structure for table travel.enquiry: #1932 - Table &#039;travel.enquiry&#039; doesn&#039;t exist in engine
-- Error reading data for table travel.enquiry: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `travel`.`enquiry`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `package`
--
-- Error reading structure for table travel.package: #1932 - Table &#039;travel.package&#039; doesn&#039;t exist in engine
-- Error reading data for table travel.package: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `travel`.`package`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `subcategory`
--
-- Error reading structure for table travel.subcategory: #1932 - Table &#039;travel.subcategory&#039; doesn&#039;t exist in engine
-- Error reading data for table travel.subcategory: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `travel`.`subcategory`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `users`
--
-- Error reading structure for table travel.users: #1932 - Table &#039;travel.users&#039; doesn&#039;t exist in engine
-- Error reading data for table travel.users: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `travel`.`users`&#039; at line 1
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
