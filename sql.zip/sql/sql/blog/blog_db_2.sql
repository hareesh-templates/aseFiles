-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 15, 2023 at 10:52 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `blog_db_2`
--

-- --------------------------------------------------------

--
-- Table structure for table `blog`
--

CREATE TABLE `blog` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `area` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `event_date` varchar(55) NOT NULL,
  `key_url` text NOT NULL,
  `image` text NOT NULL,
  `meta_desc` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `blog`
--

INSERT INTO `blog` (`id`, `title`, `area`, `content`, `event_date`, `key_url`, `image`, `meta_desc`) VALUES
(1, 'Innovation Inspiring Construction Technology for Future Development', 'Vizag', '<p>Innovation emerging in every aspect of the business world, if you see banks transformed into digital banking, normal markets took e-commerce route etc., Everyday something new happening in the world and changing the process in a completely different way.</p>\r\n\r\n<p>In the same way, spreadsheets and paper works has transformed in a new level to plan 3D printing and AI technology, to build construction industry in a higher and greater level.</p>\r\n\r\n<p>Modernising construction through innovation by adapting technological ways to speed up the process and improve a way beyond designs with quality measures with beautiful super vision of engineering.</p>\r\n\r\n<p><strong>Innovative Technology Improving Construction Industry:</strong></p>\r\n\r\n<p>The construction industry bridging the gap of time and quality with its innovative technology and improving construction industry with various techniques in different fields.</p>\r\n\r\n<p><strong>3D Printing:</strong></p>\r\n\r\n<p>Material sourcing is the important factor which always makes construction delay and material wastage is one of the draw back that will always impact the cost of construction services. Ordering from the manufacturer and delivery from the transportation and reaching it to the site location. In all these places minimum to minimum material loss will happen some times you can find out abnormal loss too.</p>\r\n\r\n<p>As per UK Green building construction 15% of materials which come to the construction site will be spoiled in between transportation and due to other reasons.</p>\r\n\r\n<p>That&#39;s the reason 3D printing evolved to mitigate material losses. 3D printing can be done at the construction site and we can delivery materials on the spot, it will reduce the transportation cost and engineers can measure the quality checks on the spot.</p>\r\n\r\n<p><strong>AI (artificial intelligence):</strong></p>\r\n\r\n<p>The construction industry is already experiencing robots which doing bricklaying and automatic material uses on the construction site, these robots reducing the human efforts and maximizing construction quality without any delay.</p>\r\n\r\n<p>Improved safety, improved quality non stop work flow generate high standards of construction services.</p>\r\n\r\n<p><strong>Virtual Reality :</strong></p>\r\n\r\n<p>There will be some great designs, which are uniquely crafted and hard to construct. For those designs virtual reality is the way to build construction before hand itself to see the blue print of the total project.</p>\r\n\r\n<p>The use of virtual reality made many engineer&#39;s to stop bad construction plans and if there is any design defect they can easily find out.</p>\r\n\r\n<p><strong>Modular Construction:</strong></p>\r\n\r\n<p>In modular construction, same type of blocks will be produced off-site and assembled on-site. Less expensive than traditional homes, finding land is easy with it, and most probably future is going to be modular construction.</p>\r\n\r\n<p><strong>Conclusion</strong>:</p>\r\n\r\n<p>The future of construction is completely technology driven, it is one of the finest way to improve infrastructure industry rapidly. Many European countries already increasing their growth curve in a rapid way. Now it is time for indian market to enhance it&#39;s roots to rerouting business opportunity driven by technology that is 3D printing, AI technology, robots and etc.</p>\r\n', '08-May-2021', 'innovation-inspiring-construction-technology-for-future-development', '12.jpeg', ''),
(80, 'test', 'eg', '<p>asdf <span class=\"marker\"><em><strong><a href=\"http://eswarigroup.com\">eg</a></strong></em></span> qwerty</p>\r\n', '1111', '3333333333333', '', '2222222222222'),
(81, 'sACSC ', 'xz Z', '<p>dsvcsdvcsdfvsdf s <a href=\"http://eswarigroup.com\">rggerfg&nbsp;</a></p>\r\n', 'x CX', 'cxVXV ', 'blog.sql', 'ds cvdsc'),
(82, 'aaaaaaaaaaaa', 'qqqqqqqqqqq', '<p>aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa</p>\r\n', '111111111', 'edc', '', ''),
(83, 'scA', 'dc', '<p>dv ds</p>\r\n', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(9) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `phonenumber` varchar(55) NOT NULL,
  `adharnumber` varchar(55) NOT NULL,
  `pannumber` varchar(20) NOT NULL,
  `company` varchar(55) NOT NULL,
  `comp` varchar(20) NOT NULL,
  `role` varchar(20) NOT NULL,
  `designation` varchar(55) NOT NULL,
  `anternate_number` varchar(55) NOT NULL,
  `present_address` text NOT NULL,
  `permanent_address` text NOT NULL,
  `joining_date` varchar(55) NOT NULL,
  `adhar_image` varchar(255) NOT NULL,
  `pan_image` varchar(255) NOT NULL,
  `about_previous_company` text NOT NULL,
  `report` int(11) NOT NULL,
  `bank_account_number` varchar(55) NOT NULL,
  `ifsc` varchar(55) NOT NULL,
  `bank_holder_name` varchar(100) NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `name`, `email`, `username`, `password`, `phonenumber`, `adharnumber`, `pannumber`, `company`, `comp`, `role`, `designation`, `anternate_number`, `present_address`, `permanent_address`, `joining_date`, `adhar_image`, `pan_image`, `about_previous_company`, `report`, `bank_account_number`, `ifsc`, `bank_holder_name`, `status`) VALUES
(1, 'Admin', 'info@aseinfra.com', 'aseinfra123', 'ase', '', '', '', 'ase infra', '', 'superadmin', '', '', '', '', '', '', '', '', 0, '', '', '', 'active'),
(2, 'ewe', 'domain.id1337@gmail.com', 'ewe123', 'f756aea5418071e064c26131e5b9267e', '+913213213213', '2132132131', '321321321', 'eh', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', 'active'),
(3, 'ase', 'info@ase.eg', 'ase', 'eg', '985625', '789478947412', '7845120369', 'ase infra', '', 'superadmin', '', '', '', '', '', '', '', '', 0, '', '', '', 'active');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `blog`
--
ALTER TABLE `blog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `blog`
--
ALTER TABLE `blog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=84;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
