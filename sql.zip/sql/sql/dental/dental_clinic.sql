-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 19, 2023 at 12:19 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dental_clinic`
--

-- --------------------------------------------------------

--
-- Table structure for table `contact_form`
--

CREATE TABLE `contact_form` (
  `id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `number` varchar(10) NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contact_form`
--

INSERT INTO `contact_form` (`id`, `name`, `email`, `number`, `date`) VALUES
(6, 'eswari', 'eswari@gmail.com', '9874563210', '0000-00-00 00:00:00'),
(7, 'esw', 'esu@email.com', '7410258963', '2023-12-25 16:25:52'),
(8, 'dcad', 'dca@wd.vc', '9', '2023-01-18 20:08:00'),
(9, 'sFADZGx', 'saDZFg@wedfg.jhgf', '1234', '2023-01-27 16:10:00'),
(10, 'sFADZGx', 'saDZFg@wedfg.jhgf', '1234', '2023-01-27 16:10:00'),
(11, 'aravind', 'aravindsai120@gmail.com', '8712655512', '2023-12-07 06:01:00'),
(12, 'sd', 'dsac@ed.jhg', '123', '2023-01-11 12:34:00'),
(13, 'fdrtfd', 'saDZFg@wedfg.jhgf', '234567', '2023-01-09 10:10:00'),
(14, 'qwerty', 'info@eswarigroup.com', '123', '2023-02-04 17:06:00'),
(15, 'asdf', 'dca@wd.vc', '12345', '2023-01-09 17:07:00'),
(16, 'asdf', 'dca@wd.vc', '12345', '2023-01-09 17:07:00'),
(17, 'kk', 'info@eswarigroup.com', '8374631133', '2023-01-15 16:00:00'),
(18, 'asdf', 'asdf@g.c', '123', '2022-01-12 22:22:00'),
(19, 'asdf', 'asdf@g.c', '123', '2023-01-10 10:54:00'),
(20, 'qwerty', 'info@eswarigroup.com', '12345', '2023-01-10 10:56:00'),
(21, 'aravind', 'info@eswarigroup.com', '837', '2023-01-10 10:58:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contact_form`
--
ALTER TABLE `contact_form`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contact_form`
--
ALTER TABLE `contact_form`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
