-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 22, 2023 at 07:55 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dental_clinic2`
--

-- --------------------------------------------------------

--
-- Table structure for table `adminreg`
--

CREATE TABLE `adminreg` (
  `ser` int(3) NOT NULL,
  `regdate` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `adminreg`
--

INSERT INTO `adminreg` (`ser`, `regdate`) VALUES
(1, '30 November,2015'),
(2, '1 December,2015'),
(34, '2 December,2015'),
(35, '3 December,2015'),
(36, '4 December,2015'),
(37, '5 December,2015'),
(38, '6 December,2015'),
(39, '7 December,2015'),
(40, '8 December,2015'),
(41, '9 December,2015'),
(42, '10 December,2015'),
(43, '11 December,2015'),
(44, '12 December,2015'),
(45, '13 December,2015'),
(46, '14 December,2015'),
(48, '15 December,2015'),
(49, '16 December,2015'),
(51, '17 December,2015'),
(52, '18 December,2015'),
(53, '19 December,2015'),
(54, '20 December,2015'),
(55, '21 December,2015'),
(56, '22 December,2015'),
(57, '23 December,2015'),
(58, '24 December,2015'),
(59, '25 December,2015'),
(60, '26 December,2015'),
(61, '27 December,2015'),
(62, '28 December,2015'),
(63, '29 December,2015'),
(65, '30 December,2015'),
(66, '25January,2023'),
(67, '25January,2023');

-- --------------------------------------------------------

--
-- Table structure for table `appo`
--

CREATE TABLE `appo` (
  `sno` tinyint(3) NOT NULL,
  `userId` tinyint(3) NOT NULL,
  `dentalCode` varchar(50) NOT NULL,
  `dentistName` varchar(50) NOT NULL,
  `appointmentDate` varchar(50) NOT NULL,
  `appointmentTime` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `appointement`
--

CREATE TABLE `appointement` (
  `ser` tinyint(4) NOT NULL,
  `userid` tinyint(3) NOT NULL,
  `code` varchar(25) NOT NULL,
  `dentist` varchar(25) NOT NULL,
  `regdate` varchar(20) NOT NULL,
  `regtime` varchar(5) NOT NULL,
  `status` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `appointement`
--

INSERT INTO `appointement` (`ser`, `userid`, `code`, `dentist`, `regdate`, `regtime`, `status`) VALUES
(37, 32, '100-Root Canal', 'shweta narang', '2023-01-09', '12 PM', 'Appointment Cre'),
(38, 33, '100-Root Canal', 'shweta narang', '2023-01-09', '6 PM', 'Appointment Cre'),
(39, 33, '100-Root Canal', 'Hareesh', '2023-01-09', '9 AM', 'Appointment Cre'),
(40, 33, '100-Root Canal', 'Hareesh', '2023-01-09', '9 AM', 'Appointment Cre'),
(41, 33, '100-Root Canal', 'Hareesh', '2023-01-09', '9 AM', 'Appointment Cre'),
(42, 33, '100-Root Canal', 'Hareesh', '2023-01-09', '9 AM', 'Appointment Cre'),
(43, 33, '100-Root Canal', 'Hareesh', '2023-01-09', '9 AM', 'Appointment Cre'),
(44, 33, '102-teeth clean', 'Hareesh', '2023-01-09', 'Slect', 'Appointment Cre');

-- --------------------------------------------------------

--
-- Table structure for table `clinic`
--

CREATE TABLE `clinic` (
  `cid` tinyint(1) NOT NULL,
  `cname` varchar(25) NOT NULL,
  `location` varchar(60) NOT NULL,
  `openhr` varchar(6) NOT NULL,
  `closehr` varchar(6) NOT NULL,
  `rooms` tinyint(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `clinic`
--

INSERT INTO `clinic` (`cid`, `cname`, `location`, `openhr`, `closehr`, `rooms`) VALUES
(1, 'Dental Clinic', 'Visakhapatnam', '9 AM', '7 PM', 30);

-- --------------------------------------------------------

--
-- Table structure for table `dentalcode`
--

CREATE TABLE `dentalcode` (
  `id` int(3) NOT NULL,
  `code` smallint(4) NOT NULL,
  `unitcost` varchar(7) NOT NULL,
  `description` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `dentalcode`
--

INSERT INTO `dentalcode` (`id`, `code`, `unitcost`, `description`) VALUES
(1, 100, 'Rs 100', 'Root Canal'),
(2, 102, 'Rs 112', 'teeth clean'),
(3, 103, 'Rs 250', 'braces'),
(6, 106, 'Rs 222', 'gum clean'),
(7, 107, 'Rs 420', 'Partial Denture'),
(8, 108, 'Rs 500', 'Tooth Replacement'),
(9, 109, 'Rs 150', 'Laser Treatment');

-- --------------------------------------------------------

--
-- Table structure for table `dentist`
--

CREATE TABLE `dentist` (
  `sno` smallint(6) NOT NULL,
  `name` varchar(20) NOT NULL,
  `age` tinyint(3) NOT NULL,
  `sex` char(1) NOT NULL,
  `phone` bigint(10) NOT NULL,
  `email` varchar(30) NOT NULL,
  `address` text NOT NULL,
  `dtype` varchar(20) NOT NULL,
  `registration_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `dentist`
--

INSERT INTO `dentist` (`sno`, `name`, `age`, `sex`, `phone`, `email`, `address`, `dtype`, `registration_date`) VALUES
(1, 'Hareesh', 26, 'm', 8985884602, 'hareesh@asetechnologies.in', 'Visakhapatnam', 'Permanent', '2023-01-06 17:56:20'),
(2, 'Heramba', 26, 'm', 8888888888, 'heramba@asetechnologies.in', 'Vizag', 'Permanent', '2023-01-06 17:58:28');

-- --------------------------------------------------------

--
-- Table structure for table `signup`
--

CREATE TABLE `signup` (
  `userid` smallint(5) NOT NULL,
  `user_level` tinyint(1) NOT NULL,
  `name` varchar(30) NOT NULL,
  `phone` bigint(10) UNSIGNED NOT NULL,
  `age` tinyint(3) NOT NULL,
  `address` text NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(20) NOT NULL,
  `registration_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `signup`
--

INSERT INTO `signup` (`userid`, `user_level`, `name`, `phone`, `age`, `address`, `email`, `password`, `registration_date`) VALUES
(1, 1, 'hareesh', 8888888888, 26, 'Visakhapatnam', 'hareesh@asetechnologies.in', 'ase', '2023-01-07 17:10:48'),
(31, 0, 'qwerty', 8523697410, 32, 'asdf', 'aravindsai120@gmail.com', 'qwerty', '2023-01-07 12:49:44'),
(33, 0, 'aravind', 8712655512, 27, 'sujathanagar', 'aravindsai120@gmail.com', '123', '2023-01-09 12:42:43');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `sid` smallint(3) NOT NULL,
  `name` varchar(20) NOT NULL,
  `age` tinyint(3) NOT NULL,
  `sex` char(1) NOT NULL,
  `phone` bigint(10) NOT NULL,
  `email` varchar(30) NOT NULL,
  `address` text NOT NULL,
  `registration_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`sid`, `name`, `age`, `sex`, `phone`, `email`, `address`, `registration_date`) VALUES
(1, 'suresh', 35, 'm', 8971215561, 'suresh@gmail.com', 'Visakhapatnam', '2023-01-06 18:22:16');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `adminreg`
--
ALTER TABLE `adminreg`
  ADD PRIMARY KEY (`ser`);

--
-- Indexes for table `appo`
--
ALTER TABLE `appo`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `appointement`
--
ALTER TABLE `appointement`
  ADD PRIMARY KEY (`ser`);

--
-- Indexes for table `clinic`
--
ALTER TABLE `clinic`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `dentalcode`
--
ALTER TABLE `dentalcode`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dentist`
--
ALTER TABLE `dentist`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `signup`
--
ALTER TABLE `signup`
  ADD PRIMARY KEY (`userid`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`sid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `adminreg`
--
ALTER TABLE `adminreg`
  MODIFY `ser` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=68;

--
-- AUTO_INCREMENT for table `appo`
--
ALTER TABLE `appo`
  MODIFY `sno` tinyint(3) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `appointement`
--
ALTER TABLE `appointement`
  MODIFY `ser` tinyint(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `clinic`
--
ALTER TABLE `clinic`
  MODIFY `cid` tinyint(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `dentalcode`
--
ALTER TABLE `dentalcode`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `dentist`
--
ALTER TABLE `dentist`
  MODIFY `sno` smallint(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `signup`
--
ALTER TABLE `signup`
  MODIFY `userid` smallint(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `staff`
--
ALTER TABLE `staff`
  MODIFY `sid` smallint(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
