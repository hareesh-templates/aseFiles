-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 17, 2023 at 02:35 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `construction_monitering-systems`
--
CREATE DATABASE IF NOT EXISTS `construction_monitering-systems` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `construction_monitering-systems`;

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `user_id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` text NOT NULL,
  `user_type` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`user_id`, `name`, `username`, `password`, `user_type`) VALUES
(1, 'Admin', 'admin', 'd033e22ae348aeb5660fc2140aec35850c4da997', 'Admin');

-- --------------------------------------------------------

--
-- Table structure for table `auto`
--

CREATE TABLE `auto` (
  `auto_id` int(11) NOT NULL,
  `auto_start` int(11) NOT NULL,
  `auto_end` int(11) NOT NULL,
  `increment` int(11) NOT NULL,
  `description` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `auto`
--

INSERT INTO `auto` (`auto_id`, `auto_start`, `auto_end`, `increment`, `description`) VALUES
(1, 100, 50, 1, 'BORROWED'),
(2, 100, 11, 1, 'BORROWED-TOOL');

-- --------------------------------------------------------

--
-- Table structure for table `borrowed_tools`
--

CREATE TABLE `borrowed_tools` (
  `borrow_id` int(11) NOT NULL,
  `tool_id` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `emp_id` int(11) NOT NULL,
  `borrowed_date` varchar(30) NOT NULL,
  `borrowed_time` varchar(30) NOT NULL,
  `due_date` varchar(30) NOT NULL,
  `date_returned` varchar(30) NOT NULL,
  `status` varchar(30) NOT NULL,
  `location_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `borrowed_tools`
--

INSERT INTO `borrowed_tools` (`borrow_id`, `tool_id`, `qty`, `emp_id`, `borrowed_date`, `borrowed_time`, `due_date`, `date_returned`, `status`, `location_id`) VALUES
(5, 1, 5, 2, '2021-03-07', '20:15:52 PM', '2021-03-11', '2021-03-07', 'RETURNED', 2);

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `emp_id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `age` int(3) NOT NULL,
  `address` text NOT NULL,
  `contact_number` varchar(30) NOT NULL,
  `position` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`emp_id`, `name`, `age`, `address`, `contact_number`, `position`) VALUES
(1, 'Hareesh', 26, 'Himamaylan City', '0912345678', 'ase devp'),
(2, 'juan dela cruz', 25, 'Binalbagan', '09123456789', 'carpenter'),
(3, 'ryan manaay', 23, 'Himamaylan city', '0912344547', 'welder'),
(4, 'juday', 25, 'Himamaylan City', '0912345678', 'kargadorr');

-- --------------------------------------------------------

--
-- Table structure for table `equipments`
--

CREATE TABLE `equipments` (
  `equip_id` int(11) NOT NULL,
  `uniquec` varchar(30) NOT NULL,
  `name` varchar(30) NOT NULL,
  `category` varchar(30) NOT NULL,
  `quantity` int(11) NOT NULL,
  `available_quantity` int(11) NOT NULL,
  `status` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `equipments`
--

INSERT INTO `equipments` (`equip_id`, `uniquec`, `name`, `category`, `quantity`, `available_quantity`, `status`) VALUES
(6, '112221', 'bachoe', 'HEAVY', 1, 1, 'UNAVAILABLE'),
(7, '111', 'tracktor', 'HEAVY', 1, 1, '');

-- --------------------------------------------------------

--
-- Table structure for table `equip_mapping`
--

CREATE TABLE `equip_mapping` (
  `map_id` int(11) NOT NULL,
  `equip_id` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `remaining_qty` int(11) NOT NULL,
  `location_id` int(11) NOT NULL,
  `date_borrowed` varchar(30) NOT NULL,
  `time_borrowed` varchar(30) NOT NULL,
  `due_date` varchar(30) NOT NULL,
  `date_returned` varchar(30) NOT NULL,
  `status` varchar(30) NOT NULL,
  `emp_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `equip_mapping`
--

INSERT INTO `equip_mapping` (`map_id`, `equip_id`, `qty`, `remaining_qty`, `location_id`, `date_borrowed`, `time_borrowed`, `due_date`, `date_returned`, `status`, `emp_id`) VALUES
(66, 6, 1, 0, 1, '2021-02-08', '23:01:53 PM', '2021-02-10', '', 'TRANSFERED', 1),
(67, 7, 1, 0, 1, '2021-03-07', '19:52:03 PM', '2021-03-20', '2021-03-07', 'RETURNED', 3);

-- --------------------------------------------------------

--
-- Table structure for table `location`
--

CREATE TABLE `location` (
  `location_id` int(11) NOT NULL,
  `location_address` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `location`
--

INSERT INTO `location` (`location_id`, `location_address`) VALUES
(1, 'Himamaylan City'),
(2, 'Kabankalan City'),
(3, 'Hinigaran'),
(4, 'Bago City\r\n'),
(5, 'korea'),
(6, 'Sipalay City');

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

CREATE TABLE `logs` (
  `log_id` int(11) NOT NULL,
  `action` text NOT NULL,
  `date_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `logs`
--

INSERT INTO `logs` (`log_id`, `action`, `date_time`) VALUES
(1, 'user Admin was login', '2023-01-22 11:51:55'),
(2, 'employee 1 was updated', '2023-01-22 14:02:32'),
(59, 'user Admin was logout', '2023-01-22 14:42:52'),
(60, 'user Admin was login', '2023-02-03 21:10:27'),
(61, 'user Admin was logout', '2023-02-03 21:10:44');

-- --------------------------------------------------------

--
-- Table structure for table `outsourcing`
--

CREATE TABLE `outsourcing` (
  `source_id` int(11) NOT NULL,
  `company_name` varchar(30) NOT NULL,
  `equip_id` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `date_outsourced` varchar(30) NOT NULL,
  `source_code` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `outsourcing_tools`
--

CREATE TABLE `outsourcing_tools` (
  `source_id` int(11) NOT NULL,
  `company_name` varchar(30) NOT NULL,
  `tool_id` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `date_outsourced` varchar(30) NOT NULL,
  `source_code` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `temp`
--

CREATE TABLE `temp` (
  `temp_id` int(11) NOT NULL,
  `equip_id` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `emp_id` int(11) NOT NULL,
  `location_id` int(11) NOT NULL,
  `unique_id` varchar(30) NOT NULL,
  `status` varchar(30) NOT NULL,
  `company_name` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `temp1`
--

CREATE TABLE `temp1` (
  `temp1_id` int(11) NOT NULL,
  `tool_id` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `emp_id` int(11) NOT NULL,
  `location_id` int(11) NOT NULL,
  `unique_id` varchar(30) NOT NULL,
  `status` varchar(30) NOT NULL,
  `company_name` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tools`
--

CREATE TABLE `tools` (
  `tool_id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `quantity` int(11) NOT NULL,
  `available_quantity` int(11) NOT NULL,
  `tool_type` varchar(30) NOT NULL,
  `status` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tools`
--

INSERT INTO `tools` (`tool_id`, `name`, `quantity`, `available_quantity`, `tool_type`, `status`) VALUES
(1, 'Helmet', 20, 15, 'NON CONSUMABLE', ''),
(2, 'Welding Rod', 100, 100, 'CONSUMABLE', '');

-- --------------------------------------------------------

--
-- Table structure for table `transfered_equipment`
--

CREATE TABLE `transfered_equipment` (
  `transfer_id` int(11) NOT NULL,
  `map_id` int(11) NOT NULL,
  `equip_id` int(11) NOT NULL,
  `emp_id_from` int(11) NOT NULL,
  `emp_id_to` int(11) NOT NULL,
  `date_transfered` varchar(30) NOT NULL,
  `time_transfered` varchar(30) NOT NULL,
  `location_id_from` int(11) NOT NULL,
  `location_id_to` int(11) NOT NULL,
  `date_returned` varchar(30) NOT NULL,
  `status` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transfered_equipment`
--

INSERT INTO `transfered_equipment` (`transfer_id`, `map_id`, `equip_id`, `emp_id_from`, `emp_id_to`, `date_transfered`, `time_transfered`, `location_id_from`, `location_id_to`, `date_returned`, `status`) VALUES
(14, 66, 6, 1, 4, '2021-03-07', '20:45:14 PM', 1, 6, '', 'TRANSFERED');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `auto`
--
ALTER TABLE `auto`
  ADD PRIMARY KEY (`auto_id`);

--
-- Indexes for table `borrowed_tools`
--
ALTER TABLE `borrowed_tools`
  ADD PRIMARY KEY (`borrow_id`);

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`emp_id`);

--
-- Indexes for table `equipments`
--
ALTER TABLE `equipments`
  ADD PRIMARY KEY (`equip_id`);

--
-- Indexes for table `equip_mapping`
--
ALTER TABLE `equip_mapping`
  ADD PRIMARY KEY (`map_id`);

--
-- Indexes for table `location`
--
ALTER TABLE `location`
  ADD PRIMARY KEY (`location_id`);

--
-- Indexes for table `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`log_id`);

--
-- Indexes for table `outsourcing`
--
ALTER TABLE `outsourcing`
  ADD PRIMARY KEY (`source_id`);

--
-- Indexes for table `outsourcing_tools`
--
ALTER TABLE `outsourcing_tools`
  ADD PRIMARY KEY (`source_id`);

--
-- Indexes for table `temp`
--
ALTER TABLE `temp`
  ADD PRIMARY KEY (`temp_id`);

--
-- Indexes for table `temp1`
--
ALTER TABLE `temp1`
  ADD PRIMARY KEY (`temp1_id`);

--
-- Indexes for table `tools`
--
ALTER TABLE `tools`
  ADD PRIMARY KEY (`tool_id`);

--
-- Indexes for table `transfered_equipment`
--
ALTER TABLE `transfered_equipment`
  ADD PRIMARY KEY (`transfer_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `auto`
--
ALTER TABLE `auto`
  MODIFY `auto_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `borrowed_tools`
--
ALTER TABLE `borrowed_tools`
  MODIFY `borrow_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `employees`
--
ALTER TABLE `employees`
  MODIFY `emp_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `equipments`
--
ALTER TABLE `equipments`
  MODIFY `equip_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `equip_mapping`
--
ALTER TABLE `equip_mapping`
  MODIFY `map_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=68;

--
-- AUTO_INCREMENT for table `location`
--
ALTER TABLE `location`
  MODIFY `location_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `logs`
--
ALTER TABLE `logs`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=62;

--
-- AUTO_INCREMENT for table `outsourcing`
--
ALTER TABLE `outsourcing`
  MODIFY `source_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `outsourcing_tools`
--
ALTER TABLE `outsourcing_tools`
  MODIFY `source_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `temp`
--
ALTER TABLE `temp`
  MODIFY `temp_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=79;

--
-- AUTO_INCREMENT for table `temp1`
--
ALTER TABLE `temp1`
  MODIFY `temp1_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tools`
--
ALTER TABLE `tools`
  MODIFY `tool_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `transfered_equipment`
--
ALTER TABLE `transfered_equipment`
  MODIFY `transfer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- Database: `dental_clinic`
--
CREATE DATABASE IF NOT EXISTS `dental_clinic` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `dental_clinic`;

-- --------------------------------------------------------

--
-- Table structure for table `contact_form`
--

CREATE TABLE `contact_form` (
  `id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `number` varchar(10) NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contact_form`
--

INSERT INTO `contact_form` (`id`, `name`, `email`, `number`, `date`) VALUES
(6, 'eswari', 'eswari@gmail.com', '9874563210', '0000-00-00 00:00:00'),
(7, 'esw', 'esu@email.com', '7410258963', '2023-12-25 16:25:52'),
(8, 'dcad', 'dca@wd.vc', '9', '2023-01-18 20:08:00'),
(9, 'sFADZGx', 'saDZFg@wedfg.jhgf', '1234', '2023-01-27 16:10:00'),
(10, 'sFADZGx', 'saDZFg@wedfg.jhgf', '1234', '2023-01-27 16:10:00'),
(11, 'aravind', 'aravindsai120@gmail.com', '8712655512', '2023-12-07 06:01:00'),
(12, 'sd', 'dsac@ed.jhg', '123', '2023-01-11 12:34:00'),
(13, 'fdrtfd', 'saDZFg@wedfg.jhgf', '234567', '2023-01-09 10:10:00'),
(14, 'qwerty', 'info@eswarigroup.com', '123', '2023-02-04 17:06:00'),
(15, 'asdf', 'dca@wd.vc', '12345', '2023-01-09 17:07:00'),
(16, 'asdf', 'dca@wd.vc', '12345', '2023-01-09 17:07:00'),
(17, 'kk', 'info@eswarigroup.com', '8374631133', '2023-01-15 16:00:00'),
(18, 'asdf', 'asdf@g.c', '123', '2022-01-12 22:22:00'),
(19, 'asdf', 'asdf@g.c', '123', '2023-01-10 10:54:00'),
(20, 'qwerty', 'info@eswarigroup.com', '12345', '2023-01-10 10:56:00'),
(21, 'aravind', 'info@eswarigroup.com', '837', '2023-01-10 10:58:00'),
(22, 'qwerty', 'info@eswarigroup.com', '78956', '2023-02-24 23:48:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contact_form`
--
ALTER TABLE `contact_form`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contact_form`
--
ALTER TABLE `contact_form`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
--
-- Database: `dental_clinic2`
--
CREATE DATABASE IF NOT EXISTS `dental_clinic2` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `dental_clinic2`;

-- --------------------------------------------------------

--
-- Table structure for table `adminreg`
--

CREATE TABLE `adminreg` (
  `ser` int(3) NOT NULL,
  `regdate` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `adminreg`
--

INSERT INTO `adminreg` (`ser`, `regdate`) VALUES
(1, '30 November,2015'),
(2, '1 December,2015'),
(34, '2 December,2015'),
(35, '3 December,2015'),
(36, '4 December,2015'),
(37, '5 December,2015'),
(38, '6 December,2015'),
(39, '7 December,2015'),
(40, '8 December,2015'),
(41, '9 December,2015'),
(42, '10 December,2015'),
(43, '11 December,2015'),
(44, '12 December,2015'),
(45, '13 December,2015'),
(46, '14 December,2015'),
(48, '15 December,2015'),
(49, '16 December,2015'),
(51, '17 December,2015'),
(52, '18 December,2015'),
(53, '19 December,2015'),
(54, '20 December,2015'),
(55, '21 December,2015'),
(56, '22 December,2015'),
(57, '23 December,2015'),
(58, '24 December,2015'),
(59, '25 December,2015'),
(60, '26 December,2015'),
(61, '27 December,2015'),
(62, '28 December,2015'),
(63, '29 December,2015'),
(65, '30 December,2015'),
(66, '25January,2023'),
(67, '25January,2023');

-- --------------------------------------------------------

--
-- Table structure for table `appo`
--

CREATE TABLE `appo` (
  `sno` tinyint(3) NOT NULL,
  `userId` tinyint(3) NOT NULL,
  `dentalCode` varchar(50) NOT NULL,
  `dentistName` varchar(50) NOT NULL,
  `appointmentDate` varchar(50) NOT NULL,
  `appointmentTime` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `appointement`
--

CREATE TABLE `appointement` (
  `ser` tinyint(4) NOT NULL,
  `userid` tinyint(3) NOT NULL,
  `code` varchar(25) NOT NULL,
  `dentist` varchar(25) NOT NULL,
  `regdate` varchar(20) NOT NULL,
  `regtime` varchar(5) NOT NULL,
  `status` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `appointement`
--

INSERT INTO `appointement` (`ser`, `userid`, `code`, `dentist`, `regdate`, `regtime`, `status`) VALUES
(37, 32, '100-Root Canal', 'shweta narang', '2023-01-09', '12 PM', 'Appointment Cre'),
(38, 33, '100-Root Canal', 'shweta narang', '2023-01-09', '6 PM', 'Appointment Cre'),
(39, 33, '100-Root Canal', 'Hareesh', '2023-01-09', '9 AM', 'Appointment Cre'),
(40, 33, '100-Root Canal', 'Hareesh', '2023-01-09', '9 AM', 'Appointment Cre'),
(41, 33, '100-Root Canal', 'Hareesh', '2023-01-09', '9 AM', 'Appointment Cre'),
(42, 33, '100-Root Canal', 'Hareesh', '2023-01-09', '9 AM', 'Appointment Cre'),
(43, 33, '100-Root Canal', 'Hareesh', '2023-01-09', '9 AM', 'Appointment Cre'),
(44, 33, '102-teeth clean', 'Hareesh', '2023-01-09', 'Slect', 'Appointment Cre');

-- --------------------------------------------------------

--
-- Table structure for table `clinic`
--

CREATE TABLE `clinic` (
  `cid` tinyint(1) NOT NULL,
  `cname` varchar(25) NOT NULL,
  `location` varchar(60) NOT NULL,
  `openhr` varchar(6) NOT NULL,
  `closehr` varchar(6) NOT NULL,
  `rooms` tinyint(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `clinic`
--

INSERT INTO `clinic` (`cid`, `cname`, `location`, `openhr`, `closehr`, `rooms`) VALUES
(1, 'Dental Clinic', 'Visakhapatnam', '9 AM', '7 PM', 30);

-- --------------------------------------------------------

--
-- Table structure for table `dentalcode`
--

CREATE TABLE `dentalcode` (
  `id` int(3) NOT NULL,
  `code` smallint(4) NOT NULL,
  `unitcost` varchar(7) NOT NULL,
  `description` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `dentalcode`
--

INSERT INTO `dentalcode` (`id`, `code`, `unitcost`, `description`) VALUES
(1, 100, 'Rs 100', 'Root Canal'),
(2, 102, 'Rs 112', 'teeth clean'),
(3, 103, 'Rs 250', 'braces'),
(6, 106, 'Rs 222', 'gum clean'),
(7, 107, 'Rs 420', 'Partial Denture'),
(8, 108, 'Rs 500', 'Tooth Replacement'),
(9, 109, 'Rs 150', 'Laser Treatment');

-- --------------------------------------------------------

--
-- Table structure for table `dentist`
--

CREATE TABLE `dentist` (
  `sno` smallint(6) NOT NULL,
  `name` varchar(20) NOT NULL,
  `age` tinyint(3) NOT NULL,
  `sex` char(1) NOT NULL,
  `phone` bigint(10) NOT NULL,
  `email` varchar(30) NOT NULL,
  `address` text NOT NULL,
  `dtype` varchar(20) NOT NULL,
  `registration_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `dentist`
--

INSERT INTO `dentist` (`sno`, `name`, `age`, `sex`, `phone`, `email`, `address`, `dtype`, `registration_date`) VALUES
(1, 'Hareesh', 26, 'm', 8985884602, 'hareesh@asetechnologies.in', 'Visakhapatnam', 'Permanent', '2023-01-06 17:56:20'),
(2, 'Heramba', 26, 'm', 8888888888, 'heramba@asetechnologies.in', 'Vizag', 'Permanent', '2023-01-06 17:58:28');

-- --------------------------------------------------------

--
-- Table structure for table `signup`
--

CREATE TABLE `signup` (
  `userid` smallint(5) NOT NULL,
  `user_level` tinyint(1) NOT NULL,
  `name` varchar(30) NOT NULL,
  `phone` bigint(10) UNSIGNED NOT NULL,
  `age` tinyint(3) NOT NULL,
  `address` text NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(20) NOT NULL,
  `registration_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `signup`
--

INSERT INTO `signup` (`userid`, `user_level`, `name`, `phone`, `age`, `address`, `email`, `password`, `registration_date`) VALUES
(1, 1, 'hareesh', 8888888888, 26, 'Visakhapatnam', 'hareesh@asetechnologies.in', 'ase', '2023-01-07 17:10:48'),
(31, 0, 'qwerty', 8523697410, 32, 'asdf', 'aravindsai120@gmail.com', 'qwerty', '2023-01-07 12:49:44'),
(33, 0, 'aravind', 8712655512, 27, 'sujathanagar', 'aravindsai120@gmail.com', '123', '2023-01-09 12:42:43');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `sid` smallint(3) NOT NULL,
  `name` varchar(20) NOT NULL,
  `age` tinyint(3) NOT NULL,
  `sex` char(1) NOT NULL,
  `phone` bigint(10) NOT NULL,
  `email` varchar(30) NOT NULL,
  `address` text NOT NULL,
  `registration_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`sid`, `name`, `age`, `sex`, `phone`, `email`, `address`, `registration_date`) VALUES
(1, 'suresh', 35, 'm', 8971215561, 'suresh@gmail.com', 'Visakhapatnam', '2023-01-06 18:22:16');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `adminreg`
--
ALTER TABLE `adminreg`
  ADD PRIMARY KEY (`ser`);

--
-- Indexes for table `appo`
--
ALTER TABLE `appo`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `appointement`
--
ALTER TABLE `appointement`
  ADD PRIMARY KEY (`ser`);

--
-- Indexes for table `clinic`
--
ALTER TABLE `clinic`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `dentalcode`
--
ALTER TABLE `dentalcode`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dentist`
--
ALTER TABLE `dentist`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `signup`
--
ALTER TABLE `signup`
  ADD PRIMARY KEY (`userid`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`sid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `adminreg`
--
ALTER TABLE `adminreg`
  MODIFY `ser` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=68;

--
-- AUTO_INCREMENT for table `appo`
--
ALTER TABLE `appo`
  MODIFY `sno` tinyint(3) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `appointement`
--
ALTER TABLE `appointement`
  MODIFY `ser` tinyint(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `clinic`
--
ALTER TABLE `clinic`
  MODIFY `cid` tinyint(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `dentalcode`
--
ALTER TABLE `dentalcode`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `dentist`
--
ALTER TABLE `dentist`
  MODIFY `sno` smallint(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `signup`
--
ALTER TABLE `signup`
  MODIFY `userid` smallint(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `staff`
--
ALTER TABLE `staff`
  MODIFY `sid` smallint(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- Database: `e-commerce_bookstoredb`
--
CREATE DATABASE IF NOT EXISTS `e-commerce_bookstoredb` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `e-commerce_bookstoredb`;

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `name` varchar(20) NOT NULL,
  `pass` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`name`, `pass`) VALUES
('admin', 'd033e22ae348aeb5660fc2140aec35850c4da997');

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `book_isbn` varchar(20) NOT NULL,
  `book_title` varchar(60) DEFAULT NULL,
  `book_author` varchar(60) DEFAULT NULL,
  `book_image` varchar(40) DEFAULT NULL,
  `book_descr` text DEFAULT NULL,
  `book_price` decimal(6,2) NOT NULL,
  `publisherid` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`book_isbn`, `book_title`, `book_author`, `book_image`, `book_descr`, `book_price`, `publisherid`) VALUES
('978-0-321-94786-4', 'Learning Mobile App Development', 'Jakob Iversen, Michael Eierman', 'mobile_app.jpg', 'Now, one book can help you master mobile app development with both market-leading platforms: Apple\'s iOS and Google\'s Android. Perfect for both students and professionals, Learning Mobile App Development is the only tutorial with complete parallel coverage of both iOS and Android. With this guide, you can master either platform, or both - and gain a deeper understanding of the issues associated with developing mobile apps.\r\n\r\nYou\'ll develop an actual working app on both iOS and Android, mastering the entire mobile app development lifecycle, from planning through licensing and distribution.\r\n\r\nEach tutorial in this book has been carefully designed to support readers with widely varying backgrounds and has been extensively tested in live developer training courses. If you\'re new to iOS, you\'ll also find an easy, practical introduction to Objective-C, Apple\'s native language.', '20.00', 6),
('978-0-7303-1484-4', 'Doing Good By Doing Good', 'Peter Baines', 'doing_good.jpg', 'Doing Good by Doing Good shows companies how to improve the bottom line by implementing an engaging, authentic, and business-enhancing program that helps staff and business thrive. International CSR consultant Peter Baines draws upon lessons learnt from the challenges faced in his career as a police officer, forensic investigator, and founder of Hands Across the Water to describe the Australian CSR landscape, and the factors that make up a program that benefits everyone involved. Case studies illustrate the real effect of CSR on both business and society, with clear guidance toward maximizing involvement, engaging all employees, and improving the bottom line. The case studies draw out the companies that are focusing on creating shared value in meeting the challenges of society whilst at the same time bringing strong economic returns.\r\n\r\nConsumers are now expecting that big businesses with ever-increasing profits give back to the community from which those profits arise. At the same time, shareholders are demanding their share and are happy to see dividends soar. Getting this right is a balancing act, and Doing Good by Doing Good helps companies delineate a plan of action for getting it done.', '20.00', 2),
('978-1-118-94924-5', 'Programmable Logic Controllers', 'Dag H. Hanssen', 'logic_program.jpg', 'Widely used across industrial and manufacturing automation, Programmable Logic Controllers (PLCs) perform a broad range of electromechanical tasks with multiple input and output arrangements, designed specifically to cope in severe environmental conditions such as automotive and chemical plants.Programmable Logic Controllers: A Practical Approach using CoDeSys is a hands-on guide to rapidly gain proficiency in the development and operation of PLCs based on the IEC 61131-3 standard. Using the freely-available* software tool CoDeSys, which is widely used in industrial design automation projects, the author takes a highly practical approach to PLC design using real-world examples. The design tool, CoDeSys, also features a built in simulator / soft PLC enabling the reader to undertake exercises and test the examples.', '20.00', 2),
('978-1-1180-2669-4', 'Professional JavaScript for Web Developers, 3rd Edition', 'Nicholas C. Zakas', 'pro_js.jpg', 'If you want to achieve JavaScript\'s full potential, it is critical to understand its nature, history, and limitations. To that end, this updated version of the bestseller by veteran author and JavaScript guru Nicholas C. Zakas covers JavaScript from its very beginning to the present-day incarnations including the DOM, Ajax, and HTML5. Zakas shows you how to extend this powerful language to meet specific needs and create dynamic user interfaces for the web that blur the line between desktop and internet. By the end of the book, you\'ll have a strong understanding of the significant advances in web development as they relate to JavaScript so that you can apply them to your next website.', '20.00', 1),
('978-1-44937-019-0', 'Learning Web App Development', 'Semmy Purewal', 'web_app_dev.jpg', 'Grasp the fundamentals of web application development by building a simple database-backed app from scratch, using HTML, JavaScript, and other open source tools. Through hands-on tutorials, this practical guide shows inexperienced web app developers how to create a user interface, write a server, build client-server communication, and use a cloud-based service to deploy the application.\r\n\r\nEach chapter includes practice problems, full examples, and mental models of the development workflow. Ideal for a college-level course, this book helps you get started with web app development by providing you with a solid grounding in the process.', '20.00', 3),
('978-1-44937-075-6', 'Beautiful JavaScript', 'Anton Kovalyov', 'beauty_js.jpg', 'JavaScript is arguably the most polarizing and misunderstood programming language in the world. Many have attempted to replace it as the language of the Web, but JavaScript has survived, evolved, and thrived. Why did a language created in such hurry succeed where others failed?\r\n\r\nThis guide gives you a rare glimpse into JavaScript from people intimately familiar with it. Chapters contributed by domain experts such as Jacob Thornton, Ariya Hidayat, and Sara Chipps show what they love about their favorite language - whether it\'s turning the most feared features into useful tools, or how JavaScript can be used for self-expression.', '20.00', 3),
('978-1-4571-0402-2', 'Professional ASP.NET 4 in C# and VB', 'Scott Hanselman', 'pro_asp4.jpg', 'ASP.NET is about making you as productive as possible when building fast and secure web applications. Each release of ASP.NET gets better and removes a lot of the tedious code that you previously needed to put in place, making common ASP.NET tasks easier. With this book, an unparalleled team of authors walks you through the full breadth of ASP.NET and the new and exciting capabilities of ASP.NET 4. The authors also show you how to maximize the abundance of features that ASP.NET offers to make your development process smoother and more efficient.', '20.00', 1),
('978-1-484216-40-8', 'Android Studio New Media Fundamentals', 'Wallace Jackson', 'android_studio.jpg', 'Android Studio New Media Fundamentals is a new media primer covering concepts central to multimedia production for Android including digital imagery, digital audio, digital video, digital illustration and 3D, using open source software packages such as GIMP, Audacity, Blender, and Inkscape. These professional software packages are used for this book because they are free for commercial use. The book builds on the foundational concepts of raster, vector, and waveform (audio), and gets more advanced as chapters progress, covering what new media assets are best for use with Android Studio as well as key factors regarding the data footprint optimization work process and why new media content and new media data optimization is so important.', '20.00', 4),
('978-1-484217-26-9', 'C++ 14 Quick Syntax Reference, 2nd Edition', '	Mikael Olsson', 'c_14_quick.jpg', 'This updated handy quick C++ 14 guide is a condensed code and syntax reference based on the newly updated C++ 14 release of the popular programming language. It presents the essential C++ syntax in a well-organized format that can be used as a handy reference.\r\n\r\nYou won\'t find any technical jargon, bloated samples, drawn out history lessons, or witty stories in this book. What you will find is a language reference that is concise, to the point and highly accessible. The book is packed with useful information and is a must-have for any C++ programmer.\r\n\r\nIn the C++ 14 Quick Syntax Reference, Second Edition, you will find a concise reference to the C++ 14 language syntax. It has short, simple, and focused code examples. This book includes a well laid out table of contents and a comprehensive index allowing for easy review.', '20.00', 4),
('978-1-49192-706-9', 'C# 6.0 in a Nutshell, 6th Edition', 'Joseph Albahari, Ben Albahari', 'c_sharp_6.jpg', 'When you have questions about C# 6.0 or the .NET CLR and its core Framework assemblies, this bestselling guide has the answers you need. C# has become a language of unusual flexibility and breadth since its premiere in 2000, but this continual growth means there\'s still much more to learn.\r\n\r\nOrganized around concepts and use cases, this thoroughly updated sixth edition provides intermediate and advanced programmers with a concise map of C# and .NET knowledge. Dive in and discover why this Nutshell guide is considered the definitive reference on C#.', '20.00', 3);

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `customerid` int(10) UNSIGNED NOT NULL,
  `name` varchar(60) NOT NULL,
  `address` varchar(80) NOT NULL,
  `city` varchar(30) NOT NULL,
  `zip_code` varchar(10) NOT NULL,
  `country` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`customerid`, `name`, `address`, `city`, `zip_code`, `country`) VALUES
(5, 'angel jude suarez', 'brgy. tooy', 'himamaylan city', '6108', 'philippines');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `orderid` int(10) UNSIGNED NOT NULL,
  `customerid` int(10) UNSIGNED NOT NULL,
  `amount` decimal(6,2) DEFAULT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp(),
  `ship_name` char(60) NOT NULL,
  `ship_address` char(80) NOT NULL,
  `ship_city` char(30) NOT NULL,
  `ship_zip_code` char(10) NOT NULL,
  `ship_country` char(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`orderid`, `customerid`, `amount`, `date`, `ship_name`, `ship_address`, `ship_city`, `ship_zip_code`, `ship_country`) VALUES
(7, 5, '20.00', '2021-03-10 05:03:55', 'angel jude suarez', 'brgy. tooy', 'himamaylan city', '6108', 'philippines');

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `orderid` int(10) UNSIGNED NOT NULL,
  `book_isbn` varchar(20) NOT NULL,
  `item_price` decimal(6,2) NOT NULL,
  `quantity` tinyint(3) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`orderid`, `book_isbn`, `item_price`, `quantity`) VALUES
(1, '978-1-118-94924-5', '20.00', 1),
(1, '978-1-44937-019-0', '20.00', 1),
(1, '978-1-49192-706-9', '20.00', 1),
(2, '978-1-118-94924-5', '20.00', 1),
(2, '978-1-44937-019-0', '20.00', 1),
(2, '978-1-49192-706-9', '20.00', 1),
(3, '978-0-321-94786-4', '20.00', 1),
(1, '978-1-49192-706-9', '20.00', 1),
(5, '978-1-484217-26-9', '20.00', 4),
(5, '978-1-118-94924-5', '20.00', 1),
(7, '978-0-321-94786-4', '20.00', 1),
(7, '978-0-7303-1484-4', '20.00', 1),
(7, '978-1-118-94924-5', '20.00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `publisher`
--

CREATE TABLE `publisher` (
  `publisherid` int(10) UNSIGNED NOT NULL,
  `publisher_name` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `publisher`
--

INSERT INTO `publisher` (`publisherid`, `publisher_name`) VALUES
(1, 'Wrox'),
(2, 'Wiley'),
(3, 'O\'Reilly Media'),
(4, 'Apress'),
(5, 'Packt Publishing'),
(6, 'Addison-Wesley');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`name`,`pass`);

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`book_isbn`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`customerid`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`orderid`);

--
-- Indexes for table `publisher`
--
ALTER TABLE `publisher`
  ADD PRIMARY KEY (`publisherid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `customerid` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `orderid` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `publisher`
--
ALTER TABLE `publisher`
  MODIFY `publisherid` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- Database: `e-commerce_dairyfarmshop-mng-sys`
--
CREATE DATABASE IF NOT EXISTS `e-commerce_dairyfarmshop-mng-sys` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `e-commerce_dairyfarmshop-mng-sys`;

-- --------------------------------------------------------

--
-- Table structure for table `tbladmin`
--

CREATE TABLE `tbladmin` (
  `ID` int(5) NOT NULL,
  `AdminName` varchar(45) DEFAULT NULL,
  `UserName` char(45) DEFAULT NULL,
  `MobileNumber` bigint(11) DEFAULT NULL,
  `Email` varchar(120) DEFAULT NULL,
  `Password` varchar(120) DEFAULT NULL,
  `AdminRegdate` timestamp NULL DEFAULT current_timestamp(),
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tbladmin`
--

INSERT INTO `tbladmin` (`ID`, `AdminName`, `UserName`, `MobileNumber`, `Email`, `Password`, `AdminRegdate`, `UpdationDate`) VALUES
(1, 'Admin', 'admin', 1234567890, 'admin@test.com', 'f925916e2754e5e03f75dd58a5733251', '2019-12-22 18:30:00', '2023-01-04 12:13:49');

-- --------------------------------------------------------

--
-- Table structure for table `tblcategory`
--

CREATE TABLE `tblcategory` (
  `id` int(11) NOT NULL,
  `CategoryName` varchar(200) DEFAULT NULL,
  `CategoryCode` varchar(50) DEFAULT NULL,
  `PostingDate` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblcategory`
--

INSERT INTO `tblcategory` (`id`, `CategoryName`, `CategoryCode`, `PostingDate`) VALUES
(1, 'Milk', 'MK01', '2019-12-24 16:27:43'),
(2, 'Butter', 'BT01', '2019-12-24 16:27:59'),
(3, 'Bread', 'BD01', '2019-12-24 16:28:12'),
(4, 'Paneer', 'PN01', '2019-12-24 16:29:18'),
(5, 'Soya', 'SY01', '2019-12-24 16:29:58'),
(7, 'Ghee', 'GH01', '2019-12-25 14:52:08');

-- --------------------------------------------------------

--
-- Table structure for table `tblcompany`
--

CREATE TABLE `tblcompany` (
  `id` int(11) NOT NULL,
  `CompanyName` varchar(150) DEFAULT NULL,
  `PostingDate` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblcompany`
--

INSERT INTO `tblcompany` (`id`, `CompanyName`, `PostingDate`) VALUES
(1, 'Amul', '2019-12-25 03:30:51'),
(2, 'Mother Diary', '2019-12-25 03:30:59'),
(3, 'Patanjali', '2019-12-25 03:31:09'),
(4, 'Namaste India', '2019-12-25 03:31:21'),
(5, 'Moll', '2023-12-25 14:52:50'),
(6, 'Moll', '2023-12-25 14:52:50'),
(7, 'Moll', '2023-12-25 14:52:50'),
(8, 'Moll', '2023-12-25 14:52:50'),
(9, 'Moll', '2023-12-25 14:52:50'),
(10, 'Paras', '2019-12-25 14:52:50'),
(11, 'Moll', '2023-12-25 14:52:50'),
(12, 'Moll', '2023-12-25 14:52:50'),
(13, 'Moll', '2023-12-25 14:52:50'),
(14, 'Moll', '2023-12-25 14:52:50'),
(15, 'Moll', '2023-12-25 14:52:50');

-- --------------------------------------------------------

--
-- Table structure for table `tblorders`
--

CREATE TABLE `tblorders` (
  `id` int(11) NOT NULL,
  `ProductId` int(11) DEFAULT NULL,
  `Quantity` int(11) DEFAULT NULL,
  `InvoiceNumber` int(11) DEFAULT NULL,
  `CustomerName` varchar(150) DEFAULT NULL,
  `CustomerContactNo` bigint(12) DEFAULT NULL,
  `PaymentMode` varchar(100) DEFAULT NULL,
  `InvoiceGenDate` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblorders`
--

INSERT INTO `tblorders` (`id`, `ProductId`, `Quantity`, `InvoiceNumber`, `CustomerName`, `CustomerContactNo`, `PaymentMode`, `InvoiceGenDate`) VALUES
(1, 4, 2, 753947547, 'Anuj', 9354778033, 'cash', '2019-12-25 08:32:47'),
(2, 1, 1, 753947547, 'Anuj', 9354778033, 'card', '2019-12-25 08:32:47'),
(3, 1, 1, 979148350, 'Sanjeen', 1234567890, 'card', '2019-12-25 11:38:08'),
(4, 4, 1, 979148350, 'Sanjeen', 1234567890, 'card', '2019-12-25 11:38:08'),
(5, 1, 1, 861354457, 'Rahul', 9876543210, 'cash', '2019-12-24 11:43:48'),
(6, 5, 1, 861354457, 'Rahul', 9876543210, 'cash', '2019-12-24 11:43:48'),
(7, 5, 1, 276794782, 'Sarita', 1122334455, 'cash', '2019-12-25 11:48:06'),
(8, 6, 1, 276794782, 'Sarita', 1122334455, 'cash', '2019-12-25 11:48:06'),
(9, 6, 2, 744608164, 'Babu Pandey', 123458962, 'card', '2019-12-25 12:07:50'),
(10, 2, 2, 744608164, 'Babu Pandey', 123458962, 'card', '2019-12-25 12:07:50'),
(11, 7, 1, 139640585, 'John', 45632147892, 'cash', '2019-12-25 14:54:24'),
(12, 5, 1, 139640585, 'John', 45632147892, 'cash', '2019-12-25 14:54:24');

-- --------------------------------------------------------

--
-- Table structure for table `tblproducts`
--

CREATE TABLE `tblproducts` (
  `id` int(11) NOT NULL,
  `CategoryName` varchar(150) DEFAULT NULL,
  `CompanyName` varchar(150) DEFAULT NULL,
  `ProductName` varchar(150) DEFAULT NULL,
  `ProductPrice` decimal(10,0) DEFAULT current_timestamp(),
  `PostingDate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblproducts`
--

INSERT INTO `tblproducts` (`id`, `CategoryName`, `CompanyName`, `ProductName`, `ProductPrice`, `PostingDate`, `UpdationDate`) VALUES
(1, 'Milk', 'Amul', 'Toned milk 500ml', '22', '2019-12-25 05:22:37', '2019-12-25 05:22:37'),
(2, 'Milk', 'Amul', 'Toned milk 1ltr', '42', '2019-12-25 04:25:20', NULL),
(3, 'Milk', 'Mother Diary', 'Full Cream Milk 500ml', '26', '2019-12-25 06:42:24', '2019-12-25 06:42:24'),
(4, 'Milk', 'Mother Diary', 'Full Cream Milk 1ltr', '50', '2019-12-25 06:42:39', '2019-12-25 06:42:39'),
(5, 'Butter', 'Amul', 'Butter 100mg', '46', '2019-12-25 11:42:56', '2019-12-25 11:42:56'),
(6, 'Bread', 'Patanjali', 'Sandwich Bread', '30', '2019-12-25 11:40:10', NULL),
(7, 'Ghee', 'Paras', 'Ghee 500mg', '350', '2019-12-25 14:53:33', '2019-12-25 14:53:33');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbladmin`
--
ALTER TABLE `tbladmin`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tblcategory`
--
ALTER TABLE `tblcategory`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblcompany`
--
ALTER TABLE `tblcompany`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblorders`
--
ALTER TABLE `tblorders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblproducts`
--
ALTER TABLE `tblproducts`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbladmin`
--
ALTER TABLE `tbladmin`
  MODIFY `ID` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tblcategory`
--
ALTER TABLE `tblcategory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tblcompany`
--
ALTER TABLE `tblcompany`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `tblorders`
--
ALTER TABLE `tblorders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `tblproducts`
--
ALTER TABLE `tblproducts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- Database: `e-commerce_sales&inventory-system`
--
CREATE DATABASE IF NOT EXISTS `e-commerce_sales&inventory-system` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `e-commerce_sales&inventory-system`;

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `CATEGORY_ID` int(11) NOT NULL,
  `CNAME` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`CATEGORY_ID`, `CNAME`) VALUES
(0, 'Keyboard'),
(1, 'Mouse'),
(2, 'Monitor'),
(3, 'Motherboard'),
(4, 'Processor'),
(5, 'Power Supply'),
(6, 'Headset'),
(7, 'CPU'),
(9, 'Others');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `CUST_ID` int(11) NOT NULL,
  `FIRST_NAME` varchar(50) DEFAULT NULL,
  `LAST_NAME` varchar(50) DEFAULT NULL,
  `PHONE_NUMBER` varchar(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`CUST_ID`, `FIRST_NAME`, `LAST_NAME`, `PHONE_NUMBER`) VALUES
(9, 'Hailee', 'Steinfield', '09394566543'),
(11, 'A Walk in Customer', 'Harry', '08523697410'),
(14, 'Chuchay', 'Jusay', '09781633451'),
(15, 'Kimbert', 'Duyag', '09956288467'),
(16, 'Dieqcohr', 'Rufino', '09891344576');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `EMPLOYEE_ID` int(11) NOT NULL,
  `FIRST_NAME` varchar(50) DEFAULT NULL,
  `LAST_NAME` varchar(50) DEFAULT NULL,
  `GENDER` varchar(50) DEFAULT NULL,
  `EMAIL` varchar(100) DEFAULT NULL,
  `PHONE_NUMBER` varchar(11) DEFAULT NULL,
  `JOB_ID` int(11) DEFAULT NULL,
  `HIRED_DATE` varchar(50) NOT NULL,
  `LOCATION_ID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`EMPLOYEE_ID`, `FIRST_NAME`, `LAST_NAME`, `GENDER`, `EMAIL`, `PHONE_NUMBER`, `JOB_ID`, `HIRED_DATE`, `LOCATION_ID`) VALUES
(1, 'Prince Ly', 'Cesar', 'Male', 'princelycesar23@gmail.com', '09124033805', 1, '0000-00-00', 113),
(2, 'Josuey', 'Mag-asos', 'Male', 'jmagaso@yahoo.com', '09091245761', 2, '2019-01-28', 156),
(4, 'Monica', 'Empinado', 'Female', 'monicapadernal@gmail.com', '09123357105', 1, '2019-03-06', 158);

-- --------------------------------------------------------

--
-- Table structure for table `job`
--

CREATE TABLE `job` (
  `JOB_ID` int(11) NOT NULL,
  `JOB_TITLE` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `job`
--

INSERT INTO `job` (`JOB_ID`, `JOB_TITLE`) VALUES
(1, 'Manager'),
(2, 'Cashier');

-- --------------------------------------------------------

--
-- Table structure for table `location`
--

CREATE TABLE `location` (
  `LOCATION_ID` int(11) NOT NULL,
  `PROVINCE` varchar(100) DEFAULT NULL,
  `CITY` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `location`
--

INSERT INTO `location` (`LOCATION_ID`, `PROVINCE`, `CITY`) VALUES
(111, 'Negros Occidental', 'Bacolod City'),
(112, 'Negros Occidental', 'Bacolod City'),
(113, 'Negros Occidental', 'Binalbagan'),
(114, 'Negros Occidental', 'Himamaylan'),
(115, 'Negros Oriental', 'Dumaguette City'),
(116, 'Negros Occidental', 'Isabella'),
(126, 'Negros Occidental', 'Binalbagan'),
(130, 'Cebu', 'Bogo City'),
(131, 'Negros Occidental', 'Himamaylan'),
(132, 'Negros', 'Jupiter'),
(133, 'Aincrad', 'Floor 91'),
(134, 'negros', 'binalbagan'),
(135, 'hehe', 'tehee'),
(136, 'PLANET YEKOK', 'KOKEY'),
(137, 'Camiguin', 'Catarman'),
(138, 'Camiguin', 'Catarman'),
(139, 'Negros Occidental', 'Binalbagan'),
(140, 'Batangas', 'Lemery'),
(141, 'Capiz', 'Panay'),
(142, 'Camarines Norte', 'Labo'),
(143, 'Camarines Norte', 'Labo'),
(144, 'Camarines Norte', 'Labo'),
(145, 'Camarines Norte', 'Labo'),
(146, 'Capiz', 'Pilar'),
(147, 'Negros Occidental', 'Moises Padilla'),
(148, 'a', 'a'),
(149, '1', '1'),
(150, 'Negros Occidental', 'Himamaylan'),
(151, 'Masbate', 'Mandaon'),
(152, 'Aklanas', 'Madalagsasa'),
(153, 'Batangas', 'Mabini'),
(154, 'Bataan', 'Morong'),
(155, 'Capiz', 'Pillar'),
(156, 'Negros Occidental', 'Bacolod'),
(157, 'Camarines Norte', 'Labo'),
(158, 'Negros Occidental', 'Binalbagan');

-- --------------------------------------------------------

--
-- Table structure for table `manager`
--

CREATE TABLE `manager` (
  `FIRST_NAME` varchar(50) DEFAULT NULL,
  `LAST_NAME` varchar(50) DEFAULT NULL,
  `LOCATION_ID` int(11) NOT NULL,
  `EMAIL` varchar(50) DEFAULT NULL,
  `PHONE_NUMBER` varchar(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `manager`
--

INSERT INTO `manager` (`FIRST_NAME`, `LAST_NAME`, `LOCATION_ID`, `EMAIL`, `PHONE_NUMBER`) VALUES
('Prince Ly', 'Cesar', 113, 'PC@00', '09124033805'),
('Emman', 'Adventures', 116, 'emman@', '09123346576'),
('Bruce', 'Willis', 113, 'bruce@', NULL),
('Regine', 'Santos', 111, 'regine@', '09123456789');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `PRODUCT_ID` int(11) NOT NULL,
  `PRODUCT_CODE` varchar(20) NOT NULL,
  `NAME` varchar(50) DEFAULT NULL,
  `DESCRIPTION` varchar(250) NOT NULL,
  `QTY_STOCK` int(50) DEFAULT NULL,
  `ON_HAND` int(250) NOT NULL,
  `PRICE` int(50) DEFAULT NULL,
  `CATEGORY_ID` int(11) DEFAULT NULL,
  `SUPPLIER_ID` int(11) DEFAULT NULL,
  `DATE_STOCK_IN` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`PRODUCT_ID`, `PRODUCT_CODE`, `NAME`, `DESCRIPTION`, `QTY_STOCK`, `ON_HAND`, `PRICE`, `CATEGORY_ID`, `SUPPLIER_ID`, `DATE_STOCK_IN`) VALUES
(1, '20191001', 'Lenovo ideapad 20059', 'Windows 8', 1, 1, 32999, 7, 15, '2019-03-02'),
(3, '20191003', 'Predator Helios 300 Gaming Laptop', 'Windows 10 Home\r\nIntelÂ® Coreâ„¢ i7-8750H processor Hexa-core 2.20 GHz\r\n15.6\" Full HD (1920 x 1080) ', 1, 1, 77850, 7, 15, '2019-03-02'),
(4, '20191002', 'Newmen E120', 'hehe', 1, 1, 550, 0, 11, '2019-03-02'),
(5, '20191002', 'Newmen E120', 'hehe', 1, 1, 550, 0, 15, '2019-03-03'),
(6, '20191002', 'Newmen E120', 'hehe', 1, 1, 550, 0, 11, '2019-03-04'),
(8, '20191002', 'Newmen E120', 'hehe', 1, 1, 550, 0, 11, '2019-03-05'),
(9, '20191002', 'Newmen E120', 'hehe', 1, 1, 550, 0, 11, '2019-03-04'),
(10, '20191004', 'Fantech EG1', 'BEST FOR MOBILE PHONE GAMERS\r\nSPEAKER:10mm\r\nIMPEDANCE: 18+-15%\r\nFREQUENCY RESPONSE: 20 TO 20khz\r\nMICROPHONE : OMNI DIRECTIONAL\r\nJACK: AUDIO+MICROPHONE\r\nCOMBINED JACK 3.5 WIRE\r\nWIRE LENGTH: 1.3M\r\nWhat in inside:-1 pcs Female 3.5mm to Audio and\r\nmicrop', 1, 1, 859, 6, 13, '2019-03-06'),
(11, '20191004', 'Fantech EG1', 'a', 1, 1, 895, 6, 13, '2019-03-01'),
(12, '20191004', 'Fantech EG1', 'a', 1, 1, 895, 6, 13, '2019-03-01'),
(13, '20191004', 'Fantech EG1', 'a', 1, 1, 895, 6, 13, '2019-03-01'),
(14, '20191002', 'Newmen E120', 'haha', 1, 1, 550, 0, 15, '2019-03-06'),
(15, '20191002', 'Newmen E120', 'haha', 1, 1, 550, 0, 15, '2019-03-06'),
(16, '20191002', 'Newmen E120', 'haha', 1, 1, 550, 0, 15, '2019-03-06'),
(17, '20191002', 'Newmen E120', 'haha', 1, 1, 550, 0, 15, '2019-03-06'),
(18, '20191002', 'Newmen E120', 'haha', 1, 1, 550, 0, 15, '2019-03-06'),
(19, '20191002', 'Newmen E120', 'haha', 1, 1, 550, 0, 15, '2019-03-06'),
(20, '20191002', 'Newmen E120', 'haha', 1, 1, 550, 0, 15, '2019-03-06'),
(21, '20191002', 'Newmen E120', 'haha', 1, 1, 550, 0, 15, '2019-03-06'),
(22, '20191001', 'Lenovo ideapad 20059', 'hehe', 1, 1, 32999, 7, 12, '2019-03-11'),
(23, '20191001', 'Lenovo ideapad 20059', 'hehe', 1, 1, 32999, 7, 12, '2019-03-11'),
(24, '20191001', 'Lenovo ideapad 20059', 'hehe', 1, 1, 32999, 7, 12, '2019-03-11'),
(25, '20191001', 'Lenovo ideapad 20059', 'hehe', 1, 1, 32999, 7, 12, '2019-03-11'),
(26, '20191001', 'Lenovo ideapad 20059', 'hehe', 1, 1, 32999, 7, 12, '2019-03-11'),
(27, '20191005', 'A4tech OP-720', 'normal mouse', 1, 1, 289, 1, 16, '2019-03-13');

-- --------------------------------------------------------

--
-- Table structure for table `supplier`
--

CREATE TABLE `supplier` (
  `SUPPLIER_ID` int(11) NOT NULL,
  `COMPANY_NAME` varchar(50) DEFAULT NULL,
  `LOCATION_ID` int(11) NOT NULL,
  `PHONE_NUMBER` varchar(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `supplier`
--

INSERT INTO `supplier` (`SUPPLIER_ID`, `COMPANY_NAME`, `LOCATION_ID`, `PHONE_NUMBER`) VALUES
(11, 'InGame Tech', 114, '09457488521'),
(12, 'Asus', 115, '09635877412'),
(13, 'Razer Co.', 111, '09587855685'),
(15, 'Strategic Technology Co.', 116, '09124033805'),
(16, 'A4tech', 155, '09775673257');

-- --------------------------------------------------------

--
-- Table structure for table `transaction`
--

CREATE TABLE `transaction` (
  `TRANS_ID` int(50) NOT NULL,
  `CUST_ID` int(11) DEFAULT NULL,
  `NUMOFITEMS` varchar(250) NOT NULL,
  `SUBTOTAL` varchar(50) NOT NULL,
  `LESSVAT` varchar(50) NOT NULL,
  `NETVAT` varchar(50) NOT NULL,
  `ADDVAT` varchar(50) NOT NULL,
  `GRANDTOTAL` varchar(250) NOT NULL,
  `CASH` varchar(250) NOT NULL,
  `DATE` varchar(50) NOT NULL,
  `TRANS_D_ID` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `transaction`
--

INSERT INTO `transaction` (`TRANS_ID`, `CUST_ID`, `NUMOFITEMS`, `SUBTOTAL`, `LESSVAT`, `NETVAT`, `ADDVAT`, `GRANDTOTAL`, `CASH`, `DATE`, `TRANS_D_ID`) VALUES
(3, 16, '3', '456,982.00', '48,962.36', '408,019.64', '48,962.36', '456,982.00', '500000', '2019-03-18', '0318160336'),
(4, 11, '2', '1,967.00', '210.75', '1,756.25', '210.75', '1,967.00', '2000', '2019-03-18', '0318160622'),
(5, 14, '1', '550.00', '58.93', '491.07', '58.93', '550.00', '550', '2019-03-18', '0318170309'),
(6, 15, '1', '77,850.00', '8,341.07', '69,508.93', '8,341.07', '77,850.00', '80000', '2019-03-18', '0318170352'),
(7, 16, '1', '1,718.00', '184.07', '1,533.93', '184.07', '1,718.00', '2000', '2019-03-18', '0318170511'),
(8, 16, '1', '1,718.00', '184.07', '1,533.93', '184.07', '1,718.00', '2000', '2019-03-18', '0318170524'),
(9, 14, '1', '1,718.00', '184.07', '1,533.93', '184.07', '1,718.00', '2000', '2019-03-18', '0318170551'),
(10, 11, '1', '289.00', '30.96', '258.04', '30.96', '289.00', '500', '2019-03-18', '0318170624'),
(11, 9, '2', '1,148.00', '123.00', '1,025.00', '123.00', '1,148.00', '2000', '2019-03-18', '0318170825'),
(12, 9, '1', '5,500.00', '589.29', '4,910.71', '589.29', '5,500.00', '6000', '2019-03-18 19:40 pm', '0318194016'),
(13, 11, '3', '10,694.00', '1,145.79', '9,548.21', '1,145.79', '10,694.00', '10694.00', '2023-01-01 06:40 am', '010164156');

-- --------------------------------------------------------

--
-- Table structure for table `transaction_details`
--

CREATE TABLE `transaction_details` (
  `ID` int(11) NOT NULL,
  `TRANS_D_ID` varchar(250) NOT NULL,
  `PRODUCTS` varchar(250) NOT NULL,
  `QTY` varchar(250) NOT NULL,
  `PRICE` varchar(250) NOT NULL,
  `EMPLOYEE` varchar(250) NOT NULL,
  `ROLE` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `transaction_details`
--

INSERT INTO `transaction_details` (`ID`, `TRANS_D_ID`, `PRODUCTS`, `QTY`, `PRICE`, `EMPLOYEE`, `ROLE`) VALUES
(7, '0318160336', 'Lenovo ideapad 20059', '2', '32999', 'Prince Ly', 'Manager'),
(8, '0318160336', 'Predator Helios 300 Gaming Laptop', '5', '77850', 'Prince Ly', 'Manager'),
(9, '0318160336', 'A4tech OP-720', '6', '289', 'Prince Ly', 'Manager'),
(10, '0318160622', 'Newmen E120', '2', '550', 'Prince Ly', 'Manager'),
(11, '0318160622', 'A4tech OP-720', '3', '289', 'Prince Ly', 'Manager'),
(12, '0318170309', 'Newmen E120', '1', '550', 'Prince Ly', 'Manager'),
(13, '0318170352', 'Predator Helios 300 Gaming Laptop', '1', '77850', 'Prince Ly', 'Manager'),
(14, '0318170511', 'Fantech EG1', '2', '859', 'Prince Ly', 'Manager'),
(15, '0318170524', 'Fantech EG1', '2', '859', 'Prince Ly', 'Manager'),
(16, '0318170551', 'Fantech EG1', '2', '859', 'Prince Ly', 'Manager'),
(17, '0318170624', 'A4tech OP-720', '1', '289', 'Prince Ly', 'Manager'),
(18, '0318170825', 'A4tech OP-720', '1', '289', 'Prince Ly', 'Manager'),
(19, '0318170825', 'Fantech EG1', '1', '859', 'Prince Ly', 'Manager'),
(20, '0318194016', 'Newmen E120', '10', '550', 'Josuey', 'Cashier'),
(21, '010164156', 'Fantech EG1', '1', '859', 'Josuey', 'Cashier'),
(22, '010164156', 'Newmen E120', '10', '550', 'Josuey', 'Cashier'),
(23, '010164156', 'A4tech OP-720', '15', '289', 'Josuey', 'Cashier');

-- --------------------------------------------------------

--
-- Table structure for table `type`
--

CREATE TABLE `type` (
  `TYPE_ID` int(11) NOT NULL,
  `TYPE` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `type`
--

INSERT INTO `type` (`TYPE_ID`, `TYPE`) VALUES
(1, 'Admin'),
(2, 'User');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `ID` int(11) NOT NULL,
  `EMPLOYEE_ID` int(11) DEFAULT NULL,
  `USERNAME` varchar(50) DEFAULT NULL,
  `PASSWORD` varchar(50) DEFAULT NULL,
  `TYPE_ID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`ID`, `EMPLOYEE_ID`, `USERNAME`, `PASSWORD`, `TYPE_ID`) VALUES
(1, 1, 'unguardable', '46ebaaa2b80c7a3459b80353e085aaeed5aff2ff', 1),
(7, 2, 'test', 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3', 2),
(9, 4, 'mncpdrnl', '8cb2237d0679ca88db6464eac60da96345513964', 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`CATEGORY_ID`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`CUST_ID`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`EMPLOYEE_ID`),
  ADD UNIQUE KEY `EMPLOYEE_ID` (`EMPLOYEE_ID`),
  ADD UNIQUE KEY `PHONE_NUMBER` (`PHONE_NUMBER`),
  ADD KEY `LOCATION_ID` (`LOCATION_ID`),
  ADD KEY `JOB_ID` (`JOB_ID`);

--
-- Indexes for table `job`
--
ALTER TABLE `job`
  ADD PRIMARY KEY (`JOB_ID`);

--
-- Indexes for table `location`
--
ALTER TABLE `location`
  ADD PRIMARY KEY (`LOCATION_ID`);

--
-- Indexes for table `manager`
--
ALTER TABLE `manager`
  ADD UNIQUE KEY `PHONE_NUMBER` (`PHONE_NUMBER`),
  ADD KEY `LOCATION_ID` (`LOCATION_ID`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`PRODUCT_ID`),
  ADD KEY `CATEGORY_ID` (`CATEGORY_ID`),
  ADD KEY `SUPPLIER_ID` (`SUPPLIER_ID`);

--
-- Indexes for table `supplier`
--
ALTER TABLE `supplier`
  ADD PRIMARY KEY (`SUPPLIER_ID`),
  ADD KEY `LOCATION_ID` (`LOCATION_ID`);

--
-- Indexes for table `transaction`
--
ALTER TABLE `transaction`
  ADD PRIMARY KEY (`TRANS_ID`),
  ADD KEY `TRANS_DETAIL_ID` (`TRANS_D_ID`),
  ADD KEY `CUST_ID` (`CUST_ID`);

--
-- Indexes for table `transaction_details`
--
ALTER TABLE `transaction_details`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `TRANS_D_ID` (`TRANS_D_ID`) USING BTREE;

--
-- Indexes for table `type`
--
ALTER TABLE `type`
  ADD PRIMARY KEY (`TYPE_ID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `TYPE_ID` (`TYPE_ID`),
  ADD KEY `EMPLOYEE_ID` (`EMPLOYEE_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `CATEGORY_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `CUST_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `EMPLOYEE_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `location`
--
ALTER TABLE `location`
  MODIFY `LOCATION_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=159;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `PRODUCT_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `supplier`
--
ALTER TABLE `supplier`
  MODIFY `SUPPLIER_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `transaction`
--
ALTER TABLE `transaction`
  MODIFY `TRANS_ID` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `transaction_details`
--
ALTER TABLE `transaction_details`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `employee`
--
ALTER TABLE `employee`
  ADD CONSTRAINT `employee_ibfk_1` FOREIGN KEY (`LOCATION_ID`) REFERENCES `location` (`LOCATION_ID`),
  ADD CONSTRAINT `employee_ibfk_2` FOREIGN KEY (`JOB_ID`) REFERENCES `job` (`JOB_ID`);

--
-- Constraints for table `manager`
--
ALTER TABLE `manager`
  ADD CONSTRAINT `manager_ibfk_1` FOREIGN KEY (`LOCATION_ID`) REFERENCES `location` (`LOCATION_ID`);

--
-- Constraints for table `product`
--
ALTER TABLE `product`
  ADD CONSTRAINT `product_ibfk_1` FOREIGN KEY (`CATEGORY_ID`) REFERENCES `category` (`CATEGORY_ID`),
  ADD CONSTRAINT `product_ibfk_2` FOREIGN KEY (`SUPPLIER_ID`) REFERENCES `supplier` (`SUPPLIER_ID`);

--
-- Constraints for table `supplier`
--
ALTER TABLE `supplier`
  ADD CONSTRAINT `supplier_ibfk_1` FOREIGN KEY (`LOCATION_ID`) REFERENCES `location` (`LOCATION_ID`);

--
-- Constraints for table `transaction`
--
ALTER TABLE `transaction`
  ADD CONSTRAINT `transaction_ibfk_3` FOREIGN KEY (`CUST_ID`) REFERENCES `customer` (`CUST_ID`),
  ADD CONSTRAINT `transaction_ibfk_4` FOREIGN KEY (`TRANS_D_ID`) REFERENCES `transaction_details` (`TRANS_D_ID`);

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_3` FOREIGN KEY (`TYPE_ID`) REFERENCES `type` (`TYPE_ID`),
  ADD CONSTRAINT `users_ibfk_4` FOREIGN KEY (`EMPLOYEE_ID`) REFERENCES `employee` (`EMPLOYEE_ID`);
--
-- Database: `eswarigroup_aseinteriors`
--
CREATE DATABASE IF NOT EXISTS `eswarigroup_aseinteriors` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `eswarigroup_aseinteriors`;

-- --------------------------------------------------------

--
-- Table structure for table `contact_form`
--

CREATE TABLE `contact_form` (
  `s.no` tinyint(3) NOT NULL,
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile` bigint(11) NOT NULL,
  `email` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contact_form`
--

INSERT INTO `contact_form` (`s.no`, `name`, `mobile`, `email`, `message`) VALUES
(1, 'hari', 7896536220, 'hari@gmail.com', 'xdvbfzd'),
(2, 'neelima i', 9963552388, 'kalyanneelima28@gmail.com', 'good services');

-- --------------------------------------------------------

--
-- Table structure for table `newsletter`
--

CREATE TABLE `newsletter` (
  `sno` tinyint(3) NOT NULL,
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `newsletter`
--

INSERT INTO `newsletter` (`sno`, `name`, `email`) VALUES
(1, 'hari', 'hari@gmail.com'),
(24, 'neelima i', 'kalyanneelima28@gmail.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contact_form`
--
ALTER TABLE `contact_form`
  ADD PRIMARY KEY (`s.no`);

--
-- Indexes for table `newsletter`
--
ALTER TABLE `newsletter`
  ADD PRIMARY KEY (`sno`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contact_form`
--
ALTER TABLE `contact_form`
  MODIFY `s.no` tinyint(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `newsletter`
--
ALTER TABLE `newsletter`
  MODIFY `sno` tinyint(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
--
-- Database: `eswarigroup_eswarigroup`
--
CREATE DATABASE IF NOT EXISTS `eswarigroup_eswarigroup` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `eswarigroup_eswarigroup`;

-- --------------------------------------------------------

--
-- Table structure for table `enquiry_form`
--

CREATE TABLE `enquiry_form` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `flat` varchar(20) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `added_on` varchar(55) NOT NULL,
  `location` varchar(100) NOT NULL,
  `budget` varchar(20) NOT NULL,
  `project` varchar(55) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `enquiry_form`
--

INSERT INTO `enquiry_form` (`id`, `name`, `email`, `flat`, `mobile`, `added_on`, `location`, `budget`, `project`) VALUES
(1, 'chandu', 'test@gmail.com', '3BHK', '9010402324', '07-09-2022', 'hyd', '8900000', 'Madhurwada'),
(2, 'chandu', 'chandhu418@gmail.com', '-', '9010402324', '07-09-2022', 'hyd', '-', 'Madhurwada'),
(3, 'chandrashekher', 'chandhu418@gmail.com', '-', '5645656456456', '13-09-2022', 'hyd', '-', 'aganampudi'),
(4, 'chandu', 'chandhu418@gmail.com', '-', '5645656456456', '13-09-2022', 'hyd', '-', 'pedagantyada');

-- --------------------------------------------------------

--
-- Table structure for table `gallery`
--

CREATE TABLE `gallery` (
  `id` int(11) NOT NULL,
  `title` text NOT NULL,
  `sub_title` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `gallery`
--

INSERT INTO `gallery` (`id`, `title`, `sub_title`) VALUES
(1, 'Bhoomi Pooja-14th October 2021', 'Aganampudi'),
(2, 'Review Meeting 2021', 'Vizag');

-- --------------------------------------------------------

--
-- Table structure for table `gallery_images`
--

CREATE TABLE `gallery_images` (
  `id` int(11) NOT NULL,
  `gallery_id` int(11) NOT NULL,
  `image` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `gallery_images`
--

INSERT INTO `gallery_images` (`id`, `gallery_id`, `image`) VALUES
(1, 1, '1.jpeg'),
(2, 1, '2.jpeg'),
(3, 1, '3.jpeg'),
(4, 1, '4.jpeg'),
(5, 1, '5.jpeg'),
(6, 1, '6.jpeg'),
(7, 1, '7.jpeg'),
(8, 1, '8.jpeg'),
(9, 2, '1_1.jpeg'),
(10, 2, '2_2.jpeg'),
(11, 2, '3_3.jpeg'),
(12, 2, '4_4.jpeg'),
(13, 2, '5_5.jpeg'),
(14, 2, '6_6.jpeg'),
(15, 2, '7_7.jpeg'),
(16, 2, '8_8.jpeg'),
(17, 2, '9.jpeg'),
(18, 2, '10.jpeg'),
(19, 2, '11.jpeg'),
(20, 2, '12.jpeg'),
(21, 2, '13.jpeg'),
(22, 2, '14.jpeg'),
(23, 2, '15.jpeg'),
(24, 2, '16.jpeg'),
(25, 2, '17.jpeg'),
(26, 2, '18.jpeg'),
(27, 2, '19.jpeg'),
(28, 2, '424.jpeg'),
(29, 2, '425.jpeg'),
(30, 2, '426.jpeg'),
(31, 2, '427.jpeg'),
(32, 2, '422.jpeg'),
(33, 2, '421.jpeg'),
(34, 2, '428.jpeg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `gallery`
--
ALTER TABLE `gallery`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gallery_images`
--
ALTER TABLE `gallery_images`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `gallery`
--
ALTER TABLE `gallery`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `gallery_images`
--
ALTER TABLE `gallery_images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;
--
-- Database: `eswarigroup_eswarihomes`
--
CREATE DATABASE IF NOT EXISTS `eswarigroup_eswarihomes` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `eswarigroup_eswarihomes`;

-- --------------------------------------------------------

--
-- Table structure for table `adminusers`
--

CREATE TABLE `adminusers` (
  `id` int(11) NOT NULL,
  `admin_name` varchar(55) NOT NULL,
  `admin_email` varchar(100) NOT NULL,
  `admin_pwd` varchar(55) NOT NULL,
  `admin_password` varchar(20) NOT NULL,
  `admin_type` varchar(20) NOT NULL,
  `status` int(11) NOT NULL,
  `admin_firstname` varchar(55) NOT NULL,
  `admin_lastname` varchar(55) NOT NULL,
  `admin_mobile` varchar(20) NOT NULL,
  `admin_area` varchar(55) NOT NULL,
  `admin_city` varchar(55) NOT NULL,
  `admin_district` varchar(55) NOT NULL,
  `admin_state` varchar(55) NOT NULL,
  `admin_pincode` varchar(11) NOT NULL,
  `admin_company` varchar(100) NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_by` int(11) NOT NULL,
  `updated_on` varchar(55) NOT NULL,
  `updated_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `adminusers`
--

INSERT INTO `adminusers` (`id`, `admin_name`, `admin_email`, `admin_pwd`, `admin_password`, `admin_type`, `status`, `admin_firstname`, `admin_lastname`, `admin_mobile`, `admin_area`, `admin_city`, `admin_district`, `admin_state`, `admin_pincode`, `admin_company`, `created_on`, `created_by`, `updated_on`, `updated_by`) VALUES
(1, 'eswarihomes', 'info@eswarigroup.com', 'e10adc3949ba59abbe56e057f20f883e', '456123@2021', 'superadmin', 1, 'Eswari', 'Homes', '8374631133', ' Northextension, Main road, Seethammadhara', 'Visakhapatnam', 'Visakhapatnam', 'Andhrapradesh', '530013', 'Eswari Groups', '2021-06-05 10:59:59', 1, '', 0),
(13, '', 'dealer1@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '123456', 'dealer', 1, 'Dealer1', 'Valepay', '9010402324', 'Yousufguda', 'Hyderabad', 'Hyderabad', 'Telnagana', '500045', 'Eswarihomes', '2020-07-31 13:15:45', 0, '', 0),
(14, '', 'dealer2@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '123456', 'dealer', 1, 'Dealer2', 'V', '901034567', 'Madhuranagar', 'Hyderabad', 'Hyderabad', 'Telangana', '500036', 'ABC', '2020-07-31 13:15:27', 0, '', 0),
(15, '', 'chandhu4128@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '123456', 'dealer', 1, 'Joshna', 'v', '9010402324', 'Yousufguda', 'Hyderabad', 'Hyderabad', 'Telangana', '500045', 'ABC', '2020-07-29 18:50:42', 0, '', 0),
(16, '', 'chandhu4189@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '123456', 'agent', 1, 'Chanduvvv', 'Valepay', '9010402324', 'Yousufguda', 'Hyderabad', 'Hyderabad', 'Telangana', '500045', 'ABC', '2020-07-31 13:32:22', 0, '', 0),
(17, '', 'jo@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '123456', 'dealer', 1, 'Joshna', 'Valepay', '9490908098', 'Yousufguda', 'Hyderabad', 'Hyderabad', 'Telangana', '500045', 'ABC', '2020-07-30 10:35:44', 0, '', 0),
(18, '', 'chandhu2418@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '123456', 'agent', 1, 'ssss', 'sasas', '9010402324', 'Yousufguda', 'Hyderabad', 'Hyderabad', 'Telangana', '500045', 'ABC', '2020-07-31 13:32:18', 0, '', 0),
(19, '', 'chandhu418@gmail.commm', 'e10adc3949ba59abbe56e057f20f883e', '123456', 'agent', 1, 'Chandu', 'dsdsa', '9010402324', 'Yousufguda', 'Hyderabad', 'Hyderabad', 'Telangana', '500045', 'ABC', '2020-07-31 13:32:13', 0, '', 0),
(20, '', '', '', '', '', 1, '', '', '', '', '', '', '', '', '', '2020-07-30 11:06:24', 0, '', 0),
(21, '', 'agent1@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '123456', 'agent', 1, 'sasas', 'asas', '765765767', 'Yousufguda', 'Hyderabad', 'Hyderabad', 'Telangana', '500045', 'ABC', '2020-07-31 13:16:05', 0, '', 0),
(22, '', 'dealer3@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '123456', 'dealer', 0, 'Dealer3', 's', '9010402324', 'Yousufguda', 'Hyderabad', 'Hyderabad', 'Telangana', '500045', 'ABC', '2020-07-31 13:16:35', 0, '', 0),
(23, '', 'nareshp777@gmail.com', 'e31f2f14dcb8cc9d86f2a33b575319b6', 'subhramanya7#', 'dealer', 0, 'PILLI', 'NARESH', '8096991326', 'PM PALEM', 'Visakhapatnam', 'Visakhapatnam', 'Andhra Pradesh', '530041', '', '2020-10-02 06:37:56', 0, '', 0),
(24, '', 'mallipaddirajasekhar55@gmail.com', '4f11ce4c7fcb236b8f5bea48ddae2a77', 'raja9640', 'dealer', 0, 'MALLIPADDI', 'RAJASEKHAR', '9640344728', 'Seethammadhara', 'Visakapatnam', 'Visakapatnam', 'Ap', '530013', '', '2020-10-02 12:55:08', 0, '', 0),
(25, '', 'hemalathagoud999@gmail.com', '4f11ce4c7fcb236b8f5bea48ddae2a77', 'raja9640', 'dealer', 0, 'MALLIPADDI', 'RAJASEKHAR', '9640344728', 'Seethammadhara', 'Visakapatnam', 'Visakapatnam', 'Ap', '530013', '', '2020-10-02 13:08:21', 0, '', 0),
(26, '', 'chandhu418@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '123456', 'agent', 1, 'Chandrashekher', 'V', '9010402324', 'Yousufguda', 'hyderabad', 'Hyderabad', 'telangana', '500045', '', '2020-12-21 05:24:27', 0, '', 0),
(27, '', 'alluries15666@gmail.com', '8737d7a19b9fffe657e415a04e1ef614', 'avrp@8898', 'Select Type', 0, 'A. Venkata', 'Ramprasad', '9392323445', 'Gunadala', 'Vijayawada', 'Krishna', 'Ap', '520008', '', '2021-07-11 16:57:03', 0, '', 0),
(28, '', 'debrajchatterjee_2007@rediffmail.com', 'f639f05cab4d9f95582536f26fafa8dc', 'Sep@121981', 'agent', 1, 'Debraj', 'Chatterjee', '+918469844301', '1000', 'Vizag', 'Visakhapatnam', 'Andhra Pradesh', '530022', '', '2022-01-28 10:54:32', 0, '', 0),
(29, '', 'spulle8@gmail.com', '7e2c259b6fd432642e883482862346bd', 'sudheerkumar', 'dealer', 0, 'pulle', 'sudheerkumar', '9154219308', 'nadithota', 'vishakaptnam', 'vishakaptnam', 'Andhra pradesh', '530047', '', '2022-03-27 11:41:19', 0, '', 0),
(30, '', 'foo-bar@example.com', '903a98d709fa4683aaaa036b84c125a6', 'ZAP', 'dealer', 0, 'ZAP', 'ZAP', 'ZAP', 'ZAP', 'ZAP', 'ZAP', 'ZAP', 'ZAP', '', '2022-05-05 02:22:49', 0, '', 0),
(31, '', 't4ctici4n@yahoo.com', 'a718adb5966eb0ed4b9b0c4d990cb425', '15231523', 'dealer', 0, 't4ctici4n', 'test', '209312521312', '21', 'ttt', '21', 'Nagaland', '22123', '', '2022-07-09 08:22:48', 0, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `blog`
--

CREATE TABLE `blog` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `modified` datetime NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '1=Active | 0=Inactive',
  `address` text NOT NULL,
  `area` varchar(255) NOT NULL,
  `about_area` text NOT NULL,
  `2017_price` varchar(20) NOT NULL,
  `2018_price` varchar(20) NOT NULL,
  `2019_price` varchar(20) NOT NULL,
  `2020_price` varchar(20) NOT NULL,
  `street` varchar(255) NOT NULL,
  `city` varchar(100) NOT NULL,
  `district` varchar(100) NOT NULL,
  `pincode` varchar(20) NOT NULL,
  `state` varchar(55) NOT NULL,
  `about_property` text NOT NULL,
  `property_status` varchar(55) NOT NULL,
  `budget_from` varchar(20) NOT NULL,
  `budget_to` varchar(20) NOT NULL,
  `price_sqft` varchar(20) NOT NULL,
  `added_by` int(11) NOT NULL,
  `features` varchar(255) NOT NULL,
  `nearby` varchar(255) NOT NULL,
  `modified_by` int(11) NOT NULL,
  `bed_rooms` int(11) NOT NULL,
  `property_type` varchar(55) NOT NULL,
  `content` text NOT NULL,
  `event_date` varchar(55) NOT NULL,
  `key_url` text NOT NULL,
  `meta_desc` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `blog`
--

INSERT INTO `blog` (`id`, `title`, `created`, `modified`, `status`, `address`, `area`, `about_area`, `2017_price`, `2018_price`, `2019_price`, `2020_price`, `street`, `city`, `district`, `pincode`, `state`, `about_property`, `property_status`, `budget_from`, `budget_to`, `price_sqft`, `added_by`, `features`, `nearby`, `modified_by`, `bed_rooms`, `property_type`, `content`, `event_date`, `key_url`, `meta_desc`) VALUES
(1, 'The Future of Real Estate In 2021', '2021-03-16 07:29:15', '2021-02-10 06:32:33', 1, '', 'Vizag', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, '', '<p><strong>Introduction</strong>:</p>\r\n\r\n<p>The home is the beautiful destination of a household, and buying a property is the memorable achievement of a middle-class family. As per 2019 statistics, over 50% of Indian population owns the house, and the rest live in rental apartments and houses.</p>\r\n\r\n<p>There is a lot of scope in real estate sector to invest and benefit in the Indian market.</p>\r\n\r\n<p>Even when there is a strike of Covid-19 all sectors dropped down but the only industry prevailed in the market and upscaling its limits was the real estate sector.</p>\r\n\r\n<p><strong>Quick Takeaways</strong>:</p>\r\n\r\n<p>&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Future trends in the Real Estate Industry</p>\r\n\r\n<p>&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; How digitization helping customers finding properties</p>\r\n\r\n<p>&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Importance of real estate sector in Indian investment market.</p>\r\n\r\n<p>Will discuss some of the significant future trends in real estate in 2021 as follows.</p>\r\n\r\n<p><strong>Property Ownership</strong>:</p>\r\n\r\n<p>Living a happy life is what all dream about, and now pandemic thought everyone home is the safest place in life. This proves the importance of a home in 2021; thus, this has a significant impact on a boom in the real estate sector.&nbsp;</p>\r\n\r\n<p><strong>Digital Integration Enhancing the Market</strong>:</p>\r\n\r\n<p>Yes! When we observe the digital revolution, customers are nearing the markets very quickly, the traditional methods of seeing a property and waiting for the customer abolished and made many things possible via digitisation.&nbsp;</p>\r\n\r\n<p>For example, 99acres.com, square yards, and upcoming future platforms like Eswari Homes made revolutionary changes in the real estate sector by introducing online property platforms with thousands of options and many more choices with beautiful structures and great amenities with social media platforms and other media channels to near the customer quickly.</p>\r\n\r\n<p><strong>Distance Doesn&#39;t Matter in Buying A Property</strong>:</p>\r\n\r\n<p>Work from home is the new trend in 2021; Covid-19 impacted the businesses to run their activities from home; the future companies are trying to make their employees work from home. In this way, they are saving office space and other operational expenses.</p>\r\n\r\n<p>It&#39;s clear that now going office is replaced with work from home, and people are interested in buying properties wherever they want and not near their offices.</p>\r\n\r\n<p><strong>Affordable Homes</strong>:</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>The digitisation and removal of intermediaries reduced property searching cost and available to millions of people just in a click distance through different property search engines.&nbsp;</p>\r\n\r\n<p>The market rate will never be an in a straight line, but when you compare the past trends in the property search engines, it will show you the affordable homes with many amenities that serve the need of a customer in his budget.</p>\r\n\r\n<p><strong>Investment in Indian Real Estate Sector</strong>:</p>\r\n\r\n<p>In residential and office space, there is a tremendous demand for Real Estate investment in India. In 2019 the market attracted 43,780 crore investment, and the retail market witnessed a USD 1 billion investment from private equity. The institutional investment was resulted in USD 712 by the end of March 2020</p>\r\n\r\n<p>These statistics prove that the growth in the real estate sector and the importance of property purchasing in India.</p>\r\n\r\n<p><strong>Purchase and Sale</strong>:</p>\r\n\r\n<p>One of the biggest worries of property purchasers is that the property cost cut down or market value reduces. But if we observe the past two decades&#39; trends in the Real Estate sector, the property value is multiplying but not coming down. Hence purchasing a property is the best investment, and when you sell a property, the value will be doubled, and you will be in a profitable position.&nbsp;</p>\r\n\r\n<p><strong>Conclusion</strong>:</p>\r\n\r\n<p>The above article states the importance of real estate industry trends in India which constitutes the best investment source for many businesses and the tremendous viable opportunity for consumers to invest their money and improve their lifestyle in future.</p>\r\n', '25-January-2021', 'the-future-of-real-estate-in-2021', ''),
(2, 'Great properties at your fingertips', '2021-04-27 08:46:24', '2021-02-16 08:49:26', 1, '', 'Vizag', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, '', '<p><strong>Introduction</strong>:</p>\r\n\r\n<p>Home is not just doors or windows it&rsquo;s a lifestyle that reflects our taste and preferences. New generation homes coming with awesome and beautiful amenities that mesmerizing the living taste of every household.</p>\r\n\r\n<p>Looking for a home through an agent or a broker is a tedious job but digital marketing and the internet revolution made home searching easy with different platforms like Square yards, Eswarihomes.com, and 99acres.com&nbsp;</p>\r\n\r\n<p>Wonders are ahead and the Real estate sector is always at the upscaling limit in India. It&#39;s not an imagination to built up but properties are indeed going to be the real assets in the future. The best real estate properties are available in Visakhapatnam, the southern part of India.</p>\r\n\r\n<p>Quick Takeaways from the article:</p>\r\n\r\n<ul>\r\n	<li>How online marketing helping the real estate sector</li>\r\n	<li>Benefits of adapting digital marketing</li>\r\n	<li>Best real estate provider in Visakhapatnam</li>\r\n	<li>How digital marketing helping customers in finding properties</li>\r\n</ul>\r\n\r\n<p>Let&rsquo;s discuss the role of Digital mediums which is influencing Real Estate Marketing</p>\r\n\r\n<p><strong>Social Media Influence</strong>:</p>\r\n\r\n<p>More than half of smartphone users using worldwide social media platforms to share their day-to-day activities with their friends and family. Social media is not only used for sharing personal things but also used to search for different fields like business, lifestyle, products, and many more informative like Real Estate properties in Visakhapatnam.</p>\r\n\r\n<p>Real estate companies utilizing social media channels to reach a larger audience simply and easily with a direct approach by showcasing their listed properties in different locations.</p>\r\n\r\n<p><strong>Websites Are Welcoming Platforms</strong>:</p>\r\n\r\n<p>Websites are the gateways to know the reliability and history of a company to be believed by a customer, and without a website, it&rsquo;s hard for a customer to understand a company. That is why it is essential to have a website.</p>\r\n\r\n<p>Websites acts as the hosting platforms for many consumers who want to purchase a property, for example, Eswarihomes.com is one of the finest websites which helps many customers to search for property in Andhra Pradesh especially in Visakhapatnam, with a list of amazing and luxurious budget-friendly properties. Where a customer can trust on it by easily going through the information about the company.</p>\r\n\r\n<p><strong>Digital Marketing:</strong></p>\r\n\r\n<p>Realtors are renovating their marketing strategy with digital marketing, search engine optimization helping many real estate businesses to reach a high volume of customers and bringing great leads.</p>\r\n\r\n<p>Paid campaigns like Facebook ads and Google ads inventing a separate route for customers who are searching properties online. PPC (pay per click) is generating a high volume of leads and CTA (call to action) features are directly generating customer information through the landing page of the website.</p>\r\n\r\n<p>Customize your advertising in digital marketing like specify a location and target audience. Then it will directly reach only those locations and people based upon the keywords and the specification which we mention in the digital ad.</p>\r\n\r\n<p><strong>Organic Ways</strong>:</p>\r\n\r\n<p>If you set up your business online then it need not be always a paid campaign but you can also set up organic routes to navigate the audience towards your site. Placing keywords, using customized high range low size images, creating wonderful and eye-catching content, and placing informative blogs on the website, etc.</p>\r\n\r\n<p>Organic methods will result in the long term but they are a very good method to adapt and develop any business. Especially realtors must and should maintain organic methods to develop their sites from a very early stage of their marketing campaigns to achieve remarkable results in the future.</p>\r\n\r\n<p><strong>Email Marketing</strong>:</p>\r\n\r\n<p>Everyone has an email on their smartphones and Email marketing is the most budget-friendly marketing tactic which every business loves to implement in their marketing strategy. It&rsquo;s the place where leads turn into clients and the beautiful content will pull out a customer to purchase a property or service from a business.&nbsp;</p>\r\n\r\n<p><strong>Conclusion</strong>:</p>\r\n\r\n<p>Searching a property online is the best way to compare and get great budget-friendly flats near you. As per statistics, the brokerage cost has been eliminated and truly customers are benefited from this process.</p>\r\n\r\n<p>Easy and hassle-free real estate services made many happy customers through digital marketing in the real estate sector. Eswari Homes is becoming one of the top leader in Andhra Pradesh in adopting digital marketing services and that leading as the best real estate developer in Visakhapatnam.</p>\r\n', '11-February-2021', 'great-properties-on-your-finger-tips', ''),
(6, 'Importance of Investing in Real Estate 2021!', '2021-04-27 08:47:46', '2021-03-05 09:07:02', 1, '', 'Vizag', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, '', '<p><strong>Introduction:</strong></p>\r\n\r\n<p>India is the seventh-largest country in the world with a total area of 32,87,263 KM.</p>\r\n\r\n<p>As per the census India report In 1920 the Indian population was 318 million whereas in 2020 it is 1.38 billion.</p>\r\n\r\n<p>The land is the same but there is a huge hike in population, increasing population equally influencing the demand for land in India, that is why every year on average land values are multiplying like anything.</p>\r\n\r\n<p>The average income of an Indian farmer is 77k per year but the 1-acre land costing a minimum to minimum 5 lakhs to 20 lakhs and the maximum&#39;s reaching more than a crore. The outcome from land is crop it&#39;s 77k but the value of land is unimaginable in India.</p>\r\n\r\n<p>Whereas if we observe in the cities like metropolitan the average 100 Square yards house is costing minimum to minimum 50 lakhs to 1 crore. The statistics might show wrong but if you enquire a normal person in your locality you will get the same figures.</p>\r\n\r\n<p>So there is a huge scope in <a href=\"http://eswarihomes.com/\">investing your money in Real Estate.</a></p>\r\n\r\n<p><strong>Importance of Investing In Real Estate:</strong></p>\r\n\r\n<p>The real estate sector is the second largest employer of India after agriculture and</p>\r\n\r\n<p>The contribution of the real estate sector to India&#39;s gross domestic product (GDP) is estimated to increase by 13% in 2025.</p>\r\n\r\n<p><strong>[&nbsp; ] Assured Returns:</strong></p>\r\n\r\n<p>If you invest money in land or property there is an assurance that it will grow in a year. The land value increase and in the meanwhile, you can earn capital revenue every month through rent.</p>\r\n\r\n<p><strong>[&nbsp; ] Exemption from Income Tax:</strong></p>\r\n\r\n<p>There are many perks of tax benefits while investing in Real Estate. You can gain tax deductions as well you can show it as maintenance cost and decrease your taxes for the very long term.</p>\r\n\r\n<p>After year&#39;s of purchasing a property, you can show the cost of the asset has decreased its value and reap the benefits of tax exemption.</p>\r\n\r\n<p><strong>[&nbsp; ] Appreciation:</strong></p>\r\n\r\n<p>When you buy a property that might costed 10 lakhs but there are many chances for change in market rate within a year. The market rate might increase a certain percentage to give great appreciation.</p>\r\n\r\n<p><strong>[&nbsp; ] Cash Flows:</strong></p>\r\n\r\n<p>Generating income from an asset and pay in the mortgage amount is what makes a person earn extra cash flows. This is a clever option for people who wants to purchase a house and earn income out of it.</p>\r\n\r\n<p><strong>[&nbsp; ] Increase Equity and wealth</strong></p>\r\n\r\n<p>When you purchase a house on a loan you&#39;re investing in real equity. As time flows your capital will turn your asset and you earn property and get benefits of cash flows from the property.</p>\r\n\r\n<p><strong>[&nbsp; ] Investment Diversified:</strong></p>\r\n\r\n<p>As per investment management statistics investing in real estate assets has lesser risk than any other equity or share market. As you go on with lesser investment in the short period your asset will turn double in years<strong>.</strong></p>\r\n\r\n<p><strong>[&nbsp; ]&nbsp; Real estate property advantage:</strong></p>\r\n\r\n<p>If you&#39;re trying to apply for a bank loan by mortgaging your property then the bank can provide up to 80% of the loan on your property value. It is used as collateral and termed as the real asset.</p>\r\n\r\n<p><strong>[&nbsp; ] Conclusion:</strong></p>\r\n\r\n<p>As the increasing population influencing the land rates that is why there are many advantages correlated with investing money in the Real Estate sector.</p>\r\n\r\n<p>Moving forward in the coming years the prices will be unstoppable and the land is the new gold mine and living in the own house termed as a royal legacy in future.</p>\r\n\r\n<p>Start investing in the real estate sector to generate high income and live a happy lifestyle.</p>\r\n', '04-March-2021', 'importance-of-investing-money-in-real-estate-2021', ''),
(7, 'Developing Landmarks of Real Estate in Visakhapatnam!', '2021-03-16 07:10:47', '2021-03-16 07:11:45', 1, '', 'Vizag', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, '', '<p><strong>Introduction</strong>:</p>\r\n\r\n<p>The most profitable and sustainable business in India is the real estate sector, it has managed to sustain over years without any diversion or deviation by being an upscaling sector by contributing 13% to the national GDP and more every year.</p>\r\n\r\n<p>If you term the fastest developing cities in the Asia the first name will appear as the Visakhapatnam, due to its natural demographic situations like Vizag natural seaport making it an industrial area for corporates and industries and the land of seashore making it loveable to live as peaceful natural heritage hub for a residential area for <a href=\"http://eswarihomes.com/\">2 &amp; 3BHK flats in Visakhapatnam</a>.</p>\r\n\r\n<p>we all knew that the most important resources are limited and the land is the utmost limited resource in the world, we cannot produce land but we can use it as a great investment source. So that is why this boom in the Real Estate Sector, and if you go through the developing conditions in Visakhapatnam the land rates are reaching heights, so let&rsquo;s give an idea about which area will be the best investment source to book an <a href=\"http://eswarihomes.com/\">apartment or flat in Visakhapatnam</a>.</p>\r\n\r\n<p>Flats for Sale in Visakhapatnam Best locations to search!</p>\r\n\r\n<p>Pendhurthi:</p>\r\n\r\n<p>It is a place for the best residential and neighbourhood and it is in the top list of the growing real estate sector for <a href=\"http://eswarihomes.com/\">apartments in Visakhapatnam</a>. It is for those people who want to live nearby the city and connect all the locations to Visakhapatnam within an average of one-hour.</p>\r\n\r\n<p>This place is also focused as an industrial place, and VUDA approval making one of the hottest hubs in Visakhapatnam for a residential purpose. Due to VUDA activities, it has all the specifications that fulfil to be the developing location.</p>\r\n\r\n<p>Madhurawada:</p>\r\n\r\n<p>Madhurawada is one of the hotspots of Visakhapatnam, where it is located near IT Hub and very near to the beach, naturally it&rsquo;s a unique place to live in and the land rate is unimaginably increasing every day. We can conclude this is the best place to invest your money, if you want to purchase a property near NH5 Visakhapatnam to Vizianagaram highway this is the best investment.</p>\r\n\r\n<p>Yendada:</p>\r\n\r\n<p>It is located nearby Madhurawada one of the developing areas of Visakhapatnam, with a range of affordable and budget-friendly apartments. Soon the prices are expected to hike up to the sky, so plan your investment in this location to reinvent your future,<a href=\"http://eswarihomes.com/\"> best flats for sale in Yendada </a>book now.</p>\r\n\r\n<p>Seethammadhara:</p>\r\n\r\n<p>It is located at the eastern ghats of Visakhapatnam, It&rsquo;s a quite pleasant location to be live in, that termed this place as a purely residential area of Visakhapatnam. Want to live out of pollution and live in a peaceful environment this is the best location to be. So we term this as the best location for <a href=\"http://eswarihomes.com/\">apartments for sale in Visakhapatanam</a>.</p>\r\n\r\n<p>PM Palem;</p>\r\n\r\n<p>It is one of the part of Madhurawada, in the jurisdictions of GVMC, it is one of the wonderful areas to locate your real estate investment. The renowned international cricket stadium Dr. Rajasheker reddy is located here. Well connected to several bus stops and it is one of the educational hubs by locating many educational institutes and training centers.</p>\r\n\r\n<p>MVP Colony:</p>\r\n\r\n<p>buy residential luxury apartments in MVP colony. It is a high-class township in Vizag city. And it is recognized as one of the largest colonies in the total Asian Continent. It is because the largest residential and commercial hubs are located in this place.</p>\r\n\r\n<p>MVP colony has its advantages by having schools and colleges, hotels, restaurants, banks, and hospitals, etc. that is why MVP colony is terming itself as the developing location of the real estate sector in Visakhapatnam. Why late flats for sale in mvp colony visakhapatnam</p>\r\n\r\n<p>Akkayapalem:</p>\r\n\r\n<p>Situated at the north of Visakhapatnam, and connected to the NH5 is one of the oldest residential areas of Visakhapatnam, the best connecting networks to travel and surrounded by colleges, schools, and institutes. It is one of the profitable locations to invest in as well as ready to occupy for residential purposes.</p>\r\n\r\n<p>Gajuwaka:</p>\r\n\r\n<p>Gajuwaka it&rsquo;s a heavily populated area as well densely located industries along the lines of VSEZ, and Vizag steel plant, DRDO, NSTL, and Visakhapatnam Port Trust. All these public and private sectors are located nearby the Gajuwaka. Due to its heavy demand, the land rates are hiking up and it is the right time to buy properties in Gajuwaka.</p>\r\n\r\n<p>Conclusion:</p>\r\n\r\n<p>This is the best time to invest your money in real estate, especially in Visakhapatnam. The investment which you do today will increase tomorrow. <a href=\"http://eswarihomes.com/\">The best properties are available in Visakhapatnam.</a> Increase your status by buying a property, either a flat or land anything will be sufficient to increase your worth of investment either double or even ten times in coming years.&nbsp;</p>\r\n\r\n<p>Plan your investment in developing Visakhapatnam to grow your wealth easily with the help of Eswari Homes the best property search engine providing great options from verified properties in and around Visakhapatnam, why late, book now! Flats for sale in vizag.</p>\r\n', '13-March-2021', 'developing-landmarks-of-real-estate-in-visakhapatnam', ''),
(8, 'Search Luxury Apartments through ESWARI HOMES!', '2021-04-06 07:23:02', '2021-04-06 09:23:02', 1, '', 'Vizag', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, '', '<p>Are you searching for apartments in Visakhapatnam? Confused with a lot of options and hard to choose one? Let&rsquo;s discuss in detail about the most valid and informative certified home search engine ESWARI HOMES which will help you to find beautiful and <a href=\"http://eswarihomes.com/\">luxurious apartments in Visakhapatnam</a>.</p>\r\n\r\n<p>You read it right! ESWARI HOMES is one of the leading home search engines in Visakhapatnam with more than a decade of Real estate industry experience. It has made many happy customers with its remarkable suggestions to drive people happy and wealthy.</p>\r\n\r\n<p>ESWARI HOMES main focus was to give a sustainable growth suggestion to its customers with unimaginable development sites in and around Visakhapatnam.</p>\r\n\r\n<p><strong>The Best Luxury Apartments in Visakhapatnam with ESWARI HOMES:</strong></p>\r\n\r\n<p>The ESWARI HOMES platform will provide the best options and suggestions to its customers with numerous options in and around Visakhapatnam.</p>\r\n\r\n<p><strong>The Property Search Engine:</strong></p>\r\n\r\n<p>If you&rsquo;re seriously searching for <a href=\"http://eswarihomes.com/\">apartments in Visakhapatnam</a>, then ESWARI HOMES is the best platform to provide you various options with great amenities. ESWARI HOMES has a great network of builders and realtors in Visakhapatnam. All realtors in Visakhapatnam are registered with ESWARI HOMES that&rsquo;s why ESWARI HOMES the property search engine in Visakhapatnam. Search apartments in Vizag.</p>\r\n\r\n<p><strong>Budget-friendly:</strong></p>\r\n\r\n<p>Affordability is the main aim of ESWARI HOMES. We don&rsquo;t want to create a monopoly market for our customers, we want to create a way towards a happy home destination for our customers to fulfil their dreams of owning a home within their budget.</p>\r\n\r\n<p><strong>Price Difference:</strong></p>\r\n\r\n<p>We place prices at a minimum cost that will be in reach of customers, and if you search other properties with a comparing line then you will get to know the important facts of realistic and less price of ESWARI HOMES property search engine.</p>\r\n\r\n<p><strong>Amenities That Inspire and Aspire</strong><strong>:</strong></p>\r\n\r\n<p>If you term property then amenities are attributes to it. Wherever you search amenities describe another story of development and luxury form of a house. We take care of amenities as the utmost important factor in home search, and we provide them for sure in our properties.</p>\r\n\r\n<p><strong>Direction to Development</strong>:</p>\r\n\r\n<p>If you&rsquo;re purchasing property means it doesn&rsquo;t mean you&rsquo;re spending money! It should be like an incremental investment. We provide you such kind of properties where growth is guaranteed and development is the routing core for it.</p>\r\n\r\n<p><strong>Verified Properties</strong>:</p>\r\n\r\n<p>100% verified properties are the important feature of the ESWARI HOMES property search engine. Into a happy direction with greatly built-in houses with each stage quality check. Mesmerizing architecture and happy living space is what making it a wonderful space for you to lead life.</p>\r\n\r\n<p><strong>Conclusion</strong>:</p>\r\n\r\n<p>How to find the <a href=\"http://eswarihomes.com/\">best luxury apartments in Visakhapatnam</a>? Is solved so far I guess in the above article. ESWARI HOMES is the source to find out the best apartments in Visakhapatnam. The <a href=\"http://eswarihomes.com/\">flats for sale in Visakhapatnam</a> through ESWARI HOMES. Search properties within your budget. You can look for wonderful amenities within your budget in ESWARI HOMES. What are you waiting for a look into our website and choose your loving home in your budget within your city?</p>\r\n', '06-April-2021', 'search-luxury-apartments-through-ESWARI-HOMES', ''),
(10, 'Find Luxurious Apartments with ESWARI HOMES', '2021-04-17 07:51:14', '2021-04-17 09:51:14', 1, '', 'Vizag', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, '', '<p>Are you searching for apartments in Visakhapatnam? Do you feel the price is important for you? Are you dreaming of luxurious amenities? Then you have reached a perfect platform for the&nbsp;<a href=\"http://eswarihomes.com/\"><strong>best</strong>&nbsp;<strong>luxury flats in Visakhapatnam</strong></a>&nbsp;available through ESWARI HOMES. It is one of the finest property search engine in Visakhapatnam</p>\r\n\r\n<p>ESWARI HOMES works with the motto to help its customers by providing&nbsp;<strong><a href=\"http://eswarihomes.com/\">luxury apartments in Visakhapatnam</a>&nbsp;</strong>at an affordable cost, and value-added services with luxury amenities will make customers feel happy and satisfied.</p>\r\n\r\n<p><strong>Why You Need To Choose ESWARI HOMES for Finding Luxurious Apartments in Visakhapatnam:</strong></p>\r\n\r\n<p><strong>Property Search Engine:&nbsp;</strong></p>\r\n\r\n<p>ESWARI HOMES is termed as the best property search engine in Visakhapatnam, due to its reliable services from the past one decade and best suggestions of developing properties in and around Visakhapatnam made this platform the most trusted property seller in the Vizag.&nbsp;</p>\r\n\r\n<p><strong>Luxury Apartments or Flats:</strong></p>\r\n\r\n<p>The&nbsp;<strong><a href=\"http://eswarihomes.com/\">best luxury apartments in Vizag</a>&nbsp;</strong>available at ESWARI HOMES, You can choose various options from our property search engine eswarihomes.com the one of the&nbsp;<strong><a href=\"http://eswarihomes.com/\">best real estate company in Visakhapatnam</a>.&nbsp;</strong>You love the amenities and the design as well as the structure of the building. The options and comparisons will make you feel this is the best place to search for luxury apartments in Visakhapatnam.</p>\r\n\r\n<p><strong>Pocket Friendly:</strong></p>\r\n\r\n<p>ESWARI HOMES main motto is to help customers by providing their dream home. We knew your hard-earned money and will navigate you to get the best and affordable apartment that suits your pocket as well fulfills your dream. You can also compare with other property providers with ESWARI HOMES.</p>\r\n\r\n<p><strong>Great Partnership with Builders and Realtors:</strong></p>\r\n\r\n<p>We are the only company in Visakhapatnam, which has enormous connections and a great relationship with builders as well realtors. We try to provide things as easy and cost-friendly to our customers. And also in our search engine, you can avail many properties to compare and buy your dream home.</p>\r\n\r\n<p><strong>Appreciate Your Value:</strong></p>\r\n\r\n<p>The money invested in properties will never go to waste. ESWARI HOMES is trying to navigate its customers in a way where they can fulfill their dream for home and earn through the developing sites and properties. Suggesting the best routes to our customers is our main motto to appreciate their worth of value to the next level.</p>\r\n\r\n<p><strong>Developing Sites:</strong></p>\r\n\r\n<p>If you observe all ESWARI HOMES properties will be available at the developing centers of Visakhapatnam. Every property will guide you to build an empire within years of investment. So when you decide to purchase a property ESWARI HOMES is the best place to search and purchase.</p>\r\n\r\n<p><strong>Certified and Verified properties:</strong></p>\r\n\r\n<p>We provide all the certified and verified properties to our customers, and quality structures and best constructional value properties will be listed on our website. Our assurance will always guide you to invest in the right properties that are Certified properties.</p>\r\n\r\n<p><strong>Why You Need To Come To Us:</strong></p>\r\n\r\n<p>A decade of Real Estate Industry experience as a property search engine, more than 20 years of real estate professional experience in guiding people to purchase the best and affordable homes. Apart from all these, we are on a mission to provide ultimate services to customers to fulfill their dream for home.</p>\r\n\r\n<p><strong>Conclusion:</strong></p>\r\n\r\n<p>Luxury is within your limits, just click on our website to fulfill your dream for&nbsp;<strong><a href=\"http://eswarihomes.com/\">the best luxury flats in Visakhapatnam</a>.&nbsp;</strong>It is the right time to invest and Real Estate is booming, within years your money will double. Your worth of investment will always make you feel like a wonderful decision. Why late surf into Eswari Homes website right now!</p>\r\n', '17-April-2021', 'find-luxurious-apartments-with-ESWARI-HOMES', ''),
(12, 'Amenities Inspire Your Living Space!', '2021-04-27 08:39:56', '2021-04-27 10:39:56', 1, '', 'Vizag', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, '', '<p>Amenities are the new age lifestyle requirements, amenities are a status symbol. A house without amenities is termed as a house without a roof. That is why amenities has that much importance in new flats and individual homes.</p>\r\n\r\n<p>Whenever you&#39;re purchasing a house or a flat you must and should enquire about what are the available amenities with the property. In short and simple words amenities will add value to your properties.</p>\r\n\r\n<p>Look for Amenities Before Purchasing a Property:</p>\r\n\r\n<p><strong>Parking Facility</strong>:</p>\r\n\r\n<p>Your real assets (Vehicles) are secured if your living space has a parking facility. So parking is a must and should amenity before you purchase any <a href=\"http://eswarihomes.com/\">property in Visakhapatanam</a>. Let&#39;s search properties in <a href=\"http://eswarihomes.com/\">Eswarihomes.com</a> to get wonderful options of flats in the prime locations of Visakhapatanam.</p>\r\n\r\n<p><strong>24/7 security</strong>:</p>\r\n\r\n<p>CCTV camera&#39;s and security guards in the apartments or gated community will make your home feel safe. They will take care of all security issues and take actions to control theft and stop unwanted people to come into your living space. So security is a must and should for opting a flat or individual home.</p>\r\n\r\n<p><strong>100% Vastu</strong>:</p>\r\n\r\n<p>As per our tradition and culture, Vastu is an important element in building a house. So before choosing a house enquire about Vastu. And wanna get 100% Vastu properties then search in EswariHomes.com you will find 100% Vastu equipped flats. The <a href=\"http://eswarihomes.com/\">best property provider in Visakhapatanam</a> Eswari Homes.</p>\r\n\r\n<p><strong>Playground and Swimming Pool</strong>:</p>\r\n\r\n<p>Olden days are golden days wherever you go there is a playground and wells. Where people use to play and swim. But the modern generation doesn&#39;t have those facilities. Where villages became towns and towns became cities, everywhere it is a concrete jungle. That is why look for those properties where you find children&#39;s playground and Swimming pool. And don&#39;t forget to search for properties in Eswari Homes, where you find all the amenities under one roof with multiple options in prime locations of Visakhapatanam.</p>\r\n\r\n<p><strong>Park</strong>:</p>\r\n\r\n<p>A small park in your apartments will generate a lot of enthusiasm and a fresh feeling to start your day. Greenery will always attract and astonishes then what are you waiting. If you wanna purchase a home there will be many options but choose a wise decision through Eswari Homes.</p>\r\n\r\n<p><strong>Beautiful Interior design</strong>:</p>\r\n\r\n<p>The wonderful design makes a wonderful ambience and that is what makes a big difference. Modern designs make luxurious ambience and a happy leading lifestyle, so before purchasing let&#39;s check the design that will create a separate loving amenity to fulfil your dream home.</p>\r\n\r\n<p><strong>Clubhouse</strong>:</p>\r\n\r\n<p>Areas meant for gatherings, and the areas where indoor games exists also people find each other for meetings and all a clubhouse is the part of a gated community. If you&#39;re purchasing a flat in Visakhapatnam do search in Eswari Homes it will redirect you to the best option to fulfil all the important amenities.</p>\r\n\r\n<p><strong>Conclusion:</strong></p>\r\n\r\n<p>Do you think only the above mentioned are amenities! No! There are other things too, but these are basic as well must required amenities. So before purchasing a house or a <a href=\"http://eswarihomes.com/\">flat in Visakhapatnam</a> don&#39;t forget to look for Eswari Homes, one of the leading property search engine in Visakhapatnam. Procure a home at an affordable cost and include all your loving amenities in your apartment.</p>\r\n', '27-April-2021', 'amenities-inspire-your-living-space', ''),
(13, 'How Can Real Estate sustain in Covid-19', '2021-05-03 12:25:11', '2021-05-03 14:23:55', 1, '', 'Vizag', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, '', '<p>We all knew the road to success is not so easy in any sector, especially during the covid-19 period, now it is harder than before.</p>\r\n\r\n<p>Let&#39;s discuss through the Real Estate sector, what are the places where it can regain its power by applying various techniques and processes.</p>\r\n\r\n<p>We strongly believe there is no end to the <a href=\"http://eswarihomes.com/\">Real Estate</a> sector, the statistics showcase the importance of the real estate sector, with that confidence we believe the real estate sector will always be in boom and it is one of the important sources for our Indian GDP growth.</p>\r\n\r\n<p><strong>Strong Reasons To Be Pointed out for Real Estate Sector to Survive:</strong></p>\r\n\r\n<p><strong>T</strong>he following are the important reasons where the real estate sector can survive, let&#39;s discuss in detail.</p>\r\n\r\n<p><strong>Keeping Employees Motivated and Stay Positive In This Period:</strong></p>\r\n\r\n<p>Our stakeholders are our power, they make our business successful. During these hard times if any Real Estate organisation removing their best salesmen is the biggest mistake which they are doing.</p>\r\n\r\n<p>Always be positive and stay ahead of the market, things will be normal and lockdown will end and covid-19 will disappear, then these salesmen will run our business in a high frequency.</p>\r\n\r\n<p><strong>Digitisation is the New Source of Business Growth:</strong></p>\r\n\r\n<p>During these hard times, it is important and mandatory for taking a huge turn by digitising the business. Salespeople can&#39;t meet customers and customers can&#39;t come to the office or site. At this time digitisation of the process will make things possible.</p>\r\n\r\n<p>Virtual site visits will make things more interesting, social media platforms will make businesses alive by showcasing the real picture of the organisation and it will engage customers who want to buy properties.</p>\r\n\r\n<p><strong>Connect Your Customers with Information:</strong></p>\r\n\r\n<p>Productive communication will always generate huge returns in any sector, especially in the <a href=\"http://eswarihomes.com/\">Real Estate</a> sector. Engage the audience with the latest information about the Real Estate sector relating to your project, or specific location prices and discounts will make them interesting.</p>\r\n\r\n<p>Even though if you&#39;re not talking about prices and discounts let them know about the project size, quality measures and approval from various organisations like RERA approval and HMDA approval everything will make them engage and they continue to believe your organisation.</p>\r\n\r\n<p><strong>Ensure to Convey Govt reforms:</strong></p>\r\n\r\n<p>Central Government always makes sure to prioritise the real estate sector in its budget meetings, so always make sure to present the govt reforms and plans to take advantage of the present situation to gear up the business in a new way. The organisation that portrays good command over the market is the one who knew every aspect of its business.</p>\r\n\r\n<p><strong>Conclusion</strong>:</p>\r\n\r\n<p>The <a href=\"http://eswarihomes.com/\">Real Estate</a> boom is unstoppable if you follow the above-mentioned methods. You can carry on business in a new way and sustain it in a long run. Always believe Things will change according to the time, so always welcome new methods and trends to continue the successful real estate business and satisfy your customers.</p>\r\n', '03-May-2021', 'how-can-real-estate-sustain-in-covid-19', ''),
(14, 'Lockdown Doesn\'t Stop You from Purchasing a Property', '2021-05-12 07:12:33', '2021-05-12 09:12:33', 1, '', 'Vizag', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, '', '<p>It is a tough time and we all aware that covid-19 impacting many lives all over the world. It is high time for being safe but nothing stops you from purchasing a property during this lockdown. Yes you read it perfectly, Eswari Homes presenting homes through online, you can search your loving home online by just going through <a href=\"http://eswarihomes.com/\">Eswarihomes.com</a></p>\r\n\r\n<p><a href=\"http://eswarihomes.com/\">Luxurious 2 &amp; 3BHK apartments</a> in an affordable range. You just click on our website Eswari Homes (property search engine) then you will be redirected to thousands of properties and many options at your fingertips.</p>\r\n\r\n<p><strong>Purchase Properties Through Eswari Homes:</strong></p>\r\n\r\n<p>A lockdown may stop many activities but digital routes don&#39;t stop us to fulfil our customer dreams. Let&#39;s discuss how we can handle this time to purchase a property as follows.</p>\r\n\r\n<p><strong>Search Through Eswari Homes Website:</strong></p>\r\n\r\n<p>Thousands of properties at your fingertips, get brand new properties within your locality. Amazing designs and luxurious amenities. Search through Eswari Homes <a href=\"http://eswarihomes.com/\">best property seller in south India</a>.</p>\r\n\r\n<p><strong>Schedule Timings and Appointment:</strong></p>\r\n\r\n<p>Don&#39;t afraid of so many people at our location, we will make our customers safe and prioritise. We schedule our customer visits in that way social distancing and home searching will be easy for customers to look into properties.</p>\r\n\r\n<p><strong>Affordable Prices :</strong></p>\r\n\r\n<p>You might have seen there is a hike in the property prices in this lockdown period, but Eswari Homes didn&#39;t hike the prices at all. We work for our customer dreams and our motto is to provide an <a href=\"http://eswarihomes.com/\">affordable range of luxurious homes</a> to everyone.</p>\r\n\r\n<p><strong>Site Pictures and Models and Virtual Tour:</strong></p>\r\n\r\n<p>We provide virtual tours to our customers, our property images, and videos are available on our site. After verifying all those property images and videos then only we request you to visit our site. Safety is an important factor we all mind in this lockdown.</p>\r\n\r\n<p><strong>The world is locked but not Investment opportunities:</strong></p>\r\n\r\n<p>Every industry is facing some problems, but the Real Estate industry rising 9-10 percent every year. This shows the advantages correlating with property purchasing. So stop worrying and start purchasing properly now. It&#39;s the best time for property investment.</p>\r\n\r\n<p><strong>Conclusion</strong>:</p>\r\n\r\n<p>Our motto is to provide affordable luxurious homes to our customers. We make sure our customers safety as our priority, and we provide all the facilities from site visiting registration work in terms of property purchase. Visit EswariHomes.com for more information and own your dream home today.</p>\r\n', '12-May-2021', 'lockdown-doesnot-stop-you-from-purchasing-a-property', ''),
(15, 'Housing Societies Must Take these Precautions to Flight Against Corona virus.', '2021-05-19 12:59:28', '2021-05-19 14:56:08', 1, '', 'Vizag', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, '', '<p>Home is the only safest place in this pandemic. Wearing mask, keeping social distance and working from home is the new ways of leading a life in this hard times of life.</p>\r\n\r\n<p>Do you think is your housing society is safe? You&#39;re sharing your space with hundreds of families, if one person gets covid then everyone will be in danger, that is why either it might be apartment or housing society like Gated community everyone should be careful and maintain social distance as well wearing a mask is strict and compulsory.</p>\r\n\r\n<p>Let&#39;s follow the following precautions to safeguard your home and your neighborhood from Covid-19 especially in your housing society.</p>\r\n\r\n<p><strong>Installing Sanitization Spots At Entry &amp; Exit Places:</strong></p>\r\n\r\n<p>Everyone should need to posses hand sanitizers but it&#39;s not practically happening that is why Housing Societies must and should place sanitization spots in the entry and exit spots so that whoever comes in and goes out they will undergo through sanitization and half of the risk will be reduce then and there. Covid-19 is contagious so if we eradicate by hand sanitizing that will be great thing for your locality.</p>\r\n\r\n<p><strong>Maintaining Social Distance:</strong></p>\r\n\r\n<p>Sports clubs, parks walkways everything should be closed for some time during in this lock down period, until the situation comes into our control we should maintained strict social distancing otherwise it is impossible to control covid-19 in the Housing Societies.</p>\r\n\r\n<p><strong>Regular Disinfection and Temperature Checkups in the society.</strong></p>\r\n\r\n<p>Healthy and hygiene environment will be make a best place to live in that is why daily or weekly housing societies should disinfectionate the surroundings like benches, staircases, parking places etc. In that way the cause of effect will be reduced and your neighborhood will be safe to live.</p>\r\n\r\n<p>Whoever coming inside either a housing society member or someone who is coming for delivery, if we check his normal temperature it will definitely eradicate the pandemic to come into your way.</p>\r\n\r\n<p><strong>Let&#39;s Stop Outsiders:</strong></p>\r\n\r\n<p>This is a bad phase of world, it&#39;s better not to welcome anybody at this moment of time because covid-19 is contagious and it will come from human to human when they touch, sneeze even when they talk. That is why we can not trust anybody in this situation. Let&#39;s try to stop until everybody gets vaccinated.</p>\r\n\r\n<p><strong>Essential Supply To Whole Society:</strong></p>\r\n\r\n<p>In your Housing Society there will be members like president and vice president. Form them and arrange a virtual meeting for food essentials to all the residents, so that nobody will go out. In this way people can be safe and they get essentials easily.</p>\r\n\r\n<p><strong>Conducting Medical Checkups:</strong></p>\r\n\r\n<p>Housing Societies must take medical checkups because it&#39;s a group of residents we can not believe who has and who doesn&#39;t have infected with Covid-19. That is why it&#39;s always good to take medical checkups in this way, Housing Societies like apartments will be safe to live.</p>\r\n\r\n<p><strong>Conclusion</strong>:</p>\r\n\r\n<p>Being safe is the first and foremost important thing when you live in Housing Societies. Make sure to follow the above rules so that everything will go in a right way. We hope for better tomorrow for that lets live and let&#39;s follow the restrictions in this lockdown.</p>\r\n', '19-May-2021', 'housing-societies-must-take-these-precautions-to-flight-against-corona-virus', ''),
(16, 'Inner View of Pandemic on Real Estate Sector', '2021-05-26 12:32:02', '2021-05-26 14:32:02', 1, '', 'Vizag', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, '', '<p>The time has become upside down, we cannot predict the market, if we thought of relaxing another new variant of pandemic is hitting, it is very hard to sustain any business especially the <a href=\"http://eswarihomes.com/\">Real Estate</a> Sector.</p>\r\n\r\n<p>There is a moment in the <a href=\"http://eswarihomes.com/\">Real Estate</a> sector, the moment is not that huge as which creates momentum in the whole industry. People are the assets to this sector, due to pandemic and unending lock downs it&#39;s hard to expect much sales from <a href=\"http://eswarihomes.com/\">Real Estate</a> Sector in this year.</p>\r\n\r\n<h3><strong>However People Will Buy:</strong></h3>\r\n\r\n<p>Those who saved their incomes from very long time to purchase a home they will definitely buy a property. It might get bit delayed but definitely things will turn positive towards <a href=\"http://eswarihomes.com/\">Real Estate</a> Sector soon. Already half of 2021 is over now. Let&#39;s hope for the best days to turn a great start again for Real Estate Sector in 2021.</p>\r\n\r\n<h3><strong>International Buyers are Going Behind:</strong></h3>\r\n\r\n<p>Large number of NRI&#39;s going back to purchase a property at this momentum of second wave of covid-19. States are locked and many countries restricted India for touring and traveling from air. This is a huge impact on Real Estate Sector in India. Let&#39;s hope for the best to settle everything in India.</p>\r\n\r\n<h3><strong>Rental Income and Vacation spots:</strong></h3>\r\n\r\n<p>Those who thought of earning rental income, their dreams gone bad due to pandemic, many IT employees gone back to their villages because of this many rental houses are vacated. Due to lockdowns in the country many touring spots are closed down. It&#39;s hard time for those who have invested recently in properties.</p>\r\n\r\n<h3><strong>Technology Transforming Real Estate In Pandemic:</strong></h3>\r\n\r\n<p>Many realtors opting Digital Marketing to drive their business, it&#39;s a easy way to reach customers, generate leads and inform their customers about their upcoming projects and new trends in the market through social media platforms.</p>\r\n\r\n<h3><strong>Conclusion:</strong></h3>\r\n\r\n<p>Every problem gives a solution, and every solution drives us to a successful mission. So let&#39;s hope things will get back to normal, and definitely <a href=\"http://eswarihomes.com/\">Real Estate</a> has an edge over other sectors to continue it&#39;s never ending successful stories to give lot of revenue to the GDP of India.</p>\r\n', '26-May-2021', 'inner-view-of-pandemic-on-real-estate-sector', '');
INSERT INTO `blog` (`id`, `title`, `created`, `modified`, `status`, `address`, `area`, `about_area`, `2017_price`, `2018_price`, `2019_price`, `2020_price`, `street`, `city`, `district`, `pincode`, `state`, `about_property`, `property_status`, `budget_from`, `budget_to`, `price_sqft`, `added_by`, `features`, `nearby`, `modified_by`, `bed_rooms`, `property_type`, `content`, `event_date`, `key_url`, `meta_desc`) VALUES
(17, 'Eswari Homes The Best Real Estate Company in Hyderabad', '2021-06-02 12:22:21', '2021-06-02 14:22:21', 1, '', 'Vizag', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, '', '<p>Modern problem requires modern solutions and Eswari Homes always ready to provide solutions in the Real Estate Sector and that is why it has become the <a href=\"http://eswarihomes.com/\"><strong>best real estate company in Hyderabad</strong></a>.</p>\r\n\r\n<p>Hyderabad has become the best place to live, as it is historically continuing its legacy and the IT boom made it&#39;s as a wonderful place for IT employees to build their careers in the highly developing Hyderabad.</p>\r\n\r\n<p>The best home search engine, where you get all types of properties within a click. Apartments/flats, residential homes, open plots and commercial spaces etc. Just at your fingertips, you can <strong>b<a href=\"http://eswarihomes.com/\">uy properties from Eswari Homes</a></strong>. <a href=\"http://eswarihomes.com/\"><strong>Flats for sale in Hyderabad</strong></a>, <a href=\"http://eswarihomes.com/\"><strong>Eswari Homes the best real estate company in Hyderabad</strong></a>.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>Why Eswari Homes Best In Hyderabad?</strong></p>\r\n\r\n<p>With the limitless feature of the Home Search Engine, Eswari Homes can build a bridge between builders and customers to sell and buy properties easily with a vast community of builders/realtors as partners in the Real Estate Sector.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>Find Properties Easily:</strong></p>\r\n\r\n<p>Hyderabad is one of the prominent locations in India, if you&#39;re searching for a property there are many applications and many realtors but Eswari Homes is the only platform where you can classify your property search easily, you select Apartments/Flats, villas, Residential Homes and commercial spaces etc just by a click-through Eswari Homes. Eswari Homes is the best choice for<strong> <a href=\"http://eswarihomes.com/\">property search in Hyderabad</a>.</strong></p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>Budget-Friendly Properties:</strong></p>\r\n\r\n<p>Purchasing a home is a dream for many people, to achieve your dream just click on Eswari Homes, where you get thousands of property options to choose and all properties will be within your budget. <a href=\"http://eswarihomes.com/\"><strong>Affordable properties on Eswari Homes</strong></a></p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>Verified Properties:</strong></p>\r\n\r\n<p>All the realtors in the Eswari Homes are verified, before verifying all the properties details from foundation to flooring and tiles to walls everything Eswari Homes verifies then only we will make sure to position in our website. I.e most <a href=\"http://eswarihomes.com/\"><strong>trusted property search engine Eswari Homes</strong></a></p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>Developing Locations:</strong></p>\r\n\r\n<p>We wish our customers grow, we work to grow along with them, that is why all our projects will be located in developing locations and centred at growth corridors to increase the property value within years.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>World Class Amenities:</strong></p>\r\n\r\n<p>Eswari Homes just not deliver the property, we will try to deliver the <a href=\"http://eswarihomes.com/\"><strong>world-class living experience</strong></a> to our customers and amenities are the part of the great developing trend to anticipate happy living space. Eswari Homes provides the <a href=\"http://eswarihomes.com/\"><strong>best amenities</strong></a> to their customers.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>Conclusion:</strong></p>\r\n\r\n<p>The above article clearly explains the facts regarding<strong> <a href=\"http://eswarihomes.com/\">the best real estate company in Hyderabad</a></strong>. Eswari Homes enhancing the real estate sector through its great resourceful process to deliver great properties to customers in and around Hyderabad, from budget to location, amenities to development Eswari Homes trying its best to give great services to customers by being a bridge between builders or Realtors to Customers. The vast community in the real estate industry made it the <a href=\"http://eswarihomes.com/\"><strong>best real estate company in Hyderabad </strong></a></p>\r\n', '02-June-2021', 'eswari-homes-the-best-real-estate-company-in-hyderabad', ''),
(18, 'Analysis of GST on Real Estate Sector', '2021-07-07 11:22:50', '2021-07-07 13:04:15', 1, '', 'Vizag', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, '', '<p>The concept of GST was introduced on 1st July, 2017 after years of deliberations and promotion of related concepts like co-operative federalism. This year marks the completion of 4 years of the GST regime. Let us understand the nuances of GST and the impact of <a href=\"http://eswarihomes.com/\"><strong>GST on real estate transaction</strong></a>. This article will provide an <a href=\"http://eswarihomes.com/\"><strong>analysis of GST on real estate sector</strong></a>.</p>\r\n\r\n<p>Let us look at GST and Real Estate as two separate entities. We will understand each concept individually and then analyse the impact of one on the other.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>What is GST?</strong></p>\r\n\r\n<ul>\r\n	<li>Goods &amp; Services Tax is a universal indirect tax for the whole of the nation.</li>\r\n	<li>Before GST regime, there were a number of indirect taxes which were levied by both the centre and the state.</li>\r\n	<li>With the implementation of GST, all the Goods and services have come under an umbrella taxation system. This was aimed to reduce the burden on the tax-payer.</li>\r\n</ul>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>The main features of the GST system:</strong></p>\r\n\r\n<ul>\r\n	<li>The GST is applicable only on the supply-side as against the previous system which was applicable on both the supply and demand sides.</li>\r\n	<li>It is a destination-based taxation system.</li>\r\n	<li>It is a dual GST system where the states levy SGST and the Centre levies CGST.</li>\r\n</ul>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>The reforms brought about by the GST system:</strong></p>\r\n\r\n<ul>\r\n	<li>Creation of a common national market</li>\r\n	<li>Reduces tax burden</li>\r\n	<li>Increased transparency due to its self-policing character</li>\r\n	<li>Mitigation of cascading effect</li>\r\n	<li>Making Indian products and services more competitive</li>\r\n</ul>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>The <a href=\"http://eswarihomes.com/\"><strong>GST implications on Real Estate transactions</strong></a> is a very confusing topic, let us understand it in detail so you will be able to make informed decisions in the future.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>What is Real Estate?</strong></p>\r\n\r\n<p>Real estate in simpler terms means Property in the form of land in isolation or both land and building taken together.</p>\r\n\r\n<p>Real Estate project means construction and development of a land into saleable property. This is done by builders who play a role in the construction and realtors who play a role in the sale of the said real estate project.</p>\r\n\r\n<p>The GST is levied on all levels of development of the project right from construction (on construction materials, and the like) till the sale (GST on sale or purchase of the property, transaction costs, etc.)</p>\r\n\r\n<p>According to the GST Act 2016, the following tax regime has been introduced for <a href=\"http://eswarihomes.com/\"><strong>residential real estate transaction</strong>s</a> w.e.f 01-04-2019. Let us understand the provisions briefly.</p>\r\n\r\n<ul>\r\n	<li>GST to be charged at 5% without input tax credit for properties that are not part of the affordable housing segment.</li>\r\n	<li>GST to be charged at 1%without ITC for properties that come under affordable housing.</li>\r\n	<li>GST for under construction properties is 12%</li>\r\n	<li>GST is not applicable on resale of old properties or projects that have been already completed.</li>\r\n	<li>Builders receive ITC on materials used for construction from suppliers and manufacturers, they were expected to transfer it back to the buyers, however this has not happened.</li>\r\n</ul>\r\n\r\n<p>The GST Council has announced the criteria for a residential property to come under the affordable housing segment:</p>\r\n\r\n<ul>\r\n	<li>The Total carpet area of the residential property cannot exceed 60 square metres in metropolitan areas.</li>\r\n	<li>The total carpet area of the residential property cannot exceed 90 square metres in non-metropolitan cities and towns.</li>\r\n	<li>The total value of the property cannot exceed Rupees 45 Lakhs in both metropolitan and non-metropolitan areas.</li>\r\n</ul>\r\n\r\n<p>The <a href=\"http://eswarihomes.com/\"><strong>GST on real estate transactions</strong></a> has been reduced, this benefits both the builders/sellers and buyers. Benefits of GST rate cuts on residential properties:</p>\r\n\r\n<ul>\r\n	<li>Simpler tax structure which means greater compliance by the builders</li>\r\n	<li>Interests of buyers are protected due to the fact that the ITC is expected to be transferred to the buyers.</li>\r\n	<li>Optimum prices of the properties are guaranteed due to the ITC of 1% in affordable housing segment.</li>\r\n	<li>The unused ITC is not added to the project costs which will ultimately result in fair pricing of the properties.</li>\r\n</ul>\r\n\r\n<p>GST is not applicable in case of</p>\r\n\r\n<ol>\r\n	<li>Sale of Ready to move-in flats</li>\r\n	<li>Resale of old property</li>\r\n	<li>Sale/Purchase of Land</li>\r\n</ol>\r\n\r\n<p><strong>Registration and Stamp Duty </strong></p>\r\n\r\n<p>The Registration and Stamp duty have remained unaffected by the GST. The states have their own rate of GST which is levied based on their rules and regulations. The sale or purchase of completely constructed property or under construction property attract registration and stamp duties. The <a href=\"http://eswarihomes.com/\"><strong>GST implications on real estate transactions</strong></a> have no effect on stamp duties and registration charges, whatsoever.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>GST implications on real estate</strong></p>\r\n\r\n<p>Though initially the <a href=\"http://eswarihomes.com/\"><strong>GST on real estate transactions</strong></a> was maintained high, the changes which came into effect in 2019 brought out the necessary reforms. The <a href=\"http://eswarihomes.com/\"><strong>GST on real estate reduced</strong></a>, bringing affordable housing closer to the buyers. The reforms in <a href=\"http://eswarihomes.com/\"><strong>GST on real estate transactions</strong></a> have been incorporated in-line with the target of &ldquo;Housing for All by 2022&rdquo;.</p>\r\n\r\n<p>While real estate in India does not directly come under the GST regime, many activities like construction, and building materials like cement, steel, etc. used for construction come under the regime. Various activities and services are now taxable under the regime.</p>\r\n\r\n<p>Let us see some segments where home buyers are likely to pay GST or not pay GST.</p>\r\n\r\n<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\"class=\"table table-bordered\">\r\n	<tbody>\r\n		<tr>\r\n			<td style=\"height:22px\">\r\n			<p><strong>GST on</strong></p>\r\n			</td>\r\n			<td style=\"height:22px\">&nbsp;</td>\r\n			<td style=\"height:22px\">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"height:22px\">\r\n			<p>Housing Maintenance Charges</p>\r\n			</td>\r\n			<td style=\"height:22px\">\r\n			<p>Likely to pay 18%</p>\r\n			</td>\r\n			<td style=\"height:22px\">\r\n			<p>If it is &gt;7500 per month</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"height:22px\">\r\n			<p>Rent</p>\r\n			</td>\r\n			<td style=\"height:22px\">\r\n			<p>No GST</p>\r\n			</td>\r\n			<td style=\"height:22px\">\r\n			<p>If rented for residential purposes</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"height:22px\">\r\n			<p>Home Loan</p>\r\n			</td>\r\n			<td style=\"height:22px\">\r\n			<p>No GST for buyers</p>\r\n			</td>\r\n			<td style=\"height:22px\">\r\n			<p>GST on processing fee, legal fee, etc.</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"height:22px\">\r\n			<p>Affordable Housing</p>\r\n			</td>\r\n			<td style=\"height:22px\">\r\n			<p>1% GST without ITC</p>\r\n			</td>\r\n			<td style=\"height:22px\">&nbsp;</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>On a brighter note, with the GST regime being slowly incorporated into all the transactions, the realtors, builders and buyers are getting the maximum benefits from the same. The increased demand for residential properties has pushed up the transaction rate. As of now, the <a href=\"http://eswarihomes.com/\"><strong>GST implications on real estate transactions</strong></a> cannot be accurately gauged and it will be clearer with more time.</p>\r\n', '07-July-2021', 'analysis-of-gst-on-real-estate-sector', ''),
(19, '5 Reasons Why You should Buy a House in 2021', '2021-08-16 14:17:43', '2021-08-16 16:17:43', 1, '', 'Vizag', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, '', '<p><a href=\"http://eswarihomes.com/\"><strong>Home-buying in 2021</strong></a> has become a mandate with the increasing work-from-home scenario. Working from the comfort of your home is what the millennials are looking for. Affordable yet modern homes are the most in-demand.</p>\r\n\r\n<p>Now you must be wondering, with the pandemic and increased cost of living, <a href=\"http://eswarihomes.com/\"><strong>is 2021 a good year to buy a house</strong></a>? Let us make this very clear that the right time to buy a house is ALWAYS and whenever you want to own a place.</p>\r\n\r\n<p>With the current pandemic scenario, the real estate sector has slowed down only to leap further and faster. The home-buying sector has increased its sales post-pandemic and this has led to high demand for houses, both apartments, and gated communities. The more the work-from-home scenario continues, the more the demand is going to be. This calls for an open policy and framework that will make home-buying much easier than it already is.</p>\r\n\r\n<p>Here are some reasons why<a href=\"http://eswarihomes.com/\"> <strong>buying property in 2021</strong></a> is the best decision you will ever make.</p>\r\n\r\n<p><strong>1.&nbsp;&nbsp;&nbsp; Ease in Home Prices</strong></p>\r\n\r\n<p>As per the <a href=\"http://eswarihomes.com/\"><strong>Housing Price Index 2021</strong></a> released by the RBI, house prices have fallen by 1% in Q3 of 2020. Since then the prices have eased or haven&rsquo;t changed at all. This has increased the demand among working professionals. The major cities where the investments have risen are Bengaluru, Pune, Hyderabad, and Chennai.</p>\r\n\r\n<p>But <a href=\"http://eswarihomes.com/\"><strong>buying a home in 2021</strong></a> in the tier-II and tier-III cities has its own benefits. With the prices consistently dropping, the demand for houses in the suburban areas around the cities has increased. However, many realtors are serving on a first-come-first-serve basis with the demand too high to handle.</p>\r\n\r\n<p>Tier-II and tier-II cities like Visakhapatnam and Vijayawada are really lucrative locations to invest in a home. <a href=\"http://eswarihomes.com/\"><strong>2BHK apartments in Visakhapatnam</strong></a> are now affordable and covered with all amenities that are equivalent to the <a href=\"http://eswarihomes.com/\"><strong>2BHK apartments in Hyderabad</strong> </a>and other major cities.</p>\r\n\r\n<p><a href=\"http://eswarihomes.com/\"><strong>Buying a house in 2021</strong></a> has become more transparent and hassle-free with the new acts like RERA coming into play. With the acts and laws now increasing transparency,&nbsp; the realtors are also benefitting from the increased demand.&nbsp;</p>\r\n\r\n<p><strong>2. Home Loan Rates at a 15-year Low</strong></p>\r\n\r\n<p>With the bankers interested in providing loans for more approachability, the home loan has become a simpler process than ever. All you have to do is to keep your credit profile credible. Here&rsquo;s a link to our previous blog on the <a href=\"http://eswarihomes.com/\"><strong>Importance of Credit Score for Home Loans</strong>.</a></p>\r\n\r\n<p>With home loan rates consistently low for the 14th time, there is a possibility they might drop further. Here&rsquo;s your chance to become a homeowner this year. This is the best time to <a href=\"http://eswarihomes.com/\"><strong>buy a house in&nbsp; 2021</strong></a> and there&rsquo;s no doubt about it.</p>\r\n\r\n<p><strong>3.&nbsp;Decrease in RBIs Repo Rate</strong></p>\r\n\r\n<p>The Reserve Bank of India lends money to banks when there is a shortage of funds on the basis of the repo rate.</p>\r\n\r\n<p>RBIs Repo Rate is what determines the bankers&rsquo; decision on home loan interest rates. This has consistently been dropping and this year too it dropped by 115 base points to support the slumping economy. This is in addition to the 135 base points drop in 2019.</p>\r\n\r\n<p>When the repo rate is decreased, banks are allowed to pass some benefits in the form of home loans. This means a possible drop in the EMIs. Lower EMIs are more likely to attract homebuyers. So for those who are looking for an opportunity to avail a home loan now is a better time to apply for one.</p>\r\n\r\n<p>Additionally, a reduced repo rate also reduces the funding costs faced by developers resulting in more projects by them. More projects mean more options for you to choose your home from.</p>\r\n\r\n<p><strong>4. Incentives for Home-buyers</strong></p>\r\n\r\n<p>The incentives for <a href=\"http://eswarihomes.com/\"><strong>home-buying in 2021</strong></a> have gone up like never before. Here are a few compelling reasons for you to <a href=\"http://eswarihomes.com/\"><strong>buy a house in 2021</strong></a>:</p>\r\n\r\n<p>&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Post-pandemic, property values are at more realistic levels</p>\r\n\r\n<p>&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Mortgage and Home Loan interest rates are at an all-time low</p>\r\n\r\n<p>&middot;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;Relatively low stamp duties in some states like Maharashtra</p>\r\n\r\n<p>&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Flexible payment schemes</p>\r\n\r\n<p>&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; GST and stamp duty waiver on home-buying</p>\r\n\r\n<p>&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; The slump in registration charges</p>\r\n\r\n<p>&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Cost-saving incentives by realtors and builders</p>\r\n\r\n<p>Home-buying in 2021 is lucrative for those looking to buy one for a long time. Now you have the reasons to book your own flat at your preferred locations. Enjoy that perfect cup of coffee in your own <a href=\"http://eswarihomes.com/\"><strong>3BHK apartment in Vizag</strong></a> with a view of the beach or the hills. Your own home bought in the most cost-effective manner is going to last forever. This is going to be the best decision you&rsquo;ve made ever.&nbsp;</p>\r\n\r\n<p><strong>5. Remote Work is going to continue</strong></p>\r\n\r\n<p>Don&rsquo;t you want to <a href=\"http://eswarihomes.com/\"><strong>buy a home in 2021</strong></a> and settle down once and for all enjoying the comfort of your own home? Who doesn&rsquo;t want that, right?</p>\r\n\r\n<p>The ongoing strain of the virus is calling for more remote work routines. Work from home has several benefits, for both the employees and employers. Here are some key advantages of working from home:</p>\r\n\r\n<p>&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Flexibility in work timings, i.e., you get to manage your time.</p>\r\n\r\n<p>&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Saves travel budget and no more travel fatigue!</p>\r\n\r\n<p>&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; No more missing out on home-cooked food.</p>\r\n\r\n<p>&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; You can personalize your workspace according to your comfort.</p>\r\n\r\n<p>Work from home is not only beneficial for employees but also for employers. It reduces the cost of infrastructure and absenteeism. So it is no surprise that employers want their employees to continue their work from home.</p>\r\n\r\n<p>In such circumstances, having a home that you can call your own plays a positive role. You get to create your own workspace and make it as comfortable as you see fit. You get to enjoy your home and your work at the same time. This also boosts your productivity.</p>\r\n\r\n<p>You can now work and spend some quality time with your family. And what&rsquo;s better than doing it all in your own home?</p>\r\n\r\n<p>However, there are some important measures that you should take before buying a home. Here are the steps you need to take and the thoughts you need to think about buying a home.</p>\r\n\r\n<p>&Oslash; Deciding on a budget is the first and foremost step as you need to understand your affordability according to your repayment capacity.</p>\r\n\r\n<p>&Oslash; Check your credit score and make sure you are eligible to avail a home loan</p>\r\n\r\n<p>&Oslash; Get pre-approved for a home loan. There are many professionals who will assist you to get pre-approved.</p>\r\n\r\n<p>&Oslash; Find out which bank provides the lowest and most competitive interest rates.</p>\r\n\r\n<p>&Oslash; Consult an Expert and never lose out on the best deals.</p>\r\n\r\n<p>&Oslash; Then comes the most important decision of identifying the right property at the location you prefer.</p>\r\n\r\n<p>&Oslash; After you select the property, document verification is the next step.</p>\r\n\r\n<p>&Oslash; Make sure all the property-related documents are verified and the credentials of the builder or realtor also need to be verified.</p>\r\n\r\n<p>&Oslash; Understand the possession policy if it is in the plan approval stages.</p>\r\n\r\n<p>&Oslash; Check all the amenities and verify the documents thoroughly if it is a ready-to-move-in property.</p>\r\n\r\n<p>&Oslash; Understand and read the documents and agreements carefully and find out about any hidden or extra charges.</p>\r\n\r\n<p>&Oslash; The final step is to register the property in your name and you are a homeowner.</p>\r\n\r\n<p><a href=\"http://eswarihomes.com/\"><strong>Home-buying in 2021</strong></a> is now simple and easy. It is your turn to become a home-buyer now. Happy home-buying!!</p>\r\n', '16-Aug-2021', '5-reasons-why-you-should-buy-a-house-in-2021', ''),
(20, 'Most Common Vaastu Tips for Your Home', '2021-08-28 11:16:35', '2021-08-28 13:16:35', 1, '', 'Vizag', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, '', '<p>Vaastu has become an indispensable concept for a home. The most common <a href=\"https://eswarihomes.com/\"><strong>vaastu tips for your home</strong></a> are available anywhere online or with experts. The best way to acquire <a href=\"https://eswarihomes.com/\"><strong>vaastu tips for your home</strong></a> is by consulting an expert.</p>\r\n\r\n<p>Builders and realtors nowadays are mostly adhering to the common Vaastu requirements in their constructions. However, you can modify them according to your specifications by consulting with the engineers and builders.</p>\r\n\r\n<p>To get a better understanding of the concept of Vaastu, let us delve into further details in this article.</p>\r\n\r\n<p>There has always been a debate around the concept of &ldquo;Vaastu&rdquo;, whether or not it is valid or is it a pure science or pseudoscience. This concept can be better understood by understanding the scientific backing behind it. When Googled, you will find that Vaastu is the science of architecture. It is translated as the science of construction and architecture, following which gives your home better ventilation and gives you some peace of mind.</p>\r\n\r\n<p>The earth is surrounded by energy sources like the sun, wind, water, and fire. The effect of sunlight, the flow of wind, etc influence our lives in the most unimaginable ways. Vaastu shastra is an ancient science that takes into consideration all the atmospheric factors, their effects on life and then gives the basic design of a perfect home.</p>\r\n\r\n<p>With modernity and technology taking the main seat in our lives in the future, Vaastu Shastra has been believed to become redundant. However, considering the geography of the earth some principles remain true even today. Let us take a sneak peek into some of these principles which aid in leading a life in tranquility.</p>\r\n\r\n<p><strong>Vaastu Tip #1</strong></p>\r\n\r\n<p>The main entrance of your home is not just for people to enter and exit. It is believed to be meant for the flow of energies too. The ideal direction for the entrance of your home is north, east, and north-east. Make sure to buy a home that has either one of these faces. If you are buying a ready-to-move-in home, you can renovate to get the preferred direction for your home. The basic <a href=\"https://eswarihomes.com/\"><strong>Vaastu tips for your home</strong></a> when adhered to can bring peace and happiness to you and your family.</p>\r\n\r\n<p><strong>Vaastu Tip #2</strong></p>\r\n\r\n<p>The shape of your rooms should be square or rectangular. They should be well-lit, airy, and spacious. The centre of the house should preferably be empty, to let in the positive energy. Heavy furniture like almirahs should be placed in the south-west direction. It is advised that water structures like plants, aquariums, water fountains, or even paintings depicting water be avoided in bedrooms. If you need to place a mirror in the bedroom, make sure it does not face the bed. Ensure that the dining space is near the kitchen and not near the main door.</p>\r\n\r\n<p><strong>Vaastu Tip #3</strong></p>\r\n\r\n<p>Did you know that each room in your house needs to be in a specific direction? Here are some common <a href=\"https://eswarihomes.com/\"><strong>vaastu tips for your home</strong></a> on which direction each room should be in.</p>\r\n\r\n<p>Kitchen: The ideal direction for a kitchen is south-east. It is a strict no-no if the kitchen is in the north. The south-east direction ensures proper ventilation and sunlight from all directions which are necessary for a kitchen.</p>\r\n\r\n<p>Master Bedroom: According to the most basic <a href=\"https://eswarihomes.com/\"><strong>Vaastu tips for your home</strong></a>, the master bedroom must be in the south-west direction. It should never be in the south-east direction as the direction is dominated by the fire element.</p>\r\n\r\n<p>Kids&rsquo; Bedroom: The kids&rsquo; bedroom must also face the south-west direction. Make sure they sleep with their heads in the south or west direction for a healthy body and peaceful mind.</p>\r\n\r\n<p>Bathrooms: According to Vaastu shastra, the toilet should be in the west or north-west direction. Avoid purchasing homes that have toilets placed in other directions as there are no remedies for removing the negative doshas that come with the placement, according to Vaastu shastra.</p>\r\n\r\n<p><strong>Vaastu Tip #4</strong></p>\r\n\r\n<p>The overhead water tank placement in the west or south-west direction is the most important of the <a href=\"https://eswarihomes.com/\"><strong>Vaastu tips for your home</strong></a>. If it is placed in the south-west direction, make sure it is 2 feet above the ground.</p>\r\n\r\n<p><strong>Vaastu Tip #5</strong></p>\r\n\r\n<p>Vaastu experts believe that the septic tank harnesses negative energy, as the waste from the kitchen and toilets is flushed into it. As per the Vaastu tips for your home, it should be placed only in the north-west direction. It should not touch the compound wall.</p>\r\n\r\n<p>Vaastu Shastra emphasizes that every structure reverberates with energy as the earth is surrounded by resources like fire, water and other elements. Vaastu aims at eliminating negative energy and bring in positive energy to your home. Now that we have seen the basic Vaastu tips for your home, let us understand why Vaastu shastra is important for your new home.</p>\r\n\r\n<p>●&nbsp;&nbsp;&nbsp;&nbsp; Improving Financial Prosperity</p>\r\n\r\n<p>●&nbsp;&nbsp;&nbsp;&nbsp; Aiding in Career Stability</p>\r\n\r\n<p>●&nbsp;&nbsp;&nbsp;&nbsp; Helping in good physical and mental health</p>\r\n\r\n<p>●&nbsp;&nbsp;&nbsp;&nbsp; Improving interpersonal relationships</p>\r\n\r\n<p>●&nbsp;&nbsp;&nbsp;&nbsp; Academic development</p>\r\n\r\n<p>As per Vaastu the earth is made up of 5 elements- fire, water, wind, earth and space. The balance of these elements in your home is supposed to bring positive energy and good vibrations to you and your family. Let us now see the dominant directions of each of these elements-</p>\r\n\r\n<p>●&nbsp;&nbsp;&nbsp;&nbsp; Earth- Prithvi- Its dominant traits are providing patience and stability. It dominates every center and every corner of your home.</p>\r\n\r\n<p>●&nbsp;&nbsp;&nbsp;&nbsp; Air- Vayu- It is believed to bring joy and happiness. It dominates the East direction.</p>\r\n\r\n<p>●&nbsp;&nbsp;&nbsp;&nbsp; Space- Akasha- Its dominant direction is the West for its traits are cognitive energy and mental space.</p>\r\n\r\n<p>●&nbsp;&nbsp;&nbsp;&nbsp; Fire- Agni- It represents money, success, and confidence. Its dominant direction is the South.</p>\r\n\r\n<p>●&nbsp;&nbsp;&nbsp;&nbsp; Water- Jal- It is the elixir of life. It is hence associated with health and immunity. Its dominant direction is the North.</p>\r\n\r\n<p>It is not possible for every builder to adhere to these common vaastu tips for your home. But if you believe in Vaastu Shastra, then you can renovate the home according to your specifications or request the builder to make a few modifications to suit your needs.</p>\r\n\r\n<p>The Vaastu Shastra experts believe that following the basic <a href=\"https://eswarihomes.com/\"><strong>Vaastu tips for your home</strong></a> ensures peace and prosperity. For you to attain the best in life, they believe that following the <a href=\"https://eswarihomes.com/\"><strong>Vaastu tips for a happy home</strong></a> is necessary. Vaastu Shastra takes into account the measurements, design, and layout and gives you the best <a href=\"https://eswarihomes.com/\"><strong>Vaastu advice for apartments</strong></a> or individual houses.</p>\r\n\r\n<p>Whether or not you believe in Vaastu Shastra there are certain do&rsquo;s and don&rsquo;ts while constructing a house. Following these tips helps you build a home that makes your life easy and happy. Contact us for more details on how we find the best homes that suit your needs.</p>\r\n\r\n<p>Keep a tab on our blog for more updates.</p>\r\n', '28-Aug-2021', 'most-common-vaastu-tips-for-your-home', ''),
(21, 'Most Important Factors for Investing in Real Estate', '2021-09-04 07:54:28', '2021-09-04 09:54:28', 1, '', 'Vizag', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, '', '<p><a href=\"https://eswarihomes.com/\"><strong>Real Estate Investing</strong></a> in India is a lucrative opportunity in the current scenario as the work from home trend is predicted to continue in the near future and people are on the lookout for their own nests. This is also true because the pandemic has slumped the returns on the traditional investment options like stock markets. However, the initial investment for real estate is high due to which it is difficult for the real estate sector to replace the traditional investment options.</p>\r\n\r\n<p>The definition of real estate states that it is a piece of land which can be vacant or be built upon. The growth in real estate has been vague for quite some time. But the latest trends and surveys state that <a href=\"https://eswarihomes.com/\"><strong>real estate investment</strong></a>s are bound to grow in the next decade or so. However, in countries with large tracts of land and a disproportionate population, the real estate sector has seen a growth like no other industry.</p>\r\n\r\n<p><a href=\"https://eswarihomes.com/\"><strong>Real estate investing</strong></a> has a potential to become a very profitable business. It&rsquo;s a very dangerous business, too. It&rsquo;s a business that has a lot of ups and downs, and you need to understand that and be prepared for it. There are a lot of different ways to invest in and profit from real estate. You can do it directly, as the owner of the building, or indirectly, as the lender who finances the building. You can also provide services to the building owner, such as property management or construction.</p>\r\n\r\n<p>Now, let us consider the factors that influence <a href=\"https://eswarihomes.com/\"><strong>real estate investment</strong></a>. While the &ldquo;location, location, location&rdquo; adage still holds true for the sector, there are many other factors that need to be taken into consideration for <a href=\"https://eswarihomes.com/\"><strong>real estate investing</strong></a>.</p>\r\n\r\n<p><strong>What is real estate investment?</strong></p>\r\n\r\n<p><a href=\"https://eswarihomes.com/\"><strong>Real estate investment</strong></a>, <a href=\"https://eswarihomes.com/\"><strong>real estate investing</strong></a>, real estate, or property investment are terms used to describe the process of acquiring and investing in various types of real estate. Property types commonly dealt with include residential, commercial, and vacant properties. Real estate can be defined as &ldquo;real&rdquo; property, and also the rights that are attached to it. It is commonly used as a collective term to refer to all movable and immovable property which is attached with certain rights and obligations to a definite individual. Investment in real estate is a popular way to make a profit. When a property is bought with the sole purpose of reselling at a higher price, it is called a <a href=\"https://eswarihomes.com/\"><strong>real estate investment</strong>.</a></p>\r\n\r\n<p><a href=\"https://eswarihomes.com/\"><strong>Real estate investment</strong></a> is a type of investment that allows you to buy a property to either live in or rent out for a profit. Real estate can be a great investment, as long as you know what you&rsquo;re doing. There are a lot of different factors that can determine your success. But it&rsquo;s important to know what those factors are so you can avoid the wrong decisions.</p>\r\n\r\n<p>Real estate is one of the safest assets in the world, but that doesn&#39;t mean that it&#39;s 100% safe. It&#39;s not. The real estate market is one of the most volatile ones. If you&#39;re not careful, you can face money loss. How do you avoid that? It&#39;s not an easy question to answer, but you can start by slowing down and doing proper research. In this article, we&#39;ll try to identify the most important factors that influence <a href=\"https://eswarihomes.com/\"><strong>real estate investment</strong></a> and real estate market trends. And then we&#39;ll talk about the risk you have to take to invest in real estate.</p>\r\n\r\n<p><strong>Is real estate investment risky?</strong></p>\r\n\r\n<p><a href=\"https://eswarihomes.com/\"><strong>Real estate investment</strong></a> is a very popular topic in the media. This article is here to answer a very simple question: Is <a href=\"https://eswarihomes.com/\"><strong>real estate investment</strong></a> risky? In fact, it&rsquo;s not. In fact, it&rsquo;s one of the safest investments you can make. The reason why many people believe it&rsquo;s risky is that they don&rsquo;t know about the factors that influence <a href=\"https://eswarihomes.com/\"><strong>real estate investment</strong></a>. However, if you know a few things about it, it&rsquo;s a great opportunity to make a lot of money. First of all,let us understand why <a href=\"https://eswarihomes.com/\"><strong>real estate investment</strong></a> is considered a safe investment. The reason why <a href=\"https://eswarihomes.com/\"><strong>real estate investment</strong></a> is considered a safe investment is that it&rsquo;s a tangible asset that has a market price. If you invest in real estate, you will be able to sell it at any time. And you can&rsquo;t say that about most other investments. For example, stocks are considered risky because you can&rsquo;t sell them at any time. You can just hope that they go up in price. You can&rsquo;t even sell them at all if you don&rsquo;t have the cash to pay for them. So, if you decide to invest in real estate instead of stocks, you&rsquo;ll be able to sell the real estate at any time if you need cash.</p>\r\n\r\n<p>The real estate industry is certainly one that is filled with risks, especially when it comes to investment. However, if you are smart about it, you can minimize the risks involved in becoming a real estate investor. There are some things you can do in order to minimize your risks and increase your chances of having a successful investment. We try to explain the factors influencing real estate investing in this article.</p>\r\n\r\n<p><strong>How to identify the best investment area?</strong></p>\r\n\r\n<p>In the current real estate market, there are a few factors that can influence a property&#39;s value. Understanding the different factors that influence a property&#39;s value is a good way to determine which properties to invest in and which ones to avoid. Location is the most important factor for a real estate investor. It is absolutely essential that you know the area of town you are investing in. Investing in an area with a high crime rate or high poverty rate is not beneficial to you. Do some research on the area and make sure it is a place you want to invest in.</p>\r\n\r\n<p>You can buy a house in a good location for a reasonable price. Location is the most important factor when you are buying a real estate property. The best way to invest in real estate is to have a good knowledge of the location of the property. You can get a lot of information on different properties from real estate agents. You can also read the newspapers and the Internet for the latest information on real estate. The government is also doing its best to resolve any problems in the real estate sector.</p>\r\n\r\n<p><strong>How do home loan rates influence real estate investment?</strong></p>\r\n\r\n<p>Real estate is a very popular way to invest your money. The cost of real estate has risen significantly in the last decade. Many people today invest in real estate in order to make a profit. There are many factors that influence the growth of the real estate sector. The increased demand for housing increased the value of real estate.</p>\r\n\r\n<p>Home loan interest rates are generally used as a benchmark for real estate rates across India. They are the single most important factor influencing your <a href=\"https://eswarihomes.com/\"><strong>real estate investment</strong></a> as they will affect your cash flow, return on investment and your ability to refinance your home loan. The current average home loan interest rate is 6.75%. The interest rates have been going down since the last few years and that has been an advantage for real estate investors. The home loan rate can be a deciding factor in your investment plans. If you are considering a <a href=\"https://eswarihomes.com/\"><strong>real estate investment</strong></a>, you should know how home loan rates can affect you.</p>\r\n\r\n<p><strong>Why is the Property&rsquo;s condition important for investing?</strong></p>\r\n\r\n<p>When you are looking to invest in real estate, the condition of the property is one of the most important factors to consider. However, this is something that most people do not pay attention to. This is the reason why many investors buy properties that are in poor condition. The condition of the property is vital to its value. If the property has been neglected from the time it was purchased, there is a possibility that the property will need a lot of work. Even if you find a good deal, if the property has serious defects, the value of the property will eventually go down. This is because the property will require repair and renovation. To prevent this, it is important to buy the right property.</p>\r\n\r\n<p><strong>How to identify long-term opportunities?</strong></p>\r\n\r\n<p>Real estate industry is one of the most popular ways of investment. There are numerous ways for investing in real estate. It can be buying a property for personal use, for rent or to resell at a premium price. There are various factors that determine the profitability of an investment. The most important factors that affect the profitability of <a href=\"https://eswarihomes.com/\"><strong>real estate investment</strong></a> are location of the property, its condition, the rental rates, the growth of the community, the state of the real estate market, the mortgages, the timeline of the investment, the annual growth of the rental income, the annual growth of the property value, the annual growth of the area value, the cash flow and the purchase price. Another important factor is the risk and the cash flow and the purchase price.</p>\r\n\r\n<p>If you are interested in investing in real estate, you will need to understand the factors influencing <a href=\"https://eswarihomes.com/\"><strong>real estate investment</strong></a>. You have to take into account these factors before starting a <a href=\"https://eswarihomes.com/\"><strong>real estate investment</strong></a>. It is good to have a strategy before going into the market. It is a good idea to start with a smaller investment and work your way up. Before making a purchase, you have to see the condition of the property. <a href=\"https://eswarihomes.com/\"><strong>Real estate investment</strong></a> is one of the most profitable businesses in the world today. Just make sure you are looking at the right factors when you are investing.</p>\r\n\r\n<p>Real estate is a very useful investment area. This is because the prices are low and banks are more willing to lend. If you are looking to make money with real estate, you must start with buying your own home. This way you will be familiar with the process. Many people are looking to invest their money. As prices are low, they are just waiting for the time to be right. This is the best time to invest, as prices will just continue to go up!</p>\r\n\r\n<p>We hope you enjoyed our article on how to invest in real estate. If you have any real estate inquiries, please contact us. Thank you for reading, we are always excited when one of our posts is able to provide useful information on a topic like this!</p>\r\n', '04-September-2021', 'most-important-factors-for-investing-in-real-estate', '');
INSERT INTO `blog` (`id`, `title`, `created`, `modified`, `status`, `address`, `area`, `about_area`, `2017_price`, `2018_price`, `2019_price`, `2020_price`, `street`, `city`, `district`, `pincode`, `state`, `about_property`, `property_status`, `budget_from`, `budget_to`, `price_sqft`, `added_by`, `features`, `nearby`, `modified_by`, `bed_rooms`, `property_type`, `content`, `event_date`, `key_url`, `meta_desc`) VALUES
(22, 'Buying a Home is Easy If you Know What Questions to Ask', '2021-09-09 14:12:18', '2021-09-09 16:12:18', 1, '', 'Vizag', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, '', '<p><a href=\"https://eswarihomes.com/\"><strong>Buying a house in Visakhapatnam</strong></a> is easy and the rates are affordable. The only thing that you need to do is find a house and contact the builder and then register your name. <a href=\"https://eswarihomes.com/\"><strong>Buying property in Vizag</strong></a> has never been easier. There are many builders who provide home loans which make it an affordable process for everyone. One can also buy a plot of land and construct their own house. The only requirement is that one should hire an expert who can help them with the purchase process for the <a href=\"https://eswarihomes.com/\"><strong>house for sale in Visakhapatnam</strong></a>.</p>\r\n\r\n<h3><strong>Why is Buying a Home Important?</strong></h3>\r\n\r\n<p><a href=\"https://eswarihomes.com/\"><strong>Buying a home</strong></a> is one of the most important steps in life. It provides stability for your family and gives you financial stability as well. <a href=\"https://eswarihomes.com/\"><strong>Buying a house in Visakhapatnam</strong></a> is an exciting process for everyone, with it comes new furniture, paint, and renovations to spruce up your new place!</p>\r\n\r\n<p>The process of <a href=\"https://eswarihomes.com/\"><strong>buying a home in Visakhapatnam</strong></a> can be overwhelming at first, with all the paperwork and closing costs involved. But there are also many upsides. And this article will explore them so that you can be more confident in your decision to buy a new house!</p>\r\n\r\n<p>This article will explore everything from the paperwork to closing costs, so that you can be more confident in deciding on whether or not to move forward with buying your own home!</p>\r\n\r\n<h3><strong>How to Find the Perfect Home in Today&#39;s Market?</strong></h3>\r\n\r\n<p>There are many advantages to buying a house these days. For starters, the housing market has never been better. In addition, there are plenty of affordable homes on the market with great features and amenities. Homeownership is an investment that will continue to appreciate in value, too.</p>\r\n\r\n<p>In this article, we&#39;ll explore your options for finding the perfect home in today&#39;s market and teach you everything you need to know before making a purchase decision!</p>\r\n\r\n<h3><strong>How much Does it Cost to Buy a Home in India?</strong></h3>\r\n\r\n<p>One of the most difficult decisions a person has to make in their life is deciding to buy a home. You want to make sure that you get the best price and that you also get the best quality for your money. This article will go over some of the factors that can influence how much it costs to buy a home in India.</p>\r\n\r\n<p>Factors:</p>\r\n\r\n<p>- Mortgage: This is one of the biggest factors in how much it costs to buy a home. Depending on what type of mortgage you get, interest rates, and other factors, your monthly mortgage payments could be very different.</p>\r\n\r\n<p>- Price Tag: If you know what you&rsquo;re looking for and what kind of neighborhood or city or location, this could tell you how much it will cost to buy a home in India based on size.</p>\r\n\r\n<p><strong>Things That You Should Consider Before Buying a New Property</strong></p>\r\n\r\n<p>We&#39;ve all been there. You go online to check out a new property and you fall in love with it. But before you pull the trigger, there are a few things that you should consider first.</p>\r\n\r\n<p>Some of these considerations may have never crossed your mind, but they&#39;re important nonetheless. We will take a look at some of these considerations and how to avoid making any costly mistakes when buying a new property.</p>\r\n\r\n<h3><strong>Questions To Ask Yourself Before Buying A House</strong></h3>\r\n\r\n<p>Home is a place where you can find peace and happiness. Buying a house is a very important decision in one&#39;s life. Buyers should be aware of the following ten questions to ask themselves before they decide to buy a house:</p>\r\n\r\n<p>1. What are your priorities?</p>\r\n\r\n<p>2. When do you want to buy the house?</p>\r\n\r\n<p>3. What type of area do you want to live in? e.g., rural or urban areas?</p>\r\n\r\n<p>4. How big of a house do you want to buy?</p>\r\n\r\n<p>5. What kind of lifestyle do I want?</p>\r\n\r\n<p>6. Who will live in the home?</p>\r\n\r\n<p>7. Do I want to move often?</p>\r\n\r\n<p>8. Do you have any restrictions on your budget? If yes, why not set an amount and stick with it throughout the process of buying a house in Visakhapatnam?</p>\r\n\r\n<p>9. How many bathrooms/bedroom/living room will this home provide for me and my family members?</p>\r\n\r\n<p>10. Do I require outdoor spaces, such as a garden or patio, and if so how much room do I need for these outdoor spaces?</p>\r\n\r\n<p>11. Are there any amenities?</p>\r\n\r\n<p>12. Is the location close to your office, your children&rsquo;s school, the mall or the hospital?</p>\r\n\r\n<p><a href=\"https://eswarihomes.com/\"><strong>Buying a house in Visakhapatnam</strong></a> is a big decision and should not be taken without proper consideration and research. It is advisable to go through this article before you make your purchase. There are many things to keep in mind when <a href=\"https://eswarihomes.com/\"><strong>buying a house in Visakhapatnam</strong></a>. Here are some points that you can consider as you plan your journey of <a href=\"https://eswarihomes.com/\"><strong>buying a house in Visakhapatnam</strong></a>:</p>\r\n\r\n<h3><strong>What You Need To Know About Visakhapatnam</strong></h3>\r\n\r\n<p>Visakhapatnam is a beautiful and well connected city in the state of Andhra Pradesh and is situated on the coast of Bay of Bengal. It has a rich history and culture that reflects the lifestyle of the people living here.</p>\r\n\r\n<p>Visakhapatnam is one of the fastest growing cities in India. It has seen an exponential growth in recent years, new companies opening their offices in this part of the country, which has led to an increase in demand for <a href=\"https://eswarihomes.com/\"><strong>buying a house in Visakhapatnam</strong></a>. The city also offers excellent employment opportunities to people from different parts of the country. The city is developing at an exponential rate.</p>\r\n\r\n<p>Visakhapatnam is also known as Vizag. It is the largest city in Andhra Pradesh and has a population of 4,096,000 people. The city has an impressive coastline of nearly 35 kilometres and you can find some great beaches here. Visakhapatnam is one of the best places to live in India, thanks to its mild climate and good infrastructure. The city provides many opportunities for job seekers. Here are some tips on how to search for houses in Visakhapatnam.</p>\r\n\r\n<p>Visakhapatnam has been voted as the cleanest city in India for three consecutive years.</p>\r\n\r\n<h3><strong>What are the Best Methods for Finding A House?</strong></h3>\r\n\r\n<p>As the number of people who own homes continues to grow, many people are looking for <a href=\"https://eswarihomes.com/\"><strong>properties for sale in Visakhapatnam</strong></a>. Others may want to move from one home to another because of various reasons such as retirement or wanting a bigger home. However, it is not always easy to find a perfect home which has all the features that a person wants in a given location and budget range.</p>\r\n\r\n<h3><strong>How Can You Determine Your Home Loan Qualification?</strong></h3>\r\n\r\n<p>Are you thinking about getting a loan? You should know that there are many factors that can determine your qualification. It all really depends on what kind of loan you want, how much money you make, and what your credit score is.</p>\r\n\r\n<p>The first thing to do is calculate your income and expenditure. When you&rsquo;ve done that, you can use an online EMI calculator to determine the amount of money you will need for a house. The amount of money for which your monthly repayments are affordable will depend on what kind of home loan you&rsquo;re looking for.</p>\r\n\r\n<p>The process of home loan qualification is not a complicated one. All you need to have is a stable income, a secure job and enough cash in the bank. In order for you to know how much your budget should be, you need to establish your monthly expenses. This includes the basic necessities such as food, clothing and shelter.</p>\r\n\r\n<p>Understanding your financial capability is important so that you can calculate how much money you can afford to spend on home loans every month without sacrificing your lifestyle or future goals. <a href=\"https://eswaricapital.com/blogdetails.php?key=importance-of-credit-score-for-home-loans\"><strong>Read our Blog here to know more about credit score</strong></a>.</p>\r\n\r\n<h3><strong>Which Home Insurance Policy is Right for You?</strong></h3>\r\n\r\n<p>Home insurance is a type of property insurance that provides protection to the house and its contents from events such as theft, storm, fire, and other natural disasters. It also provides liability protection for injuries or damages to people or other property.</p>\r\n\r\n<p>There are various types of home insurance policies available in the market. If you&#39;re not sure what your needs are, it&#39;s best to consult with a qualified professional who can help you choose the right one for your specific needs.</p>\r\n\r\n<p>Buying a house is one of the biggest investments you will make in your life. The process may seem like a daunting task at first, but it doesn&#39;t have to be. There are many factors to take into consideration when buying a house, and it can be difficult to know what questions to ask. This guide walked you through the steps of buying your dream home and provided questions you should ask yourself before making an offer on any property. Let us reiterate some of them here again.</p>\r\n\r\n<p>1. Is the house in a good location?</p>\r\n\r\n<p>2. Is the house spacious enough for your needs?</p>\r\n\r\n<p>3. Does the house have enough storage space?</p>\r\n\r\n<p>4. Who is responsible for maintenance of the property?</p>\r\n\r\n<p>5. What is the proximity of the house to schools, colleges, hospitals, markets etc.?</p>\r\n\r\n<p>It is important to ask the right questions before buying a house in Visakhapatnam as it is a big decision and can have long-term consequences.</p>\r\n\r\n<p>Ask about the neighborhood, crime rate, schools, local attractions, and the type of work commute you will be faced with. These questions will help you find the best <a href=\"https://eswarihomes.com/\"><strong>properties for sale in Visakhapatnam</strong></a> and settle down for good.</p>\r\n', '09-September-2021', 'buying-a-home-is-easy-if-you-know-what-questions-to-ask', ''),
(23, 'Advantages of Living in a Gated Community', '2021-09-15 08:13:45', '2021-09-15 10:13:45', 1, '', 'Vizag', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, '', '<p>The number of gated communities in India has increased by more than ten percent in the last five years. If you&#39;re considering moving into a gated community, you may be asking yourself what makes gated communities unique? This blog will explore the essential amenities of a gated community and also focuses on the <a href=\"https://eswarihomes.com/\"><strong>benefits of gated community</strong></a> living.</p>\r\n\r\n<p>Like everything else in this world, a gated community is a product of its time and place. They have a history of being built in certain locations and have had to adapt to changing social and economic demographics. Gated communities are unique in how they are created, maintained, and kept secure. You should always ask yourself if it&#39;s right for you.</p>\r\n\r\n<p>If you&#39;re moving to a new area, what are some of the best ways to find the best place to live for you? While there are a lot of factors to consider, one of the best ways to get started is talking to folks who have already done the moving process.</p>\r\n\r\n<p>Gated communities aren&#39;t just popular in India, they&#39;re popular all over the world. Gated communities are growing in popularity for a number of reasons. If you are looking for your next place to live, consider finding your next home in a gated community.</p>\r\n\r\n<p>A gated community is a community with a controlled or restricted entrance. Gated communities normally have a wall or fence around the perimeter, with a security guard or some other measure in place to control entry. Gated communities are quite popular in some countries, with some gated communities numbering in the several thousands. But what are the <a href=\"https://eswarihomes.com/\"><strong>benefits of living in a gated community</strong></a>? And what exactly are the things you should consider when moving into a gated community? In this article, we will explore the <a href=\"https://eswarihomes.com/\"><strong>benefits of living in a gated community</strong></a> and discuss just what you should consider when moving into a gated community.</p>\r\n\r\n<p><strong>What makes gated communities unique?</strong></p>\r\n\r\n<p>Not everyone can afford to live in an apartment or home within city limits, so many people tend to look for apartments or homes in gated communities. That&rsquo;s because these communities offer several amenities you won&rsquo;t find in most apartment complexes. Gated communities are generally located in more rural areas, with fewer city services. That means residents rely on private amenities to provide services that would normally be provided by the city. These <a href=\"https://eswarihomes.com/\"><strong>benefits of gated communities</strong></a> and amenities can include private security, pools, fitness centers, playgrounds, picnic areas, and more.</p>\r\n\r\n<p>A gated community is a community with restricted access, usually with a physical gate. Gated communities are a type of common interest development. Some people feel safer when they know that they can only enter a community through a controlled gate or guardhouse, and a gate or a guardhouse contributes to the feeling of safety.</p>\r\n\r\n<p><strong>Essential amenities of a gated community</strong></p>\r\n\r\n<p>You can&rsquo;t get away from the fact that gated communities are becoming more and more popular. It&rsquo;s no wonder. A gated community offers a controlled and safe environment where you and your family can enjoy living without the fear of crime and violence. There are, however, some cons that you need to take into account.</p>\r\n\r\n<p>An essential amenity is one that is so important to the lifestyle of your residents that they could not live without it. Amenities, for example, are the features that attract people to live in your community. The location, the quality of the buildings, the quality of the homes, the quality of the schools, the availability of public transportation, the number of shopping centers, etc. are all amenities.</p>\r\n\r\n<p><strong>Benefits of Gated Communities Lifestyle</strong></p>\r\n\r\n<p>When it comes to settling down, gated communities are the new &lsquo;in&rsquo; thing. While there are many residential communities that are not specifically gated or have no security features, these are the ones that are seeing the most attention from the buyers. The rise in gated communities has been accompanied by a rise in the sales of the homes that are located in them. People are now realizing that gated communities are not just a place where the rich reside, but are also a great place to live in.</p>\r\n\r\n<p>One of the biggest <a href=\"https://eswarihomes.com/\"><strong>benefits of living in a gated community</strong></a> is the sense of security. Having a gate at the entrance and security guards at the entrance of the community makes it feel safer and secure. Also, you can get to know your neighbors and be more friendly and helpful to each other. A few of the cons of living in a gated community include that it can create a feeling of claustrophobia and that the gates and the guards can make the community feel snooty.</p>\r\n\r\n<p><strong>Things to consider before moving in</strong></p>\r\n\r\n<p>Are gated communities safe and secure? Are gated communities for everyone? What else should we consider before we decide to call a gated community home?</p>\r\n\r\n<p>In India, more people are showing interest to live in some form of gated communities. They are everywhere from individual villas to high-rise apartments. People live in gated communities for a variety of reasons: the most common of which is for safety and security.</p>\r\n\r\n<p>Perhaps you have been tempted to move into a gated community. There are a lot of great things about living in a gated community. The idea of a gated community is appealing to many people. In a gated community, you get a lot more freedom. You can go out and come back at any time of the day. It is a hassle free lifestyle. But you should consider a few things before moving into a gated community.</p>\r\n\r\n<p>Gated communities, more often than not, come with a plethora of amenities that you can&rsquo;t find anywhere else. But, the more the amenities the more the price tag. What makes gated communities such a hot property? Is it really worth the price? Does gated community living make you happier? And if so, what more are the <a href=\"https://eswarihomes.com/\"><strong>benefits of living in a gated community</strong></a>?</p>\r\n\r\n<p><strong>Why should you consider moving in?</strong></p>\r\n\r\n<p>The number of gated communities around the country is increasing every year. As the need for security increases, gated communities offer an exclusive world where residents can enjoy a host of amenities. Gated communities offer a safe, secure environment with full amenities for residents. But the <a href=\"https://eswarihomes.com/\"><strong>benefits of living in a gated community</strong></a> lies in that It is a place where families can have their own space without being disturbed by anyone.</p>\r\n\r\n<p>Gated communities are often thought of as exclusive, elitist communities that only the wealthy can afford. There is also the perception that gated communities are not safe, but there are many things to consider before making any final decisions. A gated community does not mean that you&rsquo;re living behind closed walls. Gates just control the traffic in and out.</p>\r\n\r\n<p>The reason why gated communities are safe is because they&rsquo;re usually monitored by security guards and they employ 24/7 surveillance systems. Also, the exclusivity of these communities helps to keep out potential burglars and other unwanted people.</p>\r\n\r\n<p>We are excited to have shared these <a href=\"https://eswarihomes.com/\"><strong>benefits of living in gated communities</strong></a> with you, and hope that you find the one that is the best fit for you. Gated communities are growing in popularity, so consider finding your next home in one of these safe and beautiful communities. Now that you&rsquo;re familiar with the <a href=\"https://eswarihomes.com/\"><strong>benefits of living in a gated community</strong></a>, you can start your search for your next home! If you&rsquo;re ready to start looking for your next home, call us. We&rsquo;d love to help you find the perfect home for you and your family.</p>\r\n\r\n<p>We&rsquo;ve talked a lot about the <a href=\"https://eswarihomes.com/\"><strong>benefits of living in a gated community</strong></a>. We hope that you have enjoyed this blog post and have found the information valuable. We hope you&rsquo;ll be able to find a community that interests you, and that you&rsquo;re able to have a safe and beautiful place to call home. If you are interested in finding out more about the gated communities that are available, please contact us.</p>\r\n', '15-September-2021', 'advantages-of-living-in-a-gated-community', ''),
(24, 'Why Invest in Real Estate in Visakhapatnam', '2021-09-20 11:25:45', '2021-09-20 13:25:45', 1, '', 'Vizag', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, '', '<p>Visakhapatnam is a unique city in all respects. It is a mainland city in Andhra Pradesh which has a lot of surprises in store for the people who visit this beautiful city. It offers a spectacular holiday experience to all its visitors. To understand why Visakhapatnam is a good investment destination, you need to take a look at the different factors that would play a role in helping you decide whether Visakhapatnam real estate is a good deal for you.</p>\r\n\r\n<p>Visakhapatnam real estate is a booming market. There are a number of reasons why a person should invest in Visakhapatnam real estate. This blog will list out some of these reasons and also talk about some of the various factors that a person needs to consider while <a href=\"https://eswarihomes.com/\"><strong>investing in real estate in Visakhapatnam</strong>.</a></p>\r\n\r\n<p>Visakhapatnam, the city in the southern part of India, has risen to become a popular real estate option in recent years and with good reason. If you&#39;re in the market to purchase a piece of property here, there are a few things you&#39;ll need to know. Visakhapatnam is one of the <a href=\"https://eswarihomes.com/\"><strong>best real estate investment</strong></a> opportunities. The city has witnessed a tremendous growth in property investments and also property prices over the last few years, which has made Visakhapatnam property investment more lucrative. This blog will discuss why you should consider <a href=\"https://eswarihomes.com/\"><strong>investing in Visakhapatnam real estate</strong></a>, the factors to consider while investing in Visakhapatnam and why Visakhapatnam is one of the best places for real estate investments in the country.</p>\r\n\r\n<p>Visit www.eswarihomes.com to get more information on Visakhapatnam properties.</p>\r\n\r\n<p><strong>Why should you invest in Visakhapatnam?</strong></p>\r\n\r\n<p>Visakhapatnam is the heart of Andhra Pradesh. It is a place where a person can enjoy a life full of fresh air and a lot of greenery. The place is also a heaven for those who enjoy a life full of natural beauty. It is a place that will give you the best life that you have only dreamed of. There are a lot of reasons why someone should invest in the beautiful city. Some of those reasons are listed below.</p>\r\n\r\n<p>●&nbsp;&nbsp;&nbsp;&nbsp; Visakhapatnam is the only city from Andhra Pradesh to have been included in the list of top 10 cities in terms of investment potential.</p>\r\n\r\n<p>●&nbsp;&nbsp;&nbsp;&nbsp; In recent times, <a href=\"https://eswarihomes.com/\"><strong>real estate in Visakhapatnam</strong></a> has been growing, with a number of new projects being launched in the city.</p>\r\n\r\n<p>●&nbsp;&nbsp;&nbsp;&nbsp; The city is witnessing a lot of growth in terms of infrastructure and development.</p>\r\n\r\n<p>●&nbsp;&nbsp;&nbsp;&nbsp; It is one of the cities selected for smart city projects.</p>\r\n\r\n<p>●&nbsp;&nbsp;&nbsp;&nbsp; The city has a number of educational institutes that have attracted a lot of investments from a number of companies.</p>\r\n\r\n<p>●&nbsp;&nbsp;&nbsp;&nbsp; The city has a number of attractions, including beaches, parks, hills, and historic sites.</p>\r\n\r\n<p><strong>Why is Visakhapatnam the best city to invest in?</strong></p>\r\n\r\n<p>Visakhapatnam (Vizag) is The city is located on the east coast of India, in the north central part of the state. It is bounded by Odisha to the north, and Tamil Nadu to the south and Telangana in the west.</p>\r\n\r\n<p>Visakhapatnam is a port city in south-eastern India and is a large city, both in terms of area and population, in the state of Andhra Pradesh. The city is the administrative headquarters of Visakhapatnam District and the Eastern Naval Command of the Indian Navy. This city is a major tourist attraction, with many beaches along the coast of Bay of Bengal, and is also one of the fastest growing cities in the country.</p>\r\n\r\n<p>Visakhapatnam is a major port city on the eastern coast of India. The city is a major tourist destination as it is a base for visiting the popular tourist spots of Araku Valley, Borra Caves, Simhachalam, etc. It is one of the largest cities of India and is home to a large population. It is a commercial hub and a major industrial centre, and is known for its steel and ship-building industries. Like any other real estate market, <a href=\"https://eswarihomes.com/\"><strong>Visakhapatnam also has a booming property market</strong></a> which is witnessing a rise in the number of property buyers every year. If you are planning to <a href=\"https://eswarihomes.com/\"><strong>invest in property in Visakhapatnam</strong></a>, here are a few points you need to consider.</p>\r\n\r\n<p><strong>What are the best places to invest in Visakhapatnam?</strong></p>\r\n\r\n<p>Visakhapatnam city, also known as Vizag, is one of the main cities located in the state of Andhra Pradesh. It is located on the coast, and is also known as the &ldquo;Goa of the East&rdquo;. It is the third most populous city in the southern region of the country, and is also known for its rich history. It is one of the major ports in the country, and is one of the most popular tourist destinations in the country. It is also known for its beaches, and is also known for its various historical monuments. The city is also well known for its various parks, and is also known for its amazing temples. The city has multiple universities, and is also known for its educational system. It is also known for its various festivals, and is also known for its variety in foods. It is also known for its high-quality living, and is also known for its amazing connectivity. There are many reasons why you should <a href=\"https://eswarihomes.com/\"><strong>invest in Visakhapatnam real estate</strong></a>.</p>\r\n\r\n<p>Visakhapatnam is one of the most preferred destinations for real estate investments. Visakhapatnam is known for its natural scenic beauty, the city is also famous for its beaches. Visakhapatnam is one of the fastest growing cities in India. It is the major economic hub of Andhra Pradesh. The city is well-connected with the rest of India with various modes of transportation. The city is also known for its various educational institutions. Visakhapatnam is the <a href=\"https://eswarihomes.com/\"><strong>best place to invest in real estate</strong></a>. <a href=\"https://eswarihomes.com/\"><strong>Visakhapatnam real estate</strong></a> is in demand in recent years. The city has not only attracted domestic investors but also foreign investors. There are many <a href=\"https://eswarihomes.com/\"><strong>residential projects in Visakhapatnam</strong></a>. The city also offers many commercial properties to invest in.</p>\r\n\r\n<p>The major <a href=\"https://eswarihomes.com/\"><strong>areas in Visakhapatnam to invest</strong></a> are Bheemili, Madhurawada, P.M.Palem to the north, Seetammadhara, Akkayyapalem, Murali Nagar at the heart of the city, Gajuwaka, Pendurthi and Anakapalle to the South. The closed radius of just 50km makes it more convenient for transportation and also brings in a fresh ray of hope to expand into the suburbs too. The IT SEZ and the Industrial areas are at the two ends of the city providing a suitable environment for the employees to buy a property closer to their work location.</p>\r\n\r\n<p><strong>What is the Best time to invest in Visakhapatnam?</strong></p>\r\n\r\n<p>When is the <a href=\"https://eswarihomes.com/\"><strong>best time to invest in real estate</strong></a> is a question that is almost impossible to answer, because it would depend on individual factors, your lifestyle, your financial stability and even more than that. However, if you are looking to <a href=\"https://eswarihomes.com/\"><strong>invest in real estate in Visakhapatnam</strong></a>, the best time would be the present! There are many factors that contribute to the worth of property in any location, but one of the most crucial factors is the location. The location of the property is very important because it can affect the worth of the property, and this is the first thing you need to consider when looking to <a href=\"https://eswarihomes.com/\"><strong>invest in real estate in Visakhapatnam</strong></a>.</p>\r\n\r\n<p><strong>How to make investment decisions while investing in real estate in Visakhapatnam?</strong></p>\r\n\r\n<p>Real estate in Visakhapatnam is a booming market. With a huge surge in residential and commercial real estate demand all over the country, the boom is not limited to a particular city or state. <a href=\"https://eswarihomes.com/\"><strong>Real estate market in Visakhapatnam</strong></a> has in fact overheated in recent years. The all-round development in the city is attracting both local and non-local buyers in large numbers. Since the market is in a boom, the city is witnessing numerous residential and commercial projects. The city is also focusing on transforming into a smart city. As the real estate prices are hitting the roof, you should make smart decisions while <a href=\"https://eswarihomes.com/\"><strong>investing in real estate in Visakhapatnam</strong></a>.</p>\r\n\r\n<p>Visakhapatnam is also the headquarters of Visakhapatnam district and Amaravati revenue division. It is also the financial and commercial capital of the state. It is one of the fastest growing cities in India and one of the few cities in the country to be a part of the &quot;World City Network&quot;, with direct connectivity to 13 other cities. Visakhapatnam is home to the oldest shipyard and the only natural harbour on the east coast of India. Visakhapatnam city is also called the Fertile City since it is home to numerous public and private sector organizations and educational institutions.</p>\r\n\r\n<p><strong>Which factors do you need to consider while investing in properties in Visakhapatnam?</strong></p>\r\n\r\n<p>Visakhapatnam is the administrative headquarters of Visakhapatnam district and the Eastern Naval Command of the Indian Navy. It is also home to the Indian Coast Guard Academy, the Naval Science and Technological Laboratory, the Central Institute of Fisheries Nautical and Engineering Training, the Naval Dockyard, the Eastern Naval Command, the Headquarters of the Indian Navy&#39;s Andhra Pradesh-based Southern Naval Command, the Andhra Pradesh Police Academy, and the Andhra Pradesh Fire Services.</p>\r\n\r\n<p>Visakhapatnam is one of the most developed cities in the state of Andhra Pradesh. It is also one of the major educational hubs in the state. The city has seen a lot of infrastructural growth over the past few years. Its proximity to other major cities makes it a favorite among real estate investors. The city is rich in natural resources. Its proximity to beaches makes it a perfect weekend getaway for the citizens of Hyderabad and Chennai. The city is also close to the state of Telangana. The availability of amenities in the city has made it one of the most sought after residential destinations in the state. It is also one of the most preferred business destinations in the country.</p>\r\n\r\n<p><strong>Should you invest in commercial or residential real estate?</strong></p>\r\n\r\n<p>Although both commercial and residential real estate are considered to be investments, the investment type is totally different. When you invest in residential property, it is considered to be a long-term investment, whereas, when you invest in commercial property, it is considered to be a short-term investment. However, if you are looking to invest in commercial real estate, then you have to take into account some major factors before making any decision.</p>\r\n\r\n<p><strong>What are the costs involved in commercial real estate development in Visakhapatnam?</strong></p>\r\n\r\n<p>The cost of <a href=\"https://eswarihomes.com/\"><strong>commercial real estate development in Visakhapatnam</strong></a> depends on a number of factors. The cost of land, labor and infrastructure development and the type of commercial real estate you are looking for would influence the total construction cost of the project.</p>\r\n\r\n<p><a href=\"https://eswarihomes.com/\"><strong>Vizag real estate prices in 2021</strong></a> have been increasing rapidly and it has become a lucrative investment option for many. Many people are planning to invest in commercial real estate in the city, but they want to know the cost involved. Investing in commercial land requires a lot of money and you need to keep certain factors in mind while investing in commercial real estate in the city.</p>\r\n\r\n<p><strong>What kind of returns can you expect on your investment?</strong></p>\r\n\r\n<p><a href=\"https://eswarihomes.com/\"><strong>Real estate in Vizag</strong></a> is at an all-time high. Be it the apartments in the city or even the villas in the outskirts, <a href=\"https://eswarihomes.com/\"><strong>property prices in Vizag</strong></a> are skyrocketing. The city has witnessed a steady growth in its economy in the past few years, which is fueling the real estate market. <a href=\"https://eswarihomes.com/\"><strong>Real estate in Vizag</strong></a> is not just limited to the residential units, but also includes commercial units, land development, plots, apartments, villas, etc. Commercial units are mostly located in the city, while the suburbs are home to villas. There are also many condominiums in Vizag. The city is witnessing a boom in the number of constructions being undertaken all over the city. <a href=\"https://eswarihomes.com/\"><strong>Real estate in Vizag</strong></a> is a booming market, but it is necessary to understand the factors before investing in the city. It is important to understand the market trend before venturing into the real estate sector.</p>\r\n\r\n<p>Well, all of us are aware of the booming markets of NCR and Bangalore. But, the markets of Visakhapatnam are also equally booming. You can make thousands of rupees of profit by <a href=\"https://eswarihomes.com/\"><strong>investing in the real estate of Visakhapatnam</strong></a>. Visakhapatnam is now one of the most sought after real estate markets in India. The city has everything that you could want in a real estate investment. The prices are affordable, the area is growing economically and, with all the new projects launching in the city, the market can stay lucrative for a long time. While investing in real estate, do your due diligence. Choose an area, which is best suited for your investment, whether it is for commercial or residential. If you are planning on buying a property in Visakhapatnam, wait no more and get in touch withus.</p>\r\n', '20-September-2021', 'why-invest-in-real-estate-in-visakhapatnam_', ''),
(25, '5 Things you should know before choosing a real estate agency', '2021-10-08 05:24:23', '2021-10-08 07:24:23', 1, '', 'Vizag', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, '', '<p>If you are in the market to buy a home, make sure to go through all the information available to you to make an informed decision. When buying a home it is easy to be swept away by the thought of owning a home. However, it&#39;s important to <a href=\"https://eswarihomes.com/\"><strong>choose a real estate agent</strong></a> you can trust. Real estate agents are not just agents, they are business people that can show you how to make the most of your investment through their experience.</p>\r\n\r\n<p><a href=\"https://eswarihomes.com/\"><strong>Choosing the right real estate agency</strong></a> is not easy. With the increasing demand for real estate services, it is natural that more and more real estate agencies are coming up. However, all real estate agencies are not alike. Given the increasing competition, it is important to find an agency that can give you the best possible service.</p>\r\n\r\n<p>All real estate agents are not the same. Just like real estate is not about bricks and mortar, it is also never about the sign outside the office, the number of years they have been in business or the number of offices they operate.</p>\r\n\r\n<p><a href=\"https://eswarihomes.com/\"><strong>Choosing a realty agency</strong></a> is a complicated procedure. It is often a decision based on word of mouth, local reputation and personal references. While these are good indicators, there are many things that need to be considered before you start looking for an agency. This blog is meant to help find the right agency for your needs. Here are five things you should know before choosing a real estate agency.</p>\r\n\r\n<p><strong>What to look for when choosing a real estate agent?</strong></p>\r\n\r\n<p>When it comes to real estate, choosing the right agency is a big deal. Not only does it make a difference when it comes to the price of the property, but it also makes a difference when it comes to the assistance they provide when you buy a property. <a href=\"https://eswarihomes.com/\"><strong>Choosing the right real estate agency</strong></a> is the difference between a bad experience and a good one.</p>\r\n\r\n<p>#5 Is the agency licensed?</p>\r\n\r\n<p>#4 Do they have a minimum fee?</p>\r\n\r\n<p>#3 Do they have a cancellation policy?</p>\r\n\r\n<p>#2 Is there a conflict of interest?</p>\r\n\r\n<p>#1 What are their procedures for customer service?</p>\r\n\r\n<p><strong>How to choose the right real estate agency?</strong></p>\r\n\r\n<p>There are a lot of real estate agencies out there and it can be hard to choose the right one. Here are five things to consider before you <a href=\"https://eswarihomes.com/\"><strong>choose a real estate agency</strong></a>:</p>\r\n\r\n<ol>\r\n	<li>Does the agency have a website? A website is a good indicator of how big and professional the agency is. If the agency doesn&#39;t have a website, you should be wary. It might be a scam or a small, local agency that can&#39;t do much for you.</li>\r\n	<li>What is the agency&#39;s reputation? Do some research on the agency&#39;s reputation. Check out what others say about the agency and don&#39;t be afraid to ask for references. Don&#39;t forget to check out the agency&#39;s reviews online.</li>\r\n	<li>Can you trust the agency? It&#39;s important to be able to trust the agency you choose. You will be working with the agency for a long time and you want to be able to trust them.</li>\r\n	<li>How long has the agency been in business? A company that has been around for a long time has a better chance of being trustworthy and reliable.</li>\r\n	<li>What is the agency&#39;s business model? Does the agency have a business model that matches your goals?</li>\r\n</ol>\r\n\r\n<p><strong>What are the different elements that you need to consider in your decision making process?</strong></p>\r\n\r\n<p>When you&rsquo;re looking for a good real estate agency, you want to find one that&rsquo;s going to be able to help you buy your real estate. Being able to buy your real estate comes down to having a lot of things in mind. It&rsquo;s easy to find an agency that&rsquo;s going to be able to find your dream home, but you want to make sure that you&rsquo;re going to be able to get the most out of the agency because the agency isn&rsquo;t going to get the most out of you. Basically, you want to be making sure that you&rsquo;re going to be able to buy your property in a timely manner and that your real estate is bought at a price that you&rsquo;re going to be happy with. You&rsquo;re going to want to be looking at a lot of different things in the real estate agency that you&rsquo;re looking at hiring. In order to make sure that you&rsquo;re going to be able to make the right decision, you need to make sure that you&rsquo;re going to be able to look at different things. Those things are going to be the experience, the reputation, the sales history, the ability to help you in a bad market and the ability to help you in a good market.</p>\r\n\r\n<p><strong>What are the crucial aspects in making the right choice when buying a home?</strong></p>\r\n\r\n<p>As you are moving closer to the big decision of <a href=\"https://eswarihomes.com/\"><strong>choosing a real estate agency</strong></a> to sell your house, there are several things you should be aware of. A few of the things you should know are the following:</p>\r\n\r\n<ul>\r\n	<li>The broker will be the one who&#39;s responsible for the purchase of your house. The agency only acts as a broker for you. You will have to pay the agency a commission.</li>\r\n	<li>Make sure that the agency has a lot of experience in the area you&#39;re buying in.</li>\r\n	<li>Everyone is looking to make money. Make sure that the agency you are looking at is not looking to sell you a house for a higher price than what it&#39;s worth.</li>\r\n	<li>Look for an agency that is willing to help you with the entire process of buying your house.</li>\r\n	<li>Make sure that the agency has a good reputation in the area.</li>\r\n</ul>\r\n\r\n<p>Choosing a real estate agency can be difficult. There are many different agencies to choose from, and each one will have its own advantages and disadvantages. To help you better understand the process, we&rsquo;ve compiled 5 things you should know before <a href=\"https://eswarihomes.com/\"><strong>choosing a real estate agency</strong></a>. We hope that we&rsquo;ve helped you discover the steps you should take before choosing an agency. The article provides a solid background on what a real estate agency can do for you, and what you should look for in a real estate agency.</p>\r\n\r\n<p>Real estate is not just about the house.</p>\r\n\r\n<p>Real estate is a business that&#39;s all about relationships.</p>\r\n\r\n<p>We at www.eswarihomes.com Express our gratitude for visiting our website. We know you have a choice of thousands of real estate agencies to choose from, and we really appreciate you giving us an opportunity to assist you in your real estate needs. There is a lot of information on the internet and we know you want to find the right real estate agency for you and your specific needs. We hope we can provide you with the information you need to make the right decision and help you find the right real estate agency for you.</p>\r\n', '06-October-2021', '5-things-you-should-know-before-choosing-a-real-estate-agency ', ''),
(26, 'Reasons Why Real Estate Agents Fail in 2021', '2021-10-18 04:04:37', '2021-10-18 06:04:37', 1, '', 'Vizag', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, '', '<p>With the advent of technologies that are already in place in the industry, there are a lot of changes that come into question the future of real estate agents in the near future. This post is an attempt to analyze the reasons for the decline of real estate agents in the near future.</p>\r\n\r\n<p>The real estate industry is going through a tough time as the economy improves and more people enter the market as home buyers. In 2021, out of the agents who started their business in 2017, how many will still be in business? The improving economy is a double-edged sword for real estate agents, as it&#39;s both an opportunity and a challenge.</p>\r\n\r\n<p>The real estate market can be a minefield of information. It is constantly changing. If you are one of the many people who want to succeed as a real estate agent then you are going to have to learn how to navigate this new market. Here are the top reasons why you are going to fail in 2021.</p>\r\n\r\n<p>With the right knowledge today, real estate agents can build a successful business running their real estate agency. But there are certain things that real estate agents need to do to ensure that their real estate agency is successful in 2021. Here are some reasons why real estate agents fail in 2021.</p>\r\n\r\n<p><strong>The new world of virtual reality is here - The way you&#39;re doing business is old news</strong></p>\r\n\r\n<p>In the real estate industry, the competition is intense. There are a number of home buying companies that have been successful. Now, a new trend is emerging. New companies are being formed to help first-time buyers find the best homes as soon as possible. In fact, some of these companies are creating their own sales teams to sell new homes as soon as they come on the market. This trend is changing the way that real estate agents conduct business. In fact, agents that fail to adapt to the changing times will probably fail in 2021.</p>\r\n\r\n<p>New developments of new homes are being built quicker than ever before. An increasing number of new homes are being built farther away from new developments</p>\r\n\r\n<p>Real estate agents succeed in 2021 because of their ability to focus on the new technologies. These technologies will continue to rise, and agents will need to learn to use them. It&#39;s very likely that the agents who haven&#39;t gotten up to speed on these new technologies will be left behind. Many agents will look for new careers in the next few years, and the agents who haven&rsquo;t gotten up to speed with the new technology will be left behind.</p>\r\n\r\n<p><strong>The connection between technology and real estate</strong></p>\r\n\r\n<p>The question we&#39;re asking is: How will technology fundamentally change the way we work and live and how will the real estate industry be affected? If you ask this same question to other industries, you&#39;ll find that they&#39;re all using technology to redefine what they do, how they do it and how they serve their customers. In fact, every industry is taking part in the technology boom, from healthcare to agriculture to traffic, and even to fashion. In the next ten years, we&#39;ll see a massive shift in the way real estate agents work and the type of jobs they perform. The digital revolution will change everything &ndash; from the way we network and connect with others to the way we search for a home. The real estate industry will be a part of this change.</p>\r\n\r\n<p><strong>The end of the traditional</strong></p>\r\n\r\n<p>The real estate industry is a tough business, especially in a time when the internet is a growing trend. Although many real estate agents will argue otherwise, the fact is that technology has become a big part of this industry. In fact, real estate agents that fail to adapt to the way online marketing works will most likely move into a lower level in 2021.</p>\r\n\r\n<p><strong>The changing face of real estate</strong></p>\r\n\r\n<p>The real estate industry is changing. It&rsquo;s changing so much, in fact, that it&rsquo;s hard to keep up with the changes. Once an industry that seemed to be stuck in the past, real estate has made great strides over the past few years. The aim of this post is to outline some of the biggest changes that you can expect to see in the next decade. So without further ado, let&rsquo;s dive into the future of real estate!</p>\r\n\r\n<p><strong>The changing face of real estate agents</strong></p>\r\n\r\n<p>It&#39;s no secret that the real estate industry is changing. The Internet has been the catalyst for a major shift in consumer behavior, especially in the way people buy and sell real estate. The days of the traditional real estate agent are quickly becoming a thing of the past. In their place, a new breed of real estate agent has emerged. These new real estate agents are tech savvy, social media savvy, and above all, completely comfortable with change. They are the new face of real estate.</p>\r\n\r\n<p>Real estate is moving fast, the sooner you embrace the change the better. Start making use of the new tools now, so you are ready for the change in 2021. Even if you are doing your work well, you might not be thinking about the things you need to be thinking about.</p>\r\n\r\n<p>Real estate is a huge market, and the opportunities for real estate agents are limitless. Just by reading this blog, you can see how many different ways there are to make money in real estate. But with such big opportunities come big challenges, and with such big challenges come bigger risks. Real estate is a business, and like with any business, you must do your research and work hard to ensure that your business is successful. With that said, we want to help you avoid common problems that real estate agents face in 2021 and beyond.</p>\r\n\r\n<p>The world is changing. There&rsquo;s no denying that. And in the real estate industry, there are lots of changes that are happening right now. One trend that&rsquo;s becoming increasingly popular is the move towards online marketing. While it used to be all about print ads and door knocking, people are now finding their homes online. This means that real estate agents need to adjust too. But how can you adjust to the market? Perhaps you should consider our services at ___. We&rsquo;d be happy to help you.</p>\r\n', '16-October-2021', 'reasons-why-real-estate-agents-fail-in-2021', '');
INSERT INTO `blog` (`id`, `title`, `created`, `modified`, `status`, `address`, `area`, `about_area`, `2017_price`, `2018_price`, `2019_price`, `2020_price`, `street`, `city`, `district`, `pincode`, `state`, `about_property`, `property_status`, `budget_from`, `budget_to`, `price_sqft`, `added_by`, `features`, `nearby`, `modified_by`, `bed_rooms`, `property_type`, `content`, `event_date`, `key_url`, `meta_desc`) VALUES
(27, 'How to Create Wealth by Investing in Real Estate', '2021-10-21 07:32:05', '2021-10-21 09:32:05', 1, '', 'Vizag', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, '', '<p><strong>What is real estate investing?</strong></p>\r\n\r\n<p>Investing in real estate can be a great way to build wealth. However, with so many different property types, it can be hard to know where to start your investment journey. This blog will look at what options are available to you as an investor, including commercial properties. You will also learn more about what you need to look out for to make the right investment decisions.</p>\r\n\r\n<p>Real estate can be a great asset to create wealth over the long term. The real estate market is always changing which is why it is important for you to track the market carefully. This blog will look at some of the different ways you can use to help you with the right kind of investment.</p>\r\n\r\n<p>There are many ways to build wealth, but one of the safest (and smartest) ways to invest is in the real estate market. Real estate investment is not for the faint of heart, but it can lead to financial freedom over time. However, there are many factors to consider when it comes to getting started in real estate investment. But this blog will help you learn how to get started (and what mistakes to avoid).</p>\r\n\r\n<p><strong>Where to invest?</strong></p>\r\n\r\n<p>If you&#39;re looking for a way to build your wealth over the long term, consider real estate investment. This can be a great option for those who have the money to spend, a healthy amount of patience and a willingness to learn a bit about the ins and outs of the real estate market. Here&#39;s a rundown of the pros and cons of real estate investment. The pros of real estate investment include the fact that real estate tends to hold its value over time. So there&#39;s a good chance that if you buy a piece of property, you&#39;ll be able to sell it for a good price in the future. In addition, the interest rates on a home mortgage are much lower than those of other types of loans. This is a good thing because it means you spend less money on interest over the course of the loan.</p>\r\n\r\n<p>You may be familiar with real estate investment trusts (REITs). They&#39;ve been popular for several years and new ones continue to be created and bought by investors and institutions. But there&#39;s another type of real estate investment that&#39;s an alternative to REITs: private REITs. These investments, sometimes called &quot;mini-REITs,&quot; are pass-through entities that allow investors to earn income from investments in income-producing real estate without many of the risks and complexities associated with REIT shares.</p>\r\n\r\n<p><strong>Tips to help you succeed in real estate investment</strong></p>\r\n\r\n<p>Real estate investment is a year round activity. To maximize returns, you need to be well informed on everything about real estate, from the different types of real estate, to the different legal obligations you need to comply with as a landlord. The right real estate investment can be a great asset in building wealth over the long term. Real estate isn&#39;t the easiest way to create wealth, but it is one of the fastest ways. Real estate was one of the biggest wealth creators in the last few centuries.</p>\r\n\r\n<p><strong>What are the pros and cons of real estate investment?</strong></p>\r\n\r\n<p>Real estate investment has been around for ages, from the days of the Roman Empire when wealthy individuals would buy land and rent it out to tenants to generate a profit. In the modern era, it has evolved into a whole new business practice, with many companies and brokerages offering advice and services to help investors decide on the best real estate investment opportunities. As with any investment, real estate is a tool with a range of benefits and a number of risks. On the one hand, investing in real estate can be a very lucrative business, but on the other it can also lead to a financial disaster.</p>\r\n\r\n<p>Real estate investment is one of the most preferred methods for building wealth over the long term. However, it is not an investment that is suitable for everyone. There are many factors that you need to consider before you take the plunge. You&#39;ll also need to understand that no two real estate investments are the same and the amount you earn may vary depending upon the property and location</p>\r\n\r\n<p><strong>How to create wealth by investing in real estate?</strong></p>\r\n\r\n<p>The real estate market is booming, and if you are looking for a solid investment, you should definitely consider investing in real estate. Below are some benefits of using real estate as an investment tool. The main benefit is that it is simple to see your profits. Whenever you are investing in real estate, there are many factors that contribute to the growth of your investment. The best real estate investments are those that are built with long-term goals in mind. This means you should try to find a property that will hold its value for a long time. By picking the right property, you will be able to see your profits grow over time.</p>\r\n\r\n<p>Investing in real estate is one of the best ways to create wealth over the long term. It doesn&rsquo;t matter if you&rsquo;re a seasoned investor or just starting out, the right real estate investment can be a great asset in building wealth over the long term. While there are certainly some risks associated with real estate investing, it is a solid investment choice when you know what you&rsquo;re doing. Below we&rsquo;ve outlined a few of the key ways real estate can be a great investment in building wealth over the long term.</p>\r\n\r\n<p><strong>What makes real estate a sound investment?</strong></p>\r\n\r\n<p>Real estate is an investment that can help you build wealth over the long term. It&rsquo;s one of the only investments that can actually deliver a return when you need it to. It can also serve as a hedge against inflation over the long term. The key to building wealth is to be in real estate for the long haul. As with most things in life, the best route is to buy low and sell high.</p>\r\n\r\n<p>Real estate investment is a good investment when you consider four key factors - capital, cash flow, value appreciation and leverage. Capital refers to the initial amount you invest in the property. Cash flow is the amount of money you receive from renting or leasing out the property. Value appreciation is the dollar amount the property appreciates over time. Leverage is the amount of money you borrow to buy the property.</p>\r\n\r\n<p>In order to determine if real estate is a sound investment, you need to determine if the properties you are looking to purchase are a good long-term investment. The checklist below will help you analyze the investment to determine if it&#39;s a good move. If you can answer &ldquo;yes&rdquo; to at least three of the questions below, the investment is a good one. If you can&rsquo;t answer &ldquo;yes&rdquo;, it&rsquo;s a good idea to do more research.</p>\r\n\r\n<p>When it comes to creating wealth, investments that come with income can be a great way to build your portfolio. This is because the additional income will help you to pay for necessities and wants without having to take money from your investment portfolio. We also recommend choosing investments that generate capital gains and dividends because these can help boost your wealth faster than if you only generate income. We hope you enjoyed our blog about investment strategies to help you build wealth.</p>\r\n\r\n<p>Whether you are looking for a primary residence, an investment property, or the perfect vacation home, it is important to be smart in your real estate investments by doing your research and understanding how real estate works. Doing your research, understanding the market, and making a strong investment can really help you succeed in the long run. If you are interested in making a smart real estate investment, please contact us anytime. Thank you for reading, we are always excited when one of our posts is able to provide useful information on a topic like this!</p>\r\n\r\n<p>As you can see in the example above, investing in real estate can be a great way to build wealth over time. However, you should always look at the pros and cons of every investment before making your decision. If you are interested in learning more about how investing in real estate could impact your long-term wealth, please contact us at. We would be happy to talk with you more about your options.</p>\r\n', '21-October-2021', 'how-to-create-wealth-by-investing-in-real-estate', ''),
(28, 'Only the Best Builder Can Make Your Best Home', '2021-11-06 10:16:42', '2021-11-06 11:16:42', 1, '', 'Vizag', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, '', '<p>Home is the space that&#39;s intensely personal to each one of us. To spend our lives permanently under one roof becomes easy when we have the best home that suits our interests best.</p>\r\n\r\n<p><br />\r\nBuying a home for yourself isn&#39;t the last stage. With that comes the decision to choose the best builder for making your home look the way you want. With the rise in business specifically over the city of Vishakapatnam it is easy to be swept away by any agency that claims to be the builders. However, it&#39;s important to find the right or the best one who could build your home to its best.</p>\r\n\r\n<p><br />\r\nThe look of your house depends on the hard work and construction of the builder, who with his architectural designs and techniques tries to keep up with your plan of a beautiful looking house.</p>\r\n\r\n<p><br />\r\nChoosing the right builders for your home isn&#39;t easy with innumerable agencies around you claiming to do the same better. Though the goal is same, yet every agency has its differences. Thus, the blog explains how to choose the right builders for your home.<br />\r\n<br />\r\nHow to choose the right builders for your home?<br />\r\n<br />\r\n1. Knowing the builder&#39;s experience -- the builder&#39;s efficiency depends on his experiences in the industry. A builder who has been marketing throughout can be relied upon more than the one who&#39;s new to it or has lesser experience. An experience builder has more knowledge of the material to be used, the modern day techniques of construction, and has the best quality of service. Someone with enough experienced will build you a home that&#39;ll stand up to your expectations.<br />\r\n<br />\r\n2. Rate of success of the builder -- the number of homes built by the builder is an important point to put your attention to. It surely tells you the quality of the home he has constructed.<br />\r\n<br />\r\n3. Builder who meets your need -- We all look for something different in our own homes. Different builders offer different styles. Making sure that the builder you choose is providing you the service in a budget that&#39;s affordable for you and also comes closest to your desire or expectation of the construction is important.<br />\r\n<br />\r\n4. A well coordinated team -- it is crucial for any customer to find out if the builder has a well coordination team of professionals who are eligible to give wholesome information on your queries.<br />\r\n<br />\r\n5. Accreditations and licenses -- looking into the license of the builder, his authenticity is a requirement that&#39;s must.<br />\r\n<br />\r\nNot being fooled by the claims of any builders is a wise thing to do. More emphasis should be laid on to how the home meets your need and how it serves the need of your family. This will help you find a builder that is reliable and reputable at the same time, and who will turn your home to your most important asset.</p>\r\n', '06-November-2021', 'only-the-best-builder-can-make-your-best-home', ''),
(29, 'Things to keep in mind while buying your first Real Estate Property', '2021-11-09 06:32:43', '2021-11-09 07:30:49', 1, '', 'Vizag', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, '', '<p>Home is a place we all want to or dream to own in our life. Real estate is the land along with any permanent improvements attached to the land, whether natural or man made. The purchase of a house or a real estate property requires a large part of your investment. Investing on a home is something we start dreaming of since a very young age. It is a dream which all of us badly want to be true. Buying a house for yourself require years of saving, planning and researching.</p>\r\n\r\n<p>Therefore, it is important to invest on a property keeping certain things or factors in mind.</p>\r\n\r\n<p><strong>1. THE BUILDER</strong></p>\r\n\r\n<p>The builder or the real estate developer is the most important part of buying a real estate property. He is the one upon whom your residential destination depends. Therefore a lot of research work need to be done before finalising your builder because the success of your purchase of a property depends more on the positive services provided by your builder. Only the builder who has given positive performances in this field in his career can be trusted upon, for finding you the same.</p>\r\n\r\n<p><strong>2. RERA REGISTRATION</strong></p>\r\n\r\n<p>Before finalising the house deal one must check whether the real estate property developer is RERA, i.e., Real Estate Regulatory Authority registered.</p>\r\n\r\n<p><strong>3. DIFFERENT ROOMS AND OTHER REQUIREMENTS</strong></p>\r\n\r\n<p>Before finalising any property one must think of the future. The rooms that you require not just in present but in future as well, you must check their availability since purchasing a house or a property is an investment for life.</p>\r\n\r\n<p><strong>4. CONNECTIVITY</strong></p>\r\n\r\n<p>Choosing a locality where transport, schools, medical stores, and grocery stores are nearby is very important since it helps in a smooth running of your everyday life. Making your life hassle free and easier all of it saves you a lot of time.</p>\r\n\r\n<p><strong>5. PROPERTY PRICE</strong></p>\r\n\r\n<p>Fixing a budget while buying a house is very important. It makes it easier to shortlist a house if you&rsquo;re sure about the amount you&rsquo;re willing to spend on it. Comparing the price of the property with the requirements it meets is rational.</p>\r\n\r\n<p><strong>6. LAND RECORD</strong></p>\r\n\r\n<p>The land over which your flat is built is very crucial. You must find out the topography and soil quality of the land on which your house is built. The plot should be registered and clear of all dues.</p>\r\n\r\n<p><strong>7. LEGAL CHECK OF PROPERTY</strong></p>\r\n\r\n<p>Ensuring that the property is legally authorized to be constructed on the plot it stands on is very important.</p>\r\n\r\n<p><strong>8. APARTMENT POSSESSION</strong></p>\r\n\r\n<p>As a buyer, one should have a clear estimate of the timeline for possession. Usually, a developer asks for a six-month grace period, however there should be a valid explanation for that.</p>\r\n', '08-November-2021', 'things-to-keep-in-mind-while-buying-your-first-Real-Estate-Property', ''),
(30, 'How you can do vastu at your home?', '2021-11-16 10:11:10', '2021-11-16 11:11:10', 1, '', 'Vizag', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, '', '<p>In today&#39;s world all of us are working towards building a successful and powerful life. Positive and supportive energy is vital to a blissful and successful life. Scientific studies have proved that positive vibes and peaceful surroundings largely lead to the success of individuals. We naturally curse our stars for the discontent and unhappiness in our lives. But there are other forces working towards an unhappy life that causes mental stress and bad health.&nbsp; These happens when you go against vastu.</p>\r\n\r\n<p>The meaning of vastu is dwelling, which is the home for God and humans. Vastu Shastra is based on various energies that come from the atmosphere like solar</p>\r\n\r\n<p>energy from the sun, cosmic energy, lunar energy, thermal energy, magnetic energy, light energy and wind energy. To enhance peace these energies can be balanced. These energies when balanced bring prosperity and success. If a house is made according to the vastu principles the inhabitants enjoy all the happiness in life, but if it is against principles it&#39;ll be a place for all sorts of problems and restlessness. Vastu considered the interplay of various forces of nature involving the five elements of Earth, water, wind, fire and ether and strives to maintain equilibrium as these elements influence, guide and change the living styles of not only human beings but every living being on earth.</p>\r\n\r\n<p>We all care about our homes and spend time, effort and money, trying to make them more comfortable. Once the house is constructed, it&#39;s not so easy to make the</p>\r\n\r\n<p>structural changes. Here are some of the remedies suggested by Mahha Guru &ndash; Gauravv Mittal that you can do yourself to to remove or lessen the Vastu dosha and bring prosperity in life.</p>\r\n\r\n<ul>\r\n	<li><strong>*</strong>Allow a bright light on the main door.</li>\r\n	<li><strong>*</strong>Avoid keeping a television in the bedroom. Televisions and computers should ideally be placed in the southeast corner of the living room or study room and not in the northeast corner or southwest corner.</li>\r\n	<li><strong>*</strong>Avoid keeping any water feature or plants in the bedroom.</li>\r\n	<li><strong>*</strong>Do not use separate mattresses and bedsheet.</li>\r\n	<li><strong>*</strong>Arrange the furniture to form a square or a circle or an octagon.</li>\r\n	<li><strong>*</strong>Brighten the corners.</li>\r\n	<li><strong>*</strong>Place a picture of a&nbsp;bright sunrise on the southern wall in the living room.</li>\r\n	<li><strong>*</strong>Dining room should not expose to the front door of your house.</li>\r\n	<li><strong>*</strong>Never put a mirror in the kitchen.</li>\r\n	<li><strong>*</strong>Keep the broom and mops out of the sight in the kitchen.</li>\r\n	<li><strong>*</strong>Keep the bathroom and toilet door closed as much as possible.</li>\r\n	<li><strong>*</strong>Windows should open outward normally.</li>\r\n	<li><strong>*</strong>Do not keep prickly cactus, or other such plants in the house.</li>\r\n	<li><strong>*</strong>Place an aquarium in the northeast corner of the living room. An aquarium with nine gold fishes and one black fish, in the northeast corner/portion of the house, is very good.</li>\r\n	<li><strong>*</strong>Place a happy family picture in the living room.</li>\r\n	<li><strong>*</strong>Ensure there are no high trees like Banyan, Pipal, Thornytrees whose reflection falls on your house.</li>\r\n	<li><strong>*</strong>There should not be obstructive houses surrounding your plot.</li>\r\n	<li><strong>*</strong>The house should be airy with enough water resource.</li>\r\n	<li><strong>*</strong>The house should be airy with enough water resource.</li>\r\n	<li><strong>*</strong>The toilet seat should be installed on the south or west wall.</li>\r\n	<li><strong>*</strong>One should never hoard stale food, withered flowers, torn clothes, waste paper, waste materials, empty tins, old jars and useless things. These things prevent Lakshmi from entering the house.</li>\r\n	<li><strong>*</strong>If the house has marble flooring, see that the old leather shoes are not lying here and there. Marble is considered to be a holy stone. If possible avoid marble in the bedroom, bathroom, and toilet. In a place of worship in the house, it is necessary to have an open atmosphere. Use marble in the Puja room. Take care that there is enough light and air.</li>\r\n	<li><strong>*</strong>Since the toilet should not be near worship room; if at all its there, then it should not be used and should be kept clean always.</li>\r\n	<li><strong>*</strong>Keep cleanliness. Use sea salt and Gau Mutr (Cow urine) to wipe.</li>\r\n	<li><strong>*</strong>Light incense sticks daily basis in the evening in the house temple.</li>\r\n	<li><strong>*</strong>When sitting for worship, keep your face towards northeast.</li>\r\n	<li><strong>*</strong>Cash boxes should be kept in the south direction of the room and the door of the almirah should open towards the north.</li>\r\n	<li><strong>*</strong>Telephones can be placed in the southeast or northwest corner.</li>\r\n	<li><strong>*</strong>The northeast area has to be kept clean, the wellbeing of male issues is found to be precarious if not kept clean.</li>\r\n	<li><strong>*</strong>One should sleep with his head pointing towards the south.</li>\r\n	<li><strong>*</strong>Students should be facing east while studying, for academic excellence.</li>\r\n	<li><strong>*</strong>Keep the gas in the southeast corner of the kitchen; Person should face the east while cooking.</li>\r\n	<li><strong>*</strong>Drinking water should be in the northeast of the kitchen.</li>\r\n	<li><strong>*</strong>The statue of Lord Hanuman should not be placed in southeast. It may be a cause of a fire hazard.</li>\r\n	<li><strong>*</strong>The hinges of doors should be noiseless. The hinges may be greased periodically.</li>\r\n	<li><strong>*</strong>Bed should not be put under a beam.</li>\r\n	<li><strong>*</strong>Efforts should be made a leave the rooms open on the northeast side.</li>\r\n	<li><strong>*</strong>Almirahs and beds should be set very close to the southwest wall and at a distance from the northeast wall.</li>\r\n	<li><strong>*</strong>A house should not have paintings which depict depressing scenes, i.e. like an old woman crying, scenes of war or poverty. It should have a picture of say, a sunrise, an ocean, mountains, flowers or laughing children.</li>\r\n</ul>\r\n', '16-November-2021', 'how-you-can-do-vastu-at-your-home', ''),
(31, 'What can Buyers expect in specific Neighbourhoods?', '2021-11-24 10:27:44', '2021-11-24 11:27:44', 1, '', 'Vizag', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, '', '<p><a href=\"https://eswarihomes.com/\"><strong>Investing on a real estate</strong></a> means spending most part of your hard earned savings. For some it is a one-time experience and for those who can afford multiple purchases it&rsquo;s an experience they come across quite a few times in their lifetime. Since these investments require a huge part of your savings one must pay attention to certain factors while purchasing a <a href=\"https://eswarihomes.com/\"><strong>property</strong></a>. Having a home of one&rsquo;s own is a dream to all. Some has already achieved it and others are working day and night to get a home that they can call their own. Since it is a vital part of life and comes under the basic need called &lsquo;shelter&rsquo; none on earth can avoid the want of a home. Thus, the blog will clarify all your doubts about purchasing a property that is convenient to your lifestyle. Let us now look at the important factors while <strong><a href=\"https://eswarihomes.com/\">buying a real estate property</a> </strong>one by one.</p>\r\n\r\n<p>The buyer must be having a choice of his own as to the location he or she wants his or her home to be at. This varies from person to person depending on their choices. The blog will talk about the general factors that one must look for while making <a href=\"https://eswarihomes.com/\"><strong>a real estate purchase</strong></a>. Having a home in an area that is already crowded isn&rsquo;t easy since the value of spaces in those areas are more than the plots in areas that are not inhabited by many. Thus, buying a small piece of property at a place which is in demand might cause the same as buying a large piece of property in a scarcely populated area where the <a href=\"https://eswarihomes.com/\"><strong>demand for plot</strong></a> is not much. Thus, what actually matters are the value of the place in which one wants to buy a property.</p>\r\n\r\n<p>The value of a place is then dependent on several factors. A property that is centrally located is what the clients desire. Thus most of the buyers end up buying <a href=\"https://eswarihomes.com/\"><strong>plots in central areas</strong></a> and this adds to the value of that area. The more demanding a place is, the more is its price. Some buyers may want to live in an area that&rsquo;s more open, or is comparatively less crowded. They can opt for buying properties in areas which are not so much in demand. This will not only give them more spaces but will also add value to their property since the areas not in demand at present wouldn&rsquo;t remain the same in the near future. These areas will surely gain value with time when the demanding areas are overly crowded and buyers need to shift to areas that are just developing. To keep in mind that an area that is not in demand now may not be the same in future is a wise move. The value and demand of a place will change according to the developments taking place and the requirement of the place. Thus one must not only buy home seeing the advantages he gets at present but also must analyse what he is capable of achieving from an area he is investing on in future.</p>\r\n\r\n<p>Other than this buyer must find out if the house is located in close proximity to hospitals, schools, marketplaces and offices. Easy accessibility to these places plays an important role since these things are a part of our daily lives thus having them easy is what all the buyers desire. Though these things are important buyers should see that their house is not located very close to railway stations or the roadways since the noises around these areas aren&rsquo;t pleasing for a lifetime stay. With growing technologies and modern days the stresses we come across are not less. Home is the only place that makes us feel light taking most of our stress away. Therefore, one must look for a property that&rsquo;s available around greeneries and water bodies since these are usually pleasant to calm our nerves down. All these add to the peace of our mind which is very much needed.</p>\r\n\r\n<p>Your neighbourhood shouldn&rsquo;t be troublesome. One must feel safe at a place they live in. Thus it&rsquo;s important to look for property in places that have zero crime rates. Staying away from too much crowd is always beneficial. The kind of crowd you surround yourself with has a lot to do with your daily well-being. Therefore, it&rsquo;s important to buy a property at a specific neighbourhood that doesn&rsquo;t give you any second thought relating to the factors described in the blog. Your home isn&rsquo;t just your present, it also is your future.</p>\r\n', '24-November-2021', 'what-can-buyers-expect-in-specific-neighbourhoods', ''),
(32, 'Things To Look Out For When Viewing A Property', '2021-11-30 09:23:51', '2021-11-30 10:23:51', 1, '', 'Vizag', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, '', '<p>Purchasing a property is just the first step to your home buying process. It is truly a beautiful experience for all of us. We all have dreamt at one point in life to own a property of our own. The more easy it sound the more complex the process is.</p>\r\n\r\n<p>1. Research about the market rate for property - Before taking any final decision it is important for you and your family to research a bit about the property rates so that you&#39;re sure and confirmed that the price you&#39;re paying is worth for the property you&#39;re purchasing.</p>\r\n\r\n<p>2. Know about the surrounding areas - A value of a place largely depends on its surrounding areas. Therefore it&#39;s important for one to know a little about the surrounding areas. Since the condition of your area and the environment matters, these things are to be looked out for.</p>\r\n\r\n<p>3. Choose head over heart - When you develop a liking for a property do not buy it straight away. Seeing the other things related to the property, comparing it with any other properties of your choice is important. Because it&#39;s a one time thing or experience no research should be incomplete.</p>\r\n\r\n<p>4. Safety of the location&nbsp; -&nbsp; Ensure the safety of the location your property is in. Since safety is one of the most crucial things, making sure that the property onPM which you are investing is safe is a must. All of us want a safe and health environment for us and our family. For the well being of all safety is the priority.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>For the <a href=\"https://eswarihomes.com/\"><strong>best real estate property in and around Vishakapatnam</strong></a> Eswari Homes is one of the best choice. Eswari Homes has a wide range of options for its clients to choose the <strong><a href=\"https://eswarihomes.com/\">best real estate properties in Vizag</a>. </strong>Find the <a href=\"https://eswarihomes.com/\"><strong>best properties in Vizag with Eswari Homes</strong></a>. There shouldn&#39;t be any second thought while you&#39;re finalizing which property to own therefore choose from the <strong><a href=\"https://eswarihomes.com/\">properties at sale in Vizag</a>. </strong></p>\r\n', '30-November-2021', 'things-to-look-out-for-when-viewing-a-property', ''),
(33, '5 Amenities to Look For While Investing In a Real Estate', '2021-12-07 10:49:37', '2021-12-07 11:49:37', 1, '', 'Vizag', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, '', '<p>While <a href=\"https://eswarihomes.com/\"><strong>investing in a real estate</strong></a> everybody needs at least a bit of help to get the best value of the money they spend, the reason why <a href=\"https://eswarihomes.com/\"><strong>Eswari Homes</strong></a> is here to help you understand the amenities you must look for when investing in a real estate property. Whenever anyone plans to buy a property for personal use, amenities play an important role in finalizing that decision because these facilities serve as a medium to make to make your purchase the different one from the lot. A home buyer must look for all the amenities that he can afford in his budget range.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>1. A Garden - Whenever you plan to buy a personal property, amenities play an important role in helping you finalize your decision. A garden is something one must look for to walk around in the morning for a fresh start to the day. For a peaceful conduct of lifestyle it is convenient to have a garden in your township. These amenities are desirable but not a basic necessity though.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>2. Parking Area - To have a parking lot alloted to you comes under basic necessity if you own a car. Make sure that the real estate developers not charge an extra expense for it. <strong><a href=\"https://eswarihomes.com/\">Real estate developers in Vizag</a> </strong>provide these facilities free when you buy from their real estate properties. Before finalizing the apartment one should look for the number of parking that the builder is providing. The number of parking spaces should be equal to the number of bedrooms in your flat as it gets included in the total amount you pay for a property. <strong><a href=\"https://eswarihomes.com/\">Flats for sale in Vizag</a> </strong>are mostly preferred by the customers as most of the projects are in the developing stage and you will get an ample amount of space for your vehicles.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>3. Swimming Pool - The swimming pool is one of those amenities that attracts a major number of buyers but is used much less by the residents. But if your real estate developer provides a swimming pool with your property, go for it since it adds to your lifestyle.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>4. Gymnasium - Fitness is a routine to many of us and it is one of the most important things in life for everybody even though most of us do not take it sincerely. Fitness is the most accurate way to cure different health issues.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>5. Safety and Security - The safety and security of you and your family members is the topmost priority of any home buyer. Real Estates providing extra security like guards at every entrance along with high-security CCTV cameras, landline service to connect instantly to the security staff, and many more is a must. Your investment is worth if you&#39;re <strong><a href=\"https://eswarihomes.com/\">investing in Vizag</a>.</strong></p>\r\n', '07-December-2021', '5-amenities-to-look-for-while-investing-in-a-real-estate', ''),
(34, 'Why Real estate is still the most reliable investment in India?', '2021-12-14 09:39:16', '2021-12-14 10:39:16', 1, '', 'Vizag', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, '', '<p>Even in America real estate has been one of the top investment option. Infact real investment is now being increasingly preferred over other popular investment options. All of us want to invest on something that&#39;s more valuable, something that we can rely on. And real estate investment is one such thing. It is way ahead of investments on gold, stocks, mutual funds, saving accounts etc. Real estate is generally a great investment option. It can generate ongoing&nbsp;passive income&nbsp;and can be a good long-term investment if the value increases over time. You may even use it as a part of your overall strategy to&nbsp;begin building wealth.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><em>Below are 5 reasons why real estate is not only your safest, but also best&nbsp; and long term investment option.</em></p>\r\n\r\n<p>An important benefit for real estate investors is that they can earn passive rental income from the property investment. The income generated from these kinds of investments vary depending on location, city, demand and also the property type. Few of the cities in demand such as Hyderabad, Mumbai, Delhi, Bangalore and Kolkata provide ample opportunities to earn high rental income.</p>\r\n\r\n<p>Not just in India but all over the world, real estate is considered one of the safest sectors to invest on. In India, it is the second large employee sector after agriculture and its growth is certain. Even though it has its temporary setbacks t&rsquo;s still the safest investment option and will only continue to grow in the long term.</p>\r\n\r\n<p>Stocks are mostly about uncertainty where real estate is not.if you&#39;re trading in stocks and derivatives it surely is a risky game. If you do not have excellent skills on the field it&#39;ll be more than difficult to make money out of equities and leverage trades.</p>\r\n\r\n<p>To make an investment on a real estate you do not require any special skills. Even if you&#39;re a first time investor you can do it. Not only is it safer, it will also most likely get you&nbsp;better&nbsp;returns in the long run aside from providing you with a solid roof over your head for generations to come.</p>\r\n\r\n<p>The chances of becoming a billionaire or a millionaire is more in real estate than in any other industry. More people have become millionaires and billionaires from real estate than possibly any other industry. Moreover, populations are growing &ndash; but the supply of land is limited. So the demand will continue to grow &ndash; and returns from real estate will continue to yield great returns in the long term.</p>\r\n', '14-December-2021', 'why-real-estate-is-still-the-most-reliable-investment-in-india', ''),
(35, 'Am I Ready to Purchase/Build a Home - The Essential Checklist', '2021-12-21 12:10:58', '2021-12-21 13:10:58', 1, '', 'Vizag', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, '', '<p>How do you prepare for an exam? Yes, homebuying is similar or even tougher. If you&#39;re spending your entire income of a lifetime on a purchase then it&#39;s not just a moment&#39;s thinking that goes behind it. It&#39;s an entire bucket list that needs to be ticked. Your property is your greatest fortune and spending a huge sum of money on it is a difficult and a crucial part. Thus being extra cautious when it comes to purchasing a property is important. Also keeping in mind it is a one time decision for some.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>1. Location</strong> - To know where your property is located is important since you and your family must be expecting to reside in a place which is not overly crowded, so as to avoid commotion. Also knowing that the area is safe and secure so that the safety of your family members is maintained. Therefore before paying a large sum of money finding out that the location meets your requirement is a must.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>2. Legal Certificate -</strong> Finding out with your agent that the property you&#39;re choosing to purchase is legally certified is important for you to avoid any future risk regarding it. If you&#39;re buying a property in your life time you would want to be more than one hundred percent sure that your property is legally authorized and is not troublesome.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>3. Transportation -</strong> Choosing a locality where transport system is easily avaliable and accessible is important for you and your other family members. If you&#39;re an office goer you would want to reach your workplace on time everyday and if the transportation route isn&#39;t easily accessible it would start bothering you. Similarly it&#39;s important for your children to reach school on time and this is easily possible if the transport system is accessible and available at your location.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>4. Nearby Market -</strong> Market is indispensable to the running of everyday life. Can&#39;t deny how many things one need in a day that they fetch from the market. Therefore you would want to be living at a close proximity to the market, to fetch your required stuffs at time when needed. Therefore availability of market nearby your property is important.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>5. Greenery - </strong>You must already have been tired of living in the midst of chaos that complements the city life. After every hectic day at work you and your family must be looking for an escape to feel the peace around. And for that greenery around your locality is important. A breath of fresh air is very much needed for a healthy day to day living. Thus if you find a property that also gives you these amenities try never to miss it.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>6. Cost - </strong>The whole home buying process depends on the cost. You must figure out and draw a line to your budget. This makes it clear for you to finalize which property you&#39;re worth paying for. Also finding out from different agencies their price ranges is important. Comparing the price each of the agencies offer and then figuring out which one to finalize makes it easy for you to know that the decision you&#39;re making is the right one.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>7. Physical survey and access to the property - </strong>Never believe just in words no matter which agency you&#39;re merging with. Contact the agency and fix a date to physically survey the place and access the property so that you can be sure that your bucket list is ticked correctly. Go out there to match if everything your real estate agency promised is actually available and accessible.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>8. Land Record -</strong> Knowing or finding out information from the neighborhood about your property is important since you&#39;re new to the place and you probably know nothing about it. Thus talking to the neighbors and finding out the land record keeps any future problems away and also assures you that your purchase is 100% worth.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>If all these are marked on your bucket list then you&#39;re good to go for making a lifetime purchase of a property.</p>\r\n', '21-December-2021', 'am-i-ready-to-purchase-build-a-home-the-essential-checklist', ''),
(36, 'Enhanced Affordability of Residential Real Estate records upsurge in Realty sales', '2021-12-28 12:21:04', '2021-12-28 13:21:04', 1, '', 'Vizag', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, '', '<p>Real estate is always a fortune for everybody. It&#39;s a critical driver of economic growth. Real estate, which is also referred to as &quot;real property,&quot; is the land plus any other tangible improvement that might take place upon it or be installed in it. The improvement might be a building that&#39;s been erected there, or a roadway. It can be something that&#39;s been inserted into the ground, such as a septic system. Land with any of these structures is said to be &quot;improved.&quot; It&#39;s &quot;unimproved&quot; when it lacks them. A golden opportunity for consumers all around the world is investing on real estate because the home loan rates are falling and also the stagnant real estate prices. The more home loan rate falls the more it becomes affordable for customers or clients to invest on real estate. What needs to be considered is the fact that home loan rates are just an aspect of affordability criteria. The most important factor promoting housing demand is the appealing offers and deals given out by developers as per the latest consumer sentiment surveys.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>When compared to last year, the first quarter of 2021 witnessed a revival with the recorded positive growth.&nbsp; Hyderabad saw a growth percentage of 123 in the housing market sector. One of the most important factor why there&#39;s an upsurge in the demand for real estate is that the developers are keen on providing offers and deals keeping up with the sentiment of their clients.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>One of the prominent developers is ESWARI HOMES as it has provided housing properties at affordable prices in the city of Hyderabad. It has been successful in offering spacious luxury properties at a reasonable price. The real estate economy has once again reached it&#39;s growth after Covid-19 had hit the world. It is the most perfect time to purchase a property since it&#39;s never been this affordable. Even the banks like HDFC and Kotak Mahindra are charging lesser interest on home loans, thereby giving our customers scopes to have the best deal ever.&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>A data analysis of India&#39;s residential markets shows a significant improvement in the span between July and September 2021. According to some report the number of houses sold has reached the fifth digit between July to September in states such as Hyderabad, Pune, Bangalore, Mumbai and others. The tremendous jump in sales numbers could also be attributed to the 10-year-low home loan interest rates - home loans are currently available at 6.50% annual interest.</p>\r\n', '28-December-2021', 'enhanced-affordability-of-residential-real-estate-records-upsurge-in-realty-sales', ''),
(38, 'Under-Construction vs.Ready-to-move-in Apartments: What should you buy?', '2022-01-04 11:37:20', '2022-01-04 12:37:20', 1, '', 'Vizag', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, '', '<p>Choosing from <a href=\"https://eswarihomes.com/\"><strong>properties in Vishakhapatnam</strong></a> for purchase is never an easy task. The major dilemma for homebuyers is the number of advantages and disadvantages that are related to under construction homes and ready to move in apartments. An under construction apartment anywhere around the world is invariably lower in price when compared to ready to move in apartments. In an under construction apartment clients do not really know what they are investing on since it is under construction whereas in ready to move in apartments they know what they are buying. What mostly happens in real estate market is that when you invest on an under construction apartment, it is subject to change in time of delivery. Sometimes, though not always the reality doesn&#39;t match with the brochure that&#39;s been presented to you earlier, so why go into that risk at all? Often the quality of materials promised is not the quality of materials used, hence your requirements are compromised. When an under construction home progresses towards completion, the cost keeps rising. What you pay during the booking of an under construction house and what you pay during the possession of it is huge, the reason why many people prefers it. For end users this may not be a preferable choice but for those who aims for higher returns this is more than a favorable choice since they book the apartment at a much lesser price and then sell it off just when it&#39;s ready for completion and get maximum returns. But there are quite a number of risks involved in these kind of apartments. To keep you away from these risks ESWARI HOMES has a wide variety of <a href=\"https://eswarihomes.com/\"><strong>apartments for sale in Vizag</strong></a>. There&#39;s no fixed time of delivery as the project may get under a lot of other land related issues. A ready-to-move unit offers the luxury of zero encumbrances and hassle-free living with immediate effect. There have been instances when under-construction projects have also been cancelled altogether with courts directing homebuyers for full refund of investments. Ready-to-move flats are sold at bulk rates inclusive of all charges. A homebuyer often has to shell in extra money for stamp duty in order to register a flat after taking over its possession from the builder.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>You may have question about which property to buy, should we buy under construction property or should it be a ready to move property. Ready to move in properties are properties available for direct occupancy. There are more than one benefit of purchasing a ready to move in property. There&#39;s no risk involved in your purchase of a ready to move in property, since you buy exactly what you see. You can regularly visit and check your apartment before you make your final payment keeping in mind everything that the property provides you. Experiencing the quality of the final product is important but is easy when you go for purchasing a ready to move in property. And to find your perfect property we have scaled down some of the best <a href=\"https://eswarihomes.com/\"><strong>flats for sale in Vishakhapatnam</strong></a>. So while purchasing a property choose a home that appeals to you more. Your convenience is the priority, so we brought you <strong><a href=\"https://eswarihomes.com/\">luxury apartments in Vishakhapatnam</a>.</strong></p>\r\n', '04-January-2022', 'under-construction-vs-ready-to-move-in-apartments-what-should-you-buy', '');
INSERT INTO `blog` (`id`, `title`, `created`, `modified`, `status`, `address`, `area`, `about_area`, `2017_price`, `2018_price`, `2019_price`, `2020_price`, `street`, `city`, `district`, `pincode`, `state`, `about_property`, `property_status`, `budget_from`, `budget_to`, `price_sqft`, `added_by`, `features`, `nearby`, `modified_by`, `bed_rooms`, `property_type`, `content`, `event_date`, `key_url`, `meta_desc`) VALUES
(39, 'What are common areas in apartments and buildings?', '2022-01-11 12:27:59', '2022-01-11 13:27:59', 1, '', 'Vizag', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, '', '<p>Common Areas is a term used by many quite often. It must have been easy for you to understand that it&rsquo;s a word related to apartments and complexes. By the term itself it becomes clear that these are areas that are used by more than one family occupying a flat in a building. The owners of the building own these areas equally. These are areas paid equally by all the residents of an apartment complex. All the owners of the apartment are co-owners of the common areas. These areas belong to all the owners equally. When you purchase a ready-to-move-in house you pay for the total area including the common area. According to the Real Estate Act, 2016, common areas include:</p>\r\n\r\n<p>1.&nbsp; Staircases, elevators, elevator lobbies, fire escapes, and common entrances and exits of buildings.</p>\r\n\r\n<p>2. Common terraces and basements, parks, play areas, parking spots and common storage spaces.</p>\r\n\r\n<p>3.&nbsp; The areas allocated to the people employed for the management of the property</p>\r\n\r\n<p>4. All facilities mentioned in the project agreement.</p>\r\n\r\n<p>Common areas and facilities cannot be divided and no owner or resident can ask for a division or partition. Any covenant such as this will be invalid. Moreover, co-owners cannot hinder or encroach the rights of others, in terms of common areas. The association of apartment owners has the right to access the apartment, during reasonable hours, for maintenance, repair and other related works. Any such work should be in accordance with the provisions of the Apartment Act of the respective state and the bye-laws.</p>\r\n\r\n<p>Common areas are a cause of lots of disputes among <a href=\"https://eswarihomes.com/\"><strong>apartments in Vizag</strong></a> since these are owned by more than one people. The opinions of the apartments owners&#39; clashes concerning the use of common areas. No matter the size of land allocated to them by the <strong><a href=\"https://eswarihomes.com/\">best builders in Vizag</a> </strong>they all have equal rights towards the common space. Every owner owns as much area of the common land as the other and hence are entitled to use the property as much as they want. What&#39;s forbidden by the <a href=\"https://eswarihomes.com/\"><strong>real estate developers in Vizag</strong></a> is that, no owner can initiate an action that may cause complications for the other owner. Neither can any permanent structure be built in common spaces. You can enjoy your right as a co owner as long as you are within the lines of commonality. These are areas collectively taken care of by every resident.</p>\r\n\r\n<p>To identify the common area that&#39;s included in your personal area go through the sale deed and the registration documents which must have the clear information about your piece of land and also about the common facilities avaliable. To maintain such areas that are occupied by all, an association must be formed, so that it becomes a collective responsibility for each of the owners to take initiative towards maintaining it. There cannot be any portion or action that may impact the others. According to the&nbsp;Real Estate (Regulation and Development) Act, 2016&nbsp; every owner should be responsible for making payments towards the maintenance of the property and the premises. There are a wide variety of <a href=\"https://eswarihomes.com/\"><strong>apartments for sale in Visakhapatnam</strong></a> where common areas can be used for different purposes but they cannot be converted by any owner just for his personal interest. Common areas can include hallways, sidewalks, parking lots, community swimming pools, and laundry facilities, though the list doesn&rsquo;t end there. If people in a residential building or development are free to use a space, it is likely a common area.</p>\r\n', '11-January-2022', 'what-are-common-areas-in-apartments-and-buildings', ''),
(40, 'Dreaming of buying an apartment in Vizag? Now is your chance', '2022-01-18 10:41:50', '2022-01-18 11:40:07', 1, '', 'Vizag', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, '', '<p>If you&rsquo;re dreaming of buying an apartment in Vizag, now is your chance to get your hands on a bargain as <strong><a href=\"https://eswarihomes.com/\">flats for sale in Vishakhapatnam</a> </strong>are now what everybody is grooving for. Your dream of an apartment is mostly the reflection of your positive outlook and prosperous future. Buying an apartment in India is a tempting option for many. There are innumerable options they can choose from. The <a href=\"https://eswarihomes.com/\"><strong>luxury apartments for sale in Vizag</strong></a> are worth your temptation. &nbsp;All the buyers try their level best to carve out their own personal benefits out of these options. The first time you decide to invest in a real estate sector, you would definitely choose to spend on an apartment rather than a villa. This is mainly due to the fact that <a href=\"https://eswarihomes.com/\"><strong>2bhk apartments in Vishakhapatnam for sale in Vizag</strong></a> are much cheaper than villas. But buying an apartment comes with its own drawbacks. With the surge in the real estate sector many builders has come to lure its prospective buyers by making false promises and as a result many buyers have fallen into this trap.</p>\r\n\r\n<p>An apartment is not just about a place you live in. Home is an emotion therefore an apartment of your own is where your emotions lie. From your laughter to your pain, from your lows to your highs, the four walls of your apartment sees it all and happens to be with you throughout. It is a place that holds most of our memories and also the place that&rsquo;s been with us throughout our growth. Be it your sorrow, or your joy, home is the space where your footsteps lead to. Thus choosing a home that your desire to own isn&rsquo;t an easy task. Who wouldn&rsquo;t want a comfortable destination that they can call their home.</p>\r\n\r\n<p>Now is the time to open your doors to the magnificent lifestyle with Eswari Homes as it has got you covered with its available <a href=\"https://eswarihomes.com/\"><strong>apartments</strong> <strong>for sale in Vizag</strong></a>. A forum where you find all your solution to home buying complications that eases your decision making and helps you trust and rely upon us for your first purchase of the most fascinating apartment of your lifetime. Eswari Homes is all about bringing a revolution to your lifestyle with its modern architectural apartments. The harmony of your life is balanced with the luxurious spaces that are made available to you when you purchase a property with us. Our exquisite apartments with its spacious 2bhk and 3bhk flats are worth your chance and choice.</p>\r\n\r\n<p>You must have worked hard to finally be thinking of buying an apartment today and therefore there are some mistakes that you must avoid committing. Sometimes you may get the location right which gives you an easy access to your areas of interest but that may not be everything. To ensure a happy and peaceful living, you must carry out a research on the real estate developer&rsquo;s reputation. The market dynamics in real estate keeps fluctuating, therefore, before investing your income you must know if the time is right or not. Overlooking paper works are a major mistake that one must avoid since everything you pay for is worth only when the papers are correct. Therefore, scrutinizing the documents to check if they are legitimate and up to date is mandatory. Although all we want is for you to find your most desirable apartment at the most favourable time yet we believe in maintaining a transparency about possible drawbacks so that our clients are never lured or trapped into some blunder.</p>\r\n', '18-January-2022', 'dreaming-of-buying-an-apartment-in-vizag-now-is-your-chance', ''),
(41, 'Advantages and Disadvantages of Independent House and Apartments', '2022-01-25 09:13:25', '2022-01-25 10:13:25', 1, '', 'Vizag', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, '', '<p>Deciding the type of house you want to buy from the <strong><a href=\"https://eswarihomes.com/\">houses for sale in Vishakhapatnam</a> </strong>is definitely a daunting task. You must be having a family that&#39;s already talking about you buying a house. With that you&#39;ll get all kinds of talk advising you to buy the most advantageous types of house. When you&#39;re living in a <strong><a href=\"https://eswarihomes.com/\">luxury apartment in Vishakapatnam</a> </strong>you get a chance to live within a community which gives you the sense of togetherness in a certain locality. But living in an independent house gives you complete privacy and also offers freedom from mandatory maintenance charges that one has to pay when living in an apartment.</p>\r\n\r\n<p>The advantages that you receive when you choose from the <a href=\"https://eswarihomes.com/\"><strong>independent houses for sale in Vishakapatnam </strong></a></p>\r\n\r\n<p>1. You enjoy the freedom of complete privacy for you and your family.</p>\r\n\r\n<p>2. Most of the spaces become yours which you can utilize for other purposes such as gardening, gym, swimming, etc.</p>\r\n\r\n<p>3. Renovating your home and reconstructing it becomes your own personal choice for which you need no one else&#39;s permission.</p>\r\n\r\n<p>4. It&#39;s for you to choose if you wanna construct the house anymore and rent out some part of it.</p>\r\n\r\n<p>5. You can carry on all the activities at your own convenience.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>The disadvantages of having an independent house</p>\r\n\r\n<p>1. With individual houses you and your children become more lonely since you have no connection with anyone else in the locality.</p>\r\n\r\n<p>2. You have to put the effort of finding play zones for your children since it&#39;s about your own personal interest and not of an entire community living in an apartment.</p>\r\n\r\n<p>3. When you&#39;re in need of some maintenance or reconstruction, it&#39;ll be your responsibility to go find someone who&#39;ll provide you the service you require, no body else will do it for you.</p>\r\n\r\n<p>4. It won&#39;t always be easy for your to leave the elders of your family alone at home when you know there&#39;s nobody around.</p>\r\n\r\n<p>Advantages of buying from <a href=\"https://eswarihomes.com/\"><strong>apartments for sale in Vizag</strong></a></p>\r\n\r\n<p>1. You get to be around a lot of people who occupy Flats in the apartment. Therefore you make life long friendships that doesn&#39;t give you the feeling of loneliness.</p>\r\n\r\n<p>2. An apartment comes with its own play area that are commonly used by all the kids so they do not have to go else where.</p>\r\n\r\n<p>3. Going out for a vacation becomes easy since you can lock your house and leave for vacation without worrying much since there are people around always that gives you a secure feeling.</p>\r\n\r\n<p>4. A lot of areas are assigned to you that belong to all the owners equally. These areas can be hall rooms, gyms, play areas etc.</p>\r\n\r\n<p>5. If you come across any problem toh can approach it together in a community that will work better in bringing an effective result.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>Disadvantages of buying an apartment</p>\r\n\r\n<p>1. The land assigned to you is comparatively less when compared to <a href=\"https://eswarihomes.com/\"><strong>independent house for sale in Vizag</strong> </a>since in an apartment the shares are divided among quite a number of family.</p>\r\n\r\n<p>2. In an apartment your actions can be interrupted by your neighbors.</p>\r\n\r\n<p>3. According to your need when you carry on the construction of your home in an apartment and by chance if it causes your neighbors a problem they are free to complain and it&#39;s your duty to get it solved.</p>\r\n\r\n<p>It&#39;s important for you to weigh the pros and cons of both the types to finally decide which one is more suitable for you. What modern nuclear families look upto are apartments so that they get to live within a community and not just alone. Keeping with the need there are more apartments being built rather than individual houses. The builders and developers are providing all sorts of amenities to attract the buyers. We cannot really call one better and the other slightly worse because with regard to your employment, our you&#39;re family choice one can decide according to their own taste and convenience. Since financial background matters a lot, it really has a lot to do with your final decision of whether to go for an independent house or an apartment.</p>\r\n', '25-January-2022', 'advantages-and-disadvantages-of-independent-house-and-apartments', ''),
(44, 'WHAT ARE THE BENEFITS OF BUYING PROPERTY IN ITS LAUNCHING PHASE?', '2022-02-15 10:55:51', '2022-02-15 11:55:51', 1, '', 'Vizag', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, '', '<p>Those who are familiar with the real estate market are aware of terms like pre-launch, new-launch, etc. All of these are terms used specially for the sale and purchase of real estate. What attracts the buyers mostly are properties that are in the new launch phase. If you are planning to buy a <strong><a href=\"https://eswarihomes.com/\">flat for sale in Vizag</a> </strong>or a particular place, it is better you go for newly launched projects since they will be economical as compared to ready to move in homes.</p>\r\n\r\n<p>When a property is in a launch phase, most of the developers give attractive price offers to attract the buyers. Real estate is that one competitive market where all the sellers put out their best offers to attract the buyers and those buyers that makes a deal earlier than the rest gets most of the advantages. This is for sure an opportunity for the aspiring buyers to book a new home at a lowest price. Newly launched projects aren&#39;t just meant for</p>\r\n\r\n<p>stay, but it is also a good investment. Therefore, you can either invest on a newly launched property for investment or for stay, both of which are a perfect choice. If you carry out a research you&#39;ll find out that ready-to-move-in houses, and semi constructed projects are priced higher than newly launched ones. So the choice is yours whether you prefer a ready to move in home or a newly launched project.</p>\r\n\r\n<p>One of the advantages of buying a property in its launching phase is that you can block the price before the rate of it goes up. Properties usually go through a price hike following the launching phase in the real estate market. Considering this buying a property in its launching phase is more favorable to the clients. Price hikes are generally the result of investing demand of a property, developments in that area, rise in labour cost, rising cost of raw materials, etc. The amount of money that you save when you purchase a property in its launching phase can be used later for future expenses. One smart thing you can do is you can sell off the property later in its ready to occupy stage and earn more than what you paid and increase your share of profit.</p>\r\n\r\n<p>When you go for a<strong> <a href=\"https://eswarihomes.com/\">property for sale in </a></strong><a href=\"https://eswarihomes.com/\"><strong>Vishakapatnam</strong></a> that is in a ready to be occupied stage, chances are less that you&#39;ll like everything about it. Though you&#39;ll get to own an apartment, yet you may not like the view it offers. Something about it maybe in a way that you won&#39;t really like. But when you purchase a property in its launching phase you can make a choice from the lot and decide exactly which unit is going to fit your needs perfectly. You are free to choose and change the layouts. And all of these will not cross your budget, that&#39;s the good thing about it.</p>\r\n\r\n<p>In case you&#39;re looking forward to expanding your investment, the safest is to go for a property that is in launching phase. It doesn&#39;t require you to be an experienced investor or a first time home buyer. It works well and same for all. It helps you save a lot of money and it&#39;s also worthy of your investment. But while doing all of these you must keep your eyes and ears open and choose a reliable and trusted builder who has experience in the field of real estate market to avoid getting into unexpected complications toh must check for RERA registration number and all the other legal documents mandated by the government before buying a <strong><a href=\"https://eswarihomes.com/\">property for sale in Vizag</a>, </strong>India.</p>\r\n\r\n<p>This blog surely helped you know the benefits and disadvantages of buying properties at different stages. Now that you know the benefits and shortcomings of properties at different stages you can make a choice and start exploring the latest range of <strong><a href=\"https://eswarihomes.com/\">luxury properties in Vizag</a> </strong>or projects presented or offered by ESWARI HOMES in Hyderabad.</p>\r\n', '15-February-2022', 'what-are-the-benefits-of-buying-property-in-its-launching-phase', ''),
(45, 'Mortgage Meaning And Overview', '2022-02-22 11:06:53', '2022-02-22 12:06:53', 1, '', 'Vizag', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, '', '<p>Owning a home is something that almost every Indian dreams. No matter how much we dream, what we know is that it doesn&#39;t come true easily. If you are a first-time home buyer in particular, you need to be equipped with the know-hows of how a home loan works in the current scenario. When one doesn&#39;t have enough financial backing but is in need of a home he can call his own, there comes to rescue some of the well knowing lending companies, that offer you a variety of loans that may suit your circumstances and fulfill your dream of your own home.</p>\r\n\r\n<p>If you&#39;re wondering what mortgage is, let me tell you that a mortgage is an agreement signed by you and your lender which gives the lender the right to take away your property if by any chance you fail to repay the loan you&#39;ve borrowed together with the interest. Mortgage loans are specially available to those who wish to buy a home or to borrow money against the value of a property that he or she already owns.</p>\r\n\r\n<p>While applying for a loan or getting it sanctioned one must be aware of few important factors. The size of the loan matters as you have to pay back the entire amount you borrowed together with the interest rates charged upon it. You must find out in the beginning itself the mortgage loan interest rates.</p>\r\n\r\n<p>You may be eligible to borrow quite an amount. It is the lender&#39;s duty to tell you the amount you can borrow. But how much you can borrow is not how much you should borrow. You must borrow depending upon your affordability so that you don&#39;t run too thin on other stuffs. Lenders do not really look after your financial circumstances. Therefore, to know how much you can afford to repay you&#39;ll need to keep in account your family&#39;s income, expenses and savings. Knowing these helps you to see what fits comfortable within your budget.</p>\r\n\r\n<p>Mortgages are usually of two types; fixed rate mortgages and adjustable rate mortgages. These are the 2 types of mortgages. Now let me clear out the differences for you.</p>\r\n\r\n<p>In a fixed rate mortgage the lenders provide the borrowers with an established interest rate over a set term of 10, 15, 20 or 30 years. The shorter the time span within which a borrower repays the higher the payment. Simultaneously the longer the time span taken to repay a loan the lesser the payment. However, the more time you take to return the money, the more interest rate you&#39;re charged.</p>\r\n\r\n<p>Adjustable rate mortgages are mortgages in which the interest rate that the borrower pays can usually change over the life of the loan. The primary risk with an ARM is that interest rates may increase significantly over the life of the loan, to a point where the mortgage payments become so high that they are difficult for the borrower to meet.</p>\r\n\r\n<p>If you&#39;re planning to apply for any of these&nbsp;<a href=\"https://eswaricapital.com/\"><strong>best home loans</strong></a>&nbsp;you can always contact ESWARI CAPITAL. Once you get your loan approved you can always choose your favorite and safest piece of property brought to you by the <a href=\"https://eswarihomes.com/\"><strong>best real estate company in Vizag</strong></a>,&nbsp;ESWARI HOMES.</p>\r\n', '22-February-2022', 'mortgage-meaning-and-overview', ''),
(46, 'WHAT IS REAL ESTATE APPRAISAL?', '2022-03-01 11:50:51', '2022-03-01 12:50:51', 1, '', 'Vizag', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, '', '<p>You may certainly know what real estate is but what you may not know is the meaning of the term real estate appraisal. To familiarize you with both real estate and the meaning of real estate appraisal we&rsquo;ve brought you this blog. Let&rsquo;s just start exploring what it possible means. Real estate appraisal is a process used usually by banks in order to arrive at the fair market value of a property. It is certain of a seller to invariably value his property with a lot of bias. Similarly, a buyer too can or may value it lower because of his or her own reasons. In situations and circumstances like this it is important to arrive at a price or rate that is fair to everybody. Everybody here includes the seller, the buyer and the bank. To arrive at this juncture, financial institutions and lending companies gather specific information in order to measure the worth of a particular property in order to be able to decide the fair worth of the real estate. This process through which the financial institutions set the fair worth or value of a property is known as Real Estate Appraisal.</p>\r\n\r\n<p>There are but two specific methods used by the real estate appraisers to arrive at the fair value of a specific property.</p>\r\n\r\n<p><strong>1. Cost Approach</strong></p>\r\n\r\n<p>Through this method the evaluator arrives at a property&rsquo;s current value by calculating the cost required in case the building was to be built right from the scratch added with the worth of the land. That&rsquo;s how these evaluators arrive at a property&rsquo;s fair and final value.</p>\r\n\r\n<p><strong>2. Sales Comparison Method</strong></p>\r\n\r\n<p>In this method the price of the property that&rsquo;s in question is compared to the price of the property recently sold in the neighbourhood. This information could only be gathered by examining the sales deed registration at respective offices. This is how the fair rate of a property is decided.</p>\r\n\r\n<p>Technical and legal experts are sent by the banks in order to physically examine the property and evaluate its appraisal report based on factors including land, size, area, etc. The cleanliness or tidiness of the property too has a direct impact on the rate of the particular property.</p>\r\n\r\n<p><strong>How Your Home Loan Is Affected By Property Appraisal?</strong></p>\r\n\r\n<p>It is the bank who decides the value of your property through its process of property appraisal. Depending on your capacity to repay the loan the banks give you maximum of 80% of the entire value as home loan. The rest of the 20% is on you to manage through your own personal sources.</p>\r\n\r\n<p>How <a href=\"https://eswarihomes.com/\"><strong>Property Appraisals</strong></a> Help Home Buyers?</p>\r\n\r\n<p>For all of us, home buying is an extremely emotional and difficult but important life decision. It is so because it is about an amount that takes almost a lifetime to be collected of saved. There are instances in which a buyer might agree to pay a price higher than the fair value only because they liked the property. But this is completely foolish, since you must pay exactly what it&rsquo;s worth. You must negotiate with your real estate agent to bring the price down to the fair worth and if they don&rsquo;t agree all you must do is move away from the deal. Because if you pay a price greater than the fair price then in future when you think of selling off the property you&rsquo;d would certainly get a price lesser than the one you paid.</p>\r\n\r\n<p>There are so many real estate companies out there to save you from all these complexities or troubles. It&rsquo;s your responsibility to find out the right one from the lot. Depending on the <strong><a href=\"https://eswarihomes.com/\">real estate agent</a> </strong>you are dealing with you will get a property that would benefit you. Therefore if you&rsquo;re inhabiting in or around Vizag, one of the top real estate companies you can get in touch with is ESWARI HOMES. We are a team of professionals and experts bringing you only the best at the most affordable price range.</p>\r\n', '01-March-2022', 'what-is-real-estate-appraisal', ''),
(48, 'DIFFERENT TYPES OF REAL ESTATE PROPERTIES YOU SHOULD KNOW', '2022-03-08 08:47:56', '2022-03-08 09:47:56', 1, '', 'Vizag', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, '', '<p>Real estate investments can be of many forms. If it is your first time in real estate it is crucial for you to understand the different types of real estate investments. This will give you a clarity that you require making it possible for you to choosewhich real estate investment is best for you. This blog will help youunderstand the different kinds of real estate.</p>\r\n\r\n<p><strong>1. Residential Real Estate</strong></p>\r\n\r\n<p>Residential properties are what comes to our mind first when we think of real estate. Residential properties are one of the most popular types of real estate to invest in. There are a different variety of houses that are available to you when you&#39;re investing on real estate. Thus it is important for you to know them all in order to better understand real estate. Real estate in residential properties include any property that is used for residential purposes. The types of houses in residential real estate can be - bungalows, single family homes, condominiums, townhouses etc. This is the beginning for most of the real estate clients since entry to deals regarding residential real estate has a comparatively lower cost. Also, loans for residential real estate properties are easier to obtain than commercial real estate.</p>\r\n\r\n<p><strong>2. Commercial Real Estate</strong></p>\r\n\r\n<p>It is the second most common type of real estate type that clients prefer. This is in the second position when comes to the investment that clients make on real estate. Any property used for business purposes is known as commercial real estate or CRE. There are different types of commercial real estate properties one can have and they are - hotels and lodging, schools, malls, office spaces, etc. But at times buying a property that is commercial is more expensive than investing in residential real estate.</p>\r\n\r\n<p><strong>3. Vacant Land</strong></p>\r\n\r\n<p>Vacant lands are vacant lands with no structures formed on it. It can also include farmlands or ranches or it basically is a piece of land above which nothing concrete has been formed and is therefore vacant. These are also known as raw lands. The cost to invest on vacant lands would vary depending upon the location, size, and your authority over it. Buying a vacant land is really an investment as you earn a lot higher when you sell the land off than what you earned when you bought it.</p>\r\n\r\n<p><strong>4. Industrial Real Estate</strong></p>\r\n\r\n<p>Where are the goods that we use are manufactured? Thought about this? These are manufactured in warehouses popularly known as industries. These properties are referred to as industrial properties. These properties are located away from cities in some vacant so that the citizens of an area aren&#39;t affected by the harmful substances that it releases.</p>\r\n\r\n<p>All types of real estate investment have some advantages and disadvantages. So, we cannot say which one is the best. But if you want to succeed as a real estate investor, you&rsquo;ll need to analyse your financial situation and the prospects of growth of the property you are looking to invest in. Moreover, plan how you will be using the property in both the long run and short run.</p>\r\n\r\n<p>You will find a number of <a href=\"https://eswarihomes.com/\"><strong>top real estate companies</strong></a> around you giving you the best real estate investment deals. You must be careful while choosing from them as these are lifetime investments worth a lot of money and sometimes all your savings. ESWARI HOMES is one of the best <a href=\"https://eswarihomes.com/\"><strong>real estate developers in Vizag</strong></a> that you can always try for.</p>\r\n', '08-March-2022', 'different-types-of-real-estate-properties-you-should-know', 'Real estate investments can be of many forms. If it is your first time in real estate it is crucial for you to understand the different types of real estate investments.'),
(49, 'THE ULTIMATE GUIDE TO REAL ESTATE INVESTMENT TRUST (REIT) | ESWARI HOMES', '2022-03-15 10:55:52', '2022-03-15 11:55:52', 1, '', 'Vizag', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, '', '<p>Investment in India can be in various forms. Indians have quite a lot of options to spend their money. If you&#39;re an Indian you can invest on stocks, buy <a href=\"https://eswarihomes.com/\"><strong>real estate properties</strong></a>, golds, mutual funds as well as government securities. The things or ways to invest on are plenty and one of the best is REIT Investments.</p>\r\n\r\n<p>REIT stands particularly for Real Estate Investment Trusts. That one investment option which fascinates people of quite a few generations is Real Estate Investment Trusts. REIT was introduced back in the year 2007 by the Securities and Exchange Board of India. Buying a piece of land or property is always a positive step that brings great results. But you wouldn&#39;t just go around buying a property that you may call your own. You do not just buy an apartment and call it investment. There&#39;s a way to go for it. Realty does offer you the advantages of price appreciation or a regular income in the form of rent but you must know how to invest on it. Here is a guide that would help you understand the basics of REIT investing so that no broker or <strong><a href=\"https://eswarihomes.com/\">realty companies</a> </strong>can cheat you. It is our responsibility to let you know what you should be aware of and keep in mind when it comes to real estate in India.</p>\r\n\r\n<p>1. You must never invest on a product because everybody else around you is doing that. You must avoid doing this specially in the case of real estate. It&#39;s alright for you to invest on a real estate property if you need a new place to move in, also if you can afford a second home or if you can&#39;t put it up for rent. Realty is expensive unlike other investments. It requires huge investment fund. Thus it&#39;s important you to dig deep into it for better introspection.</p>\r\n\r\n<p>2. You must have enough patience to have the space that fits your need perfectly. To find the home or land that perfectly fit your needs is a not a simple task. From different realty companies you&#39;ll get to know about many under construction properties, as well as ready to move in apartments. By looking at all the pros and cons of each type considering the surrounding areas, as well as location together with amenities you have to choose the one that suits your requirement the best.</p>\r\n\r\n<p>3. A thorough background check is important for all the real estate investors. If you like a particular property advertised by any of the construction or real estate companies and you are deciding to buy it you must first pay a visit to the property site and go through all the paperwork. Take a certified accountant or a broker friend with you if possible to check all the documents.</p>\r\n\r\n<p>4. Developers must disclose the carpet area of the properties they sell to their clients according to RERA Act. This was done to ensure that you are only paying for the usable space in a unit when you&#39;re buying a real estate property.&nbsp;</p>\r\n\r\n<p>5. Taking to the neighbors around your real estate property site is important since they are the ones who have been living there for quite some time and have comparatively more knowledge about the place than you. Enquire about the amenities, the kind of crowd in that area, how close are the offices, schools, hospitals and railways from that area. All this will help you strengthen your decision.</p>\r\n\r\n<p>A real estate investment is worth your choice as well as your decision. But keep in mind all the key factors before determining if that&#39;s what you want or if that&#39;s what you&#39;re looking for. Veggie signing on hard papers think of all these factors rationally, and only then go for it. Through real estate trust fund you can channel your funds into owning a real estate or generating income from it.</p>\r\n', '15-March-2022', 'the-ultimate-guide-to-real-estate-investment-trust-reit', 'Investment in India can be in various forms. Indians have quite a lot of options to spend their money. '),
(50, 'NRIs BUYING PROPERTY IN INDIA - IMPORTANT FACTORS TO CONSIDER | ESWARI HOMES', '2022-03-22 11:43:03', '2022-03-22 12:43:03', 1, '', 'Vizag', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, '', '<p>If you are planning to buy properties in India and if you are a non-resident Indian there could have been no better time to do that.&nbsp; Buying a property in India had become much affordable as India&#39;s real estate sector has recently gone through price correction.</p>\r\n\r\n<p>There are multiple rules and regulations involved in this process which makes it a complex affair. Hence if you&#39;re attempting to invest in a property in India, here are some inorganic things you should keep a check on.</p>\r\n\r\n<p><strong>1. Nature of the Property</strong></p>\r\n\r\n<p>If you&#39;re an NRI buying property in India you can buy all sorts of properties but you cannot purchase agricultural land, farm house and plantation property. To acquire these lands such as plantation properties and farm houses you&#39;ll be required to take approval from the RBI as well as the government.</p>\r\n\r\n<p><strong>2. Tax Benefits</strong></p>\r\n\r\n<p>The NRIs are offered tax benefits. If you sell off the property within 3 years of your purchase time, it comes under the short-term capital gain wherein taxes are applicable. If you sell the same property after 3 years, then it will come under the long-term capital gain where the investment in another property is applicable.</p>\r\n\r\n<p><strong>3. Transactions</strong></p>\r\n\r\n<p>If you are a NRI buying a property in India it does not require you any special permission. But you must keep in mind that you cannot pay in foreign currency. You can purchase a property in India using Indian currency. There are no special restrictions on the number of property you can purchase.</p>\r\n\r\n<p><strong>4. Home Loans</strong></p>\r\n\r\n<p>The NRIs investing in Indian real estate are now provided <a href=\"https://eswaricapital.com/\"><strong>home loans</strong></a> by banks and housing finance companies registered with the National Housing Bank on the permission of RBI for purchasing real estate in India.</p>\r\n\r\n<p><strong>5. Power of Attorney</strong></p>\r\n\r\n<p>Since you&#39;re reducing in a property abroad you can give the power of attorney to somebody you&#39;re close to. It can be your friends or relatives who can complete the property purchase process in India. The PoA can be general or specific about the rights your representative can exercise.</p>\r\n\r\n<p>Managing a real estate investment requires considerable effort, especially if you plan to give the house out on rent. Now, with <strong><a href=\"https://eswarihomes.com/\">ESWARI HOMES</a></strong>, you can avail of end-to-end&nbsp;<a href=\"https://eswarihomes.com/\"><strong>Property Management Services</strong></a>&nbsp;through our trusted partner. Sit back and relax, while your dedicated property manager takes care of everything - from finding tenants and ensuring you get the rent on time, to managing and maintaining the property.</p>\r\n\r\n<p>As an NRI, you should make investments in India by keeping these points in mind to make it a hassle-free process for you. Investing in real estate for NRIs has not only been a profitable investment but also works on an emotional ground where you can always be connected to your homeland. The Indian government has made this whole journey simple and problem-free.</p>\r\n', '22-March-2022', 'nris-buying-property-in-india-important-factors-to-consider', 'If you are planning to buy properties in India and if you are a non-resident Indian there could have been no better time to do that.'),
(51, 'RENTING VS BUYING A HOUSE – WHICH IS MORE PROFITABLE?', '2022-03-29 10:37:29', '2022-03-29 12:37:29', 1, '', 'Vizag', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, '', '<p>Buying a house is something we all dream of. But if you&rsquo;re thinking of owning a house then you must calculate all the pros and cons related to it, and also if it is worth it. We, at ESWARI HOMES understand your dream of buying your own house but due to the demand in the housing market the price rates in the metropolitan cities have sky rocketed. This has enabled the homebuyers to opt for renting a home instead of buying one. But for the section of the customers who can afford to buy a house it is always confusing as to what&rsquo;s better, renting or owning, since they put more weightage to owning a house of their own. For them as well as for the other clients we have laid down the advantages as well as the disadvantages of both renting and buying.</p>\r\n\r\n<p><strong>ADVANTAGES OF OWNING A HOME</strong></p>\r\n\r\n<p>Buying a home or a real estate gives you immense security as well as makes you feel proud. When you live on rent you pay the rents every month but you do not own any physical asset. Whereas buying a home gets you a proper physical asset. Also when you&rsquo;re living on rent you are required to reallocate from time to time which wastes a lot of time of yours. Also, your money and energy is wasted which doesn&rsquo;t happen when you own a home. Investments made on real estate are safe investments as you get higher returns in case you choose to sell off the property.</p>\r\n\r\n<p><strong>ADVANTAGES OF RENTING</strong></p>\r\n\r\n<p>When you purchase a property by taking <a href=\"https://eswaricapital.com/\"><strong>housing loan</strong></a>&nbsp; you are required to pay monthly EMIs, which you do not have to pay when you rent a house. Thus the burden in this case is comparatively less. You do not have to handle with the legal issues that one handles when buys a house of his own. When you rent a property you have pretty good chances of getting a flat at the location of your choice, which may not be the case when you buy a property.</p>\r\n\r\n<p>Making a choice of whether it is better to rent or buy is a complex one. Only after careful thinking and planning one can decide between buying v/s renting. If you&rsquo;re really have a bad time trying to find out if you should buy a house or rent one then the first step you must take is calculate the investment returns on the down payment and other related costs related to buying a house. The second step is to calculate the investment returns of the difference between the EMI payments and the rent over the entire duration of ownership.&nbsp;After figuring this all out if you&rsquo;re still looking forward to own a house then let us tell you that you must watch out the housing market conditions. We know owning a house makes more sense yet if the returns are not sufficient then that&rsquo;s not worth doing. Get to know the great <a href=\"https://eswarihomes.com/\"><strong>real estate companies</strong></a> all around the city to finally choose who to buy your real estate from.</p>\r\n', '29-March-2022', 'renting-vs-buying-a-house-which-is-more-profitable', 'Buying a house is something we all dream of. But if you are thinking of owning a house then you must calculate all the pros and cons related to it, and also if it is worth it. '),
(52, '7 WAYS YOU CAN TURN YOUR ORDINARY HOME INTO A SMART HOME | ESWARI HOMES', '2022-04-05 11:08:44', '2022-04-05 13:08:44', 1, '', 'Vizag', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, '', '<p>With so many different companies and brands coming in the market and launching a variety of different smart lighting systems, speakers, sensors it has become easier to convert your home into a smart home. But figuring out the solutions available in market for <strong><a href=\"https://aseinfra.com/\">home improvements</a> </strong>is a confusing task. That is why it is important to understand how to transform your home into a smart home. Budget is not something you should worry about since there are many ways to turn your home into a smart home by not going over the budget. The products required to transform your home are also becoming more and more affordable. This makes it easy to build a smart home. Read this step by step guide which will allow you to convert your home into a smart home.&nbsp;</p>\r\n\r\n<p><strong>1. Smart Lighting</strong></p>\r\n\r\n<p>To change the appearance of your <strong><a href=\"https://eswarihomes.com/\">residential properties</a> </strong>the easiest way is to alter the lighting. When you opt for smart lighting, you can easily control the ambience of the house by using a Wi-Fi connection. You also get a mobile application through which you control the entire lighting system. Controlling it has now got easier and easier. If you want to automate your existing lighting system you can alter the switches and replace them with smart switches and cameras.</p>\r\n\r\n<p><strong>2. Smart Speakers</strong></p>\r\n\r\n<p>Nowadays smart speakers play a vital role in a household since they control the various functions of the house using the voice commands. They work as an assistant to control the activities of your home. You can choose between the Google Home speaker or the Amazon Echo speaker. If you want one single speaker to take command you can go for Amazon Echo speaker or if you want various speakers to control then you can choose Google Home speaker. Google home is controlled using Google assistant. Amazon Echo devices are controlled using Amazon Alexa.&nbsp;</p>\r\n\r\n<p><strong>3. Smart Thermostats</strong></p>\r\n\r\n<p>Those who have climate control systems knows that these systems consume the maximum amount of energy. When the weather is at extreme these they make sure that the ambience insure your residential property is comfortable. You can go a step further and&nbsp;save even more energy&nbsp;with the help of smart thermostats. These ensure that you can easily control the ambiance of your home. These thermostats have a predictive system which means that they can set the temperature of the house conveniently and on their own.</p>\r\n\r\n<p><strong>4. Home Security Cameras</strong></p>\r\n\r\n<p>While you convert your home into a smart home it becomes important for you to make it secure as well. It is easy to secure the smart homes as they basically rely on sensors and devices rather than individuals. It also saves you the monthly costs of paying a security guard or a watchman. The best tool which you have got to handle the security of your home in a smarter way is the smart camera. With the help of CCTV you can easily monitor your home.</p>\r\n\r\n<p><strong>5. Smart Audio Systems</strong></p>\r\n\r\n<p>No matter which room you&#39;re in you&#39;ll be equally entertained. With smart audio systems you&#39;ll be able to stream music in any part of the room you are. Moreover, they can stream music from a variety of different services like Spotify. You can also select the tracks through your smartphone.</p>\r\n\r\n<p><strong>6. Smart Sensors</strong></p>\r\n\r\n<p>Smart sensors are like the backbone of any smart home household. Without sensors it becomes difficult to control the smart home. The smart sensors ensure that they detect motion inside and outside the home. Inside the house, they correct the climate control system to make the ambiance more habitable. Also, they can switch on and off the lights depending on whether a room is vacant or not. Hence, it becomes easier for you to automate the climate control system.</p>\r\n\r\n<p><strong>7. Smart Irrigation System</strong></p>\r\n\r\n<p>With technology evolving you no more need to carry on the tasks of irrigation manually. The moisture in your land and garden can automatically be detected with the smart irrigation systems.</p>\r\n\r\n<p>So when&nbsp; you think of converting your home into a smart home these are the steps you must follow. All the steps mentioned are completely different from each other but using them all will completely transform your home into a smart one. You can control them from your mobile application as well which will ensure that you can customize each element of your home remotely. In the process, you can also save a significant amount of resources and utilities. With smart systems becoming more and more affordable, now there is no reason why you should not convert your home into a smart home.</p>\r\n', '05-April-2022', '7-ways-you-can-turn-your-ordinary-home-into-a-smart-home', 'With so many different companies and brands coming in the market and launching a variety of different smart lighting systems, speakers, sensors it has become easier to convert your home into a smart home');
INSERT INTO `blog` (`id`, `title`, `created`, `modified`, `status`, `address`, `area`, `about_area`, `2017_price`, `2018_price`, `2019_price`, `2020_price`, `street`, `city`, `district`, `pincode`, `state`, `about_property`, `property_status`, `budget_from`, `budget_to`, `price_sqft`, `added_by`, `features`, `nearby`, `modified_by`, `bed_rooms`, `property_type`, `content`, `event_date`, `key_url`, `meta_desc`) VALUES
(53, 'What is a floor plan? Important points to understand – ESWARI HOMES', '2022-04-12 11:18:42', '2022-04-12 13:18:42', 1, '', 'Vizag', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, '', '<p>A house floor plan is essential as having a house floor plan provides a view of the housing project with all the details incorporated into a 3D model before things are turned into reality. To create floor plans the designers work with clients and create a masterpiece before simply working on the architectural aspects. Floor plans are important to avoid disasters in house plans and construction. A floor plan designed by an experienced <a href=\"https://aseinfra.com/\"><strong>builder</strong></a>&nbsp;or an architect will help keep away those errors that could destroy your floor plan layouts.</p>\r\n\r\n<p>Before getting deep into it we will elaborate on why are floor plans important. However, before that let us just figure out what is a floor plan.</p>\r\n\r\n<p><strong>HOUSE FLOOR PLAN</strong><br />\r\nHouse floor plans are scaled diagrams of a selected room or an entire house drafted by a man experienced or skilled in the field of architecture. It is a blueprint which helps you to turn your ideas of your designing floor plans into visuals before converting them into reality. Floor plan gives you a clear picture of all the structural elements. You are in complete control of your floor plan and you are also free to suggest changes and alterations before it is turned into reality. With the help of it you get a picture of every room&rsquo;s positioning, furniture placement and everything else.</p>\r\n\r\n<p><strong>IMPORTANCE OF HOUSE FLOOR PLANS</strong></p>\r\n\r\n<p>To own a home every homebuyer first has to go through the dream of owning a home. You must be saving a lot of floor plan features and designs that you come across over Instagram and Pinterest. You may have a lot of ideas in your mind but without a floor plan they are all a waste. Only with a floor plan can you translate those thoughts and concepts into visuals and check how it all would look if put together. Therefore, a floor plan is something that helps you visualize everything and help the builders into turning them to reality.</p>\r\n\r\n<p>Before the construction process of your house begins it needs to be checked and regulated and thus a blueprint of it is presented to relevant authorities for necessary permissions. You must get the blueprint authorized in order for your work to be completed without unnecessary interference and inaccuracies.</p>\r\n\r\n<p>With the floor plan available you and your architect can track the materials required for the project&rsquo;s completion. The contractors can order the materials accordingly prior to the time o installation so that unnecessary delays could be avoided.</p>\r\n\r\n<p>With the blueprint of the floor plan in your hand you can quickly work on the furniture required. You can choose furnishings that don&rsquo;t look over the board or bare or cramped. Floor plans help you manage and arrange furnishing items accordingly.</p>\r\n\r\n<p>To help you with all of that let the <a href=\"https://eswarihomes.com/\"><strong>best real estate companies</strong></a> in your city find you your dream home.</p>\r\n', '12-April-2022', 'what-is-a-floor-plan-important-points-to-understand', 'A house floor plan is essential as having a house floor plan provides a view of the housing project with all the details incorporated into a 3D model before things are turned into reality. '),
(54, 'The impact of location on property value - Eswari Homes', '2022-04-19 09:45:23', '2022-04-19 11:45:23', 1, '', 'Vizag', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, '', '<p>Location is that one factor which becomes more important than the property when it comes to value of property. If you&#39;ve ever made a decision depending solely on the real estate then you have majorly mistaken. Because location is something you cannot bother less about when planning for buying a house. Let&#39;s just begin to make you understand the importance of location in real estate.</p>\r\n\r\n<p>You can make any changes you&#39;d like to with the condition of your home. You can also change the price of your property. But just think within yourself can you really change or alter the location of your real estate property? A good location can change an entire neighborhood overnight.</p>\r\n\r\n<p>A good location would impact its desirability directly, the desirability would create demand among masses, and it is the demand which raises the real estate prices. Demand and supply are the two important factors that directly impact real estate appraisal.</p>\r\n\r\n<p>So what you must do is not buy a real estate seeing its current neighborhood as it may change with time. But your real estate in a neighborhood where you can see your future. Do enough research before going in for a particular one. Better neighbourhood also means more expenses so be ready for that as well. The wise thing to do while making real estate investment is to stop looking at the current status of the neighborhood and start paying attention to the future of the neighborhood. The companies providing <a href=\"https://eswarihomes.com/\"><strong>real estate services</strong></a> are likely to suggest you to buy your apartment in a safe neighborhood, but keep in mind the fact that the neighborhood that&#39;s safe today may not be so a few years later, so rather than looking at the present status of any location, look forward to the future status of a certain neighborhood. Similarly the neighborhood or a location that may not seem safe now is not likely to remain the same a couple of years later. What makes sense is the future value of an area.</p>\r\n\r\n<p>Always research what the millenials prefer. If most of them prefer a certain locality it&#39;s a strong indicator that you&#39;re buying a location that is going to have strong demand, and the more the demand the more the real estate prices. If you buy in a location that is equally attractive to the largest pool of buyers you will have a much easier time when you go to sell.</p>\r\n\r\n<p>If you have a family or you&#39;re planning to extend a family you would require a locality close to schools. Buying a real estate property in a location where there are good schools will increase the demand for your property, thereby raising the property value. A safe way to invest in real estate is to invest in a great school district.&nbsp;</p>\r\n\r\n<p>Easy transportation to workplace is what attracts most of the buyers. Having a home at a close proximity would save you a lot of time which is what people are now ready to invest on. This is why the areas close to highways, trains, or other means of easy transportation always seem to appreciate faster than areas farther away.</p>\r\n', '19-April-2022', 'the-impact-of-location-on-property-value-eswarihomes', 'Location is that one factor which becomes more important than the property when it comes to value of property. '),
(55, '5 factors that decrease your property value - Eswari Homes', '2022-04-26 08:48:48', '2022-04-26 10:48:48', 1, '', 'Vizag', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, '', '<p>Since your home is one of your biggest purchases of life you would definitely want to protect it. Whether you&#39;re selling a property or buying it you need to find out what the property is really worth. From location to planned infrastructure, facilities, size and aesthetics, there are numerous factors that affect what a property is worth.&nbsp;Keep reading to know what affects the value of your property.</p>\r\n\r\n<p><strong>1. Bad Neighbors</strong></p>\r\n\r\n<p>Bad neighbours are a no no for everyone. When you go to purchase a property it is one of the most important things that you enquire about. Since your neighbourhood has a lot to do with your daily life in a particular area, it directly affects you. If your real estate property is situated in a bad neighborhood you cannot expect home buyers to pay a huge sum of money for its purchase. The better the neighborhood your property is located in the more will be the value of your property, it is as simple as that.</p>\r\n\r\n<p><strong>2. Location</strong></p>\r\n\r\n<p>The area in which your property is located has a lot to do with the value of your real estate. If your house is located near best schools, restaurants, shops and is also easily accessible it&#39;ll add value to your real estate property. The more popular and accessible an investment location is, the more will be the property value.</p>\r\n\r\n<p><strong>3. Age and Condition</strong></p>\r\n\r\n<p>Age is another crucial factor that affects your property value. The fresher the property is the more will the homebuyers looking forward to buying a property would want to pay since a newly built home would not require any major real estate renovation or repairs. Age plays a crucial role yet age alone is not the factor, even the condition of your real estate matters. Home buyers would rather prefer purchasing a few years old property which is well maintained over buying a home that&#39;s new but needs major repairs.</p>\r\n\r\n<p><strong>4. Supply and Demand</strong></p>\r\n\r\n<p>The going up and the going down of the supply and demand has a major and direct influence on your real estate property. If the demand for property in your area is high and the supply of it is fixed the price for property is likely to rise as more and more people attempt to buy. Supply can be increased by dividing the larger structures into smaller units. When the availability of real estate which we can also call the supply exceeds the demand, the value of your real estate will go down.</p>\r\n\r\n<p><strong>5. Economic Factors</strong></p>\r\n\r\n<p>The economic condition of a certain area will have a direct effect on people&#39;s ability to purchase and sell real estate properties in that area. When the economy of an area is booming, and there is enough employment and people earning a good amount of money, their buying power will increase. This will lead them to invest on new property in that area. This will then increase the demand for property in that area, the more the demand the more will be the value for property in any area. Similarly if the employment rate at an area is low and the job facilities scarce, it will lead to wage drops and people wouldn&#39;t be able to purchase a property. The demand will get low, and the supply therefore will exceed the demand and hence the value for the property will be likely to increase.</p>\r\n\r\n<p>To know more about <a href=\"https://eswarihomes.com/\"><strong>real estate services</strong></a> you can contact the team of ESWARI HOMES 24*7.</p>\r\n', '26-April-2022', '5-factors-that-decrease-your-property-value-eswarihomes', 'Since your home is one of your biggest purchases of life you would definitely want to protect it. '),
(56, 'Release Deed: Meaning and Purpose of Release Deed  ESWARI HOMES', '2022-05-03 08:55:36', '2022-05-03 10:55:36', 1, '', 'Vizag', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, '', '<p>A release deed or you can call it a deed of release, is a document that is legal, a document that frees a property or an asset from prior claims or obligations. A release deed is usually executed when your <a href=\"https://eswaricapital.com/\"><strong>home loan</strong></a>&nbsp;provider grants you a legal certificate or a legal document that mentions that you have paid your loan fully in the return of which the lender is freeing or releasing the collateral submitted by you as a mortgage or security against the loan. A deed of release is something that discharges all the parties involved from their previous obligations which helps you in avoiding the possibility of disputes in future.</p>\r\n\r\n<p><strong>So, the 3 basic factors of release deed are:</strong></p>\r\n\r\n<ol>\r\n	<li>A release deed frees your property or your any valuable asset from prior obligations or claims.</li>\r\n	<li>An individual can give up his right in a property through a deed of release.</li>\r\n	<li>For the release deed to have a legal sanction, a release deed must be registered and stamp duty and registration charges be paid.</li>\r\n</ol>\r\n\r\n<p>Types of Release Deeds</p>\r\n\r\n<p>There can be many different types of release deeds.</p>\r\n\r\n<ul>\r\n	<li>Release deeds are often used to end future commercial disputes.</li>\r\n	<li>Release deeds are used to end loan agreements.</li>\r\n	<li>They are also used to end personal guarantees.</li>\r\n</ul>\r\n\r\n<p>Once release deed is sanctioned a property gets free from all legal claims and obligations. The release deed is a document that ensures that no previously signed agreement can be continued by the parties involved, doesn&rsquo;t matter whether the party releasing his claim on property gets any monetary consideration or not.</p>\r\n\r\n<p>When you apply for home loan because you want to purchase a <a href=\"https://eswarihomes.com/\"><strong>real</strong> <strong>estate</strong></a> the banks across the world keep the original documents of the collateral with themselves with the entire period of tenure. It is only after your home loan EMIs are cleared that you get back your original documents. It is mandatory of the banks to issue a release deed which says that they have no claim over your property.</p>\r\n\r\n<p>Therefore, a deed of release is a legal document which eliminates a claim previously made on an asset. It helps you get rid of the previous agreement forming a release deed which gives you a legal sanction that says that your property is free from any prior obligation. It is provided usually when a homeowner has received the title of a property that belongs to him from the lender upon completing the mortgage payments. To release you and the lender from past obligations it is a document that&rsquo;s must.</p>\r\n', '03-May-2022', 'release-deed-meaning-and-purpose-of-release-deed-eswarihomes', 'A release deed or you can call it a deed of release, is a document that is legal, a document that frees a property or an asset from prior claims or obligations.'),
(57, 'Transfer of Property / Different ways to transfer property', '2022-05-10 10:33:08', '2022-05-10 12:33:08', 1, '', 'Vizag', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, '', '<p>Investing in <a href=\"https://eswarihomes.com/\"><strong>real estate</strong></a> property is something that has always attracted customers as well as been in trend. The transfer of immovable property from the owner to the designated heirs can be possible through inheritance or through direct purchase. Transfer of property can most easily be done through sale deed which is also known as Transfer Deed. Property ownership can be obtained through these 5 basic ways:</p>\r\n\r\n<p><strong>1. Purchase of property</strong></p>\r\n\r\n<p>If you have a property that you own and you want to directly sell it off then a Sale Deed is what you need. In this case you must register it in the office of the Sub Registrar in order to execute your sale deed or transfer deed. Doing this will ensure that your ownership has now been transferred to your buyer. When the deed is being registered you are required to pay a stamp duty and registration fee only after which the property will be transferred.</p>\r\n\r\n<p><strong>2. Making a gift deed</strong></p>\r\n\r\n<p>A gift deed is that one in which an immovable property is shared among parents, siblings, etc. This is a cost-effective method of real estate property transfer. As per law it is mandatory to register Gift Deed for any immovable property. Once a property is transferred through Gift Deed you cannot reverse it. Neither can you ask for financial compensation. The Gift Deed too requires you to pay a charge for stamp duty but it is not as much as it in the Sale Deed property transfer process.</p>\r\n\r\n<p><strong>3. Transferring via relinquishment of ownership in a property</strong></p>\r\n\r\n<p>You may own multiple properties individually or you may co-own them with others. In this case you can transfer the property rights to another or the co-owner by executing a Release Deed. This transfer like the above one is irreversible. Once the deed is registered the stamp duty is applicable. The stamp duty is applied only to the part of the property that&rsquo;s released and not on the total value of the property that you own.</p>\r\n\r\n<p><strong>4. Through settlement</strong></p>\r\n\r\n<p>Settlement deed comes into execution when a property is co-owned by a third party. Here, the third party is the one interested to settle in favour of an individual who did not show similar interest. The share is outlined according to the wishes of the settler.</p>\r\n\r\n<p><strong>5. Will or inheritance</strong></p>\r\n\r\n<p>It is one of the most common method used for transfer of property. If you go by the law of succession the property is transferred if a person dies intestate. The testator can revoke the will while he is alive. Beneficiaries are given the ownership only after the testator has died. Beneficiaries do not have to get the property registered. All they ned to do is apply to the local civil authorities to process the mutation of the property in his or her name and for that the recipient must carry a copy of Will Deed, succession certificate and death certificate of the testator.</p>\r\n\r\n<p>We are aware that there are multiple ways to transfer property but it still becomes a consuming as well as confusing task. Based on the information above decide and think which one are you in a position to do and in need seek legal help.</p>\r\n', '10-May-2022', 'transfer-of-property-different-ways-to-transfer-property', 'Investing in real estate property is something that has always attracted customers as well as been in trend. The transfer of immovable property from the owner to the designated heirs can be possible through inheritance or through direct purchase. '),
(58, 'What Homebuyers are looking for today - Eswari Homes', '2022-05-17 08:24:52', '2022-05-17 10:24:52', 1, '', 'Vizag', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, '', '<p>Time is changing and so are the kinds of homebuyers. With the change in the type of homebuyers the features homebuyers are looking for today has also changed. First time home buyers are the ones with most of the questions during their homebuying process since they haven&#39;t had the experience of buying a home before. Irrespective of where you live, you must carry on your own independent research before looking out to buy a <a href=\"https://eswarihomes.com/\"><strong>real</strong> </a><strong><a href=\"https://eswarihomes.com/\">estate in Vizag</a> </strong>or anywhere else in the world. If you were looking for properties in Vizag you could look up to properties listed with ESWARI HOMES, a renowned <a href=\"https://eswarihomes.com/\"><strong>real estate company</strong></a>. Let&#39;s just find out what homebuyers want today in the properties they are looking for. This would help you sell off your property in a shorter timespan.</p>\r\n\r\n<p><strong>1. House with smart technologies -</strong> People shopping for real estate in today&#39;s world are extremely tech savvy. Growing up with mobile phones, tablets, computers and laptops around they do not only want to use technology to find their home but they want it in their homes.</p>\r\n\r\n<p><strong>2. Home office -</strong> Almost all companies except the few selected ones encourage working from home, specially after the world met a pandemic as huge as Covid. Therefore a home office is something every new homebuyer today look for.</p>\r\n\r\n<p><strong>3. Hardwood floor -</strong> If you walk into a home that&#39;s decades old or almost a century old you&#39;ll find a lot of wall-to-wall carpeting, as this was highly preferred during the 20th century because it not only reduced heating bills but also was physically comfortable. But for the new home buyers, they prefer gleaming hardwood floors as it makes the space feel free and wide giving it a clean and new feeling.</p>\r\n\r\n<p><strong>4. Urban home with amenities - </strong>The one feature that first time home buyers are looking for today is an urban city where amenities were easy to utilize. Infact they are looking for buildings with amenities. They want an environment where lifestyle could be active and that which offered them more scope of socialization.</p>\r\n\r\n<p><strong>5. Walk -</strong> <strong>in closets for ladies - </strong>One thing that is sure to attract any new female home buyer is a walk in closet. We know how much women love shopping and we encourage them to love that even more.</p>\r\n\r\n<p>Specially to keep their preference in mind a walk in closet is something that most of the real estate companies offer. This is a home feature that would attract any lady of the family.</p>\r\n\r\n<p>Therefore, if you are looking for a new home, you must go with the choices and preferences of today&#39;s generation and ask your real estate agent about these home features. Depending on these or some of the additional features that you may want you can finalize your choice of a property. Real estate investments are expensive as well as worth, keeping your eyes and ears open is therefore a must to avoid any future discrepancies. If you think you need to know more about real estate you can always visit our website.</p>\r\n', '17-May-2022', 'what-homebuyers-are-looking-for-today-eswarihomes', 'Time is changing and so are the kinds of homebuyers. With the change in the type of homebuyers the features homebuyers are looking for today has also changed. '),
(59, 'What is Title Deed and Why it is Important? - Eswari Homes', '2022-05-24 08:57:33', '2022-05-24 10:57:33', 1, '', 'Vizag', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, '', '<p>To help yourself during the process of <a href=\"https://eswarihomes.com/\"><strong>property purchase</strong></a> you should expand your knowledge of vocabulary relating to this field or else you will be in a much tense situation. There are various terms applied here and there and also to the buyer&#39;s ownership of a physical <a href=\"https://eswarihomes.com/\"><strong>real estate</strong></a> property. The document that proves the buyer&#39;s ownership is known as title deed. At times it is also referred to as sale deed. If you&#39;re thinking that these two things are same, let me tell you, they are not. Title Deed is something else and sale deed is something else. To clear things up for you we have the clear specifications of what title deed is. Read through to know about it.</p>\r\n\r\n<p><strong>What is a title deed?</strong></p>\r\n\r\n<p>The Oxford dictionary defines a title deed as the &ldquo;legal right to own something, particularly land or property; a document that proves this right.&rdquo; When you purchase a real estate property you do not obtain the legal ownership of it unless you go through a formal process known as registration. Through this process property ownership is transferred to you.</p>\r\n\r\n<p>Though sale deed and title deed are terms used interchangeably they are both very different from each other. Title Deed is a concept where sale deed is always in a documentary form. Here, one helps establish the other. The sale deed soon turns into a title deed after going through the process of registration. It serves as a proof that you now own a property.</p>\r\n\r\n<p><strong>Importance of Title Deed</strong></p>\r\n\r\n<p>It is very crucial that you must go through all the paperwork before and whitest purchasing a real estate property. Title Deed is the most sought after way to let the world know about the property&#39;s owner. In case you are the owner of a certain property but you hold no legal documents, no one will believe its yours and also somebody else might just occupy it illegally. Holding a clear title gives you protection against ownership of property. It is the proof of your legal ownership and gives you the freedom to exercise your property rights.</p>\r\n\r\n<p>Having a title deed is like being sure about the ownership. If you&#39;re sure of your ownership you can carry on further transactions. If you have the right over a property and you also have legal ownership you can resell it in future, transfer it, mortgage it or gift it.</p>\r\n\r\n<p>You also need a title deed to avail loans from bank since banks ask you to deposit ownership documents while lending you a particular amount as security.</p>\r\n\r\n<p>In the absence of your sale deed it becomes difficult or almost impossible to prove the ownership, one cannot even defend his claim over a property.</p>\r\n\r\n<p>Having such documents is necessary to prove the authentic of the priori transactions. It also informs about the property liabilities attached to the property.</p>\r\n', '24-May-2022', 'what-is-title-deed-and-why-it-is-important-eswarihomes', 'There are various terms applied here and there and also to the buyers ownership of a physical real estate property. '),
(60, 'Real Estate Vs Stocks - Investment Best Suitable for You | Eswari Homes', '2022-05-31 08:15:21', '2022-05-31 10:12:13', 1, '', 'Vizag', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, '', '<p>Wealth is something that can be grown, but there are different ways to do that. Investments made on stocks as well as real estate both allow you to earn passive income. If you&#39;re willing to grow your wealth, and save for your next big financial expenditure, the most important step is to determine which form of investment is right for you.</p>\r\n\r\n<p>Real estate is less volatile when compared to stocks because the value that stocks carry rises or falls more quickly than of the <strong><a href=\"https://eswarihomes.com/\">real estate property</a>,</strong> which makes real estate investment more secure. On contrast to that real estate is also less liquid, so selling the stock and getting direct access to your money is easier when it comes to stocks.</p>\r\n\r\n<p>But you should always remember that investments on both stocks and real estate is worth making. But if you&#39;re to choose any one from the both then you must focus and rely on your budget limit, risk tolerance and financial goals.</p>\r\n\r\n<p>When deciding whether to go for real estate investment or for investment on stock, the investor has to consider several factors such as how much money can they afford to invest, and how long they can wait to access the benefit. Let&#39;s just read on to know is it better to invest in stocks or on real estate.</p>\r\n\r\n<p>While you&#39;re deciding where to invest you must consider the potential return on investment or ROI. If you&#39;re wondering what ROI is, it is the efficiency or profitably of an investment. It is impossible to predict an accurate possible return but what you can do is compare the past returns on both the kinds of investments to know the road you&#39;re going down to.</p>\r\n\r\n<p>The returns that you get on real estates vary in large amount depending on the location as well as the property type. Stocks tend to increase its value at a faster rate than real estate. If you measure historically then stock investments offer less ROI than real estate investments.</p>\r\n\r\n<p>Let&#39;s look at the benefits of investment into real estate and stock market so that you can figure out which one is suitable for you or whether you should <a href=\"https://eswarihomes.com/\"><strong>invest in real estate</strong></a> or stock.</p>\r\n\r\n<p><strong>Benefits of investing on real estate</strong></p>\r\n\r\n<p><strong>1. Tax Advantages -</strong> When it comes to real estate investment some of your expenses are deducted due to certain tax deductions, property taxes as well as peppery management fees.</p>\r\n\r\n<p><strong>2. Long Term Security -</strong> It is a long term security which means that over a long period of time, the value of it is going to appreciate and not depreciate. But while you are waiting for the appreciation you can also earn some extra money or wealth by renting out the property.</p>\r\n\r\n<p><strong>3. Protection Against Inflation -</strong> Inflation is the process in which the price of almost everything in the market increases, so when the price of products, goods and services in the market increase, so does the value of the rented property which allows you to earn higher income.</p>\r\n\r\n<p><strong>Benefits on investing on stocks</strong></p>\r\n\r\n<p><strong>1. Less expensive transaction - </strong>the lower upfront cost is much much lower and also your trading transactions are going to be much lesser. Opening a brokerage account is a must when you purchase or sell stocks but now you can have them for little to no cost at all.</p>\r\n\r\n<p><strong>2. Simpler diversification - </strong>Average investors wouldn&#39;t be able to make diverse investments when it comes to real estate. But with stocks it is much easier. Diversifying investments are important as they save you from fluctuations while assuring you higher ROIs.</p>\r\n\r\n<p><strong>3. More Liquidity -</strong> With stocks you&#39;ll be able to identify the value of your investment at any point of time which you cannot do in real estate and also at any given time you can access to its benefit.</p>\r\n\r\n<p>Given all of these factors you can go for either real estate investments or stock investments depending on your affordability, choices, preferences, or financial goals.</p>\r\n', '31-May-2022', 'real-estate-vs-stocks-investment-best-suitable-for-you-eswarihomes', 'Wealth is something that can be grown, but there are different ways to do that. Investments made on stocks as well as real estate both allow you to earn passive income.'),
(61, 'CARPET, BUILT-UP AND SUPER BUILT-UP AREA -  OVERVIEW | ESWARI HOMES', '2022-06-07 10:58:55', '2022-06-07 12:58:55', 1, '', 'Vizag', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, '', '<p>Homebuyers come across terms like carpet area, builtup area and super built up area during their homebuying process when they try to measure the size of homes. Read this blog to understand what these terms mean as well as what exactly do they convey.</p>\r\n\r\n<p><strong>Carpet Area</strong></p>\r\n\r\n<p>Under the Pradhan Mantri Awas Yojana introduced by the central government in India with its mission to provide Housing for All by 2022 carpet area means &lsquo;the net usable floor area of an apartment, excluding the area covered by the external walls but including the area covered by internal partition walls of the apartment&rsquo;. Under this government mission carpet area means the &lsquo;area enclosed within the walls and the actual area to lay the carpet&rsquo;.</p>\r\n\r\n<p>In simple words carpet area is the area in your house or flat which could be covered using a carpet. It is the space in your house where you can lay your carpet. When you <a href=\"https://eswarihomes.com/\"><strong>buy a house</strong></a> it&#39;s important to calculate the carpet area and the formula to calculate it is</p>\r\n\r\n<p><strong>Carpet Area = Area of Bedroom + Living Room Balconies + toilets - thickness of the inner walls</strong></p>\r\n\r\n<p><strong>Built Up Area</strong></p>\r\n\r\n<p>The builtup area in a flat is its carpet area + the space taken by the wall. The built up area in a <a href=\"https://eswarihomes.com/\"><strong>real estate</strong></a> includes some additional areas apart from carpet area that includes u unusable areas such as balcony, flower beds, terrace etc. Thus, a flat would seem larger than what it is when expressed in terms of builtup area. To calculate the built up area of your apartment use this super easy formula.</p>\r\n\r\n<p><strong>Built up area = carpet area + area of walls + area of balcony</strong></p>\r\n\r\n<p><strong>Super Builtup Area</strong></p>\r\n\r\n<p>In a multi storey apartment or mostly in housing societies you&#39;ll find various common areas. The people residing in a building or society has to equally pay for its maintenance for the upkeep of these areas, and also they have to make a certain payment while purchasing the flat in the society.</p>\r\n\r\n<p>In other words super builtup areas can be measured by adding the total built up area, with the areas occupied by common areas, including the lift lobby, corridors, elevator etc. Amenities such as pool, garden and clubhouses too may be added by the developers while calculating super built-up area.</p>\r\n\r\n<p>RERA has recently made it mandatory for the developers to sell flats based on the carpet area. Before this measure was taken they included the super built-up areas too in the space measuring unit.</p>\r\n', '07-June-2022', 'carpet-builtup-and-super-builtup-area-overview-eswarihomes', 'Homebuyers come across terms like carpet area, builtup area and super built up area during their homebuying process when they try to measure the size of homes. '),
(62, 'Things to Consider Before Buying Property for Rental Income | Eswari Homes', '2022-06-14 10:05:42', '2022-06-14 12:05:42', 1, '', 'Vizag', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, '', '<p>Have you thought about how you&#39;re going to generate income after your retirement? Buying a property for rental income is an effective way to generate income. But because real estate investment is not a child&#39;s game, you must consider and evaluate the expected return, expenses, rewards, and risks that come with property for rental income. To consider an of these is to make the most out of your investment.</p>\r\n\r\n<p>1. When you&#39;re buying a house from a <a href=\"https://eswarihomes.com/\"><strong>real estate company</strong></a> to put it out on rent it is important for you to know or find out if it will generate a decent and satisfactory income. Because the main reason to buy a property for rental income is to generate income from it therefore you must figure out if it&#39;s capable of generating an expected income.</p>\r\n\r\n<p>2. The worst thing that could happen to you when it comes to rental properties is that the property is located in an area that is declining rather than stable. A city or a locality where the population is growing in numbers is a good way to invest because the more the population the greater the investment opportunity.</p>\r\n\r\n<p>3. The more expensive your property is going to be the greater will be the cost for maintaining it. So what you can do is avoid buying the nicest house in a locality as well as the worst house. Choose and invest on a property that&#39;s neither too nice nor too worse so that what you pay for it is a balance of the two.</p>\r\n\r\n<p>4. It is very important for you as a rental property investor to be familiar with the tenant landlord laws and obligations I your state and locality. This is a very important factor to save both your rights as the landlord and the tenants rights too. You must understand the tenant&#39;s rights and your obligations regarding security deposit, lease requirements, eviction rules, fair housing, and more in order to avoid legal hassles.</p>\r\n\r\n<p>5. Insurance is another investment that you have to subtract from your rental income. You have to devise an idea about how much a disaster could cost you and have to subtract that amount from your rental income. If your property is located in a disaster prone area then it is likely to eat away all your income. So you must avoid purchasing a property in these areas.</p>\r\n\r\n<p><strong>Conclusion</strong></p>\r\n\r\n<p>You must not expect just anything. Be practical as well as realistic with your expectations. Just like any other forms of investment rental property wouldn&#39;t bring you a large monthly paycheck right away. Choosing a wrong property could be the worst mistake. But it is still a good way to generate effective income.</p>\r\n', '14-June-2022', 'things-to-consider-before-buying-property-for-rental-income-eswarihomes', 'Buying a property for rental income is an effective way to generate income. '),
(63, 'Gifting A House - A Comprehensive Guide | Eswari Homes', '2022-06-21 09:08:31', '2022-06-21 11:08:31', 1, '', 'Vizag', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, '', '<p>Through Section 122 of the Transfer of Property Act gift is defined as the transfer of certain existing movable and immovable <a href=\"https://eswarihomes.com/\"><strong>property</strong></a> which is but voluntarily, without any consideration by a doner to a donee. The ownership of it must be transferred by the doner and accepted by the done.</p>\r\n\r\n<p>Not everything that you own can be gifted. A gift is accepted as valid only when it is voluntarily gifted by the person who owns the property and accepted by the person to whom it is given. A property is termed as a gift when given to another person without any or little consideration.</p>\r\n\r\n<p>The one who is gifting a house is known as the donor, and the one receiving the gift of house property is known as donee. When it is an immovable property that is given as a gift it is known as transfer of property and it must be made in writing through a gift deed. The gift deed is required to be signed by both the doner and the donee in the presence of two witnesses.</p>\r\n\r\n<p>The gift deed must be registered with the local registration office. For the registration process to be started and completed both the sides need to be present. There&#39;s a fee that needs to be paid as registration fee. Only then can the registration process be completed. The basic documents that are required to be be submitted are:</p>\r\n\r\n<ul>\r\n	<li>Gift Deed</li>\r\n	<li>Adhaar and PAN of both parties</li>\r\n	<li>Latest Electricity Bill</li>\r\n	<li>Property Tax Bill</li>\r\n	<li>All the documents related to the property</li>\r\n	<li>Encumbrance Certificate</li>\r\n</ul>\r\n\r\n<p>Then comes the stamp duty. Stamp duty must be paid as percentage of market value of the property. If the gift is being made to a close relative a lower stamp duty is applicable compared to the stamp duty applicable when it is transferred to some other person.</p>\r\n\r\n<p>Gift is something everybody likes to give to the person that they love. And property is something that is one of the most valuable asset one can give another. To gift your loved ones the best property you can always reach out to ESWARI HOMES.</p>\r\n', '21-June-2022', 'gifting-a-house-a-comprehensive-guide-eswarihomes', 'Through Section 122 of the Transfer of Property Act gift is defined as the transfer of certain existing movable and immovable property which is but voluntarily, without any consideration by a doner to a donee. '),
(64, 'How smart cities are good fit for property investment', '2022-06-28 10:04:04', '2022-06-28 12:04:04', 1, '', 'Vizag', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, '', '<p><strong>Before we figure out how smart cities are good fit for property investment, let us find out what even is a smart city?</strong></p>\r\n\r\n<p>By smart city we can easily understand the fact that it&#39;s a kind of city that has something to do with advanced technology which makes the term smart applicable somewhat. Better technology means a simpler way of living, a comfortable life. The advancement of technology for a comfortable life doesn&#39;t mean depletion of mother Earth, smart cities are eco friendly to the Earth. Smart cities came to emerge after studying the problems faced by the residents of an area due to poor planning and maintenance. The basic amenities such as water, electricity, transport, sanitation, education and health care are all governed or controlled by the use of well advanced technology. Some cities that have already transformed into smart cities are Gujarat, Kochi, Naya Raipur, and few others.</p>\r\n\r\n<p><strong>Why smart cities are investor-friendly?</strong></p>\r\n\r\n<p>Smart city investment is a good and a wise choice for property investors looking forward to <a href=\"https://eswarihomes.com/\"><strong>buying property</strong></a>. The price of real estate properties in smart cities are now reasonable which makes it investor friendly. Therefore if you invest on real estate properties in smart cities expect a higher return on your investment.</p>\r\n\r\n<p>Real estate investment properties in smart cities are an impeccable choice for property investors given the steady growth and development in these areas. These cities offer almost everything that it did not few years back.</p>\r\n\r\n<p>From amenities to facilities these cities provide them all making these investments the best real estate investment of your life. Smart cities guarantee an improved quality of life for all their citizens and are one of the primary reasons why investors should invest in them.</p>\r\n\r\n<p>The implementation of infrastructural plans in smart cities has surpassed the expectations of investors and firms, making it an entirely new experience. Infrastructure forms the foundation of any smart city, and realizing the same; the government has invested heavily in it, widening the prospects of interventions and investments from property investors.</p>\r\n\r\n<p>Tech-driven interventions have boosted the confidence of real estate agents and property investors in smart cities. This is bound to increase in the near future. The main features of such cities include smart metering, an abundance of parking spaces, 24/7 surveillance, greenery, an uninterrupted supply of water and electricity, all of this is enabled by the latest technological interventions making these cities a sustainable and viable solution for the future.</p>\r\n', '28-June-2022', 'how-smart-cities-are-good-fit-for-property-investment', 'The advancement of technology for a comfortable life doesn\'t mean depletion of mother Earth, smart   cities are eco friendly to the Earth.'),
(65, 'How apartment living will enhance your work-life balance?', '2022-07-05 10:54:47', '2022-07-05 12:52:20', 1, '', 'Vizag', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, '', '<p>Since the time corona has hit the globe work life has seemed to blend a little with personal life. Work from home is a phrase or a term that have come into maximum use while the country was going through pandemic as the work from home culture slowly started to seep in. Since work has entered the boundaries of your luxury flats the lines between the two has slowly begun to blur. In this context we must know why life in apartment will enhance your work-life balance.</p>\r\n\r\n<p>There are hardly anything negative about the work from home culture which has begun to gain momentum since 2019.</p>\r\n\r\n<p>Even though this has creates employment opportunities for the mass yet individuals are having trouble maintaining this work-life balance.</p>\r\n\r\n<p>Let us look at the reasons why and how apartment living will enhance your work-life balance.</p>\r\n\r\n<p>You must have heard the idiom which says all work and no play makes Jack a dull boy. This is the case with all of us since we are all humans like Jack. A break from work is a must to make you feel less stressful while revitalizing you. Even though WFH is a good opportunity you must see that your work doesn&#39;t collide with your leisure time. We understand that you become lethargic living with your family and you do not often find the zeal to go out for recreational activities. To cure this laziness you can look forward to purchasing your property from <strong><a href=\"https://eswarihomes.com/\">reliable builders</a> </strong>as the apartments provided by them will allow spaces for leisure amenities. For your convenience the <a href=\"https://eswarihomes.com/\"><strong>real estate developers</strong></a> all over the world have now come up with apartment communities that include leisure amenities such as swimming pool, gym, garden, playground, clubhouses etc.</p>\r\n\r\n<p>With the presence of these recreational areas you get to maintain both your work life as well as your personal life in a smooth way. You do not have to cover miles to go spend quality time with your family.</p>\r\n\r\n<p>If you&#39;re working from home we are sure you must be suffering with eye strain, headaches, and neck &amp; back pains as modern day work involves us sitting in front of a computer. Apartment communities that provide fitness areas would lure you into different exercises which will act as a recreational activity for you, in turn improving the condition of your health.</p>\r\n\r\n<p>Can you claim that you do not want to feel like you belong? No, right? It&#39;s because all of us crave for the sense of belonging. Having someone to talk to and spend time with is necessary in these trying times. Apartment complexes give you this opportunity to live in a community which in a way helps you maintain work-life balance. The residents come together to celebrate occasions and festivals. In this way it becomes easier for you to make friends and connect with others. Such events also allow us to cope with stress, either from work or personal life, better in a healthy way.&nbsp;</p>\r\n\r\n<p>Suppose you are working from home and bound into a hectic work schedule when something in your apartment is in need of service, how would you manage that together? With apartment complexes you get a list of contacts that offer professional maintenance services. This would save you the time which you would have otherwise spent looking for the service provider.</p>\r\n\r\n<p>These are only some of the ways in which apartment living enhances your work life. If you want to know more about the advantages it brings you can directly turn into the official page of ESWARI HOMES.</p>\r\n', '05-July-2022', 'how-apartment-living-will-enhance-your-work-life-balance', 'There are hardly anything negative about the work from home culture which has begun to gain momentum since 2019. ');
INSERT INTO `blog` (`id`, `title`, `created`, `modified`, `status`, `address`, `area`, `about_area`, `2017_price`, `2018_price`, `2019_price`, `2020_price`, `street`, `city`, `district`, `pincode`, `state`, `about_property`, `property_status`, `budget_from`, `budget_to`, `price_sqft`, `added_by`, `features`, `nearby`, `modified_by`, `bed_rooms`, `property_type`, `content`, `event_date`, `key_url`, `meta_desc`) VALUES
(66, 'What are the advantages of having a second home', '2022-07-12 10:39:21', '2022-07-12 12:39:21', 1, '', 'Vizag', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, '', '<p>A second home is thought mainly to be a home away from home that can be used spending vacations and holidays. That&#39;s what general public thinks. What they do not understand is that they can also use it as a primary residence. Second home has more than just one or two uses. It is beneficial in so many ways.</p>\r\n\r\n<p>Let&#39;s look at the advantages that come with owning a second home.</p>\r\n\r\n<p><strong>1. Financial Security</strong></p>\r\n\r\n<p>The number one benefit of owning a second home is financial security. Second homes usually reduces your overall debt. It increases your cash flow and prevents you from taking further loan. If your family is going through financial hardship, your second home will be of great help. If you have a second home you can put it on rent immediately and earn some instant money. It can be rented for a short term agreement period. But it&#39;ll give you long term profits.</p>\r\n\r\n<p><strong>2. Get Rid Of Debt</strong></p>\r\n\r\n<p>Having two homes can help you reduce or get rid of your overall debt, since the primary home you use for residing and the other one you may use for earning money in different ways. In case you rent out your home you&#39;ll get a fixed monthly income.</p>\r\n\r\n<p><strong>3. Build Wealth</strong></p>\r\n\r\n<p>We are all humans and we&#39;ll grow old and retire one day. So how are you going to survive after your retirement? Having your second home brings you monthly income which helps you to build wealth that you may use after retirement. It helps you build wealth much faster than any other form. If you&#39;re looking forward to retire in the near future you must rent out your second home from now.</p>\r\n\r\n<p><strong>4. Tax Benefit</strong></p>\r\n\r\n<p>There are some tax benefits that are available to the ones who buy second home by taking home loans. Section 80C provides tax savings on the principal amount, while Section 24B offers tax deductions on the home loan interest rates disbursed to service the loan. Borrowers can also claim a tax deduction of Rs. 1.5 lakhs on house loan principal repayments under Section 80C and a deduction of Rs. 2 lakhs under Section 24B of the Income Tax Act.</p>\r\n\r\n<p><strong>5. Holiday Home</strong></p>\r\n\r\n<p>With a second home you never have to worry about where to travel and when. A second home will offer you the freedom of being in a different location for weekends and give you the privilege of hosting family and friends. A second home will also allow you to maintain connections with your community while on vacation.&nbsp;Every time you want to take a vacation you can visit your second home and also avoid paying huge sum of money to rental homes. Having your own second home means you never have to worry about who to travel with and how long to stay.</p>\r\n\r\n<p>Your second home becomes a <a href=\"https://eswarihomes.com/\"><strong>high value asset over a period of time</strong></a> which can be put into so many use as well as can be a form of wealth. Thus you shouldn&#39;t think twice before purchasing your second home because it&#39;s always the best form of investment.</p>\r\n', '12-July-2022', 'what-are-the-advantages-of-having-a-second-home', 'Second home has more than just one or two uses. It is beneficial in so many ways. '),
(67, 'Documents Checklist for Buying Property', '2022-07-19 11:47:31', '2022-07-19 13:47:31', 1, '', 'Vizag', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, '', '<p>Buying a property means a huge investment of capital and any mistake made during this homebuying process can cause you a great problem. Therefore it becomes very important for you to <a href=\"https://eswarihomes.com/\"><strong>check property documents</strong></a> before signing the sale agreement.</p>\r\n\r\n<p>Just the way we pay special attention to the location and surroundings while buying a house it is extremely important to pay heed to the the legal documents of the property to avoid later troubles. There are numerous documents that you must sign in order to complete the homebuying process but no matter how long or tiring the process is you cannot overlook anything as even the littlest of mistakes can cause you a problem of a lifetime. Each and every documents are important and each one of them preserve your ownership rights. You must go through each document thoroughly and understand the importance that they hold in your homebuying journey.</p>\r\n\r\n<p>These are some of the significant documents that you&#39;ll need to buy properties in India.</p>\r\n\r\n<p><strong>1.Title Deed</strong> - Title Deed is the document that records the transfer of ownership of a property. It is the most significant document, hence, you must check the title deed of the property to ensure that the seller actually owns the property and has the right to sell it off. You must ask the seller to show you the original copy of the document as most of them show only the photocopy.</p>\r\n\r\n<p><strong>2.Kind of Property</strong> - You must know the property kind for it can be freehold property, leasehold or a government accommodation. Freehold property means you own the land on which the property is built and leasehold means you have the right to live in the property for a stipulated period of time.</p>\r\n\r\n<p><strong>3.Tax Receipt and Bill </strong>- Property tax is what the owner of a property must pay to the government as an annual charge levied by the government body. It is a huge liability and before you finalize everything you should make sure that the seller has cleared all the property tax bills in the past and has the receipt of the same. You must see that there are no pending payments which you might be expected to pay when buying the property.</p>\r\n\r\n<p><strong>4.Encumbrance Certificate</strong> - Before buying the property, ensure that the owner has the encumbrance certificate. This certificate ensures that that the property is not mortgaged. If the property is mortgaged and there are pending dues, the owner is liable to clear them before selling the property. This certificate can be acquired from the office of the sub-registrar.</p>\r\n\r\n<p><strong>5.No-Objection Certificate </strong>- Your homebuying process cannot finish without the no objection certificate. It is also known as NOC. A NOC is a proof that the property that you&#39;re purchasing hasn&#39;t violated any of the building laws during the time of construction.</p>\r\n\r\n<p>These are the documents that you must must look for while purchasing a property. And these are not all. There are many more with these being the basic and the most significant ones.</p>\r\n', '19-july-2022', 'documents-checklist-for-buying-property', 'Buying a property means a huge investment of capital and any mistake made during this homebuying process can cause you a great problem.'),
(68, 'Vastu tips to attract wealth to your home', '2022-07-26 11:48:24', '2022-07-26 13:48:24', 1, '', 'Vizag', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, '', '<p>Only if we could live in a world deprived of anything materialistic it would be an ideal kind of world. Sadly but truly money and materialistic things form an important part of our lives. If you&#39;re having a hard time holding on to money and wealth you must read these vastu tips by <a href=\"https://eswarihomes.com/\"><strong>ESWARI HOMES</strong></a> to attract wealth to your home.</p>\r\n\r\n<p>1.In the north vastu zone or area of your home you must make sure that blue is the main color and strictly avoid any shades of red in it as it is meant to bring good luck only when you have got it in your kitchen area. You must not place a dustbin, broom, washing machine or mixer grinder in this area. What kitchen represents is fire and with wrong placement of items you will end up losing money, wealth, opportunities and career.</p>\r\n\r\n<p>2.Entrance of any area is the space from which starts the flow of positive energy. Both positive energies as well as finances enter from the main entrance of any house. Therefore make this space in accordance with the vastu rules. The entry to the house should be in the north or east directions. Decorate the space with religious symbols and paintings. Maintain cleanliness and keep it clean and clutter free if you want to make it the <a href=\"https://eswarihomes.com/\"><strong>property&#39;s wealth corner</strong>.</a></p>\r\n\r\n<p>3.There are certain plants that are considered good for any household. They are believed to bring good luck to your home according to the Principles of Vastu Shashtra. Bamboo, lotus, tulsi are some of the plants that bring good luck to your home. Money plant is another major one which if placed in the favorable direction enhances positivity and helps attract wealth in hard times.</p>\r\n\r\n<p>4.There&#39;s a connect between flow of water and the flow of finances. When the flow of water is perfect so becomes the flow of finances. With a leaking pipe that needs plumbing you&#39;ll also face financial loss. So you can add water decor items to keep your finances flowing, you could also place an aquarium with fish inside which could keep the positive environment alive. Do not allow stagnant water to be an obstruction in the way of flowing finances.</p>\r\n\r\n<p>5.People do not just hang a painting or place a showpiece or a statue for no reason. These do not just augment the beauty of a house but they also influence things like finance, relationships and health. Paintings of waterfall is a good way to attract wealth and have peace in your household. You can also place the tortoise figurines and the Buddha statue which stand for peace, harmony, and good luck. Hanging wind chimes plays the role of money magnet as it attracts wealth.</p>\r\n\r\n<p>These are some of the tips laid down by the ancient Hindu science which you could follow if you&#39;re having a hard time attracting wealth. All of these doesn&#39;t require much of your time or money, it&#39;s just about a little attention and effort to create a surrounding that&#39;s as good for health as it is for financial status.</p>\r\n', '26-July-2022', 'vastu-tips-to-attract-wealth-to-your-home', 'If you are having a hard time holding on to money and wealth you must read these vastu tips by ESWARI HOMES to attract wealth to your home.'),
(69, 'Full Form of BHK and its essential guide', '2022-08-02 12:56:42', '2022-08-02 14:56:42', 1, '', 'Vizag', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, '', '<p>The common question that comes to a buyers mind when they are looking forward to <a href=\"https://eswarihomes.com/\"><strong>purchase a house</strong></a> is what does a BHK mean or what is its full form. Whenever you come across house advertisements it always shows 1BHK, 2BHK, 3BHK or more but there&#39;s always a BHK at the end. This blog will act as a guide to make you understand what is implied by BHK.</p>\r\n\r\n<p>BHK stands for Bedroom, Hall and Kitchen. It signifies all the three together, hence the short form BHK. 1BHK, 2BHK, 3BHK or more are types of BHK configurations that you choose when deciding your budget in the process of house hunting.</p>\r\n\r\n<p>1BHK includes 1 bedroom, 1 hall room and a kitchen. Similarly 2BHK includes 2 bedrooms, 1 hall room and 1 kitchen. And 3BHK stands for 3 bedrooms, a hall room and a kitchen. So BHK stands for number of bedrooms, hall and kitchen.</p>\r\n\r\n<p>1BHK would seem perfect for a couple without children but people in joint families would require an apartment of 2BHK or 3BHK depending on the size of the family. Because there&#39;s no mention of toilet space doesn&#39;t mean you won&#39;t have any, all the configurations mentioned about would include a bathroom and toilet space.</p>\r\n\r\n<p>Investing on a property is not a child&#39;s game specially for the ones who are investing on real estate for the first time ever. It is very crucial to decide which one amount all the configurations is suitable for you. So if you are a couple or your family consists of only two members then it&#39;s ideal for you to invest on 1BHK. But if your family is planning to extend then 1BHK will feel very compact. Therefore what you can do is invest on 2BHK as it is a perfect long term investment option for any nuclear family.</p>\r\n\r\n<p>2BHK apartments are preferred by most of the population, it is because it provides better amenities and comes in different sizes. Many of you invest quite a higher amount on purchasing an apartment of 1BHK. What we advise is to invest on small 2BHK as it will cost lesser compared to your investment that you make for 1BHK.</p>\r\n\r\n<p>Real estate investment, any day is a long term and a safe investment. So, think before you invest. In India, people usually afford to buy a house when it is also time to start a family; hence there are not many homebuyers in the market for 1 BHK. On the other hand, 2 BHK unit size is always in demand, especially for small families. Thus, 2 BHK is a wiser choice.</p>\r\n\r\n<p>Whether you are living in a nuclear family or you are living alone 2BHK is always a smart and wise choice. If you&#39;re living as an individual you can utilize the extra space for other purposes till the time you don&#39;t get married and plan on extending your family.</p>\r\n\r\n<p>Look into all these factors discussed above before buying or investing on real estate properties.</p>\r\n', '02-August-2022', 'full-form-of-BHK-and-its-essential-guide', 'Whenever you come across house advertisements it always shows 1BHK, 2BHK, 3BHK or more but theres always a BHK at the end.'),
(70, 'How investing in real estate at a young age is beneficial', '2022-08-09 10:46:52', '2022-08-09 12:46:52', 1, '', 'Vizag', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, '', '<p>The millennial today are much more ambitious and smarter. They have realized the benefits of <a href=\"https://eswarihomes.com/\"><strong>real estate investment at young age</strong></a>. The pattern here is simple, the earlier you invest the more is young to be your benefit. So if the youth today start investing on real estate at an age of 20 to 30 it&#39;ll build up greater corpus, resulting in better lifestyle as well as early retirement.</p>\r\n\r\n<p>When you are young the responsibilities aren&#39;t zero but they are comparatively less which gives you all a greater chance at being young investors. It also leads to financial independence at an earlier age and safe and stable income when you are old. Since real estate sector has begun to gain popularity among the masses it is the safest form of investment.</p>\r\n\r\n<p>Here are some reasons why it&#39;s beneficial to invest on real estates at a younger age.</p>\r\n\r\n<p>1. Buying <a href=\"https://eswarihomes.com/\"><strong>real estate properties from credible builders</strong></a> at a young age gives you the luxury of time as you are young at this point and also you do not have much responsibilities on your shoulder. With little responsibility you get the freedom to pick and choose the kind of property you want to invest in.</p>\r\n\r\n<p>2. Because you&#39;re young you are best fit for home loans with luring interest rates. Since you have a long way to go you can choose longer tenure of repayment. With time just when your bonus or income increases you can even utilize it to foreclose the loan.</p>\r\n\r\n<p>3. Dealing with investments at a young age will boost your financial management skills and you&#39;ll be better able to deal with future investments. From an early age you learn about investments which makes you good at it. With this you&#39;ll learn to handle cash flow, create a monthly budget, which are great for your growth in all respects.</p>\r\n\r\n<p>4. Since you&#39;ve started investing at an early age and have prepared yourself for long-term gains through investment in real estate you can easily opt for early retirement. For example if you start investing by the age of 25 you can expect a sizeable earning at an age of 50. You can utilize this time to pursue your passion.</p>\r\n\r\n<p>5. The property that you invest on will generate more monthly income than your monthly repayment outstanding of home loan. You&#39;ll be easily able to pay off the home loan EMI by using the monthly payment that you collect from the property you&#39;ve invested on. You can also be left with some savings that you can put to your personal use.</p>\r\n\r\n<p>Benefits are many but the decision is yours. Don&#39;t wait too long to make these investments because only when you&#39;re young will you be driven by the motivation to take up such forms of investment because you know your ability to handle these. If you still have queries you can always reach out to ESWARI HOMES and we&#39;ll let you know why you must invest and also the right time for these investments.</p>\r\n', '09-August-2022', 'how-investing-in-real-estate-at-a-young-age-is-beneficial', 'The millennial today are much more ambitious and smarter. They have realized the benefits of real estate investment at young age. '),
(71, 'Home Loans for women and their benefits', '2022-08-16 10:38:28', '2022-08-16 12:38:28', 1, '', 'Vizag', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, '', '<p>Buying a home of our own for most of us is one time activity in an entire lifetime. It&#39;s also an emotional decision for the most of us since it requires us to spend our savings, borrow money and take up monthly repayment option as a commitment that may last for many years. One of the major concerns of any homebuyer is to get a higher amount of home loan so that they can choose the house of their dreams without any restriction. All of these concerns are likely to go away at certain conditions making homebuying much more easier. And the solution for this is home loan for women.</p>\r\n\r\n<p>In recent times women play an important role when you <a href=\"https://eswarihomes.com/\"><strong>consider buying a home</strong></a>. A larger number of women today are taking up professional jobs and businesses and are no longer dependent on the male member of their family for their expenses. Like their husband they are now eligible to contribute equally to home loans. There comes many advantages if the home loan is taken by the female member of a family. Let us have a look at some of the significant reasons why it is always wise to include a woman as a borrower of a home loan.</p>\r\n\r\n<p><strong>Home Loan Benefits For Women</strong></p>\r\n\r\n<p>1. Women who are earning independently can apply for home loans with their husbands as co-applicants. This will benefit in increasing their home loan eligibility. This therefore will give them more flexibility while choosing a home of their own.</p>\r\n\r\n<p>2. While taking home loan, tax deduction benefit is available for both the husband and the wife. Both of them together can enjoy the tax deduction benefit on the same joint home loan. Individually, each of them can avail of a maximum deduction of Rs. 1.5 lakh on principal amount and Rs. 2 lakh on interest components of the EMI. Thereby as a couple, together they can avail of a combined maximum deduction of Rs. 3 lakh on principal and Rs. 4 lakh on interest components of the EMI, which itself amounts to significant savings in income tax.</p>\r\n\r\n<p>3. Stamp duty charges for a woman can be a lot beneficial compared to a man while buying a property. Many state governments encourage women home ownership by decreasing the stamp duty charges by 1 or 2% lesser than the males of the state. This sums upto saving Rs 30000 to Rs 60000 on a property of Rs 30 lakhs.</p>\r\n\r\n<p>4. If we go by past records it indicates that women compared to are better savers, they are not so much into unnecessary debts, also they are very much experienced with financial management, and have lower default rates compared to men. This is why the chances for home loan approval for women are more than that of men since financial institutions are keen to lend to women for their low rates of default.</p>\r\n\r\n<p>But for women to be eligible for home loans they need to fulfill certain criteria. And the criterias are :</p>\r\n\r\n<p>1. They must hold citizenship of India</p>\r\n\r\n<p>2. The age group for women should be between 20 to 60</p>\r\n\r\n<p>3. A work experience of two years minimum is a must</p>\r\n\r\n<p>4. Credit score should not be anything below 650</p>\r\n\r\n<p>5. Income of the family should not fall below 15000 per month.</p>\r\n\r\n<p>Other than the mentioned points here, the exact home loan eligibility can be calculated using the&nbsp;home loan eligibility calculator.</p>\r\n\r\n<p>The benefits mentioned above means a lot. Home loan for women can give a greater relief to the borrower as it saves some cost related to homebuying and speed up the entire home loan approval process. It isn&#39;t only for these financial benefits but it also works as a great initiative towards women empowerment. So, if you&#39;re a woman and you&#39;re looking forward to invest in a property, fill yourself up with these knowledge and take good advantage of home loan for women scheme and give your dream of homebuying a wing.</p>\r\n', '16-August-2022', 'home-loans-for-women-and-their-benefits', 'In recent times women play an important role when you consider buying a home. A larger number of women today are taking up professional jobs and businesses and are no longer dependent on the male member of their family for their expenses. '),
(72, 'What is sellable area in Real Estate and guidelines for it', '2022-08-23 12:09:09', '2022-08-23 14:08:41', 1, '', 'Vizag', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, '', '<p><strong>buying a house</strong> any homebuyer would want the best of locations, and a house which has most of the basic amenities together with a great ambience. Inspection of the house and the parties involved and asking questions about it comes under the buyer&#39;s rights.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>What is Sellable Area?</strong></p>\r\n\r\n<p>According to the rules set by the RERA which stands for Real Estate Regulatory</p>\r\n\r\n<p>Authority, sellable areas include the carpet area plus the balcony/terrace/verandah which is exclusively meant for the allottee and which falls under the amenities offered plus the shared common areas together with any other area that is signed between the seller and buyer in the agreement of sale.</p>\r\n\r\n<p>Here, in India homebuyers come across real estate terms such as carpet area, built-up area, super built-up area, etc, which makes them rattled, which is why this blog will throw a light into what these terms mean and how are they different from each other.</p>\r\n\r\n<p><strong>A. Carpet Area</strong></p>\r\n\r\n<p>By the term itself it&#39;s easy to infer that carpet area is the entire area up on which your carpet can be laid. It is the complete flooring area including the area covered by the internal partition walls. Areas such as areas covered by external walls, balconies, open terraces, play areas, etc are not included in the carpet area. It is the net usable area in your home. You can calculate the carpet area of your house by using this formula</p>\r\n\r\n<p>Carpet Area = (bedroom area + living room + balconies + toilets)</p>\r\n\r\n<p><strong>B. Built-up Area</strong></p>\r\n\r\n<p>The built-up area includes the carpet area of the house together with the thickness of the internal partition walls, outer walls and the area of the balcony. The main difference between carpet area and built-up area is that it also includes unusable areas such as areas like balconies, terraces, flower beds, etc. Therefore built-up up area turns out to be larger than the carpet area. You can arrive at the count of built-up area through the given formula</p>\r\n\r\n<p>Built-up Area = Carpet Area +Area of Walls + Area of Balcony</p>\r\n\r\n<p><strong>C. Super Built-up Area</strong></p>\r\n\r\n<p>Super built-up area is also known as sellable area. It includes the carpet area of the housing unit, external walls, balconies, and terraces and also includes a lift, play areas, gardens, gymnasium, and other areas. In the past real estate brokers used to sell flats using super built-up area as the space measuring unit. The formula for calculating the super built-up area is the following:</p>\r\n\r\n<p>Super Built-up Area = Built-up Area + Proportionate Common Area</p>\r\n\r\n<p>Read the guidelines below to know of the RERA policies.</p>\r\n\r\n<p>According to the RERA Act, 70% money paid by the homebuyers will have to be kept safe in a separate account, which can be allotted to the builders only for construction purpose.</p>\r\n\r\n<p>The builders are required to submit the original copies of the property to the legal office authority.</p>\r\n\r\n<p>Earlier the builders could sell properties based on the super built-up area, but now after the RERA Act builders can sell properties based only on the carpet area.</p>\r\n\r\n<p>After a buyer purchases a property, it comes under the duties of the developers to rectify any issues that may surface within the first 5 years of purchase. If not they will be penalized. Also the regulator cannot advertise, sell, build, invest or book a plot without registering with the regulator. The authority will have jurisdiction over the land project when the real estate is registered with&nbsp;RERA Act.</p>\r\n\r\n<p>&quot; &gt;</p>\r\n\r\n<p>Buying a house has lately been one of the most challenging tasks for every home buyer. While <a href=\"https://eswarihomes.com/\"><strong>buying a house</strong></a> any homebuyer would want the best of locations, and a house which has most of the basic amenities together with a great ambience. Inspection of the house and the parties involved and asking questions about it comes under the buyer&#39;s rights.</p>\r\n\r\n<p><strong>What is Sellable Area?</strong></p>\r\n\r\n<p>According to the rules set by the RERA which stands for Real Estate Regulatory</p>\r\n\r\n<p>Authority, sellable areas include the carpet area plus the balcony/terrace/verandah which is exclusively meant for the allottee and which falls under the amenities offered plus the shared common areas together with any other area that is signed between the seller and buyer in the agreement of sale.</p>\r\n\r\n<p>Here, in India homebuyers come across real estate terms such as carpet area, built-up area, super built-up area, etc, which makes them rattled, which is why this blog will throw a light into what these terms mean and how are they different from each other.</p>\r\n\r\n<p><strong>A. Carpet Area</strong></p>\r\n\r\n<p>By the term itself it&#39;s easy to infer that carpet area is the entire area up on which your carpet can be laid. It is the complete flooring area including the area covered by the internal partition walls. Areas such as areas covered by external walls, balconies, open terraces, play areas, etc are not included in the carpet area. It is the net usable area in your home. You can calculate the carpet area of your house by using this formula</p>\r\n\r\n<p>Carpet Area = (bedroom area + living room + balconies + toilets)</p>\r\n\r\n<p><strong>B. Built-up Area</strong></p>\r\n\r\n<p>The built-up area includes the carpet area of the house together with the thickness of the internal partition walls, outer walls and the area of the balcony. The main difference between carpet area and built-up area is that it also includes unusable areas such as areas like balconies, terraces, flower beds, etc. Therefore built-up up area turns out to be larger than the carpet area. You can arrive at the count of built-up area through the given formula</p>\r\n\r\n<p>Built-up Area = Carpet Area +Area of Walls + Area of Balcony</p>\r\n\r\n<p><strong>C. Super Built-up Area</strong></p>\r\n\r\n<p>Super built-up area is also known as sellable area. It includes the carpet area of the housing unit, external walls, balconies, and terraces and also includes a lift, play areas, gardens, gymnasium, and other areas. In the past real estate brokers used to sell flats using super built-up area as the space measuring unit. The formula for calculating the super built-up area is the following:</p>\r\n\r\n<p>Super Built-up Area = Built-up Area + Proportionate Common Area</p>\r\n\r\n<p>Read the guidelines below to know of the RERA policies.</p>\r\n\r\n<p>According to the RERA Act, 70% money paid by the homebuyers will have to be kept safe in a separate account, which can be allotted to the builders only for construction purpose.</p>\r\n\r\n<p>The builders are required to submit the original copies of the property to the legal office authority.</p>\r\n\r\n<p>Earlier the builders could sell properties based on the super built-up area, but now after the RERA Act builders can sell properties based only on the carpet area.</p>\r\n\r\n<p>After a buyer purchases a property, it comes under the duties of the developers to rectify any issues that may surface within the first 5 years of purchase. If not they will be penalized. Also the regulator cannot advertise, sell, build, invest or book a plot without registering with the regulator. The authority will have jurisdiction over the land project when the real estate is registered with&nbsp;RERA Act.</p>\r\n', '23-August-2022', 'what-is-sellable-area-in-real-estate-and-guidelines-for-it', 'While buying a house any homebuyer would want the best of locations, and a house which has most of the basic amenities together with a great ambience.'),
(73, 'What is a Duplex House? And it’s Advantages', '2022-08-30 11:59:41', '2022-08-30 13:59:41', 1, '', 'Vizag', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, '', '<p>By the them duplex you must have figured out that it means double. When we talk about a duplex apartment we are talking about an apartment in which two rooms of different sizes are joined to make a single one. In a duplex apartment living and sleeping areas are clearly divided. The sleeping area is usually located on the upper floor and the lower floor will have areas depending on your requirements. It is a type of apartment which is specifically suitable for couples and singles who prefer living in a dynamic, private but spacious homes. It is almost like having two homes in one where the sleeping area is separated from the living area to protect your privacy.</p>\r\n\r\n<p>Therefore, those deciding to <strong><a href=\"https://eswarihomes.com/\">purchase duplex houses</a>,</strong> it is a two storey building with two separate complete apartments on two separate floors with a wall that&#39;s shared and central. The bedrooms will have separate entraces in these apartments.</p>\r\n\r\n<p>You must know why you should invest on a duplex apartment. For your knowledge we&#39;ve laid down the benefits or advantages of purchasing a duplex apartment.</p>\r\n\r\n<p>1. Privacy, today, is a thing hardly found and a thing that everyone is looking for. Those who are hard on privacy can go for duplex apartments since these apartments have a lot of space and the yard in it is divided into smaller sections to increase the privacy of the people living inside.</p>\r\n\r\n<p>2. Since duplex apartments have two separate floors, so you can easily give one floor for rent and generate monthly rental income and develop or build your wealth. This way you don&#39;t even lose your ownership of the property, nor do you lose the property, in fact you get the opportunity to earn some extra income.</p>\r\n\r\n<p>3. Even though duplex are luxury homes, yet they are not much expensive. You&#39;ll find many of them available at affordable prices in the neighborhood. So they are not as costly as they sound like.</p>\r\n\r\n<p>4. As duplex apartments have two buildings so more than one family can be accommodated in it. This way two families get to stay close to each other without interfering with each other&#39;s privacy.</p>\r\n\r\n<p>5. Unlike other flats duplex apartments have more living spaces. They also come with extensive gardens, yards, and garages that give you that spacious feeling of a luxury apartment.</p>\r\n', '30-August-2022', 'what-is-a-duplex-house-and-its-advantages', 'those deciding to purchase duplex houses, it is a two storey building with two separate complete apartments on two separate floors with a wall thats shared and central. '),
(74, 'Real Estate Terms That You Must Be Familiar With', '2022-09-06 10:34:12', '2022-09-06 12:34:12', 1, '', 'Vizag', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, '', '<p>If you&#39;re from the young generation you sure will have a tough time understanding all the task estate terms when you try to look for properties to buy. Thus, here is a glossary of basic and essential real estate terms that you must be familiar with as a home buyer.</p>\r\n\r\n<p><strong>Appraisal</strong></p>\r\n\r\n<p>An appraisal is the process in which the real estate and all its features is evaluated in order to come up with a value of that property. The property can be residential, commercial or industrial. An appraisal is normally performed by a professional appraiser who is trained to provide their opinion as to the value of the real estate and its building. The appraisal report that&#39;s provided is then used by the banks who depending on it determines how much they will lend a person for the property. If the value of the real estate is appraised lower than the amount requested for a loan to purchase the property then the buyer will have to come up with more money out of their own pocket, the seller can reduce the selling price or depending on the terms of the contract the deal can be cancelled.</p>\r\n\r\n<p><strong>Buyer Agent</strong></p>\r\n\r\n<p><a href=\"https://eswarihomes.com/\"><strong>Buyer agent</strong></a> is a licensed real estate sales agent who exclusively represents the buyers in a real estate transaction.</p>\r\n\r\n<p><strong>Contract</strong></p>\r\n\r\n<p>Contract is a legal agreement between two or more parties. The agreement instructs the parties to perform a certain way. The contract must be for a legal purpose and the parties who are signing the contract must be legally be able to enter into that contract. It is always recommended that you as the seller or buyer read through the entire contract you are signing. &nbsp;While you may have a professional assisting you with the transaction ultimately you are the one signing on the bottom line and legally obligating yourself to perform in a certain manner. &nbsp;If you have any questions about the terms of the contract you should ask your real estate agent or consult with an attorney who specializes in real estate transactions.</p>\r\n\r\n<p><strong>Closing</strong></p>\r\n\r\n<p>Closing is the process in which the property that is being sold is transferred to the new owner. The transfer usually takes place after all financing, valuation, inspections are done. The seller and buyer will sign paperwork related to the new and old mortgages and also sign paperwork to transfer the title of the property into the new owners name. &nbsp;After the closing is done the title company that is involved in the closing process will have the new deed recorded with the County government.</p>\r\n\r\n<p><strong>Home Inspection</strong></p>\r\n\r\n<p>A home inspection is an education process for the client. &nbsp;The goal of a home inspection is not to see what the buyer will pay for or to fix items that may need repair. A home inspection is designed to inform buyer of everything discovered in the home in order to give the buyer a better understanding of the home and it&#39;s components, how to maintain and take care of the home, and to help the buyer have a better idea on whether or not they wish to proceed with the home purchase.</p>\r\n\r\n<p>A home inspector will never tell a buyer whether they should buy the home or not. A home inspection is the process whereby a home inspector will examine a home and all its major components to determine the quality of the components and also the home inspector will provide estimates of longevity and usefulness of the components. &nbsp;Home inspections can be performed on existing homes and on new construction homes.</p>\r\n', '06-September-2022', 'real-estate-terms-that-you-must-be-familiar-with', 'Thus, here is a glossary of basic and essential real estate terms that you must be familiar with as a home buyer.'),
(75, 'Tips To Help You Purchase Your First Home', '2022-09-13 14:02:28', '2022-09-13 16:02:28', 1, '', 'Vizag', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, '', '<p>Today the real estate market is one that seem to be present literally everywhere, given its demand lately. Regardless of where you live,&nbsp;first-time home ownership&nbsp;can be an attainable goal with the right research and advance planning. Here are some smart financial moves and <a href=\"https://eswarihomes.com/\"><strong>home purchasing tips</strong></a> you can follow up today to be on the right path to homeownership.</p>\r\n\r\n<p><strong>1. Start Saving Early</strong></p>\r\n\r\n<p>Saving is an important part of your homebuying journey. Without saving you wouldn&#39;t go ahead in your homebuying journey. Here are the important costs to consider when saving for a home:</p>\r\n\r\n<p>Down payment: Your down payment requirement will depend on the type of mortgage you choose and the lender. Some conventional loans aimed at first-time home buyers with excellent credit require as little as 3% down. But even a small down payment can be challenging to save.</p>\r\n\r\n<p>Closing costs: These are the fees and expenses you pay to finalize your mortgage, and they typically range from 2% to 5% of the loan amount. That&rsquo;s additional money you&rsquo;d have to pay, on top of your down payment. In a buyer&#39;s market, you can often ask the seller to pay a portion of your closing costs, and you can save on some expenses, such as home inspections, by shopping around.</p>\r\n\r\n<p>Move-in expenses: You&#39;ll need some cash after the home purchase. Set some money aside for immediate home repairs, upgrades and furnishings.</p>\r\n\r\n<p><strong>2. Check and strengthen your credit</strong></p>\r\n\r\n<p>Your credit score will determine whether you qualify for a mortgage and affect the interest rate lenders will offer. Having a higher score will generally get you a lower interest rate. Pay all your bills on time, and keep credit card balances as low as possible to maintain a good credit score.</p>\r\n\r\n<p><strong>3. Decide how much home you can afford</strong></p>\r\n\r\n<p>Figure out how much you can safely spend on a house before starting to shop. ESWARI HOME&#39;s home affordability calculator can help with setting a price range based on your income, debt, down payment, credit score and where you plan to live.</p>\r\n\r\n<p><strong>4. Pick the right type of house and neighborhood</strong></p>\r\n\r\n<p>Weigh the pros and cons of different types of homes, given your lifestyle and budget. A condominium or townhome may be more affordable than a single-family home, but shared walls with neighbors will mean less privacy. Don&#39;t forget to budget for homeowners association fees when shopping for condos and townhomes, or houses in planned or gated communities.</p>\r\n\r\n<p>Research potential neighborhoods thoroughly. Choose one with amenities that are important to you, including schools and entertainment options, and test out the commute to work during rush hour.</p>\r\n\r\n<p><strong>5. Stick to your budget</strong></p>\r\n\r\n<p>A lender may offer to loan you more than what is comfortably affordable, or you may feel pressure to spend outside your comfort zone to beat another buyer&rsquo;s offer. To avoid financial stress down the road, set a price range based on your budget, and then stick to it. In a competitive market, consider looking at properties below your price limit. In a buyer&#39;s market, you may be able to view homes a bit above your limit. Your real estate agent can suggest a range for your offering price.</p>\r\n', '13-September-2022', 'tips-to-help-you-purchase-your-first-home', 'Today the real estate market is one that seem to be present literally everywhere, given its demand lately'),
(76, 'What are Apartment Amenities?', '2022-09-20 10:40:52', '2022-09-20 12:40:52', 1, '', 'Vizag', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, '', '<p>The first thing that homebuyers look for when buying a home is the number of bedrooms. But as the search goes deeper they&#39;ll look for amenities that really matter to them and their families. These amenities may include distance from public transportation, if the units are pet-friendly, what all the apartment has to offer and many more things. Even though these are deal breakers there will also be rundown of apartment amenities.</p>\r\n\r\n<p><strong>Apartment Amenities</strong></p>\r\n\r\n<p>Apartment amenities are amenities that you can do without, but you want them or prefer them because they make life more productive, easier, and joyous. These are not the basic amenities that you should have everywhere as a necessity. These are what the developers offer as a bonus to make the deal or choice more appealing for you.</p>\r\n\r\n<p>When you are <strong><a href=\"https://eswarihomes.com/\">building your dream apartment</a> </strong>or on an apartment hunt, prioritize the amenities that suits your lifestyle the most. Think about what will make your living in the apartment more pleasant without utilizing much of your money. If you are a gym lover, a gym in the building would be one of the best things for you. If swimming is what you love, a swimming pool would be one of the best assets you can have in the building.</p>\r\n\r\n<h3><strong>Kinds Of Apartment Amenities</strong></h3>\r\n\r\n<p><strong>1. Transportation and Parking Amenities</strong></p>\r\n\r\n<p>When choosing a new apartment, most people will pay close attention to transportation options. While it&rsquo;s nice to know the apartment is close to a subway or bus stop, that would only be helpful for someone who commutes on public transportation. For those who have a car, amenities such as on-site garages, covered parking, or assigned parking spaces are much more appealing.</p>\r\n\r\n<p><strong>2. Pet Amenities</strong></p>\r\n\r\n<p>If pets are welcome in a building, how those pets are treated and cared for once on the property could be considered an amenity.&nbsp;</p>\r\n\r\n<p><strong>3. Common Apartment Amenities</strong></p>\r\n\r\n<p>Available amenities will depend on location, the demographics of the city or region, and what kind of residents the owner is hoping to attract. Where it&rsquo;s generally warmer, a pool or a shaded rooftop are probably a lot more appealing. While office space may be great in building catering to young professionals, a play area or childcare may be more appealing to the family set.</p>\r\n\r\n<p><strong>4. Building Amenities</strong></p>\r\n\r\n<p>Having elevator access, a doorman, or a designated package room are all amenities people will appreciate to varying degrees, depending on their lifestyle.&nbsp;</p>\r\n\r\n<p><strong>5. Community Amenities</strong></p>\r\n\r\n<p>An on-site gym or fitness center, a pool, and even a playground or community center all help residents feel more at-home and comfortable in a building. Whether there&rsquo;s a shared outdoor grilling space for cookouts, a multi-purpose room that can be reserved for parties and meetings, or a library and media room that can be used for studying or working from home, amenities make living in a building better.</p>\r\n', '20-September-2022', 'what-are-apartment-amenities', 'The first thing that homebuyers look for when buying a home is the number of bedrooms.');

-- --------------------------------------------------------

--
-- Table structure for table `blog_images`
--

CREATE TABLE `blog_images` (
  `id` int(11) NOT NULL,
  `property_id` int(11) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `uploaded_on` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `blog_images`
--

INSERT INTO `blog_images` (`id`, `property_id`, `file_name`, `uploaded_on`) VALUES
(12, 0, 'Ground-to-Kanal.png', '2021-02-01 06:24:29'),
(13, 0, 'Convert-Ares-to-Square-Feet-1.png', '2021-02-01 06:54:15'),
(14, 0, 'Guntha-to-Acre.png', '2021-02-01 06:59:07'),
(15, 0, 'Ground-to-Square-Yards-Unit-Conversion.png', '2021-02-01 07:01:50'),
(16, 1, '1112.jpeg', '2021-02-10 06:32:33'),
(17, 2, '29.jpeg', '2021-02-16 08:49:26'),
(21, 6, '123.jpeg', '2021-03-05 09:07:02'),
(22, 7, '1603.jpeg', '2021-03-16 07:11:45'),
(23, 8, '12345.jpeg', '2021-04-06 09:23:02'),
(25, 10, '12321.jpeg', '2021-04-17 09:51:14'),
(27, 12, '11231.jpeg', '2021-04-27 10:39:56'),
(28, 13, '1212.jpeg', '2021-05-03 14:23:55'),
(29, 14, '1322.jpeg', '2021-05-12 09:12:33'),
(30, 15, '1222.jpeg', '2021-05-19 14:56:08'),
(31, 16, '1563.jpeg', '2021-05-26 14:32:02'),
(32, 17, '12221.jpeg', '2021-06-02 14:22:21'),
(33, 18, '1667.jpeg', '2021-07-07 13:04:15'),
(34, 19, '12222.jpeg', '2021-08-16 16:17:44'),
(35, 20, '1987.jpeg', '2021-08-28 13:16:35'),
(36, 21, '1455.jpeg', '2021-09-04 09:54:28'),
(37, 22, '1333.jpeg', '2021-09-09 16:12:18'),
(38, 23, '1454.jpeg', '2021-09-15 10:13:45'),
(39, 24, '1666.jpeg', '2021-09-20 13:25:45'),
(40, 25, '08102021.jpeg', '2021-10-08 07:24:23'),
(41, 26, 'eswarihomes1.jpeg', '2021-10-18 06:04:37'),
(42, 27, 'eswarihomes2.jpeg', '2021-10-21 09:32:05'),
(43, 28, 'eswarihomes3.jpeg', '2021-11-06 11:16:42'),
(44, 29, 'eswarihomes4.jpeg', '2021-11-09 07:30:49'),
(45, 30, 'eswarihomes5.jpeg', '2021-11-16 11:11:10'),
(46, 31, 'eswarihomes7.jpeg', '2021-11-24 11:27:44'),
(47, 32, 'eswarihomes9.jpeg', '2021-11-30 10:23:51'),
(48, 33, 'eswarihomes10.jpg', '2021-12-07 11:49:37'),
(49, 34, 'eswarihomes11.jpg', '2021-12-14 10:39:16'),
(50, 35, 'eswarihomes12.jpg', '2021-12-21 13:10:58'),
(51, 36, 'eswarihomes13.jpg', '2021-12-28 13:21:04'),
(53, 38, 'eswarihomes15.jpg', '2022-01-04 12:37:20'),
(54, 39, 'eswarihomes16.jpg', '2022-01-11 13:27:59'),
(55, 40, 'eswarihomes18.jpg', '2022-01-18 11:40:07'),
(56, 41, 'eswarihomes20.jpg', '2022-01-25 10:13:25'),
(57, 42, 'eswarihomes22.jpg', '2022-02-01 11:50:34'),
(58, 43, 'eswarihomes23.jpg', '2022-02-08 10:44:11'),
(59, 44, 'eswarhomes24.jpg', '2022-02-15 11:55:51'),
(60, 45, 'eswarhomes25.jpg', '2022-02-22 12:06:53'),
(61, 46, 'eh27.jpg', '2022-03-01 12:50:51'),
(63, 48, 'eswarihomes28.jpg', '2022-03-08 09:47:56'),
(64, 49, 'eswarihomes30.jpg', '2022-03-15 11:55:52'),
(65, 50, 'eswarihomes31.jpg', '2022-03-22 12:43:03'),
(66, 51, 'eswarihomes32.jpg', '2022-03-29 12:37:30'),
(67, 52, 'eswarihomes40.jpg', '2022-04-05 13:08:44'),
(68, 53, 'eswarihomes41.jpg', '2022-04-12 13:18:42'),
(69, 54, 'eswarihomes43.jpg', '2022-04-19 11:45:23'),
(70, 55, 'eswarihomes44.jpg', '2022-04-26 10:48:48'),
(71, 56, 'eswarihomes45.jpg', '2022-05-03 10:55:36'),
(72, 57, 'eswarihomes46.jpg', '2022-05-10 12:33:08'),
(73, 58, 'eswarihomes48.jpg', '2022-05-17 10:24:52'),
(74, 59, 'eswarihomes49.jpg', '2022-05-24 10:57:33'),
(75, 60, 'eswarihomes50.jpg', '2022-05-31 10:12:13'),
(76, 61, 'eswarihomes51.jpg', '2022-06-07 12:58:55'),
(77, 62, 'eswarihomes52.jpg', '2022-06-14 12:05:42'),
(78, 63, 'eswarihomes53.jpg', '2022-06-21 11:08:31'),
(79, 64, 'eswarihomes54.png', '2022-06-28 12:04:04'),
(80, 65, 'eswarihomes55.jpg', '2022-07-05 12:52:20'),
(81, 66, 'eswarihomes56.jpg', '2022-07-12 12:39:21'),
(82, 67, 'eh19.jpg', '2022-07-19 13:44:24'),
(83, 68, 'eh90.jpg', '2022-07-26 13:48:24'),
(84, 69, 'eh85.jpg', '2022-08-02 14:56:42'),
(85, 70, 'eswarihomes60.jpeg', '2022-08-09 12:46:52'),
(86, 71, 'eswarihomes61.jpg', '2022-08-16 12:38:28'),
(87, 72, 'eh99.jpg', '2022-08-23 14:04:27'),
(88, 73, 'eswarihomes63.jpg', '2022-08-30 13:59:42'),
(89, 74, 'eswarihomes65.jpg', '2022-09-06 12:34:13'),
(90, 75, 'eswarihomes66.jpg', '2022-09-13 16:02:28'),
(91, 76, 'eswarihomes70.jpg', '2022-09-20 12:40:52');

-- --------------------------------------------------------

--
-- Table structure for table `bookingproject`
--

CREATE TABLE `bookingproject` (
  `id` int(11) NOT NULL,
  `project_name` varchar(255) NOT NULL,
  `location` varchar(100) NOT NULL,
  `flatno` varchar(100) NOT NULL,
  `block` varchar(100) NOT NULL,
  `floor` varchar(100) NOT NULL,
  `area` varchar(100) NOT NULL,
  `total_sqft` varchar(100) NOT NULL,
  `price_sqft` varchar(100) NOT NULL,
  `floor_rise_charges` varchar(100) NOT NULL,
  `amentities_charges` varchar(100) NOT NULL,
  `project_description` text NOT NULL,
  `am` varchar(255) NOT NULL,
  `rm` varchar(255) NOT NULL,
  `manager` varchar(255) NOT NULL,
  `flat_plot_cost` varchar(100) NOT NULL,
  `amentities` varchar(100) NOT NULL,
  `corpus_fund` varchar(100) NOT NULL,
  `maintenance_charges` varchar(100) NOT NULL,
  `stamp_duty` varchar(100) NOT NULL,
  `gst` varchar(100) NOT NULL,
  `documentation_legal_charges` varchar(100) NOT NULL,
  `reg_misc_charges` varchar(100) NOT NULL,
  `flat_plot_cost_total` varchar(100) NOT NULL,
  `reg_expenses_total` varchar(100) NOT NULL,
  `added_by` int(11) NOT NULL,
  `added_on` varchar(20) NOT NULL,
  `date_id` varchar(20) NOT NULL,
  `project_status` varchar(20) NOT NULL,
  `bm` int(11) NOT NULL,
  `first_applicant_name` varchar(255) NOT NULL,
  `first_applicant_mobile_num` varchar(55) NOT NULL,
  `first_applicant_email` varchar(100) NOT NULL,
  `second_applicant_name` varchar(255) NOT NULL,
  `second_applicant_mobile_num` varchar(55) NOT NULL,
  `second_applicant_email` varchar(100) NOT NULL,
  `verification` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bookingproject`
--

INSERT INTO `bookingproject` (`id`, `project_name`, `location`, `flatno`, `block`, `floor`, `area`, `total_sqft`, `price_sqft`, `floor_rise_charges`, `amentities_charges`, `project_description`, `am`, `rm`, `manager`, `flat_plot_cost`, `amentities`, `corpus_fund`, `maintenance_charges`, `stamp_duty`, `gst`, `documentation_legal_charges`, `reg_misc_charges`, `flat_plot_cost_total`, `reg_expenses_total`, `added_by`, `added_on`, `date_id`, `project_status`, `bm`, `first_applicant_name`, `first_applicant_mobile_num`, `first_applicant_email`, `second_applicant_name`, `second_applicant_mobile_num`, `second_applicant_email`, `verification`) VALUES
(1, 'Aditya hill view', 'Vizag', '12', 'A', '1', 'Madhurawada', '4000', '4000', '-', '-', 'test', '21', '28', '56', '-', '-', '-', '--', '-', '-', '-', '-', '-', '-', 56, '15-03-2022', '2022021501', 'Booking', 51, 'chandu', '910402325', 'ch@gmail.com', 'jo', '908908090', 'jo@gmail.com', 'Verified'),
(2, '96', 'Vizag', '12', 'A', '2', 'Gajuwaka', '2100', '3500', '-', '-', '-', '21', '28', '56', '-', '-', '-', '-', '-', '2%', '-', '-', '-', '-', 21, '15-04-2022', '2022041502', 'Booking', 51, 'chandrashekher', '70989809890', 'chandhu418@gmail.com', 'jo', '8098098098', 'jo@gmail.com', 'Verified');

-- --------------------------------------------------------

--
-- Table structure for table `careers`
--

CREATE TABLE `careers` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phno` varchar(20) NOT NULL,
  `content` text NOT NULL,
  `resume` text NOT NULL,
  `applied_on` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `careers`
--

INSERT INTO `careers` (`id`, `name`, `email`, `phno`, `content`, `resume`, `applied_on`) VALUES
(1, 'chandu v', 'chandhu418@gmail.com', '+919010402324', 'test', '', ''),
(2, 'chandu v', 'chandhu418@gmail.com', '+919010402324', 'test', 'Chandu_Resume.docx', ''),
(3, 'vcsrao', 'chandhu418@gmail.com', '+919010402324', 'test3', 'Chandu_Resume1.docx', '01-10-2021');

-- --------------------------------------------------------

--
-- Table structure for table `cities`
--

CREATE TABLE `cities` (
  `id` int(11) NOT NULL,
  `city` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cities`
--

INSERT INTO `cities` (`id`, `city`) VALUES
(1, 'Hyderabad'),
(2, 'Vizag'),
(3, 'Vijayawada'),
(4, 'Bangalore'),
(5, 'Rajahmundry');

-- --------------------------------------------------------

--
-- Table structure for table `contactus`
--

CREATE TABLE `contactus` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phno` varchar(20) NOT NULL,
  `content` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `contactus`
--

INSERT INTO `contactus` (`id`, `name`, `email`, `phno`, `content`) VALUES
(31, 'chandu', 'chandhu418@gmail.com', '9010402324', 'hiii'),
(32, 'Anil_Kumar ', 'psr_berhampur@rediffmail.com', '9437014236', ''),
(33, 'RAKESH KUMAR', 'krakesh6k@gmail.com', '09703011553', 'Required flats'),
(34, '9441095950 Sai', 'nootansai@gmail.com', '9441095950', '\r\n\r\n'),
(35, 'Usha', 'ushachintala3@gmail.com', '8985592334', ''),
(36, 'Usha', 'ushachintala3@gmail.com', '8985592334', ''),
(37, 'P M V Jaya Lakshmi', 'pathisavithri5@gmail.com', '9912559584', ''),
(38, 'P M V Jaya Lakshmi', 'pathisavithri5@gmail.com', '9912559584', 'GVMC '),
(39, 'P Divya', 'pathisavithri5@gmail.com', '9912559584', ''),
(40, 'P M V Jaya Lakshmi', 'pathisavithri5@gmail.com', '7997549111', ''),
(41, 'Resapu Niramala', 'resapu.nirmala@gmail.com', '9989435657', 'Total flat cost'),
(42, 'Mahesh yerukamajji', 'yerukumajjimahesh@gmail.com', '7702198082', 'Accounts executive job'),
(43, 'Test name', 'test@gmail.com', '9010402324', 'Hiiii8'),
(44, 'test2', 'test2@gmail.com', '9010402325', 'test test'),
(45, 'Valli', 'vallipeela@gmail.com', '9290484799', ''),
(46, 'Valli', 'vallipeela@gmail.com', '9290484799', ''),
(47, 'CH PRASAD RAO', 'chiprao@gmail.com', '09515961779', '530016'),
(48, 'Shaik Emamuddin', 'emam.bom@gmail.com', '7558581390', ''),
(49, 'Kgr varma', 'varmaganesh_1955@yahoo.co.in', '9650152741', 'Want 2bhk or 3bhk either in seethammadhara or madhurawada'),
(50, 'Santosh', '', '8073506191', ''),
(51, 'PRASAD Gvvs ', 'prasadgunnam9009@gmail.com', '9440999009', '3bhk '),
(52, 'SIX7A6EJROA4QBZS1S51HXIS http://mail.com/708', 'elainewilde29174400@gmail.com', 'elainewilde29174400@', ''),
(53, 'Uma lakshmi', '', '9848333137', ''),
(54, 'Uma lakshmi', '', '9848333137', ''),
(55, 'SOUMYA RANJAN ROUT', 'soumya.ctk@gmail.com', '08297092555', '530017'),
(56, 'B Neelkanth Bhavani Prasad', 'sirineel60@yahoo.com', '8878878639', ''),
(57, 'B sarita ', 'billasarita77@gmail.com', '96184 40650 ', '530003'),
(58, 'Sarita ', 'billasarita77@gmail.com', '96184 40650 ', '52\r\n530003'),
(59, 'Sarita ', 'billasarita77@gmail.com', '96184 40650 ', '530003'),
(60, 'Tushar Agarwal', '', '9052377110', ''),
(61, 'sudharsana', 'sudhafin@yahoo.com', '9701699725', 'looking for fat'),
(62, 'Natalie Jones', 'natalie_jones@homeownerbliss.info', '3033586531', 'Hello!\r\n\r\nI\'ve got a great article idea that could benefit first-time investors. My hope is that if I wrote it up, you\'ll share it on your website.\r\n\r\nThe piece will include tips and advice on what steps to take when buying your first investment property and how best to manage it. Additionally, I will include a mention of your website (feel free to send me a specific link you\'d like to see included).\r\n\r\nWould you be interested in taking a look at the finished piece? It\'s free!\r\n\r\nThank you!\r\nNatalie\r\n\r\n\r\nNatalie Jones\r\nnatalie_jones@homeownerbliss.info'),
(63, 'Natalie Jones', 'natalie_jones@homeownerbliss.info', '3033586531', 'Hello!\r\n\r\nI\'ve got a great article idea that could benefit first-time investors. My hope is that if I wrote it up, you\'ll share it on your website.\r\n\r\nThe piece will include tips and advice on what steps to take when buying your first investment property and how best to manage it. Additionally, I will include a mention of your website (feel free to send me a specific link you\'d like to see included).\r\n\r\nWould you be interested in taking a look at the finished piece? It\'s free!\r\n\r\nThank you!\r\nNatalie\r\n\r\n\r\nNatalie Jones\r\nnatalie_jones@homeownerbliss.info'),
(64, 'KIREETI', 'tkvskireeti@gmail.com', '8897853568', 'I am interested in buying 2bhk appartments in Yendada / PM Palem'),
(65, 'Raj', 'rajsurcommon@gmail.com', '+1-804.404.3221', 'Brand New 3 BHK Flat (LAWSON\'S BAY COLONY). What is the Project name. Any 3 BHK flats available? If yes, price and Possession date please'),
(66, 'Kumar', 'k.kondeti@gmail.com', '7780696827', ''),
(67, 'fgfjhkhlkllopp https://google.com dgdgd', 'aleksandrf2mak@inbox.ru', 'aleksandrf2mak@inbox', ''),
(68, 'Sanjay Goyal', 'skg12031977@gmail.com', '08885583631', '530004'),
(69, 'Sanjay Goyal', 'skg12031977@gmail.com', '08885583631', '530004'),
(70, 'Sanjay Goyal', 'skg12031977@gmail.com', '08885583631', '530004'),
(71, 'Sanjay ', 'skg12031977@gmail.com', '8074516687', '530004'),
(72, 'Sanjay ', 'skg12031977@gmail.com', '8074516687', '530004'),
(73, 'Sanjay', 'skg12031977@gmail.com', '8885583631 ', '530020'),
(74, 'Potnuru satish kumar', 'vynavisai@gmail.com', '9505399526', '532460'),
(75, 'Potnuru satish kumar', 'vynavisai@gmail.com', '9505399526', '9948334242'),
(76, 'Pallavi ', 'rnujella@hotmail.com', '9030022572', 'Interested'),
(77, 'KALYAN', 'INFO@ESWARIGROUP.COM', '8374631133', 'HI'),
(78, 'Potnuru satish kumar', 'vynavisai@gmail.com', '9505399526', ''),
(79, 'Vidyavathi ', '', '9440223596', ''),
(80, 'Vidyavathi ', '', '9440223596', ''),
(81, 'Mike Blare\r\n', 'cavincarmin32@gmail.com\r\n', 'tauer7732@gmail.com\r', 'Hi there \r\n \r\nI have just checked  eswarihomes.com for its SEO Trend and saw that your website could use a push. \r\n \r\nWe will improve your SEO metrics and ranks organically and safely, using only whitehat methods, while providing monthly reports and outstanding support. \r\n \r\nPlease check our services below, we offer SEO at cheap rates. \r\nhttps://www.hilkom-digital.de/cheap-seo-packages/ \r\n \r\nStart improving your sales and leads with us, today! \r\n \r\nregards \r\nMike Blare\r\n \r\nHilkom Digital Team \r\nsupport@hilkom-digital.de'),
(82, 'ravi', 'deegenco@gmail.com', '7893472066', ''),
(83, 'Jacques Olsson', 'erythroxylum.coca.seeds@gmail.com', 'erythroxylum.coca.se', 'We sell Research Chemicals, Cocaine, Coca Seeds, Coca Leaves, Coca Powder, Marijuana, Weed, Cannabis, Opioids, Ecstasy Pills, Pain Relief, HGH/HCG, Nembutal Pentobarbital, Blotters, Hashish, Heroin, we can be a solution to both Hard and Soft drugs, legal and illegal drugs. Guns for self protection and family protection as well with best prices. \r\n \r\nMinimum order 100€ \r\n \r\nFree shipping for order over 300€ \r\n \r\nDiscreet packaging. \r\n \r\nOvernight shipping with DHL, TNT, UPs or others tracking number \r\n \r\nWe ship worldwide. \r\n \r\nDelivery in EU 1-3 days and other countries out of EU 2-4 days. \r\n \r\nWe ship and e-mail you tracking number and shipping company name \r\n \r\nOur packaging being totally discrete and most secure, vacuum sealed and air tight, no custom problem as per shipment, totally safe purchase and MONEY BACK GUARANTEE if you are not satisfied with our quality or failure to get there. \r\n \r\n100% Customer Satisfaction Guaranteed. \r\n \r\nYour personal details are 1000% SECURE. \r\n \r\nYour orders are 1000% Secure and Anonymous. \r\n \r\nPayment: Western Union, MoneyGram, Bank Transfer, Bitcoin, Paypal Etc \r\n \r\nEmail: sales@bundesdrugsonline.com \r\nWhatsapp: +4915218246599 \r\nTele: +4915217748777 \r\nWebsite: https://bundesdrugsonline.com'),
(84, 'BHARGAV KUMAR PALEPU', 'bhargav.cena99@gmail.com', '9959350000', '531024'),
(85, 'test by chandu', 'testmail@gmail.com', '9010402324', 'test by chandu develeoper'),
(86, 'JamesAbiny', 'no-replykalace@gmail.com', 'no-replykalace@gmail', 'Hi!  eswarihomes.com \r\n \r\nDo you know the easiest way to mention your products or services? Sending messages through feedback forms can enable you to simply enter the markets of any country (full geographical coverage for all countries of the world).  The advantage of such a mailing  is that the emails that may be sent through it\'ll find yourself within the mailbox that\'s supposed for such messages. Causing messages using Feedback forms isn\'t blocked by mail systems, which suggests it is guaranteed to reach the recipient. You\'ll be ready to send your provide to potential customers who were previously unprocurable thanks to email filters. \r\nWe offer you to test our service for complimentary. We are going to send up to fifty thousand message for you. \r\nThe cost of sending one million messages is us $ 49. \r\n \r\nThis offer is created automatically. Please use the contact details below to contact us. \r\n \r\nContact us. \r\nTelegram - @FeedbackMessages \r\nSkype  live:contactform_18 \r\nWhatsApp - +375259112693 \r\nWe only use chat.'),
(87, 'SEO X Press Digital Agency', 'denisesupe32@gmail.com\r\n', 'moenchcarly32@gmail.', 'Hi there \r\n \r\n \r\nI have just verified your SEO on  eswarihomes.com for its SEO Trend and saw that your website could use a push. \r\n \r\n \r\nWe will increase your Ranks organically and safely, using only whitehat methods, \r\n \r\n \r\nIf interested, please email us \r\n \r\nsupport@digital-x-press.com \r\n \r\n \r\nregards \r\nMike Coleman\r\n \r\nSEO X Press Digital Agency \r\nhttps://www.digital-x-press.com'),
(88, 'Mike Jerome\r\n', 'stairsmargre32@gmail.com\r\n', 'joaniecm32@gmail.com', 'Hi there \r\n \r\nDo you want a quick boost in ranks and sales for your eswarihomes.com website? \r\nHaving a high DA score, always helps \r\n \r\nGet your eswarihomes.com to have a DA between 50 to 60 points in Moz with us today and rip the benefits of such a great feat. \r\n \r\nSee our offers here: \r\nhttps://www.monkeydigital.co/product/moz-da50-seo-plan/ \r\n \r\nNEW: \r\nhttps://www.monkeydigital.co/product/ahrefs-dr60/ \r\n \r\n \r\nthank you \r\nMike Jerome\r\n \r\nsupport@monkeydigital.co'),
(89, 'Mike Shorter\r\n', 'johnelgin7162@gmail.com\r\n', 'michaelmatthews7162@', 'Howdy \r\n \r\nWe will enhance your Local Ranks organically and safely, using only whitehat methods, while providing Google maps and website offsite work at the same time. \r\n \r\nPlease check our pricelist here, we offer Local SEO at cheap rates. \r\nhttps://speed-seo.net/product/local-seo-package/ \r\n \r\nNEW: \r\nhttps://www.speed-seo.net/product/zip-codes-gmaps-citations/ \r\n \r\nregards \r\nMike Shorter\r\n \r\nSpeed SEO Digital Agency'),
(90, 'Santosh', 'santoshpotnuru66@gmail.com', '8919920092', 'Requirement for New Flats North/ East Facing 1st or 2nd Floor in Vizag'),
(91, 'pawan', 'pawanrx8@gmail.com', '9133489911', ' Looking to purchase flat in madhurwada'),
(92, 'Mike Young\r\n', 'lawerencemartineau7162@gmail.com\r\n', 'idahernandez3262@gma', 'Greetings \r\n \r\nI have just took a look on your SEO for  eswarihomes.com for its SEO metrics and saw that your website could use a push. \r\n \r\nWe will enhance your SEO metrics and ranks organically and safely, using only whitehat methods, while providing monthly reports and outstanding support. \r\n \r\nPlease check our plans here, we offer SEO at cheap rates. \r\nhttps://www.hilkom-digital.de/cheap-seo-packages/ \r\n \r\nStart enhancing your sales and leads with us, today! \r\n \r\nregards \r\nMike Young\r\n \r\nHilkom Digital Team \r\nsupport@hilkom-digital.de'),
(93, 'David Song', 'noreply@googlemail.com', 'noreply@googlemail.c', 'Dear Sir/Madam, \r\nThis is a consultancy and brokerage Firm specializing in Growth Financial Loan. We wish to invest in any viable Project presented by your Management after reviews on your Business Project Presentation Plan. We look forward to your Swift response. \r\nEmail:davidsong2030@gmail.com. \r\n \r\nRegards, \r\nMr.David Song'),
(94, 'Tommy Abels', 'officeline8400@gmail.com', 'officeline8400@gmail', 'Hello, I am a Senior Financial Strategist. I have a client who has an interest in Investing in your country into a Joint Venture / Partnership. He has funds available meant for investment. \r\n \r\nPlease contact me if you are interested. \r\n \r\nRegards, \r\nTommy Abels \r\nSenior Financial Strategist \r\n \r\nReply to Email: officeline9600@gmail.com'),
(95, 'Mike Phillips\r\n', 'abelsolis7162@gmail.com\r\n', 'kevencoleman7162@gma', 'Hi there \r\n \r\nDo you want a quick boost in ranks and sales for your eswarihomes.com website? \r\nHaving a high DA score, always helps \r\n \r\nGet your eswarihomes.com to have a DA between 50 to 60 points in Moz with us today and rip the benefits of such a great feat. \r\n \r\nSee our offers here: \r\nhttps://www.monkeydigital.co/product/moz-da50-seo-plan/ \r\n \r\nNEW: \r\nhttps://www.monkeydigital.co/product/ahrefs-dr60/ \r\n \r\n \r\nthank you \r\nMike Phillips\r\n \r\nsupport@monkeydigital.co'),
(96, 'SEO X Press Digital Agency', 'no-replykalace@gmail.com', 'no-replykalace@gmail', 'Hello \r\n \r\nWe all know the importance that dofollow link have on any website`s ranks. \r\nHaving most of your linkbase filled with nofollow ones is of no good for your ranks and SEO metrics. \r\n \r\nBuy quality dofollow links from us, that will impact your ranks in a positive way \r\nhttps://www.digital-x-press.com/product/150-dofollow-backlinks/ \r\n \r\nBest regards \r\nMike Sheldon\r\n \r\nsupport@digital-x-press.com'),
(97, 'gopal', 'vgrauto6789@gmail.com', '9618119380', 'we have VMRDA approved lay out in vizianagaram. We planning to sell a plots i.aif any promoters were interested please to contact '),
(98, 'Mike Nicholson\r\n', 'robertramirez7162@gmail.com\r\n', 'johnelgin7162@gmail.', 'Hi \r\n \r\nWe will enhance your Local Ranks organically and safely, using only whitehat methods, while providing Google maps and website offsite work at the same time. \r\n \r\nPlease check our services below, we offer Local SEO at cheap rates. \r\nhttps://speed-seo.net/product/local-seo-package/ \r\n \r\nNEW: \r\nhttps://www.speed-seo.net/product/zip-codes-gmaps-citations/ \r\n \r\nregards \r\nMike Nicholson\r\n \r\nSpeed SEO Digital Agency'),
(99, 'K Sunny', 'sunny.noel96@gmail.com', '8897745423', 'i want flat in vizag (east and west facing) which should be near to the highway.if any available please let me know the details. '),
(100, 'K Sunny', 'sunny.noel96@gmail.com', '8897745423', 'i want flat in vizag (east and west facing) which should be near to the highway.if any available please let me know the details. '),
(101, 'Mike Chesterton\r\n', 'no-replyKet@gmail.com', 'no-replyKet@gmail.co', 'Hello \r\n \r\nWe will increase your Local Ranks organically and safely, using only whitehat methods, while providing Google maps and website offsite work at the same time. \r\n \r\nPlease check our services below, we offer Local SEO at cheap rates. \r\nhttps://speed-seo.net/product/local-seo-package/ \r\n \r\nNEW: \r\nhttps://www.speed-seo.net/product/zip-codes-gmaps-citations/ \r\n \r\nregards \r\nMike Chesterton\r\n \r\nSpeed SEO Digital Agency'),
(102, 'Mike Leman\r\n', 'no-replyKet@gmail.com', 'no-replyKet@gmail.co', 'Hi there \r\n \r\nI have just analyzed  eswarihomes.com for its SEO metrics and saw that your website could use a boost. \r\n \r\nWe will improve your SEO metrics and ranks organically and safely, using only whitehat methods, while providing monthly reports and outstanding support. \r\n \r\nPlease check our services below, we offer SEO at cheap rates. \r\nhttps://www.hilkom-digital.de/cheap-seo-packages/ \r\n \r\nStart improving your sales and leads with us, today! \r\n \r\nregards \r\nMike Leman\r\n \r\nHilkom Digital Team \r\nsupport@hilkom-digital.de'),
(103, 'Pratyusha ', 'prati.rayaprolu@gmail.com', '7829561367', 'Enquiry'),
(104, 'Beth Collins', 'collins282@yahoo.com', '203-877-1138', 'In case you didn\'t realize, the word \"Registeration\" on your site is spelled incorrectly.  I had similar issues on my website which hurt my credibility until someone pointed it out and I discovered some of the services like SpellHelper.com or SpellingCheck.com which help with these type of issues.'),
(105, 'JamesAbiny', 'no-replykalace@gmail.com', 'no-replykalace@gmail', 'Hello!  eswarihomes.com \r\n \r\nDo you know the easiest way to talk about your product or services? Sending messages through contact forms will enable you to simply enter the markets of any country (full geographical coverage for all countries of the world).  The advantage of such a mailing  is that the emails that will be sent through it will end up within the mailbox that\'s supposed for such messages. Sending messages using Contact forms isn\'t blocked by mail systems, which means it\'s sure to reach the recipient. You will be ready to send your supply to potential customers who were previously untouchable thanks to email filters. \r\nWe offer you to check our service without charge. We\'ll send up to 50,000 message for you. \r\nThe cost of sending one million messages is us $ 49. \r\n \r\nThis letter is created automatically. Please use the contact details below to contact us. \r\n \r\nContact us. \r\nTelegram - @FeedbackMessages \r\nSkype  live:contactform_18 \r\nWhatsApp - +375259112693 \r\nWe only use chat.'),
(106, 'P.subrahmanyeswaraRao', 'psrao.shiva@gmail.com', '9701348237', 'East facing flats/plots in kurmannapalem/Gajuwak/sujatha nagar'),
(107, 'Mike Thompson\r\n', 'no-replyKet@gmail.com', 'no-replyKet@gmail.co', 'Hi there \r\n \r\nDo you want a quick boost in ranks and sales for your eswarihomes.com website? \r\nHaving a high DA score, always helps \r\n \r\nGet your eswarihomes.com to have a DA between 50 to 60 points in Moz with us today and reap the benefits of such a great feat. \r\n \r\nSee our offers here: \r\nhttps://www.monkeydigital.co/product/moz-da50-seo-plan/ \r\n \r\nNEW: \r\nhttps://www.monkeydigital.co/product/ahrefs-dr60/ \r\n \r\n \r\nthank you \r\nMike Thompson\r\n \r\nsupport@monkeydigital.co'),
(108, 'Mike Harris\r\n', 'no-replyKet@gmail.com', 'no-replyKet@gmail.co', 'Hello \r\n \r\nWe all know the importance that dofollow link have on any website`s ranks. \r\nHaving most of your linkbase filled with nofollow ones is of no good for your ranks and SEO metrics. \r\n \r\nBuy quality dofollow links from us, that will impact your ranks in a positive way \r\nhttps://www.digital-x-press.com/product/150-dofollow-backlinks/ \r\n \r\nBest regards \r\nMike Harris\r\n \r\nsupport@digital-x-press.com'),
(109, 'Mike Berrington\r\n', 'no-replyKet@gmail.com', 'no-replyKet@gmail.co', 'Hi \r\n \r\nWe will enhance your Local Ranks organically and safely, using only whitehat methods, while providing Google maps and website offsite work at the same time. \r\n \r\nPlease check our services below, we offer Local SEO at cheap rates. \r\nhttps://speed-seo.net/product/local-seo-package/ \r\n \r\nNEW: \r\nhttps://www.speed-seo.net/product/zip-codes-gmaps-citations/ \r\n \r\nregards \r\nMike Berrington\r\n \r\nSpeed SEO Digital Agency'),
(110, 'Himabindu', 'adityahima@gmail.com', '09550212373', 'Hi need your hr mail id '),
(111, 'Juri Muileboom', 'juri.linkbuildingvoordeel@gmail.com', 'juri.linkbuildingvoo', 'Geachte, \r\n \r\nIk kwam je website tegen ver weg verstopt in de google search en ik zag dat er wellicht nog wat verbetering kon plaatsvinden in je rankings in de zoekmachine. \r\nIk zou graag in contact willen komen met de gene die verantwoordelijk is voor de marketing? Ik denk namelijk dat we nog minimaal 300% groei kunnen realiseren. \r\nJe kunt mij mailen op juri@linkbuildingvoordeel.nl of ga direct naar de website: https://linkbuildingvoordeel.nl  om te kijken wat we inhoudelijk voor elkaar kunnen betekenen. \r\n \r\nJe mag mij ook bellen op: 0657435401 \r\n(als ik er niet ben spreek even duidelijk je naam en bedrijfsnaam in, dan bel ik zo spoedig mogelijk terug.) \r\n \r\nAls er nog vragen zijn hoor ik dat graag! \r\n \r\nMVG \r\n \r\nJuri Muileboom \r\n \r\nCEO - Linkbuildingvoordeel.nl'),
(112, 'Mike Michaelson\r\n', 'no-replyKet@gmail.com', 'no-replyKet@gmail.co', 'Howdy \r\n \r\nI have just checked  eswarihomes.com for its SEO metrics and saw that your website could use an upgrade. \r\n \r\nWe will increase your SEO metrics and ranks organically and safely, using only whitehat methods, while providing monthly reports and outstanding support. \r\n \r\nPlease check our plans here, we offer SEO at cheap rates. \r\nhttps://www.hilkom-digital.de/cheap-seo-packages/ \r\n \r\nStart increasing your sales and leads with us, today! \r\n \r\n \r\nregards \r\nMike Michaelson\r\n \r\nHilkom Digital Team \r\nsupport@hilkom-digital.de'),
(113, 'Pavan blv', 'pavanblv84@gmail.com', '9985055222', 'Need a 3 bedroom apartment in and around vijayawada'),
(114, 'k shankar rao', 'kshankar004@gmail.com', '9949444446', 'aspen residency, flat no. 101, resapuvanipalem, visakhapatnam'),
(115, 'Venkata SatyaKiran', 'satyak20@gmail.com', '4084442204', ''),
(116, 'Rahul', 'meekmonks@gmail.com', '9885815445', ''),
(117, 'Karagani Vamsi Krishna', 'vamsiyadav025@gmail.com', '7396904042', 'Vacant Land with boundary wall in an area of 124 Sq. yds in less than 100 metres from Highway at Durga theatre, Madhurawada, Vsp 530041'),
(118, 'Sanjay', 'killhunger@gmail.com', '9010977977', 'I have a G+2 Individual House for sale in TPT Colony, Seethamadhara on 167 sq yards with 3713 sft taxable area.'),
(119, 'G PRASAD', '', '9160454516', ''),
(120, 'karri.bhaskarrao', 'karribhaskarrao99@gmail.com', '9', ''),
(121, 'Debraj', 'debrajchatterjee_2007@rediffmail.com', '+918380084301', 'Please Share Me Madhurwada, Vizag. 3bhk Proparty Detail'),
(122, 'Test by Chandrashekher', 'test@gmail.com', '9010402324', 'test case 1'),
(123, 'Test by Chandrashekher', 'test@gmail.com', '9010402324', 'test case 2'),
(124, 'dfghjkl;', 'lkjg@rfghj', '998987654', 'fghjkkk.koj'),
(125, 'Aditya', 'kotni.bobby@gmail.com', '8270000068', ''),
(126, 'somaraju', 'teluguntaraju@gmail.com', '9346029257', 'Looking for 3 BHK Flat around 50 Lakhs at Madhurwada near by locations'),
(127, 'Sai Ram Pujari', 'sairam29@gmail.com', '+13165735557', ''),
(128, 'kiranmayi', 'kiranmayi.508@gmail.com', '9885591975', ''),
(129, 'Mariast', 'mariast@gmail.com', 'mariast@mail.com', 'Hеllo all, guуѕ! Ι know, my mеѕѕagе mау be toо ѕpeсіfіс,\r\nBut mу ѕіster found nice man hеrе and they married, sо hоw abоut mе?! :)\r\nΙ am 25 уеаrѕ оld, Μаrіa, from Ukraine, I knоw Engliѕh аnd Gеrmаn lаnguаges also\r\nAnd... Ι hаve speсіfic diѕeaѕе, nаmеd nуmphomanіa. Who know what is this, саn undеrstand me (bеttеr to saу іt immedіatеlу)\r\nАh уеs, Ι сook verу taѕtу! and I lоve not only cook ;))\r\nΙm reаl gіrl, not prostіtutе, and lооking for ѕеrіouѕ аnd hоt rеlatіоnshiр...\r\nАnywау, yоu саn fіnd mу profilе hеrе: http://serpohargfi.gq/user/68367/ \r\n'),
(130, 'Rl rao', 'rlrao1958@gmail.com', '8309598071', ''),
(131, 'Test by Chandrashekher', 'chandhu418@gmail.com', '9010402324', 'mail functionality test by chandu'),
(132, 'Test by Chandrashekher', 'test@gmail.com', '9010402324', 'this is test by chandu'),
(133, 'ZAP', 'foo-bar@example.com', 'ZAP', ''),
(134, 'ZAP', 'foo-bar@example.com', 'ZAP', ''),
(135, 'ZAP', 'foo-bar@example.com', 'ZAP', ''),
(136, 'ZAP', 'foo-bar@example.com', 'ZAP', ''),
(137, 'ZAP', 'foo-bar@example.com', 'ZAP', ''),
(138, 'ZAP', 'foo-bar@example.com', 'ZAP', ''),
(139, 'AlenaSn', 'alenaSn@mail.com', 'alenaSn@mail.com', 'Hello all, guуs! I know, mу message mау be toо sреcifiс,\r\nBut mу sіѕter fоund nісе man herе and thеy marriеd, ѕо hоw аbоut me?ǃ :)\r\nI am 26 yeаrѕ оld, Аlenа, from Rоmania, Ι knоw Εngliѕh аnd Germаn languаgеѕ alsо\r\nAnd... I have ѕреcіfіс dіѕeasе, named nуmphomaniа. Ԝho knоw what iѕ thіs, саn understаnd mе (bеtter to sау іt іmmediatеly)\r\nAh yеs, I сook very taѕty! аnd I lovе not оnlу cook ;))\r\nIm reаl gіrl, nоt рrоѕtіtute, аnd lookіng fоr ѕerіous and hоt relatіоnѕhір...\r\nАnуwаy, you can find mу рrоfіlе herе: http://vahecaldome.tk/user/30804/ \r\n'),
(140, 'Sharath Kumar reddy ', 'rrsharathkumarreddy@gmail.com', '9032717196 ', 'Madhurawadha '),
(141, 'Kendrick', 'contact@techoneit.com', '02.76.69.46.98', 'Hi,\r\n\r\nI hope you\'re well. I am excited to tell you about our Full Body Resistance Band Kit that can help you get an amazing workout without having to go to the gym.\r\nThis is the best and cheapest athletic gear on the market. You can do a full body workout from the comfort of your home.\r\n\r\nI believe that this product can help you reach your fitness goals. \r\n\r\nSave 50% OFF + FREE Worldwide Shipping\r\nShop Now: https://ametathletics.sale\r\n\r\nThanks and Best Regards, \r\n\r\nKendrick'),
(142, 'Bennie', 'info@medicitechnologies.com', '0680 286 23 21', 'New Multifunction Anti-theft Waterproof Sling Bag\r\n\r\nThe best ever SUPER Sling Bag: Drop-proof/Anti-theft/Scratch-resistant/USB Charging\r\n\r\n50% OFF for the next 24 Hours ONLY + FREE Worldwide Shipping for a LIMITED time\r\n\r\nBuy now: https://fashiondaily.shop\r\n\r\nBest Wishes, \r\n\r\nBennie\r\nReal Estate Company in India | 2 &3BHK Flats in Visakhapatnam Apartments for Sale in Visakhapatnam |Flats for Sale in vizag | Eswari Homes'),
(143, 'B.S.KUMAR', 'bolleddusumanth123@gmail.com', '8327786537', 'cbm compund and narasimha nagar resale property'),
(144, 'Janagittchittibabu', 'chittibabuj2@gmail.com', '9704409485', 'Branch manager Harini devloped builders Branch manager kadapa'),
(145, 'Pradeep', 'pradeepchwdary@gmail.com', '9866081753', 'I am looking for 1400 plus sqft flat in and around akkayapalem with max budget of 90lacs. Please let me know if you have any details to share '),
(146, 'Marquita', 'bugs@modrastrecha.cz', '0494 11 98 37', 'Do you have time to brush your dog\'s teeth every day?\r\n\r\nLet your dog clean his own teeth with our dog dental care brushing stick. Made of eco-friendly natural rubber, this toothbrush is sturdy. The soft design is safe for your dogs\' gums and helps to clean their teeth and protect them from oral diseases and dental decay. \r\n\r\nAct Now And Receive A Special Discount!\r\n\r\nClick here: https://dogcare.center\r\n\r\nBest Wishes, \r\n \r\nMarquita'),
(147, 'ZAP', 'foo-bar@example.com', 'ZAP', ''),
(148, 'Ray Flynn', 'ray.flynn@diyguys.net', '6032166929', 'Hi,\r\n\r\nI hope you\'re having a good day. Would you like a guest post about advice for people thinking about buying a fixer-upper? I would love to write it for you, for free.\r\n\r\nLet me know what you think.\r\n\r\nBest,\r\nRay Flynn\r\nray.flynn@diyguys.net \r\n'),
(149, 'Ray Flynn', 'ray.flynn@diyguys.net', '6032166929', 'Hi,\r\n\r\nI hope you\'re having a good day. Would you like a guest post about advice for people thinking about buying a fixer-upper? I would love to write it for you, for free.\r\n\r\nLet me know what you think.\r\n\r\nBest,\r\nRay Flynn\r\nray.flynn@diyguys.net \r\n'),
(150, 'chandra kesava rao', 'chandru.kesav@gmail.com', '7382208163', 'Need 2bhk East face apartment in Vijayawada below 40 lakhs can you help '),
(151, 'srinivas', 'saisaketh143@gmail.com', '9620044427', ''),
(152, 'M S PRAKASH RAO ', 'msprao56@gmail.com', '08581740442', 'Want to know if you have onnging projects 8n and around akkayyapalem seetammadhara visakhapatnam '),
(153, 'M S PRAKASH RAO ', 'msprao56@gmail.com', '08581740442', 'Want to know if you have onnging projects 8n and around akkayyapalem seetammadhara visakhapatnam '),
(154, 'M S PRAKASH RAO ', 'msprao56@gmail.com', '08581740442', 'Want to know if you have onnging projects 8n and around akkayyapalem seetammadhara visakhapatnam ');

-- --------------------------------------------------------

--
-- Table structure for table `credai`
--

CREATE TABLE `credai` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `property` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `budget` varchar(255) NOT NULL,
  `added_on` varchar(100) NOT NULL,
  `employee` varchar(255) NOT NULL,
  `team` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `credai`
--

INSERT INTO `credai` (`id`, `name`, `mobile`, `property`, `location`, `budget`, `added_on`, `employee`, `team`) VALUES
(17, 'Shilpa', '7008356474', 'Seethamadhara', 'Visakhapatnam', '7000000', '24-12-2021', 'Manindra', 'Team2'),
(18, 'Jagan', '9866889866', 'Yendada', 'Yendada', 'No problem', '24-12-2021', 'Prabha', 'Team1'),
(19, 'P.Babu', '9110384532', 'P.m palem', 'P.m palem', '650000000', '24-12-2021', 'Chandra Sekhar', 'Team2'),
(20, 'Rami reddy', '9849941666', 'Dwarakanagar', 'Dwarakanagar', '18000000', '24-12-2021', 'Manindra', 'Team2'),
(21, 'Rami reddy', '9849941666', 'Dwarakanagar', 'Dwarakanagar', '18000000', '24-12-2021', 'Manindra', 'Team2'),
(22, 'Anil kumar', '7382233719', 'Yenadad', 'Yanddaad', '5000000', '24-12-2021', 'Manindrareddy', 'Team2'),
(23, 'AdhiNarayana', '9949391140', 'Dwarakanagar', 'Dwarakanagar', '7000000', '24-12-2021', 'Manindrareddy', 'Team2'),
(24, 'RV naga raju', '9490546468', 'Zilla parishad', 'Zilla parishad', '5000000', '24-12-2021', 'Manindrareddy', 'Team2'),
(25, 'Ramesh ', '8074204695', 'Pmpalem', 'Pm palem', '10000000', '24-12-2021', 'Manindrareddy', 'Team2'),
(26, 'Shrikanth', '9848686863', 'MVP colony', 'MVP colony', '10000000', '24-12-2021', 'Manindra', 'Team2'),
(27, 'Saritha', '9381612722', 'Marripalem', 'Marripalem', '18000000', '24-12-2021', 'Manindra', 'Team2'),
(28, 'Nagi', '9885484406', 'Pmpalem', 'Pm palem', '5000000', '24-12-2021', 'Manindra', 'Team2'),
(29, 'Suresh', '9505892481', 'Seethamadhara', 'Seethamadhara', '18000000', '24-12-2021', 'Manindrareddy', 'Team2'),
(30, 'Kamesh ', '8179329051', 'Dwarakanagar', 'Dwarakanagar', '15000000', '24-12-2021', 'Manindrareddy', 'Team2'),
(31, 'Prasad', '9848370370', 'Pmpalem', 'Pm palem', '18000000', '24-12-2021', 'Uday', 'Team2'),
(32, 'Prasad', '9848370370', 'Pmpalem', 'Pm palem', '18000000', '24-12-2021', 'Uday', 'Team2'),
(33, 'Pavan ', '9866989356', 'Pmpalem', 'Pm palem', '10000000', '24-12-2021', 'Manindra', 'Team2'),
(34, 'Mohan', '9951444423', 'Seethamdhara', 'Seethamdhara', '1 cr', '24-12-2021', 'Manindra', 'Team2'),
(35, 'R.k', '9866044276', 'P.M palem', 'P.m palem', '1cr', '24-12-2021', 'Manindra', 'Team2'),
(36, 'Kamesh', '8179329051', 'Madhuravada', 'Madhuravada', '1cr', '24-12-2021', 'Manindra', 'Team2'),
(37, 'Pavan', '9866989356', 'Gated community', 'Madhravada', '1.5 cr', '24-12-2021', 'Manindra', 'Team2'),
(38, 'Bharathi', '9703957919', 'Individual ', 'Sujatha nagar', 'O.5 to 1cr', '24-12-2021', 'Manindra', 'Team2'),
(39, 'Ajay', '9948400004', 'Mvp', 'Beach road', '1cr', '24-12-2021', 'Manindra', 'Team2'),
(40, 'Rama rao', '9247479841', 'Pm palem', 'Pm palem', '5000000', '24-12-2021', 'Manindra', 'Team2'),
(41, 'Anil kumar', '7382233719', 'Adarsh nagar', 'Adarsh nagar', '50 lacks', '24-12-2021', 'Manindra', 'Team2'),
(42, 'Rami reddy', '9849941666', 'Dowaraka nagar', 'Dowaraka nager', '1cr', '24-12-2021', 'Manindra', 'Team2'),
(43, 'Ravi', '9923594151', 'Villa', 'Pm palem', '1.5 cr', '24-12-2021', 'Manindra', 'Team2'),
(44, 'Prasad', '8095425797', 'Villa', 'Yendada', '1cr', '24-12-2021', 'Manindra', 'Team2'),
(45, 'Siva kumar', '9014994751', 'Flot', 'Pendurthi', '50 lacks', '24-12-2021', 'Manindra', 'Team2'),
(46, 'Gopi', '8341400476', 'Individual ', 'Gopalapatnam', '0.5 to 1cr', '24-12-2021', 'Manindra', 'Team2'),
(47, 'Krishna ', '9848016732', 'Flot', 'Siripuram', 'Siripuram ', '24-12-2021', '11cr', 'Team2'),
(48, 'Krishna', '9848016732', 'Flot ', 'Siripuram ', '1cr', '24-12-2021', 'Manindra ', 'Team2'),
(49, 'Suresh ', '8019701876', 'Individual ', 'NAD', 'NAD', '24-12-2021', '1cr ', 'Team2');

-- --------------------------------------------------------

--
-- Table structure for table `enquiry_form`
--

CREATE TABLE `enquiry_form` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `flat` varchar(20) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `added_on` varchar(55) NOT NULL,
  `location` varchar(100) NOT NULL,
  `budget` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `enquiry_form`
--

INSERT INTO `enquiry_form` (`id`, `name`, `email`, `flat`, `mobile`, `added_on`, `location`, `budget`) VALUES
(5, 'Test', 'test@gmail.com', '2BHK', '9010402324', '04-12-2021', '', ''),
(6, 'Test by Chandrashekher', 'chandhu418@gmail.com', '2BHK', '9010402324', '04-06-2022', '', ''),
(7, 'chandu123', 'chandhu418@gmail.coms', '3BHK', '8466842320', '08-06-2022', 'Madhurawada', '3500000');

-- --------------------------------------------------------

--
-- Table structure for table `event`
--

CREATE TABLE `event` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `modified` datetime NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '1=Active | 0=Inactive',
  `address` text NOT NULL,
  `area` varchar(255) NOT NULL,
  `about_area` text NOT NULL,
  `2017_price` varchar(20) NOT NULL,
  `2018_price` varchar(20) NOT NULL,
  `2019_price` varchar(20) NOT NULL,
  `2020_price` varchar(20) NOT NULL,
  `street` varchar(255) NOT NULL,
  `city` varchar(100) NOT NULL,
  `district` varchar(100) NOT NULL,
  `pincode` varchar(20) NOT NULL,
  `state` varchar(55) NOT NULL,
  `about_property` text NOT NULL,
  `property_status` varchar(55) NOT NULL,
  `budget_from` varchar(20) NOT NULL,
  `budget_to` varchar(20) NOT NULL,
  `price_sqft` varchar(20) NOT NULL,
  `added_by` int(11) NOT NULL,
  `features` varchar(255) NOT NULL,
  `nearby` varchar(255) NOT NULL,
  `modified_by` int(11) NOT NULL,
  `bed_rooms` int(11) NOT NULL,
  `event_type` varchar(55) NOT NULL,
  `content` text NOT NULL,
  `event_date` varchar(55) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `event`
--

INSERT INTO `event` (`id`, `title`, `created`, `modified`, `status`, `address`, `area`, `about_area`, `2017_price`, `2018_price`, `2019_price`, `2020_price`, `street`, `city`, `district`, `pincode`, `state`, `about_property`, `property_status`, `budget_from`, `budget_to`, `price_sqft`, `added_by`, `features`, `nearby`, `modified_by`, `bed_rooms`, `event_type`, `content`, `event_date`) VALUES
(8, 'Independence Day Celebration 2020', '2021-12-31 03:15:25', '2021-01-27 10:38:06', 1, '', 'Vizag', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, 'celebrations', 'Independence Day is celebrated annually on 15 August as a national holiday in India commemorating the nation\'s independence from the United Kingdom on 15 August 1947, the day when the provisions of the 1947 Indian Independence', '15-Aug-2020'),
(9, 'New Property Launch', '2021-12-31 03:16:26', '2021-01-29 10:58:47', 1, '', 'MVP Colony', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, 'event', 'New Property Launch', '01-Jan-2021'),
(10, 'New Property (Gayatri Residency) Launch in Rajahmundry ', '2021-12-31 03:16:34', '2021-05-28 08:44:15', 1, '', 'Vidyuth Colony', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, 'event', 'Our New Launched Project Gayatri Residency in Rajahmundry, Vidyuth Colony. Shortly updating the further details.', '26-May-2021'),
(11, 'Independence Day Celebrations 2021', '2021-12-31 03:15:59', '2021-08-16 07:45:17', 1, '', 'Vizag', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, 'celebrations', 'Independence Day Celebrations 2021', '15-Aug-2021'),
(13, 'Award Winning Celebrations - Best Emerging Property Search Portal Andhra Pradesh', '2021-12-31 03:15:54', '2021-09-04 06:53:34', 1, '', 'Vizag', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, 'celebrations', 'Award Winning Celebrations - Best Emerging Property Search Portal Andhra Pradesh', '03-September-2021'),
(14, 'Award Winning Celebrations @Vijayawada Branch - Best Emerging Property Search Portal Andhra Pradesh', '2021-12-31 03:15:47', '2021-09-04 12:49:30', 1, '', 'Vijayawada', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, 'celebrations', 'Award Winning Celebrations @Vijayawada - Best Emerging Property Search Portal Andhra Pradesh', '03-September-2021'),
(15, 'Review Meeting - 2021', '2021-12-31 03:16:39', '2021-09-07 12:52:16', 1, '', 'Vizag', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, 'event', 'Review Meeting - 2021', '07-September-2021'),
(16, 'New Project Bhoomi Pooja @ Rajahmundry', '2021-12-31 03:16:45', '2021-10-11 10:39:34', 1, '', 'Rajahmundry', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, 'event', 'New Project Bhoomi Pooja @ Rajahmundry', '10-October-2021'),
(17, 'New Project Bhoomi Pooja @ Aganampudi', '2021-12-31 03:16:51', '2021-10-14 08:21:50', 1, '', 'Aganampudi', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, 'event', 'New Project Bhoomi Pooja @ Aganampudi', '14-October-2021'),
(18, 'Kalyan Chakravarthy (Founder & CEO) Sir Birthday Celebrations', '2021-12-31 03:15:41', '2021-12-30 06:00:00', 1, '', 'Vizag', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, 'celebrations', 'Kalyan Chakravarthy (Founder & CEO) Birthday Celebrations', '22-December-2021'),
(19, 'CREDAI PROPERTY SHOW - 2021', '2021-12-31 03:16:57', '2021-12-27 11:19:00', 1, '', 'Vizag', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, 'event', 'CREDAI PROPERTY SHOW - 2021', '24-December-2021'),
(20, 'New Year Dairy Launch by Eswari Sri Akshitha', '2022-01-04 09:45:51', '2022-01-04 10:45:51', 1, '', 'Vizag', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, 'event', 'New Year Dairy Launch by Eswari Sri Akshitha', '28-December-2021'),
(21, 'Rakesh Sir Birthday Celebrations', '2021-12-31 03:15:32', '2021-12-30 05:59:39', 1, '', 'Vizag', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, 'celebrations', 'Rakesh Sir Birthday Celebrations', '29-December-2021'),
(22, 'Award Winning Celebrations - Fast Growing Real Estate Company of the Year 2022, Andhra Pradesh ', '2022-07-29 05:52:50', '2022-07-29 07:52:50', 1, '', 'Vizag', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', 0, 0, 'celebrations', 'Award Winning Celebrations - Fast Growing Real Estate Company of the Year 2022, Andhra Pradesh ', '16-July-2022');

-- --------------------------------------------------------

--
-- Table structure for table `event_images`
--

CREATE TABLE `event_images` (
  `id` int(11) NOT NULL,
  `property_id` int(11) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `uploaded_on` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `event_images`
--

INSERT INTO `event_images` (`id`, `property_id`, `file_name`, `uploaded_on`) VALUES
(14, 8, '67925793_722633711520640_1878696790660743168_o.jpg', '2021-01-27 10:38:06'),
(15, 8, '69004239_722633714853973_3808549751373168640_o.jpg', '2021-01-27 10:38:06'),
(16, 8, '69152657_722633728187305_1599003164521005056_o.jpg', '2021-01-27 10:38:06'),
(17, 9, '54436623_634520540331958_6774086487278354432_n.jpg', '2021-01-27 10:41:27'),
(18, 9, '55515105_634520353665310_5627392268638879744_n.jpg', '2021-01-27 10:41:27'),
(19, 10, '12.jpeg', '2021-05-28 08:44:15'),
(21, 11, 'IMG-20210815-WA0013.jpg', '2021-08-16 07:45:17'),
(26, 11, 'IMG20210815193655.jpg', '2021-08-16 07:45:19'),
(32, 11, 'IMG20210815193846_01.jpg', '2021-08-16 07:45:20'),
(35, 11, 'WhatsApp_Image_2021-08-16_at_10_53_26_AM.jpeg', '2021-08-16 07:45:20'),
(37, 11, 'WhatsApp_Image_2021-08-16_at_10_53_27_AM_(2).jpeg', '2021-08-16 07:45:20'),
(38, 11, 'WhatsApp_Image_2021-08-16_at_10_53_27_AM.jpeg', '2021-08-16 07:45:20'),
(59, 13, '25.jpeg', '2021-09-04 06:53:34'),
(61, 13, '3.jpeg', '2021-09-04 06:53:34'),
(68, 13, '10.jpeg', '2021-09-04 06:53:34'),
(76, 13, '18.jpeg', '2021-09-04 06:53:34'),
(77, 13, '19.jpeg', '2021-09-04 06:53:34'),
(78, 13, '20.jpeg', '2021-09-04 06:53:34'),
(97, 14, '81.jpeg', '2021-09-04 12:49:30'),
(100, 14, '111.jpeg', '2021-09-04 12:49:30'),
(102, 14, '141.jpeg', '2021-09-04 12:49:30'),
(103, 14, '151.jpeg', '2021-09-04 12:49:30'),
(105, 14, '171.jpeg', '2021-09-04 12:49:30'),
(107, 14, '191.jpeg', '2021-09-04 12:49:30'),
(110, 15, '112.jpeg', '2021-09-07 12:52:16'),
(113, 15, '42.jpeg', '2021-09-07 12:52:16'),
(119, 15, '102.jpeg', '2021-09-07 12:52:16'),
(127, 15, '182.jpeg', '2021-09-07 12:52:16'),
(131, 15, '422.jpeg', '0000-00-00 00:00:00'),
(137, 15, '428.jpeg', '0000-00-00 00:00:00'),
(138, 16, 'WhatsApp_Image_2021-10-10_at_12_52_11_PM_(1).jpeg', '2021-10-11 10:39:34'),
(139, 16, 'WhatsApp_Image_2021-10-10_at_12_52_11_PM_(2).jpeg', '2021-10-11 10:39:34'),
(140, 16, 'WhatsApp_Image_2021-10-10_at_12_52_11_PM.jpeg', '2021-10-11 10:39:34'),
(144, 16, 'WhatsApp_Image_2021-10-10_at_12_52_13_PM.jpeg', '2021-10-11 10:39:34'),
(146, 16, 'WhatsApp_Image_2021-10-10_at_12_52_14_PM.jpeg', '2021-10-11 10:39:34'),
(148, 17, 'WhatsApp_Image_2021-10-14_at_10_13_47_AM_(1).jpeg', '2021-10-14 08:21:50'),
(149, 17, 'WhatsApp_Image_2021-10-14_at_10_13_47_AM.jpeg', '2021-10-14 08:21:50'),
(158, 17, 'WhatsApp_Image_2021-10-14_at_10_41_33_AM_(1).jpeg', '2021-10-14 08:21:50'),
(162, 17, 'WhatsApp_Image_2021-10-14_at_10_41_34_AM.jpeg', '2021-10-14 08:21:50'),
(165, 17, 'WhatsApp_Image_2021-10-14_at_10_41_36_AM_(1).jpeg', '2021-10-14 08:21:50'),
(177, 17, 'WhatsApp_Image_2021-10-14_at_11_06_07_AM.jpeg', '2021-10-14 08:22:43'),
(179, 18, 'kalyan12.jpeg', '2021-12-22 10:27:57'),
(180, 18, 'kalyan11.jpeg', '2021-12-22 10:27:57'),
(183, 18, 'WhatsApp_Image_2021-12-23_at_9_26_14_AM.jpeg', '2021-12-23 05:02:40'),
(185, 18, 'WhatsApp_Image_2021-12-23_at_9_26_13_AM_(1).jpeg', '2021-12-23 05:02:40'),
(186, 18, 'WhatsApp_Image_2021-12-23_at_9_26_13_AM.jpeg', '2021-12-23 05:02:40'),
(187, 18, 'WhatsApp_Image_2021-12-23_at_9_58_59_AM.jpeg', '2021-12-23 05:29:56'),
(188, 19, 'WhatsApp_Image_2021-12-24_at_12_25_40_PM.jpeg', '2021-12-24 08:02:36'),
(189, 19, 'WhatsApp_Image_2021-12-24_at_12_48_16_PM_(1).jpeg', '2021-12-24 08:20:26'),
(190, 19, 'WhatsApp_Image_2021-12-24_at_12_48_16_PM.jpeg', '2021-12-24 08:20:26'),
(191, 19, 'WhatsApp_Image_2021-12-24_at_12_48_15_PM.jpeg', '2021-12-24 08:20:26'),
(192, 19, 'WhatsApp_Image_2021-12-24_at_7_15_26_PM.jpeg', '2021-12-24 14:51:41'),
(193, 19, 'WhatsApp_Image_2021-12-24_at_7_15_25_PM_(1).jpeg', '2021-12-24 14:51:41'),
(194, 19, 'WhatsApp_Image_2021-12-24_at_7_15_25_PM.jpeg', '2021-12-24 14:51:42'),
(195, 19, 'WhatsApp_Image_2021-12-24_at_7_15_24_PM_(2).jpeg', '2021-12-24 14:51:42'),
(196, 19, 'WhatsApp_Image_2021-12-24_at_7_15_24_PM_(1).jpeg', '2021-12-24 14:51:42'),
(197, 19, 'WhatsApp_Image_2021-12-24_at_7_15_24_PM.jpeg', '2021-12-24 14:51:42'),
(198, 19, 'WhatsApp_Image_2021-12-24_at_7_15_23_PM_(1).jpeg', '2021-12-24 14:51:42'),
(199, 19, 'WhatsApp_Image_2021-12-24_at_7_15_23_PM.jpeg', '2021-12-24 14:51:42'),
(200, 19, 'WhatsApp_Image_2021-12-24_at_7_15_22_PM.jpeg', '2021-12-24 14:51:42'),
(201, 19, 'WhatsApp_Image_2021-12-24_at_7_15_21_PM.jpeg', '2021-12-24 14:51:42'),
(202, 19, 'WhatsApp_Image_2021-12-24_at_7_16_35_PM.jpeg', '2021-12-24 14:51:42'),
(203, 19, 'WhatsApp_Image_2021-12-25_at_11_03_00_AM_(2).jpeg', '2021-12-25 06:37:44'),
(204, 19, 'WhatsApp_Image_2021-12-25_at_11_03_00_AM_(1).jpeg', '2021-12-25 06:37:44'),
(205, 19, 'WhatsApp_Image_2021-12-25_at_11_03_00_AM.jpeg', '2021-12-25 06:37:44'),
(206, 19, 'WhatsApp_Image_2021-12-25_at_11_02_59_AM_(1).jpeg', '2021-12-25 06:37:44'),
(207, 19, 'WhatsApp_Image_2021-12-25_at_11_02_59_AM.jpeg', '2021-12-25 06:37:44'),
(208, 19, 'WhatsApp_Image_2021-12-27_at_10_25_10_AM.jpeg', '2021-12-27 11:19:00'),
(209, 19, 'WhatsApp_Image_2021-12-27_at_10_21_13_AM.jpeg', '2021-12-27 11:19:00'),
(210, 19, 'WhatsApp_Image_2021-12-27_at_10_16_04_AM.jpeg', '2021-12-27 11:19:00'),
(211, 19, 'WhatsApp_Image_2021-12-27_at_10_15_10_AM.jpeg', '2021-12-27 11:19:00'),
(212, 19, 'WhatsApp_Image_2021-12-27_at_9_20_42_AM_(2).jpeg', '2021-12-27 11:19:00'),
(213, 19, 'WhatsApp_Image_2021-12-27_at_9_20_42_AM_(1).jpeg', '2021-12-27 11:19:00'),
(214, 19, 'WhatsApp_Image_2021-12-27_at_9_20_42_AM.jpeg', '2021-12-27 11:19:00'),
(215, 19, 'WhatsApp_Image_2021-12-27_at_9_20_41_AM.jpeg', '2021-12-27 11:19:00'),
(216, 19, 'WhatsApp_Image_2021-12-27_at_9_19_22_AM.jpeg', '2021-12-27 11:19:00'),
(217, 19, 'WhatsApp_Image_2021-12-27_at_9_19_21_AM.jpeg', '2021-12-27 11:19:00'),
(218, 19, 'WhatsApp_Image_2021-12-27_at_9_19_18_AM.jpeg', '2021-12-27 11:19:00'),
(219, 20, 'IMG_20211229_112900.jpg', '2021-12-29 07:00:20'),
(220, 20, 'IMG-20211229-WA0004.jpg', '2021-12-29 07:00:20'),
(221, 20, 'IMG-20211229-WA0003.jpg', '2021-12-29 07:00:20'),
(222, 20, 'IMG-20211229-WA0002.jpg', '2021-12-29 07:00:20'),
(223, 20, 'IMG-20211229-WA0001.jpg', '2021-12-29 07:00:20'),
(225, 21, 'WhatsApp_Image_2021-12-30_at_10_22_38_AM_(1).jpeg', '2021-12-30 05:59:39'),
(227, 21, 'WhatsApp_Image_2021-12-30_at_10_22_37_AM.jpeg', '2021-12-30 05:59:39'),
(228, 21, 'WhatsApp_Image_2021-12-30_at_10_22_35_AM.jpeg', '2021-12-30 05:59:39'),
(229, 21, 'WhatsApp_Image_2021-12-30_at_10_22_34_AM.jpeg', '2021-12-30 05:59:39'),
(230, 21, 'WhatsApp_Image_2021-12-30_at_10_22_33_AM.jpeg', '2021-12-30 05:59:39'),
(231, 21, 'WhatsApp_Image_2021-12-30_at_10_22_30_AM.jpeg', '2021-12-30 05:59:39'),
(262, 20, 'IMG-20220104-WA0001.jpg', '2022-01-04 10:45:51'),
(263, 22, 'WhatsApp_Image_2022-07-29_at_10_25_24_AM.jpeg', '2022-07-29 07:52:50'),
(264, 22, 'WhatsApp_Image_2022-07-29_at_10_24_02_AM_(1).jpeg', '2022-07-29 07:52:50'),
(265, 22, 'WhatsApp_Image_2022-07-29_at_10_24_02_AM.jpeg', '2022-07-29 07:52:50');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `mobile` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `name`, `email`, `mobile`) VALUES
(2, 'chandu vv', 'chandhu418@gmail.com', '09010402324'),
(3, 'shrita', 'shrita@gmail.com', '901040232'),
(4, 'Kalyan', 'kalyan@gmailcom', '9010402324'),
(5, 'Kalyan', 'kalyan@gmail.com', '901402324');

-- --------------------------------------------------------

--
-- Table structure for table `feedbackresult`
--

CREATE TABLE `feedbackresult` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `ans1` text NOT NULL,
  `ans2` text NOT NULL,
  `ans3` text NOT NULL,
  `ans4` text NOT NULL,
  `ans5` text NOT NULL,
  `ans6` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `feedbackresult`
--

INSERT INTO `feedbackresult` (`id`, `name`, `email`, `mobile`, `ans1`, `ans2`, `ans3`, `ans4`, `ans5`, `ans6`) VALUES
(5, 'chandu vv', 'chandhu418@gmail.com', '09010402324', '4', '3', '2', '1', '4', '5'),
(6, 'chandu vv', 'chandhu418@gmail.com', '09010402324', '5', '4', '4', '4', '4', '3'),
(7, 'chandu vv', 'chandhu418@gmail.com', '09010402324', '5', '4', '5', '4', '5', '4'),
(8, 'Kalyan', 'kalyan@gmailcom', '9010402324', '3', '4', '5', '4', '3', '4'),
(9, 'Kalyan', 'kalyan@gmail.com', '901402324', '4', '5', '3', '5', '5', '4');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(9) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `phonenumber` varchar(55) NOT NULL,
  `adharnumber` varchar(55) NOT NULL,
  `pannumber` varchar(20) NOT NULL,
  `company` varchar(55) NOT NULL,
  `comp` varchar(20) NOT NULL,
  `role` varchar(20) NOT NULL,
  `designation` varchar(55) NOT NULL,
  `anternate_number` varchar(55) NOT NULL,
  `present_address` text NOT NULL,
  `permanent_address` text NOT NULL,
  `joining_date` varchar(55) NOT NULL,
  `adhar_image` varchar(255) NOT NULL,
  `pan_image` varchar(255) NOT NULL,
  `about_previous_company` text NOT NULL,
  `report` int(11) NOT NULL,
  `bank_account_number` varchar(55) NOT NULL,
  `ifsc` varchar(55) NOT NULL,
  `bank_holder_name` varchar(100) NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'active',
  `branch` varchar(55) NOT NULL,
  `dob` varchar(20) NOT NULL,
  `ofc_email` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `name`, `email`, `username`, `password`, `phonenumber`, `adharnumber`, `pannumber`, `company`, `comp`, `role`, `designation`, `anternate_number`, `present_address`, `permanent_address`, `joining_date`, `adhar_image`, `pan_image`, `about_previous_company`, `report`, `bank_account_number`, `ifsc`, `bank_holder_name`, `status`, `branch`, `dob`, `ofc_email`) VALUES
(1, 'Admin', 'admin@gmail.com', 'admin', '123456', '8374631133', '1234567890', '1234567890', 'eg', '', 'superadmin', '', '8374631133', 'Vizag', 'Vizag', '2020-01-01', 'a1.jpg', 'p1.jpg', 'EswariGroup', 0, '000000000', 'ICIC0083', 'Kalyan Chakravarthy', 'active', '', '', ''),
(18, 'I Kalyan Chakravarthy', 'test1@gmail.com', 'EG01_EH001', '8374631133', '8374631133', '1234567890', '1234567890', 'eg', '', 'superadmin', 'Managing Director', '8374631133', 'Vizag', 'Vizag', '2020-01-01', '', '', 'EswariGroup', 0, '1234567890', 'ICIC0083', 'Kalyan Chakravarthy', 'active', 'C-OFFICE', '', ''),
(19, 'I Neelima', 'test@gmail.com', 'EG01_EH002', '9963552388', '9963552388', '1234567890', '1234567890', 'eg', '', 'superadmin', 'Director', '9963552388', 'Vizag', 'Vizag', '2020-01-01', '', '', '	\r\n\r\nEswariGroup', 0, '1234567890', 'ICIC0083', 'Neelima', 'active', 'C-OFFICE', '', ''),
(20, 'K Rakesh Kumar', 'krakesh6k@gmail.com', 'EG01_EH003', '9703011553', '9703011553', '1234567890', '1234567890', 'eg', '', 'superadmin', 'CFO', '9703011553', 'Vizag', 'Vizag', '2020-01-01', '', '', '	    EswariGroup', 0, '1234567890', 'ICIC0083', 'Rakesh', 'active', 'C-OFFICE', '', ''),
(21, 'ehemp2', 'ehemp2@gmail.com', 'emp2@eh', '123456', '123456', '1234567890', '1234567890', 'eh', '', '', 'AM', '', '', '', '', '', '', '', 56, '', '', '', 'active', '', '', ''),
(28, 'chandu v', 'chandhu418@gmail.com', 'emp@eh', '123456', '+919010402324', '1234567890', '1234567890', 'eh', '', '', 'RM', '', '', '', '', '', '', '', 21, '', '', '', 'active', '', '', ''),
(29, 'Admin Eswarihomes', 'admin@eswarihomes.com', 'admin@eswarihomes', '123456', '9010402324', '1234567890', '1234567890', 'eh', '', 'admin', '', '', '', '', '', '', '', '', 0, '', '', '', 'active', '', '', ''),
(30, 'Admin ASETechnologies', 'admin@asetechnologies.com', 'admin@asetechnologies', '123456', '+919010402324', '1234567890', '1234567890', 'at', '', 'admin', '', '', '', '', '', '', '', '', 0, '', '', '', 'active', '', '', ''),
(39, 'Test1', 'test1@gmail.com', 'EG01_EH039', '123456', '901040232', '1234567890', '1234567890', 'eh', '', '', 'EX', '89898989', 'hno90', 'hyd', '2020-11-06', '113.png', 'eglogo2.png', 'ats', 0, '', '', '', 'active', '', '', ''),
(40, 'Test1', 'test1@gmail.com', 'EG01_EH040', '123456', '+919010402324', '1234567890', '1234567890', 'eh', '', '', 'EX', '89898989', 'hno90', 'hyderabad', '2020-11-05', 'a1.jpg', 'p1.jpg', 'ats', 0, '8990998990', 'idb0909', 'V Chandu', 'active', '', '', ''),
(41, 'Yadla Yashwanth Raj', 'yash8185934144@gmail.com', 'EG01_EH041', '7286868414', '7286868414', '218681978927', 'EVWPR6829D', 'eh', '', '', 'EX', '7780231030', 'Dr no. 56-2-108,Lemarthi, Aganam Pudi, Gajuwaka , vishakapatnam', 'Dr no. 56-2-108, lemarthi, Aganam Pudi,Gajuwaka,vishakapatnam', '2020-08-17', 'IMG20201106091528.jpg', 'IMG_20200829_093940.jpg', 'No', 0, '20219399304', 'SBIN0006832', 'Yadla Yashwanth Raj', 'inactive', '', '', ''),
(42, 'PILLINARESH', 'nareshp777@gmail.com', 'EG01_EH042', '8096991326', '8096991326', '374628073990', 'ATHPP1996J', 'eh', '', 'admin', 'ABM', '9701023834', 'Flat No.401, 4th Floor, Sri Bhagavan Hill View, Near Baba Engg College, PM Palm Last Bus Stop, Visakhapatnam-41', '', '2019-09-01', 'Adhar.pdf', 'PAN Card.pdf', 'Saritha Infra and Geostructures', 0, '249401503113', 'ICIC0002494', 'PILLI NARESH', 'inactive', '', '', ''),
(44, 'Rajakumar pasala', 'raja1983mudra@gmail.com', 'EG01_EH044', '7793971767', '7793971767', '486069079831', 'BTRPP3358K', 'eh', '', '', 'RM', '7842109744', 'H. No. 16-18/7, Dagguvanipalemcolony,, pendurti, visakhapatnam, ap, pin,. 531173', 'H. No. 2-236, muddadada veedi, Narasannapeta, srikakulam, ap, pin. 532421', '2020-09-04', 'raw-1.jpeg', 'raw-2.jpeg', 'Mudra agricultural & skill development multi state co operative society ', 55, '20111588316', 'SBIN0000753', 'Rajakumar pasala', 'inactive', '', '', ''),
(47, 'Anupkiranvelpula', 'anupmxpk9@gmail.com', 'EG01_EH047', '7780398838', '7780398838', '492298981939', 'ASRPV8844L', 'eh', '', '', 'RM', '9948504827', '3-102 Sri parvathi Nivas Vivekananda nagar yendada visakhapatnam 530045', '3-102 Sri parvathi Nivas Vivekananda nagar yendada visakhapatnam 530045', '2020-11-04', '4B7A10DA-7456-4C60-89A3-D55FDB28EDB4.jpeg', '4F8ADA99-9816-4AC2-B692-1B3BF1F5316D.jpeg', 'Genpact Pvt Ltd Hyd', 0, '132001504450', 'ICIC0001320', 'Anup Kiran Velpula', 'inactive', '', '', ''),
(49, 'Ramunaidu', 'pasalaramunaidu93@gmail.com', 'EG01_EH049', '9010269171', '9010269171', '339477590694', 'EVAPP728K', 'eh', '', '', 'RM', '9490942478', 'Konisa vill, gajapathinagaram mandal, vizianagaram dist, AP state, pin code: 535270', 'Konisa vill, gajapathinagaram mandal, vizianagaram dist, AP state, pin code: 535270', '2018-10-10', 'IMG20201107113742.jpg', 'IMG20201107113751.jpg', 'No', 0, '249401503104', 'ICIC0002494', 'Pasala ramunaidu', 'inactive', '', '', ''),
(51, 'Chitturi Venkata Nagendra Prasad', 'prasad73.chittiri@gmail.com', 'EG01_EH051', '7093877969', '7093877969', '703784024967', 'AGHPC5744Q', 'eh', '', 'admin', 'BM', '9652017378', '6-58-19 Sramik Nagar, MVR College Road,Gajuwaka, Visakhapatnam', '6-58-19 Sramik Nagar, MVR College Road,Gajuwaka', '2018-10-20', '16047464645818305781751739754246.jpg', '16047464837738887323849468165850.jpg', 'No', 0, '440701500247', 'ICICI0004407', 'Chitturi Venkata Nagendra Prasad', 'active', 'C-OFFICE', '', ''),
(53, 'Saikumar', 'k.saikumarr3@gmail.com', 'EG01_EH053', '8886464412', '8886464412', '253442801225', 'ETTPK8323L', 'eh', '', '', 'AM', '9290618242', '50-2/8,5th floor, flat no .501, NRR Krishna kunj apartment, abid nagar , akkayyapalem, Visakhapatnam-530016', '50-2/8,5th floor, flat no .501, NRR Krishna kunj apartment, abid nagar , akkayyapalem, Visakhapatnam-530016', '2020-05-27', '16047474322913782815274184731561.jpg', '16047474454192228177639669949356.jpg', 'Vadem Technology', 56, '50320100003265', 'BARB0AKKAYY', 'K.sai kumar', 'active', 'C-OFFICE', '', ''),
(54, 'Mishra', 'debasismishra042@gmail.com', 'EG01_EH054', '07077242233', '07077242233', '897745765928', 'Dhvpm0016f', 'eh', '', '', 'RM', '9692249922', 'Kaniti road', 'Barampur  govinda vihar', '2020-07-01', '001.jpg', '008.jpg', 'Honeyy group', 0, '26170100022581', 'BARB0MVPVIS', 'Debasis mishra', 'inactive', '', '', ''),
(55, 'penumachasandeepvarma', 'sandeepvarma.p@gmail.com', 'EG01_EH055', '9705237676', '9705237676', '782370637472', 'ARCPP1841M', 'eh', '', 'admin', 'AM', '8886088856', 'flat no 402 sri vijaya sai vihar yendada vizag', 'flat no 402sri viiaya sai vihar yendada vizag', '2020-06-04', 'image.jpg', '851E6981-0D3D-49BB-A098-360A53FE5C4A.png', 'kalidindi group', 0, '', '', '', 'inactive', '', '', ''),
(56, 'Chandrasekhar', 'chandrasekhar.vizag@gmail', 'EG01_EH056', '9951870422', '9951870422', '359522315161', 'AUVPK6345B', 'eh', '', 'admin', 'ABM', '9491335098', '37-12-41/6, NGGOS  colony kapparada vizag', '37-12-41/6, NGGOS  colony kapparada vizag', '2018-10-09', '16049202140623330290535867458552.jpg', '16049202436255244965817587945124.jpg', 'Slcp', 51, '', '', '', 'active', 'C-OFFICE', '', ''),
(57, 'RAMANA', 'Nagumanthriramana@gmail.com', 'EG01_EH057', '9581899878', '9581899878', '728507656110', 'AQKPN566L', 'eh', '', 'admin', 'AM', '7981825303', 'FLAT NO 101, SREE NIVAS RESIDENCY, GANDHI NAGAR, GAJUWAKA, VISAKHAPATNAM', 'FLAT NO 101, SREE NIVAS RESIDENCY, GANDHI NAGAR, GAJUWAKA, VISAKHAPATNAM', '2020-07-01', '', 'image-2faa44c0-6c30-4ac7-92fb-2934aca605a6.jpg', 'HONEYY GROUP', 0, '587102010005087', 'UBIN0558711', 'N G S VENKATA RAMANA', 'inactive', '', '', ''),
(58, 'Pallisrinivasarao', 'pallisrinivasarao999@gmail.com', 'EG01_EH058', '9989214399', '9989214399', '803322626120', 'BHVPS8221C', 'eh', '', '', 'RM', '8121882999', 'Visalakshinager', 'Visalakshinager', '2020-10-11', 'Screenshot_2020-11-09-17-39-34-06.jpg', 'Screenshot_2020-11-09-17-39-42-72.jpg', 'Honeyy group', 0, '10653945491', 'SBIN0000953', 'Pallisrinivasarao', 'inactive', '', '', ''),
(59, 'Bharathi', 'bharathisannidhibs54@gmail.com', 'EG01_EH059', '8790252646 ', '8790252646 ', '335706803137', 'KCQPS6819P', 'eh', '', '', 'EX', '9542287855', '33-14-314 allipuram main road near axis bank atm', '33-14-314 allipuram main road', '2020-09-28', 'IMG_20190715_210238.jpg', 'IMG_20190813_122518.jpg', '', 0, '328902120000574', 'UBINO532894', 'Venkata Sai bharathi ', 'inactive', '', '', ''),
(60, 'Nagamani', 'vanisampathirao1987@gmail.com', 'EG01_EH060', '7989975807', '7989975807', '251056185550', 'BFGPB5301F', 'eh', '', '', 'RM', '7286044349', 'H. B colony... Dr no 55-29-17/1 near water tank... Sun school opp', 'Vishakapatnam', '2018-12-15', '', '', 'Sai Siri office', 0, '6705940098', 'IDIB000M308', 'Boddepalli. Nagamani', 'inactive', '', '', ''),
(61, 'Beenajaiganesh', 'ganeshasha3@gmail.com', 'EG01_EH061', '9381947824', '9381947824', '595599088954', '', 'eh', '', '', 'EX', '9949694229', 'Sivaji palem,pitapuram colony ', 'Srikakulam', '2020-11-07', 'Screenshot_2019-07-31-10-09-43-359_com.google.android.apps.photos.png', '', '', 0, '750250010050470', 'KARB0000750', 'Beena.jai ganesh', 'inactive', '', '', ''),
(62, 'PERLAVENKATANAGAMANOJKUMAR', 'manojkumarperla4@gmail.com', 'EG01_EH062', '9959088305', '9959088305', '259149263801', 'BINPP4579', 'eh', '', '', 'EX', '8341280644', '9-9-47/50; balaram nagar near taramajid vishakapatnam', '9-9-47/50 balaram nagar near taramajid manapuram colony vishakapatnam.', '2020-11-26', '1605697003421.png', '', 'Free launcher in realestate', 64, '32189107757', 'SBIN0012680', 'PERLAVENKATANAGAMANOJKUMAR', 'inactive', '', '', ''),
(63, 'Thotapriyanka', 'thotapriyanka668@gmail.com', 'EG01_EH063', '9949449441 ', '9949449441 ', '211973161945', 'AMAPT7324E', 'eh', '', '', 'EX', '8500966568 ', '1-72-5,Sector-3, M. V. P. COLONY ', 'Quater no 704,Phase 2, Satish dhawan space center, sriharikota  524124', '2020-11-26', '16071700967611429825878470267248.jpg', '', 'No', 64, '32801025382 ', 'SBIN0001982 ', 'Thotapriyanka ', 'inactive', '', '', ''),
(64, 'Lathif', 'syedlathif55@gmail.com', 'EG01_EH064', '8500225000', '8500225000', '699746121059', 'EEQPS9086J', 'eh', '', 'admin', 'AM', '9959088305', '9-9-47/59 Balaram nagar near Tara mosque vizag', '9-9-47/50 Balaram nagar near Tara mosque vizag', '2020-11-26', 'IMG-20190314-WA0014.jpg', 'IMG-20181003-WA0000.jpeg', 'Freelance', 0, '006001551303', 'ICIC0000060', 'Lathif syed', 'inactive', '', '', ''),
(65, 'KOTRA VENKATA NAGA SAI', 'saikotra123@gmail.com', 'EG01_EH065', '7658988947', '7658988947', '591109656305', 'HWEPK2656F', 'eh', '', '', 'EX', '7816015797', 'D.NO: 53-4-18/8/1,KRM colony,maddilapalem,visakhapatnam-530013.', 'D.NO: 19-86,ram nagar 3rd line,yelamanchili,visakha district-531055', '2021-01-03', '16097661729464399038423531582920.jpg', '16097661397747087494659802814090.jpg', '', 0, '39153011168', 'SBIN0008819', 'KOTRA VENKATA NAGA SAI', 'inactive', '', '', ''),
(66, 'B.Bhagya.lakshmi', 'bhagyaboddu4@gmail.com', 'EG01_EH066', '9515542401', '9515542401', '373125352378', '', 'eh', '', '', 'EX', '9347912287', 'New Gajuwaka ,High school road', 'Jangareddygudem', '2020-12-21', '16099110413016770349001604235432.jpg', '', 'Vasan eye care hospital', 0, '38902914135', 'SBIN0004721', 'Bharati nayak', 'inactive', '', '', ''),
(67, 'Mobile', 'mobileapp@gmail.com', 'EG02T_ASE067', '8885559131', '8885559131', '26730987766789', 'Hyd7ve8', 'at', '', 'admin', 'ABM', '863673883', 'HYDERABAD', 'HYDERABAD', '2021-01-01', 'images (3).jpeg', 'images (4).jpeg', 'Gheh', 0, '738838994949 ', '7gevy', 'Mobile ', 'inactive', '', '', ''),
(68, 'Mobile', 'mobile1@gmail.com', 'EG02T_ASE068', '8885559132', '8885559132', '88377738888', 'Hthh8889', 'at', '', '', 'EX', '77898', 'Hyderabad', 'Hyderabad', '2021-01-03', 'IMG-20210120-WA0022.jpg', 'IMG-20210120-WA0023.jpg', 'Yhgs', 0, '56778999987766', 'Uhs00', 'Mobiles', 'inactive', '', '', ''),
(69, 'KOLLIDURGAPRASAD', 'kollidurgaprasad36@gmail.com', 'EG01_EH069', '7095241987', '7095241987', '438248763587', 'GBXPD0773F', 'eh', '', '', 'EX', '8985770104', '56-35-9/1,thotaveedi, kancharapalem, visakhapatnam ', '56-35-9/1,thotaveedi, kancharapalem, visakhapatnam ', '2021-01-25', '16115547310853217376597280224438.jpg', '16115547393428274956693781870138.jpg', '', 0, '35952044059', 'SBIN0010614', 'Kolli Durga Prasad', 'inactive', '', '', ''),
(70, 'Bhuvaneshwar', 'bhuvan542452@gmail.com', 'EG02T_ASE070', '08121171597', '08121171597', '247173826316', 'CIMPR5069L', 'at', '', '', 'EX', 'None', 'Laldarwaza', 'Laldarwaza', '2020-07-13', 'Aadhar Bhuvan_1.pdf', 'Pan Card.pdf', 'Kaawish.in, An online e-commerce portal', 0, '30242210047148', 'CNRB0013024', 'BHUVANESHWAR RAGIPHANI', 'inactive', '', '', ''),
(71, 'Chandrashekher', 'chandhu418@gmail.com', 'EG02T_ASE071', '9010402324', '9010402324', '927209657744', 'ALNPV2767P', 'at', '', '', 'EX', '9490591803', 'Yousufguda, Hyderabad', 'HNo 6-20,Palem, Nagarkarnool', '2021-01-26', 'aadhar card.jpg', 'pan card.jpg', 'CNK Management Pvt Ltd', 0, '018301583518', 'ICIC0000183', 'VALEPAY CHANDRA SHEKHERRAO', 'active', 'HYDERABAD', '', ''),
(72, 'chelimalapraveenkumar', 'chelimala.praveen@gmail.com', 'EG02T_ASE072', '9642515594', '9642515594', '486821858718', 'ERBPK1392F', 'at', '', '', 'EX', '9652155948', 'H.No 16-11-741/D/33, Dhilshukunagar,Hyderabad', 'H.No 3-90/A ,Pasnoor,Suryapet', '2020-12-07', 'addhar (1).pdf', 'pan.pdf', 'Software Development Company (Microden Software Pvt.Ltd)', 0, '100051117327', 'INDB0000226', 'Chelimala Praveen Kumar', 'active', 'HYDERABAD', '', ''),
(73, 'SURESH', 'surimoses50@gmail.com', 'EG02T_ASE073', '9573450633', '9573450633', '951338963565', 'BWCPG4429C', 'at', '', '', 'EX', '9573450633', 'Uppal, Hyderabad', 'Uppal, Hyderabad', '1-2-2021', 'Adhar.jpeg', 'Pan.jpeg', 'Smartrise Technologies Pvt ltd', 0, '50100171317214', 'HDFC0000317', 'SURESH G', 'inactive', 'HYDERABAD', '', ''),
(74, 'chandrakanth', 'chandrakanthakkanapally@gmail.com', 'EG02T_ASE074', '9392544333', '9392544333', '654174480543', 'CHKPA9645Q', 'at', '', '', 'EX', '', '4-2-492 badichowdi sultanbazar hyderabad', '', '2020-06-19', 'over all documents.pdf', 'Pan card .pdf', 'ACCENTURE', 0, '0312165756', 'KKBK0007466', 'AKKANAPALLY CHANDRAKANTH', 'inactive', 'HYDERABAD', '', ''),
(75, 'MasarapuSantoshKumar', 'masarapukumar@gmail.com', 'EG01_EH075', '8106806586', '8106806586', '256804631091', '', 'eh', '', '', 'EX', '9550376586', 'Visakhapatnam, Sheelanagar, Gajuwaka', 'Vizianagaram, Gajapathinagaram-535270', '2021-02-03', '1612434750032_my aadhar.jpg', '', '', 0, '36570872497', 'SBIN0001458', 'M Santosh Kumar', 'inactive', '', '', ''),
(76, 'Boddetiyaminiprasanna', 'yamininimay22@gmail.com', 'EG01_EH076', '8519938744', '8519938744', '856024354618', 'DYEPB9647B', 'eh', '', '', 'EX', '', 'D/o : 35-1-45/2, r.p.peta, Kancharapalem, visakhapatnam visakhapatnam-8', 'D/o : 35-1-45/2, r.p.peta, Kancharapalem, visakhapatnam visakhapatnam-8', '2021-02-17', 'IMG_20210218_182431.jpg', 'IMG_20210218_182449.jpg', 'Siva shakthi townships', 0, '2434101206974', 'CNRB00002434', 'Boddeti yamini prasanna', 'inactive', '', '', ''),
(77, 'Kodurutarun', 'tarunkoduru7@gmail.com', 'EG01_EH077', '6281034912', '6281034912', '967448311085', 'BVCPT6710J', 'eh', '', '', 'EX', '8367048108', 'highway,m.t.c.palem,akkayyapalem,vskp-16', 'highway,m.t.c.palem,akkayyapalem,vskp-16', '2021-02-15', 'IMG-20201201-WA0006.jpg', 'IMG_20210218_182416.jpg', 'GGC CONSTRUCTION', 0, '01851010089402', 'ANDB0000185', 'Koduru tarun', 'inactive', '', '', ''),
(78, 'BNVSHANKARRAO', 'bnvshankar@gmail.com', 'EG01_EH078', '8919320229', '8919320229', '823471633557', 'BMQPS0832K', 'eh', '', '', 'RM', '9963647584', '50-91-3/1,Santhipuram,Visakhapatnam-530016.', '50-91-3/1,Santhipuram,Visakhapatnam-530016', '2021-02-26', '', '', 'Sqareyards', 0, '20100001133735', 'FSFB0000001', 'BUDDHANOOKAVENKATSHANKARRAO', 'inactive', '', '', ''),
(79, 'GUMMADI SRAVANTHI', 'gummadisravanthi88@gmail.com', 'EG02T_ASE079', '9014979810', '9014979810', '521149097613', 'ALZPG6588R', 'at', '', 'admin', '', '9492218170', 'G.SRAVANTHI D/O G SEELAMA RAJU', 'FLT NO 2E ,SRINIVASA RESIDENCY', '2021-02-01', 'IMG_20210309_101610.jpg', 'IMG-20210201-WA0000.jpg', '', 0, '62509782488', 'SBIN0021457', 'GUMMADI SRAVANTHI', 'active', 'HYDERABAD', '', ''),
(80, 'Dheeraj', 'dheeraj@eswarihomes.com', 'EG01_EH080', '8185992770', '8185992770', '942988471327', 'ESCPR4459E', 'eh', '', 'admin', 'ABM', '7995862776', 'Flat no -205, vishwanadh avenues v-1', 'Flat no -205,vishwanadh avenues v-1', '2021-04-01', 'IMG-20210106-WA0002.jpeg', 'IMG-20210127-WA0000.jpg', 'AGM at vishwanadh avenues', 0, '863411610000019', 'BKID0008634', 'Dheeraj reddy', 'inactive', '', '', ''),
(81, 'BadriRoshanAbhishek', 'roshanabhishek150@gmail.com', 'EG01_EH081', '7730082002', '7730082002', '962036525965', 'DVGPB2621N', 'eh', '', '', 'RM', '6300673083', '37-12-42/3 nggos colony ,pr gardens kapparada', '37-12-42/3 nggos colony ,pr gardens', '2021-04-08', '16183828538762376946976704351476.jpg', '16183828717084934288461650039372.jpg', 'No', 0, '35339244988', 'SBIN0013208', 'Roshan Abhishek', 'inactive', 'C-OFFICE', '', ''),
(82, 'SitapathiVasa', 'sitapathi.vasa@gmail.com', 'EG01_EG082', '7794012056', '7794012056', '494720566708', 'AJTPV7221J', 'eg', '', 'admin', 'HR', '9110556670', '401 sai balaji residency 100 ft fing road vizianagaram', '401 sai balaji residency 100 ft fing road vizianagaram', '2021-03-15', 'IMG_20181024_075044.jpg', '20180112_084717.png', 'The sun school (ADMIN HR)', 0, '610502010006852', 'UBIN0561053', 'Vasa V M Sitapathi Rao', 'inactive', '', '', ''),
(83, 'PAPARAO', 'BELAMANAPAPARAO@ESWARIHOMES.COM', 'EG01_EH083', '9533733500', '9533733500', '472061166948', 'DJSPB1302J', 'eh', '', 'admin', 'Admin', '9493166163', 'Old Gajuwaka, 530026', 'Kanugulavalasa village and post, Amadalavalasa, Srikakulam', '2020-02-17', '16184893953153518626578156822322.jpg', '16184894232368993302623714695942.jpg', 'Realince IT park Corporate Pvt Ltd', 0, '50100250798673', 'HDFC0000050', 'Belamana Paparao', 'inactive', 'GAJUWAKA', '', ''),
(84, 'Komalaalankala', 'komala@eswarihomes.com', 'EG01_EH084', '7997521994', '7997521994', '452495107251', 'EBLPA8125G', 'eh', '', '', 'EX', '7075783512', '12-72/2/1,aganampudi,gajuwaka, Visakhapatnam ', '12-72/2/1,aganampudi, gajuwaka, Visakhapatnam ', '2021-04-01', 'IMG_20210416_103552.jpg', 'IMG_20210416_103603.jpg', 'Vishwanadh avenues pvt ltd ', 0, '174010100030567', 'UBIN0817406', 'Komala Alankala ', 'inactive', '', '', ''),
(85, 'LOKESWARA RAO SESETTI', 'sesettilokeswararao@eswarihomes.com', 'EG01_EG085', '9642342305', '9642342305', '964750175469', 'BWRPS5536F', 'eh', '', 'admin', 'IT Admin', '9704189004', '15-1, LAKSHMI NAGAR ,BAJI JUNCTION  , BESIDE SAVIOUR LUTHERN CHURCH ,GOPALATANAM VISAKHAPATNAM 530027', '15-1, LAKSHMI NAGAR ,BAJI JUNCTION  , BESIDE SAVIOUR LUTHERN CHURCH ,GOPALATANAM VISAKHAPATNAM 530027', '2019-02-26', 'lokesh aadhar card 1b copy.jpg', 'LOKESH PAN CARD copy.jpg', 'SIMPSONS CO LTD', 0, '33325399206', 'SBIN0016821', 'LOKESWARA RAO SESETTI', 'active', 'C-OFFICE', '', ''),
(86, 'Usharani', 'usharanichintalapudi16@gamli.com', 'EG01_EH086', '9951786465', '9951786465', '494063877826', 'CKGPC9571G', 'eh', '', 'admin', '', '6302927735', 'Madhurawada, pmpalem, 1st busstop', 'Vizinagaram, Gantyada, lakkidam village, rajaveedhi', '2021-04-15', 'IMG_20210420_115853.jpg', 'IMG_20210420_115926.jpg', 'About credit card departmentd( Telecalling) ', 0, '35767722185', 'Sbinooo8298', 'Chinatalpudi usharani', 'inactive', '', '', ''),
(87, 'Achyuth', 'achyuthsai54@gmail.com', 'EG01_EH087', '7989538237', '7989538237', '260637479133', '', 'eh', '', '', 'EX', '9030843412', 'MIG 72 APHB COLONY pedagantyada gajuwaka visakhapatnam', 'Mig 72 Aphb colony pedagantyada gajuwaka vishakapatnam', '2021-04-22', '16195884620937589629186798186361.jpg', '16195886567932053608730272855330.jpg', 'Vishnu chemicals ', 0, '3074857388', 'CBIN0281394', 'Kompella Achuyth', 'inactive', '', '', ''),
(88, 'Vkannababu', 'kannababuvoonna@gmail.com', 'EG01_EH088', '8985769135', '8985769135', '889705241522', 'JBUPK2365A', 'eh', '', '', 'EX', '9010170345', '1-3-120(1) chinna akkireddypalam bhpv Post china gantyada gajuwaka visakhapatnam', '1-21A near railway gate kottavalasa parvathipuram Vizianagaram', '2021-04-22', '16195883395821127276900694619489.jpg', '16195883903074868162335316373105.jpg', '', 0, '9314495038', 'KKBK0007703', 'VOONNA KANNABABU', 'inactive', '', '', ''),
(89, 'T. prabhavati', 'prabhavatidas@gmail.com', 'EG01_EH089', '7893369973', '7893369973', '218743563805', 'AMIPD6077E', 'eh', '', '', 'RM', '9640535303', '3rd floor, venkata Ramana Recidency, vuda phase-2, Gandhi Nagar old gajuwaka', '3rd floor, venkata Ramana Recidency, vuda phase-2, Gandhi Nagar, old gajuwaka', '2021-04-22', 'IMG-20201118-WA0010.jpg', '16195890844588238395214498664992.jpg', 'Sri. Acharya all competitive Exam Institute', 113, '20098187643', 'SBIN0001738', 'Prabhavati Das', 'active', 'GAJUWAKA', '', ''),
(90, 'Dsuryasampath', 'sampathkrishna8@gmail.com', 'EG01_EH090', '7036723723', '7036723723', '869394219435', 'Dbfpd2232e', 'eh', '', '', 'RM', '9704050115', '64-1-144/b, Srinivas nagar, cormandal gate Visakhapatnam', '64-1-144/b, Srinivas nagar, cormandal gate, Visakhapatnam', '2021-04-22', 'IMG-20210428-WA0010.jpg', 'IMG-20210428-WA0009.jpg', 'Worked as computer operator in akash engineering works for 2 yrs and having experience in real estate as freelancer', 0, '2609101006789', 'CNRB0002609', 'Bala Krishna mohan', 'inactive', '', '', ''),
(91, 'Pilli Kishore Kumar', 'pkk05031991@gmail.com', 'EG01_EH091', '9493857253', '9493857253', '895675186747', 'BFSPP2884R', 'eh', '', 'admin', 'AM', '9642013253', 'S/o: P Dalaji Rao, D No: 59-27-42, Malkapuram, Visakhapatnam, Andhra Pradesh - 530011', 'S/o:- P Dalaji Rao, D No.59-27-42, Gandhi Street, Malkapuram, Visakhapatnam Andhra Pradesh', '2021-04-26', 'IMG_20210216_091757.jpg', 'IMG_20201014_190141.jpg', 'Highway Ventures', 92, '0462000400025700', 'PUNB0046200', 'Pilli Kishore Kumar', 'inactive', 'GAJUWAKA', '', ''),
(92, 'Vbhaskarrao', 'vydetibhaskar@gmail.com', 'EG01_EH092', '6300038538', '6300038538', '655312881932', 'AMPPB8486N', 'eh', '', 'admin', 'ABM', '8096373221', '24-79/4/4, sanath nagar, old gajuwaka', '24-79/4/4, sanath nagar, old gajuwaka', '2021-04-22', '16195937056737500006921558090188.jpg', '16195937360184518941770109740076.jpg', 'Honey group', 51, '36570100010676', 'BARBOGAJVIS', 'V bhaskar rao', 'active', 'GAJUWAKA', '', ''),
(93, 'ADDEPALLIBHUPATHIRAJU', 'bhupathiraju.369@gmail.com', 'EG01_EH093', '6301100379', '6301100379', '718029332494', 'BCRPA0738H', 'eh', '', 'admin', 'AM', '8500907433', '6-69 4th Street Sarada Nagar Kotturu Anakapalli Visakhapatnam', '', '2021-04-22', '16196722128018644119810771152848.jpg', '16196722278361581910464672146642.jpg', 'Margadarsi Chit fund Pvt ltd', 0, 'A/c 126801504957  ICICI Bank ', 'ICIC0001268', 'A BHUPATHI RAJU', 'inactive', '', '', ''),
(94, 'VISWANADHAM', 'viswanadhamdungu@gmail.com', 'EG01_EH094', '+918374713082', '+918374713082', '542003855208', 'BDKPV1558A', 'eh', '', '', 'EX', '+917888437644', 'PEDDA GANTIYADA', '2-269; INNESUPETA, DHARMAPURAM, ICHCHAPURAM, SRIKAKULAM, AP, 532312', '2021-04-27', 'IMG_20201123_105441.jpg', 'IMG_20181111_142232.jpg', 'Best tech mech&infra engineering Pvt ltd', 114, '32659815554', 'SBIN0000983', 'DUNGU VISWANADHAM', 'inactive', 'GAJUWAKA', '', ''),
(95, 'Mallaganesh', 'ganeshmalla88@gmail.com', 'EG01_EH095', '8897243193', '8897243193', '958764685240', 'BCJPM0510R', 'eh', '', '', 'RM', '9966726302', 'Ap hb Colony mig 373 dr no -18-49-12 pedagantyada gajuwaka', 'Ap hb Colony mig 373 dr no -18-49-12 pedagantyada ', '2021-04-27', 'Aadhaar ganesh new.pdf', 'pna card-1.jpg', 'Bbg', 0, '36570100003168', 'BARB0GAJVIS', 'M.Ganesh kumar', 'inactive', '', '', ''),
(96, 'Gunnabathula Sarala santhoshi rupa devi', 'ruparupadevi1986@gmail.com', 'EG01_EH096', '8309773827', '8309773827', ',592187525770', 'CTIPG5071Q', 'eh', '', '', 'RM', '7093351151', 'G.rupadevi', 'C/o K.v.ramkoti', '2021-05-05', 'Screenshot_2021_0512_100510.jpg', 'Screenshot_2021_0512_100611.jpg', 'ANR company  ', 0, '18862413000468', 'PUNB0782600', 'Gunnabathula Sarala santhoshi rupa devi', 'inactive', '', '', ''),
(97, 'Gunnabathula Sarala santhoshi rupa devi', 'ruparupadevi1986@gmail.com', 'EG01_EH097', '8309773827', '8309773827', ',592187525770', 'CTIPG5071Q', 'eh', '', '', 'RM', '7093351151', 'G.rupadevi', 'C/o K.v.ramkoti', '2021-05-05', 'Screenshot_2021_0512_100510.jpg', 'Screenshot_2021_0512_100611.jpg', 'ANR company  ', 0, '18862413000468', 'PUNB0782600', 'Gunnabathula Sarala santhoshi rupa devi', 'inactive', '', '', ''),
(98, 'PerendiChunnuSivaAkhil', 'akhilmr.perfect7@gmail.com', 'EG01_EH098', '8886827376', '8886827376', '294884403584', 'EQWPP6017E', 'eh', '', '', 'EX', '7675941230', '37-12-41/7/3', 'Nggos colony Kaparada ,', '2021-05-12', '16216802651344891122264774152143.jpg', '16216802856861608764654272776593.jpg', '', 0, '126901508355', 'ICIC0001269', 'Perendi Chunnu Siva Akhil', 'inactive', '', '', ''),
(99, 'Narayana', 'ballanki.nani4@gmail.com', 'EG01_EH099', '8106346236', '8106346236', '270255362985', 'CKCPN9964N ', 'eh', '', '', 'EX', '9398913230', '65-1-187/B, Srinivasa Nagar,corammadal gate,Gajuwaka,vskp', '1-140/1 Frivers colony Gajuwaka ', '2021-05-30', '16228620807981973739945691254527.jpg', '1622862112575639878415995162707.jpg', 'Technipfmc ', 113, '164801000010296', 'IOBA0001648 ', 'B Narayana Rao', 'inactive', 'GAJUWAKA', '', ''),
(100, 'KamminanaRojaRani', 'rojarani.kamminana@gmail.com', 'EG01_EH0100', '9346091872', '9346091872', '', '', 'eh', '', 'admin', 'Front Office Executive', '9640444078', 'Chandranagar, gopalapatnam', 'Chandranagar, gopalapatnam', '2021-06-22', '', '', '', 0, '', '', '', 'inactive', 'C-OFFICE', '', ''),
(102, 'Dineshkumar', 'kelladinesh3@gmail.com', 'EG01_EH0102', '7702716679', '7702716679', '993150654235', 'Nill', 'eh', '', '', 'RM', '8142367896', '6-65-14 sramikanagar chinagantyada gajuwaka', '6-65-14 sramikanagar chinagantyada gajuwaka ', '2021-07-01', 'BB445FC9-5E6D-4356-B60C-8CBFED61AB13.jpeg', '', '', 114, '33632839771', 'SBIN0015759', 'Kella Dinesh', 'inactive', 'GAJUWAKA', '', ''),
(103, 'Pmadhavkrishna', 'krishmad00@gmail.com', 'EG01_EH0103', '8096187349', '8096187349', '334605145163', 'JSWPK7027N', 'eh', '', '', 'EX', '6300125110', '13-221 arilova tic point Visakhapatnam', '13-221 arilova tic point Visakhapatnam', '2021-07-08', '', '', '', 0, '6038101004505', '', ' Patnana madhav krishna', 'inactive', '', '', ''),
(104, 'TRaju', 'tadiraju4@gmail.com', 'EG01_EH0104', '9000669793', '9000669793', '244958980816', 'Bampt8480j', 'eh', '', '', 'EX', '9000669793', 'Akkayyapalem', 'Akkayyapalem', '2021-07-08', '', '', '', 0, '34734774048', 'Sbin0008014', 'Tadi raju', 'inactive', '', '', ''),
(105, 'Sainagesh', 'sainagesh567@gmail.com', 'EG01_EH0105', '7013146476', '7013146476', '533250915104', '', 'eh', '', '', 'RM', '8142386216', '2-57 Vapaguta visakhapatnam', '', '2021-07-01', '16259137247762922364254321898395.jpg', '', '', 53, '203153343392', 'SBIN0010574', 'Battula sai', 'active', 'C-OFFICE', '', ''),
(106, 'sekhar', 'sekhar17111984@gmil.com', 'EG01_EH0106', '8142933111', '8142933111', '245633100476', 'APTPC0092C', 'eh', '', 'admin', 'BM', '8008823334', 'Vijayawada', 'Vijayawada', '2021-05-01', '1626767763472803536659019437956.jpg', '16267678008211455753523933826839.jpg', '', 0, '20072378014', 'SBIN0012682', 'Sekhar chalavadi', 'active', 'VIJAYAWADA', '', ''),
(107, 'OMKAR', 'pandiomkar@gmail.com', 'EG01_EH0107', '9948198578', '9391629121', '485448442977', 'EJAPP2366F', 'eh', '', '', 'RM', '9948198578', '2-27 komaravolu post pamaru md krishna dt pin 521322', '2-27 komaravolu post pamarru md krishna dt pin 521322', '2021-07-19', 'IMG-20210723-WA0011.jpg', 'IMG-20210723-WA0010.jpg', 'Idea Cellular limited', 106, '066810100018556', 'UBIN0806684', 'Andhra bank', 'active', 'VIJAYAWADA', '', ''),
(108, 'SKTABREZALIPASHA', 'shaikalimtm@gmail.com', 'EG01_EH0108', '9553822863', '9553822863', '733473707213', 'Buips3795p', 'eh', '', 'admin', 'ABM', '9553822863', '16-45/1 Sanath Nagar Kanuru penamaluru mandal', 'Nil', '2021-07-17', 'IMG_20210723_192256.jpg', 'IMG_20210723_192414.jpg', 'Nill', 0, '630601553667', 'ICIC0006306', 'SK TABREZ ALI PASHA', 'inactive', 'VIJAYAWADA', '', ''),
(109, 'Vinaykumar', 'vinaykurella83@gmail.com', 'EG01_EH0109', '9866430787', '9866430787', '889062736292', 'CFDPK8524H', 'eh', '', 'admin', 'AM', '7839553983', '51-1-9a,Gunadala, Vijayawada, Krishna,A.P-520004', '51-1-9a, Gunadala, Vijayawada,Krishna,A.P-520004', '2021-07-17', '16270579330478344143412828654629.jpg', 'Screenshot_20210723_191618.jpg', 'Kia motors', 0, '30740378384', 'SBIN0007955', 'SBI', 'inactive', 'VIJAYAWADA', '', ''),
(110, 'Pillutla anusha', 'anua28722@gmail.com', 'EG01_EH0110', '8096792102', '8096792102', '918410215861', 'DZOPA4996P', 'eh', '', '', 'RM', '9866933247', 'New Gajuwaka BC road Andhrabank', 'Guntur  narasaraopet  (M) uppalapadu', '2021-07-22', 'IMG20210116151600.jpg', '', 'honey group and jahnavi associates', 114, '36391647079', 'SBIN0000884', 'Pillutla Anusha', 'active', 'GAJUWAKA', '', ''),
(111, 'Maddusatish', 'satish27223@gemil.com', 'EG01_EH0111', '7013439026', '7013439026', '859553105416', 'ETTPK8324M', 'eh', '', '', 'RM', '7013439026', 'Vijayanagaram', 'Vijayanagaram', '2021-07-15', 'IMG-20210727-WA0001.jpg', '', 'No', 0, '35035361151', 'SBIN0002768', 'Maddu satish', 'inactive', 'C-OFFICE', '', ''),
(112, 'Uday jakkamsetti ', 'juday6013@gmail.com', 'EG01_EH0112', '7995884121', '7995884121', '4314 2926 7933', 'Bampj2579q', 'eh', '', '', 'EX', '7672073519', 'Sec-8,steel plant quarters,visakhapatnam ', 'Steel plant quarters,ukkunagaram,visakhapatnam ', '2021-07-28', '16277341758916517962744648229178.jpg', '16277342003644586813606304010275.jpg', 'Navyasri', 0, '861010610000501', 'Bkid0008610', 'Uday jakkamsetti ', 'inactive', 'GAJUWAKA', '', ''),
(113, 'Rajakishan', 'rajakishan2025@gmail.com', 'EG01_EH0113', '7286032994', '7286032994', '562266529498', 'AYZPT1879P', 'eh', '', 'admin', 'AM', '9492976525', 'Aganampudi', 'Devarapalli', '2021-08-01', '16282254194828865130333610602643.jpg', '16282254469653470405325910070992.jpg', 'Honeyy Group', 92, '32644770389', 'SBIN0002707', 'T.Raja kishan singh', 'active', 'GAJUWAKA', '', ''),
(114, 'Akkenasaisarath', 'saisarathhg@gmail.com', 'EG01_EH0114', '9347595161', '9347595161', '331202292396', 'CUIPA2142M', 'eh', '', 'admin', 'AM', '9110506468', 'Kanithi Road, Gajuwaka, Visakhapatnam', 'Bobbili, Vizianagaram, Andhra Pradesh', '2021-08-01', 'IMG_20210806_151252.jpg', 'IMG_20210806_151231.jpg', 'Honeyy Group', 92, '37647485282', 'SBIN0000820', 'Akkena sai sarath', 'active', 'GAJUWAKA', '', ''),
(115, 'Tejasaipavan', 'tejadarling2511@gmail.com', 'EG01_EH0115', '7659902030', '7659902030', '733206739812', 'BUKPT7945L', 'eh', '', '', 'RM', '7674881733', '13-18-11 sanjeev colony , b.c road gajuwaka', '13-18-11 sanjeev colony , b.c road gajuwaka', '2021-08-11', '20210813_115205.jpg', '20210813_115105.jpg', 'Honeyy group', 113, '212010100050686', 'UBIN0821209', 'Anga. Teja sai pavan', 'active', 'GAJUWAKA', '', ''),
(116, 'sarojinidevi', 'sarojifeb18@gmail.com', 'EG01_EH0116', '8297891135', '8297891135', '354241392323', 'EHFPK1380F', 'eh', '', '', 'RM', '7660920331', 'Do/no 65-4-259, nakkavaanipalam, Gajuwaka', 'Do/no 64/24/32  kunchammacolony gajuwaka visakhapatnam', '2021-09-04', '16309067199442634060470076338376.jpg', '163090674483739902988522760528.jpg', 'Honeyygroup', 113, '33468938100', 'SBIN0003436', 'K, sarojini devi', 'inactive', 'GAJUWAKA', '', ''),
(118, 'BaipalliGiri', 'baipalliarjun@gmail.com', 'EG01_EH0118', '6302863676', '6302863676', '696538027552', '-', 'eh', '', '', 'EX', '9398135975', 'BC Road, Banoji Thota, Gajuwaka', '1-47, Chinna bethalapuram, Mandasa(M), Srikakulam', '2021-09-04', '12345.jpeg', '', 'No Experience', 114, '55811010008465', 'CNRB0005581', 'Baipalli Giri', 'active', 'GAJUWAKA', '', ''),
(119, 'Allamsettiviswanadh', 'viswanadh788@gmail.com', 'EG01_EH0119', '9908465169', '9121410421', '762638928114', 'cwppa7912q', 'eh', '', '', 'RM', '8143245957', '73-4-19/1 patamata,thotavari street', '73-4-19/1 patamata,thotavari street', '2021-08-04', 'image.jpg', 'image.jpg', 'Hotel marg krishnaaya', 0, '042410100145850', 'UBIN0532975', 'Allamsetti viswanadh', 'inactive', 'VIJAYAWADA', '', ''),
(120, 'Harshavardhankavuru', 'harshakavuru@gmail.com', 'EG01_EH0120', '7013987014', '7013987014', '928101639376', 'AWWPK5897K', 'eh', '', '', 'RM', '7731003226', '39-33-41/15, 3rd road, 3Rd floor, T-3, Sri Sai Sampath enclave, Madhavadhara, Visakhapatnam-530007', '39-33-41/15, 3rd road, 3Rd floor, T-3, Sri Sai Sampath enclave, Madhavadhara, Visakhapatnam-530007', '2021-09-02', 'IMG_20210913_130942.jpg', 'IMG_20210913_130648.jpg', 'Square yards', 51, '036501512324', 'ICIC0000365', 'HARSHAVARDHAN K', 'inactive', 'Vizag', '', ''),
(121, 'GaddapuRajesh', 'rajeshgaddapu1503@gmail.com', 'EG01_EH0121', '6304536532', '6304536532', '691673612069', 'CVBPG1847H', 'eh', '', '', 'RM', '9603875429', '38-38-68/1/1', 'Vamsi nagar', '2021-09-01', 'IMG-20210106-WA0005.jpg', 'IMG_20200818_143859.jpg', '', 0, '35311880801', 'SBIN0012839', 'Gaddapu rajesh', 'inactive', 'Vizag', '', ''),
(122, 'GuntupalliHimadeepthi', 'deepthiguntupalli0401@gmail.com', 'EG01_EH0122', '8008867710', '8008867710', '698446769788', 'CKUPG6746F', 'eh', '', 'admin', 'Front Office Executive', '9347843927', '5-43,kurumadalli', '', '2021-09-01', 'IMG_20210710_105935.jpg', 'IMG_20210710_103208.jpg', 'Kotak Mahindra', 0, '3187101003804', 'CNRB0003187', 'Guntupalli Hima deepthi', 'active', 'Vijayawada', '', ''),
(123, 'GopisettiVenkataLakshmi', 'venkatalakshmigopisetti62@gmail.com', 'EG01_EH0123', '7386293069', '7386293069', '490588475033', 'DHGPG9392P', 'eh', '', '', 'Telecaller', '9441520639', '21-10/2-214 vijay durga Nagar, gundala,Vijayawada', '21-10/2-214vijay durga Nagar, gundala, Vijayawada', '2021-09-01', 'IMG-20210913-WA0035.jpg', 'IMG_20200916_174217.jpg', 'HDFC life insurance company', 0, '50432693309', 'IDIB000K834', 'Gopisetti Venkata Lakshmi', 'active', 'Vijayawada', '', ''),
(124, 'Dasarishanmukasrikeerthi', 'dasarishanmukasrikeerthi@gmail.com', 'EG01_EH0124', '7780714366', '7780714366', '273848203715', 'DHIPD9993K', 'eh', '', '', 'Telecaller', '8919885599', 'D.No:3-97,sai Nilayam,subbarao nagar,gannavaram-521101', 'D.No:3-97,sai Nilayam subbarao nagar,gannavaram-521101', '2021-09-04', 'IMG-20210831-WA0018.jpg', 'IMG-20210831-WA0015.jpg', 'Kotak mahindra ', 0, '032100100002062', 'IBKL0031VCB', 'd.shanmuka sri keerthi', 'inactive', 'Vijayawada', '', ''),
(125, 'SadipidakalaPrasanth', 'chandudhama143@gmail.com', 'EG01_EH0125', '9573809065', '9573809065', '793444350520', 'MMTPS1555H', 'eh', '', '', 'EX', '9908247430', 'Aganampudi, Visakhapatnam', 'Vannam villege, komarada mandalam, vizagamaram distic', '2021-09-17', 'Screenshot_20210919_182720.jpg', 'Screenshot_20210919_182716.jpg', 'No', 113, '2991101010471', 'CNRB0002991', 'Sadipidakala Prasanth', 'active', 'GAJUWAKA', '', ''),
(126, 'G anuhya', 'anuhyagopisetty@gmail.com', 'EG01_EH0126', '9392773549', '9392773549', '222554496236', 'DRYPG2784M', 'eh', '', '', 'Telecaller', '8801023410', 'Prathuru', 'Prathuru', '2021-09-16', '20210920_101631.jpg', '', 'HDFC life insurance ', 0, '50402826369', 'ALLA0212696', 'G.anuhya', 'active', 'Vijayawada', '', ''),
(127, 'TangiralaMeena', 'meenaraj4752@gmail.com', 'EG01_EH0127', '9391974327', '9391974327', '259681916872', '', 'eh', '', '', 'Telecaller', '9346477206', '36-8-81, jayaraju street, near Sri Chaitanya techno school, madhu gardens', '36-8-81, jayaraju street, near Sri Chaitanya techno school, madhu gardens', '2021-09-03', 'IMG-20210920-WA0002.jpg', '', 'Green valley infra services', 0, '35307045082', 'SBIN0007899', 'Tangirala meena ', 'inactive', 'Vijayawada', '', ''),
(128, 'MekalaRavi', 'raviajoop@gmail.com', 'EG01_EH0128', '8074691866', '8074691866', '326342534152', 'DPWPM0059B', 'eh', '', '', 'RM', '9000605443', 'Haripuram vill ,', 'Mandasa mdl   ,', '2021-09-16', '16321447369164765570506397762301.jpg', '16321447604896951510326609816075.jpg', 'Square yards', 0, '31819095449', 'SBIN0015307', 'Mekala Ravi', 'inactive', 'Vizag', '', ''),
(129, 'kodimaheshanilkumar', 'maheshindianroyals@gmail.com', 'EG04_EC0129', '7729887799', '7729887799', '486253229671', 'CLRPK6932L', 'ec', '', '', 'Loans Manager', '7674967203', 'DNO 36-94-294/2 JAGAJEEVAN NAGAR KANCHARAPALEM VISAKHAPATNAM 530008', 'DNO 36-94-294/2 JAGAJEEVAN NAGAR KANCHARAPALEM VISAKHAPATNAM 530008', '2021-09-20', '', 'k mahesh anil kumar pan card ..eswari captial.jpeg', 'LIC HOME LOANS HYD', 0, '20375566526', 'SBIN0001611', 'K MAHESH ANIL KUMAR', 'inactive', 'Vizag', '', ''),
(130, 'Nunnausharani', 'nunnausha96@gmail.com', 'EG01_EH0130', '9493131743', '9493131743', '455451059958', 'BWJPN2496M', 'eh', '', '', 'RM', '6303779180', 'MVP Clooney sector9 alwardpublic school opposite smiles hostel ', 'Navakandravada pithapuram Mandalam eastgodavari', '2021-09-20', 'IMG-20210920-WA0001.jpg', '', 'Squaryard ', 0, '32757910193', 'SBIN0001003 ', 'Nunnam usharani', 'inactive', 'Vizag', '', ''),
(132, 'A.Ravikiran', 'kiranking4@gmal.com', 'EG01_EH0132', '8522085443', '8522085443', '371217438071', 'COWPR2766G', 'eh', '', '', 'RM', '8790215099', 'D.no:-12-1795,manip', 'D.no.12-1795,manipal hospital, Mahanadu,tadepalli, guntur Dist;a.p.', '2021-09-24', 'IMG_20210930_164802.jpg', 'IMG_20210930_164820.jpg', 'Sri sai real estate', 133, '7093749109', 'IDIB000T503', 'A.Ravikiran', 'active', 'Vijayawada', '', ''),
(133, 'BalakrishnaA', 'baluannambhotla@gmail.com', 'EG01_EH0133', '8143973805', '8143973805', '688161757449', 'BSEPA64422H', 'eh', '', 'admin', 'AM', '7842738327', '12-1795,sr nager, tadepalli, guntur dist,ap', '12-1795,sr nager, tadepalli, guntur dist,ap', '2021-09-24', '16330066044051448936123563195869.jpg', '16330066350315190770456069109691.jpg', 'Fmg property floor ', 106, '38683783718', 'SBIN0012870', 'Balakrishna annambhotla ', 'active', 'Vijayawada', '', ''),
(134, 'B.Srikanth', 'bsrikanth.gst.in@gmail.com', 'EG01_EH0134', 'Srikanth@07', '9492266971', '438701512852', 'BOLPB4572E', 'eh', '', '', 'Accountant', '8074603838', '12-983/1, Gandhi Nagar, Aarilova, Visakhapatnam', '12-983/1, Gandhi Nagar, Aarilova, Visakhapatnam', '2021-10-01', 'IMG_20210721_113824.jpg', 'IMG_20201001_223243.jpg', 'Vikas a jain and co', 0, '50100462555303', 'HDFC0003991', 'Srikanth Biyyala', 'active', 'Vizag', '', ''),
(135, 'kalyan patnaik', 'kalyanpatnaik63@gmail.com', 'EG01_EH0135', '7036371647', '7036371647', '929426206955', 'EJUPS8528E', 'eh', '', '', 'RM', '8179691629', '23-26-2/1, chinnamma vari Street, beside 1town police station,', 'Beside 1 town police station, visakhapatnam 1', '2021-10-11', '', '', 'FRESHER', 0, '861910110008305', 'BKID0008619', 'SAHINI KALYANASURYANARAYANA PATNAIK', 'inactive', 'Vizag', '', ''),
(136, 'KILLOSAILAJA', 'killosailu@gmail.com', 'EG01_EH0136', '8978222816', '8978222816', '363830515840', 'IPUPK9424P', 'eh', '', 'admin', 'Front Office Executive', '7013044248', 'k.jagannadham,railway quaters 65/B,type-2,marripalem,vsp_530018', 'k.jagannadham,railway quaters 65/B,type-2marripalem,vsp-530018', '2021-10-20', 'Screenshot_20211018-125516_Gallery.jpg', 'IMG-20211021-WA0002.jpg', 'no', 0, '34769849946', 'SBIN0010614', 'killo sailaja', 'active', 'Vizag', '', ''),
(137, 'SandeepDasari', 'sandeep_dasari2007@yahoo.com', 'EG01_EH0137', '9014841111', '9014841111', '801473380028', 'AUYPD3931D', 'eh', '', 'admin', 'HR', '7569434599', 'Dr No :11-19,  Pl -77, Sramasakthinagar, Chinamushidiwada, Vizag', 'Dr No :11-19,  Pl -77, Sramasakthinagar, Chinamushidiwada, Vizag', '2021-10-17', 'Screenshot_2021_1006_155731.jpg', 'Screenshot_2021_1006_155813.jpg', 'Axis Bank Ltd', 0, '6961619015', 'IDIB000P182', 'Sandeep Dasari', 'active', 'Vizag', '', ''),
(138, 'Paila Tarakesh Naidu', 'naidutarakesh@gmail.com', 'EG02T_ASE0138', '6300289870', '6300289870', '959526097324', 'DQZPP1791R', 'at', '', 'admin', 'Self', '9985319350', 'Main Street ,Burja,Andhra Pradesh', '1-32', '2021-10-29', '16359178244237159803435491391288.jpg', '16359178454752849635735468292205.jpg', '', 0, '35055463932', 'SBIN0000766', 'Paila Tarakesh Naidu', 'inactive', 'Vizag', '', ''),
(139, 'NALLA DILEEP KUMAR', 'nalladileepkumar07@gmail.com', 'EG01_EH0139', '8328206792', '8328206792', '517792944815', 'AYOPN6990L', 'eh', '', '', 'RM', '7995881787', '2-58 UCIM COMPOUND , BOYAPALEM, MADHURAWADA ZONE VISAKHAPATNAM 531163', '2-58 UCIM COMPOUND , BOYAPALEM, MADHURAWADA ZONE VISAKHAPATNAM', '2021-11-01', 'New Doc 08-29-2020 11.54.39_1.jpg', 'IMG-20211026-WA0026.jpeg', 'Tekwissen', 0, '33497566225', 'SBIN0004362', 'NALLA DILEEP KUMAR', 'inactive', 'Vizag', '', ''),
(140, 'Prava kalyani murty', 'pravakalyanimurty@mail.com', 'EG01_EH0140', '9052999140', '9052999140', '7420 1642 4668', 'Bswps5579k', 'eh', '', 'admin', 'ABM', '9052999145', '50-51-12 g floor p&t colony Visakhapatnam 530013', '50-51-12 g floor p&t colony Visakhapatnam 530013', '2021-11-01', '1635930262654..jpg', '1635930296414..jpg', 'Icici bank, dhfl, BBC, indo Qatar', 0, '058801507750', 'Icic0000588', 'P kalyani murthy', 'inactive', 'Vizag', '', ''),
(141, 'Majji Annapurna', 'annapurnam257@gmail.com', 'EG02T_ASE0141', '7989842365', '7989842365', '863781516992', 'EZAPM7183M', 'at', '', '', 'EX', '7702858393', '55-7-39/2, Sanjay Gandhi Colony, Visakhapatnam-22', '55-7-39/2, Sanjay Gandhi Colony, Visakhapatnam-22', '2021-11-05', 'IMG_20210325_105702640~2.jpg', 'IMG_20211104_131931440.jpg', '', 0, '587102010004432', 'UBIN0558711', 'Majji Annapurna', 'active', 'Vizag', '', ''),
(142, 'TAMADASRINIVASARAO', 'SRINUDSIGN@GMAIL.COM', 'EG02T_ASE0142', '8498970096', '8498970096', '265662692667', 'HPPPS8168A', 'at', '', '', 'EX', '6281557605', '14-31-43 PRIYADASHINI COLONY, B.C.ROAD, GAJUWAKA,VISAKHAPATNAM-530044.', '14-31-43 PRIYADASHINI COLONY, B.C.ROAD, GAJUWAKA,VISAKHAPATNAM-530044.', '2021-01-11', 'Tamada CNU Aadhar.jpg', 'pan card.jpg', 'NO', 0, '62082446185', 'SBIN0002716', 'TAMADA SRINIVASA RAO', 'active', 'Vizag', '', ''),
(143, 'srinivasaraokonapalli', 'konapallisrinu143@gmail.com', 'EG01_EH0143', '8074415906 ', '8074415906 ', '5615 2024 9658 ', 'OURPS2984G', 'eh', '', '', 'RM', '7093603038 ', 'Gajuwaka, BC road', 'Kondapalem village, butcheyyapeta mandal ', '2021-11-03', 'IMG_20210724_111521.jpg', '16363466792534218917719094158219.jpg', 'Vk gardens', 113, '32867835379', 'SBIN0015332', 'Konapalli srinivas', 'active', 'Vizag', '', ''),
(144, 'SAIKUMARTOTA', 'saikumar06112000@gmail.com', 'EG01_EH0144', '9515614164', '9515614164', '244878664062', 'ODEPS5806P', 'eh', '', '', 'RM', '9553011652', '36-92-242/334/2 Sivalingapuram kancharapalem vskp-530008 ', '36-92-242/334/2 Sivalingapuram kancharapalem vskp-530008 ', '2021-11-05', '20210628_104559.jpg', 'Screenshot_20210806-170426_OneDrive.jpg', 'Amazon TV installation service', 114, '05150100014404', 'BARB0VISAKH', 'Tota sai kumar', 'active', 'Vizag', '', ''),
(145, 'CHITTURUHEMALATHA', 'hemalatha5291@gmail.com', 'EG01_EH0145', '7981211530', '7981211530', '2021 8358 2563', 'BkMPC1431N', 'eh', '', '', 'RM', '9121875291', '9/12/1, pailavari street, kothapet, vijayawada ', '9/12/1, pailavari street, kothapet, vijayawada ', '2021-10-23', 'IMG-20211110-WA0001.jpg', 'IMG-20211110-WA0002.jpg', 'Satisfactory', 0, '34647221241', ' SBIN0011099', 'Hemalatha', 'active', 'Vijayawada', '', ''),
(146, 'RANGUJAYALAKSHMI', 'lakshmirangu1998@gmail.com', 'EG01_EH0146', '7993197096', '7993197096', '392408764946', 'CKOPJ5787P', 'eh', '', '', 'RM', '8333050589', '1-36 chintala baza near library, nunna, vijayawada rural ', '1-36 chintala baza near library, nunna, vijayawada rural ', '2021-10-24', 'jaya-adhar card.jpg', '', 'Satisfaction ', 133, '20194405405', 'SBIN0003287 ', 'Rangu jayalakshmi ', 'active', 'Vijayawada', '', ''),
(147, 'KADITIVASU', 'vasukaditi@gmail.com', 'EG04_EC0147', '7075127742', '7075127742', '229267079373', 'GSXPK7730Q', 'ec', '', 'admin', 'Loans Manager', '', '45-44-21/2, 80feet road , akkayyapalem , Visakhapatnam-16', '45-44-21/2, 80feet road , akkayyapalem, Visakhapatnam-16', '2021-11-10', 'IMG-20211113-WA0002.jpg', 'AP_FRONT.png', '', 0, '62357630956', 'SBIN0020380', 'KADITI VASU', 'active', 'Vizag', '', ''),
(148, 'THADIPRASANNAKUMAR', 'prasannathadi699@gmail.com', 'EG01_EH0148', '8142588699', '8328295348', '425054393988', 'CWPPPP8011H', 'eh', '', 'admin', 'AM', '8328295348', '7-28 ,Chinna agiripalli , agiripalli mandal', '7-28, chinna agiripalli, agiripalli mandal ', '2021-11-10', 'VID_20211115_104854.mp4', '1636953328780.jpg', 'HDB financial services', 0, '000310100123593', 'ANDB0000003', 'THADI PRSANNA KUMAR', 'active', 'Vijayawada', '', ''),
(149, 'GUNNAMADHU', 'madhugunna789@gmail.com', 'EG01_EH0149', '8639562908', '8639562908', '435088005883', 'FSTPM6454E', 'eh', '', '', 'RM', '9040900878', 'Hb colony', 'Uppalada , Gajapati, Odisha', '2021-11-11', '16369631773323076112023730075408.jpg', '16369631989515244349075003912426.jpg', 'Srika projects', 0, '404701503859', 'ICIC0004047', 'Gunna madhu', 'active', 'Vizag', '', ''),
(150, 'CheekatiRambabu', 'rambaburams2000@gmail.com', 'EG01_EH0150', '+919573168701', '+919573168701', '459529025901', 'CCMPC4302D ', 'eh', '', '', 'RM', '+918790527936', 'old postand offece', 'Srikakulam  ippili ', '2021-11-01', '20210324_104242.jpg', '20211111_151338.jpg', 'Ex:Easybuy landmark group,  shine add agency', 0, '035110100094769', 'UBIN0803511', 'Chikati.Rambabu', 'active', 'Vizag', '', ''),
(151, 'DEVIKA', 'devikazuzoo@gmail.com', 'EG01_EH0151', '6305878441', '6305878441', '-', '-', 'eh', '', '', 'RM', '8074247208', 'Thatichetla Palem', 'Thatichetla palem', '2021-11-22', '', '', '', 0, '568210510000796', 'BKID0005682', 'Devika', 'active', 'Vizag', '', ''),
(152, 'Bellam ganesh chaithanya ', 'ganeshchaitanya7@gmail.com', 'EG01_EH0152', '7095043505 ', '7095043505 ', '653852265549', 'BGFPB7149R', 'eh', '', 'admin', 'ABM', '7981146670', 'V. L. Puram, near Delhi public school, Rajahmundry ', '5-3, panchayathi Road, Kunavaram (vlg&mandal) east godavari Dist. ', '2021-11-22', '20211129_102747.jpg', '20211129_102856.jpg', 'Escorts tractors ', 0, '6572500102988001', 'KARB0000657', 'Bellam ganesh chaithanya', 'active', 'Rajahmundry', '', ''),
(153, 'Nvenkatkiran', 'venkatkiran94917@gmail.com', 'EG01_EH0153', '8885792349', '8885792349', '446244625871', 'BUMPN9186R', 'eh', '', '', 'RM', '9515287145', '32-32-285, durmalamma arch,svp nagar,kobbarithota', '32-32-285, durmalamma arch,svp nagar,kobbarithota', '2021-11-16', 'pk aadhar .pdf', 'pk pan card (1).pdf', 'Fresher', 0, '861811610000015', 'BKID0008618', 'N.Venkatkiran', 'active', 'Vizag', '', ''),
(154, 'Nakkaappalaraju', 'appalarajunakka587@gmail.com', 'EG01_EG0154', '9100390280', '9100390280', '971628066290', 'CFNPN5356L', 'eg', '', 'admin', 'Admin', '7569828394', 'Visakhapatnam BC road market', 'Garividi', '2021-12-03', '16386018298465597132166489793657.jpg', '16386018609316284090221697741795.jpg', 'Lione', 0, '34027076240', 'SBIN0004827', 'Nakka Appala Raju', 'inactive', 'Vizag', '', ''),
(155, 'Maheshbabu', 'maheshdarling251859@gmail.com', 'EG01_EH0155', '9515287145', '9515287145', '771905960761', 'FDKPB4420D', 'eh', '', '', 'RM', '9133292976', 'Thattichetlipalem,vizag', 'Thattichetlipalem,vizag', '2021-11-22', 'IMG_20201109_095916.jpg', 'IMG_20201109_095825.jpg', 'Fresher', 0, '015210100010509', 'ANDB0000152', 'Lakshmi', 'inactive', '', '', ''),
(156, 'pullesudheerkumar', 'spulle8@gmail.com', 'EG01_EH0156', '9154219308', '9154219308', '391538723604', 'JWAPK9280D', 'eh', '', 'admin', 'Admin', '8555098082', 'DNO 7-265 Applanarsya colony Nadiuthota Vepagunta Visakhapatnamvepagunta', 'DNO 7-265 Applanarsya colony Nadiuthota Vepagunta Visakhapatnamvepagunta', '2021-12-10', 'IMG-20211020-WA0001.jpg', '', '', 0, '50100341417442', 'HDFC0009087', 'HDFC BANK', 'active', 'Gajuwaka', '', ''),
(157, 'Pedapudi Ramu', 'P.ramu13189@gmail.com', 'EG01_EH0157', '9550338006', '9550338006', '502773797161', 'FFVPR6877D', 'eh', '', '', 'RM', '7358683219', 'Gajuwaka b.c road', 'H no 1-40 kondapalem butchayyapeta (md) Vishakhapatnam (dt)', '2021-11-27', '16393793831143819063176858352815.jpg', '16393794066447537057528884408798.jpg', 'Ramky phrma', 0, '4632500112129401', 'KARB0000463', 'Pedapudi Ramu', 'inactive', 'Gajuwaka', '', ''),
(158, 'P.Ramu', 'p.ramu13189@gmail.com', 'EG01_EH0158', '9550338006', '9550338006', '502773797167', 'FFVPR6877D', 'eh', '', '', 'RM', '7358683219', 'BC ROAD GAJUWAKA', 'KONDAPALEM BUTCHYYAPETA VSKP', '2021-11-27', 'RAMU.JPG', 'R2.JPG', 'RAMKEY ', 113, '4632500112129401', 'KARB0000463', 'PEDAPUDI RAMU', 'active', 'Gajuwaka', '', ''),
(159, 'Dumpamanindra', 'manindrareddy1990@gmail.com', 'EG01_EH0159', '9701799152', '9701799152', '704463252878', 'CDAPR7688N', 'eh', '', 'admin', 'AM', '7794915461', '46-7-15 bagi vari street Dondapathy Visakhapatnam', '46-7-15 bagi vari street Dondapathy Visakhapatnam', '2021-12-08', '', 'IMG_20211218_161235.jpg', 'Bharti Axa life insurance company Visakhapatnam', 0, '32056793337', 'Sbin0003255', 'State Bank of India', 'active', 'Vizag', '', ''),
(160, 'DappadiRajesh', 'rajesh.dappadi99@gmail.com', 'EG01_EH0160', '8500962608', '8500962608', '589953198058', 'CSFPP4770B', 'eh', '', '', 'RM', '7601083513', 'Maddilapalem , vskp', 'H.no 10-535, ralakorivesdhi,Pathapatnam ,srikakulam,andhrapradesh-532213.', '2021-12-29', '16409237028073966786958752081503.jpg', '16409237261325687202549222533284.jpg', 'Surya builders', 159, '33789465726', 'Sbin0001441', 'Rajesh dappadi', 'active', 'Vizag', '', '');
INSERT INTO `login` (`id`, `name`, `email`, `username`, `password`, `phonenumber`, `adharnumber`, `pannumber`, `company`, `comp`, `role`, `designation`, `anternate_number`, `present_address`, `permanent_address`, `joining_date`, `adhar_image`, `pan_image`, `about_previous_company`, `report`, `bank_account_number`, `ifsc`, `bank_holder_name`, `status`, `branch`, `dob`, `ofc_email`) VALUES
(161, 'Mokamoseschristopher', 'moseschris429@gmail.com', 'EG01_EH0161', '9652530212', '9652530212', '780594116599', 'BIRPC8902K', 'eh', '', '', 'RM', '8466947256', '50-3-6, nehrunagar, Rajahmundry', '50-3-6, nehrunagar, Rajahmundry', '2021-11-22', 'Adhar.jpg', 'Pan Card.jpg', 'Marketing executive in jbr constructions', 0, '20215655401', 'SBIN0007170', 'Moka moses christopher', 'active', 'Rajahmundry', '', ''),
(162, 'Gangaprasadakula', 'gangaprasadakula143@gmail.com', 'EG01_EH0162', '7993922156', '7993922156', '963559961268', '', 'eh', '', '', 'RM', '6302761797', 'Madhurapudi, korukoda mandal, East Godavari', 'Madhurapudi, korukoda mandal, East Godavari district', '2021-11-22', 'IMG_20220102_164522.jpg', '', '', 0, '714510031081672', 'UBINOCG7145', 'Akula Ganga Prasad', 'active', 'Rajahmundry', '', ''),
(163, 'vprudvi', 'Prudvi315@gmail.com', 'EG01_EH0163', '8328560040', '8328560040', '640056615392', 'BTFPV7077P', 'eh', '', '', 'RM', '8328560040', 'DEWLAESWARM DIST RAJAMUNDARY ', 'DEWLAESWARM DIST RAJAMUNDARY ', '2021-11-22', 'WhatsApp Image 2022-01-02 at 4.58.16 PM.jpeg', 'WhatsApp Image 2022-01-02 at 4.58.17 PM.jpeg', 'NILL', 0, '5112377000', 'CBIN0284554', 'vprudvi', 'active', 'Rajahmundry', '', ''),
(164, 'Uday', 'joelstanel@gmail.com', 'EG01_EH0164', '7981924623', '7981924623', '461944221390', 'MRCPS7288D ', 'eh', '', '', 'RM', '6305402088', '54â€“12â€“7/6 2ND FLOOR KRISHNA COLLEGE ,ISUKATHOTA', '54â€“12â€“7/6 2ND FLOOR KRISHNA COLLEGE ,ISUKATHOTA', '2021-12-15', 'IMG-20211228-WA0008.jpg', 'IMG-20211228-WA0012.jpg', 'Andhra university ', 159, '309008980452', 'RATN0000219', 'Uday', 'active', 'Vizag', '', ''),
(165, 'PASULA ANANDA KUMAR', 'anand.kumarp557@gmail.com', 'EG01_EH0165', 'Â±917989619287', 'Â±917989619287', '854616595772', 'ANIPA5892K', 'eh', '', 'admin', 'BM', '9703557557', 'Flat no. A-1E rhythm towers, paruchurivari street,patamata lanka, Vijayawada', 'H.no. 5-78,Near A.B.M church, Veldurthi, Kurnool district, Andra Pradesh', '2022-01-03', 'IMG_20220106_113531.jpg', 'IMG_20220106_113618.jpg', 'I worked as a Associate Area manager at square yards', 0, '32664999554', 'Sbin0002807', 'PASULA ANANDA KUMAR', 'active', 'Vijayawada', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `plot_booking_form`
--

CREATE TABLE `plot_booking_form` (
  `id` int(11) NOT NULL,
  `project_name` text NOT NULL,
  `location` varchar(255) NOT NULL,
  `flat_plot_no` varchar(100) NOT NULL,
  `block` varchar(100) NOT NULL,
  `floor` varchar(255) NOT NULL,
  `area_sq_yds` varchar(255) NOT NULL,
  `first_applicant_name` varchar(255) NOT NULL,
  `first_applicant_relationship` varchar(55) NOT NULL,
  `first_applicant_nationality` varchar(55) NOT NULL,
  `first_applicant_dob` varchar(55) NOT NULL,
  `age` varchar(55) NOT NULL,
  `first_applicant_pannum` varchar(55) NOT NULL,
  `first_applicant_adharnum` varchar(55) NOT NULL,
  `first_applicant_permanent_address` text NOT NULL,
  `first_applicant_communication_address` text NOT NULL,
  `first_applicant_phone_num` varchar(55) NOT NULL,
  `first_applicant_mobile_num` varchar(55) NOT NULL,
  `first_applicant_email` varchar(100) NOT NULL,
  `first_applicant_occupation` varchar(100) NOT NULL,
  `first_applicant_annual_income` varchar(100) NOT NULL,
  `first_applicant_company_name` varchar(255) NOT NULL,
  `first_applicant_designation` varchar(255) NOT NULL,
  `second_applicant_name` varchar(255) NOT NULL,
  `second_applicant_relationship` varchar(100) NOT NULL,
  `second_applicant_nationality` varchar(100) NOT NULL,
  `second_applicant_dob` varchar(55) NOT NULL,
  `second_applicant_age` varchar(55) NOT NULL,
  `second_applicant_pannum` varchar(55) NOT NULL,
  `second_applicant_adharnum` varchar(55) NOT NULL,
  `second_applicant_permanent_address` text NOT NULL,
  `second_applicant_communication_address` text NOT NULL,
  `second_applicant_phone_num` varchar(55) NOT NULL,
  `second_applicant_mobile_num` varchar(55) NOT NULL,
  `second_applicant_email` varchar(100) NOT NULL,
  `second_applicant_occupation` varchar(255) NOT NULL,
  `second_applicant_annual_income` varchar(255) NOT NULL,
  `second_applicant_company` varchar(255) NOT NULL,
  `second_applicant_designation` varchar(255) NOT NULL,
  `am` varchar(255) NOT NULL,
  `rm` varchar(255) NOT NULL,
  `manager` varchar(255) NOT NULL,
  `total_sq_yards` varchar(255) NOT NULL,
  `price_per_sq_yards` varchar(255) NOT NULL,
  `floor_rise_charges` varchar(255) NOT NULL,
  `amentities_charges` varchar(100) NOT NULL,
  `flat_plot_cost` varchar(100) NOT NULL,
  `amentities` varchar(255) NOT NULL,
  `corpus_fund` varchar(100) NOT NULL,
  `maintenance_charges` varchar(100) NOT NULL,
  `stamp_duty` varchar(100) NOT NULL,
  `gst` varchar(100) NOT NULL,
  `documentation_legal_charges` varchar(100) NOT NULL,
  `reg_misc_charges` varchar(100) NOT NULL,
  `flat_plot_blocking_amount_total` varchar(100) NOT NULL,
  `agreement_fiveteendays_total` varchar(100) NOT NULL,
  `agreemnt_thirtydays_total` varchar(100) NOT NULL,
  `date` varchar(55) NOT NULL,
  `place` varchar(255) NOT NULL,
  `first_applicant_sign` varchar(255) NOT NULL,
  `second_applicant_sign` varchar(255) NOT NULL,
  `flat_plot_cost_total` varchar(100) NOT NULL,
  `reg_expenses_total` varchar(100) NOT NULL,
  `project_description` text NOT NULL,
  `added_by` int(11) NOT NULL,
  `added_on` varchar(20) NOT NULL,
  `date_id` varchar(20) NOT NULL,
  `project_status` varchar(20) NOT NULL,
  `my_added_on` varchar(20) NOT NULL,
  `bm` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `plot_booking_form`
--

INSERT INTO `plot_booking_form` (`id`, `project_name`, `location`, `flat_plot_no`, `block`, `floor`, `area_sq_yds`, `first_applicant_name`, `first_applicant_relationship`, `first_applicant_nationality`, `first_applicant_dob`, `age`, `first_applicant_pannum`, `first_applicant_adharnum`, `first_applicant_permanent_address`, `first_applicant_communication_address`, `first_applicant_phone_num`, `first_applicant_mobile_num`, `first_applicant_email`, `first_applicant_occupation`, `first_applicant_annual_income`, `first_applicant_company_name`, `first_applicant_designation`, `second_applicant_name`, `second_applicant_relationship`, `second_applicant_nationality`, `second_applicant_dob`, `second_applicant_age`, `second_applicant_pannum`, `second_applicant_adharnum`, `second_applicant_permanent_address`, `second_applicant_communication_address`, `second_applicant_phone_num`, `second_applicant_mobile_num`, `second_applicant_email`, `second_applicant_occupation`, `second_applicant_annual_income`, `second_applicant_company`, `second_applicant_designation`, `am`, `rm`, `manager`, `total_sq_yards`, `price_per_sq_yards`, `floor_rise_charges`, `amentities_charges`, `flat_plot_cost`, `amentities`, `corpus_fund`, `maintenance_charges`, `stamp_duty`, `gst`, `documentation_legal_charges`, `reg_misc_charges`, `flat_plot_blocking_amount_total`, `agreement_fiveteendays_total`, `agreemnt_thirtydays_total`, `date`, `place`, `first_applicant_sign`, `second_applicant_sign`, `flat_plot_cost_total`, `reg_expenses_total`, `project_description`, `added_by`, `added_on`, `date_id`, `project_status`, `my_added_on`, `bm`) VALUES
(4, 'Samhita Splendid Homes', 'Vijayawada', '12', 'A', '2', 'Tadepalli', 'chandrashekher', 'test1', 'ind', '11-08-0990', '31', 'alnpv5678p', '90898090908', 'hno90', 'hno90', '', '9010402324', 'chandhu418@gmail.com', 'sw', '8', 'ase', 'sw', 'jo', 'w', 'ind', '09-09-1991', '30', 'agkgu90', '9880808', 'hno90', 'hno90', '89097098098', '8098098098', 'jo@gmail.com', 'sw', '9', 'ase', 'sw', '21', '28', '56', '1680', '4200', '-', '-', '-', '-', '-', '-', '-', '2%', '-', '-', '90000', '90000', '90000', '22-03-2022', 'Vizag', '-', '-', '-', '-', 'test', 56, '22-03-2022', '2022032204', 'Booking', '03-2022', 51);

-- --------------------------------------------------------

--
-- Table structure for table `property`
--

CREATE TABLE `property` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `modified` datetime NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '1=Active | 0=Inactive',
  `address` text NOT NULL,
  `area` varchar(255) NOT NULL,
  `about_area` text NOT NULL,
  `2017_price` varchar(20) NOT NULL,
  `2018_price` varchar(20) NOT NULL,
  `2019_price` varchar(20) NOT NULL,
  `2020_price` varchar(20) NOT NULL,
  `street` varchar(255) NOT NULL,
  `city` varchar(100) NOT NULL,
  `district` varchar(100) NOT NULL,
  `pincode` varchar(20) NOT NULL,
  `state` varchar(55) NOT NULL,
  `about_property` text NOT NULL,
  `property_status` varchar(55) NOT NULL,
  `budget_from` varchar(20) NOT NULL,
  `budget_to` varchar(20) NOT NULL,
  `price_sqft` varchar(20) NOT NULL,
  `added_by` int(11) NOT NULL,
  `features` varchar(255) NOT NULL,
  `nearby` varchar(255) NOT NULL,
  `modified_by` int(11) NOT NULL,
  `bed_rooms` int(11) NOT NULL,
  `property_type` varchar(55) NOT NULL,
  `brochure_status` int(11) NOT NULL,
  `brochure_name` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `property`
--

INSERT INTO `property` (`id`, `title`, `created`, `modified`, `status`, `address`, `area`, `about_area`, `2017_price`, `2018_price`, `2019_price`, `2020_price`, `street`, `city`, `district`, `pincode`, `state`, `about_property`, `property_status`, `budget_from`, `budget_to`, `price_sqft`, `added_by`, `features`, `nearby`, `modified_by`, `bed_rooms`, `property_type`, `brochure_status`, `brochure_name`) VALUES
(26, 'PARIMALAM RESIDENCY', '2021-03-18 06:11:03', '2021-03-12 11:49:04', 1, 'CHINNAWALTER', 'CHINNAWALTAIR', 'Chinna Waltair is a neighborhood situated on the coastal part of Visakhapatnam City, India. The area, which falls under the local administrative limits of Greater Visakhapatnam Municipal Corporation, is about 5 km from the Dwaraka Nagar which is city centre.', '4800', '5800', '6500', '7000', 'CHINNAWALTER', 'Vizag', 'Vizag', '530017', 'Andrapradesh', '', 'Sold out', '', '', '', 1, '', '', 0, 0, '', 0, ''),
(28, 'AASTHA NIVAS', '2021-08-01 13:26:39', '2021-08-01 15:26:39', 1, 'MARRIPALEM', 'MARRIPALEM', 'Marripalem is a neighbourhood area in Visakhapatnam. It is a residential area in the city. It has many population settlements with high raised buildings and apartments. ', '3500', '4500', '5500', '6200', 'MARRIPALEM', 'Vizag', 'Vizag', '530018', 'Andrapradesh', '<p>Flats for sale in Marripalem, the <a href=\"http://eswarihomes.com\">best 2 &amp; 3BHK luxury apartments in Marripalem</a>.</p>\r\n\r\n<p>AASTHA NIVAS is a property at MARRIPALEM in Visakhapatnam with all the latest attractive amenities. If your looking for property investment in marripalem Aashtha Nivas is the best choice to buy <a href=\"http://eswarihomes.com\">2 &amp; 3BHK flats in Vizag</a>. Marripalem is a one of the best location of Visakhapatnam. It is a <a href=\"http://eswarihomes.com\">best residential area in the Visakhapatnam</a>.</p>\r\n\r\n<p>Why late? invest in Marripalem, <a href=\"http://eswarihomes.com\">Flats for sale in Vizag</a>.</p>\r\n', 'Sold out', '', '', '', 1, '', '', 0, 0, '', 0, ''),
(31, 'Abhinav Arcade', '2021-03-18 06:11:22', '2021-03-05 13:33:02', 1, 'SUJATANAGAR', 'SUJATANAGAR', 'Sujatha Nagar is a neighborhood situated on the Visakhapatnam City, India. The area, which falls under the local administrative limits of Greater Visakhapatnam Municipal Corporation, is about 2.3 km from the Pendurthi.Sujatha Nagar is a well residential colony its well connected with NAD X Road and Maddilapalem', '2800', '3200', '4000', '4500', 'SUJATANAGAR', 'Vizag', 'Vizag', '530051', 'Andrapradesh', '', 'Sold out', '', '', '', 1, '', '', 0, 0, '', 0, ''),
(32, 'VUDA Colony', '2021-08-01 13:34:26', '2021-08-01 15:34:26', 1, 'CHINNAMUSHIDIWADA', 'CHINNAMUSHIDIWADA', 'Chinnamushidiwada is a neighborhood situated on the western part of Visakhapatnam City, India. The area, which falls under the local administrative limits of Greater Visakhapatnam Municipal Corporation, is about 18 km from the Dwaraka Bus Station. ', '3500', '4500', '5500', '6200', 'CHINNAMUSHIDIWADA', 'Vizag', 'Vizag', '531173', 'Andrapradesh', '<p>Vuda colony a well designed and beautufully constructed apartments In CHINNAMUSHIDIWADA ! Flats in CHINNAMUSHIDIWADA Visakhapatnam. <a href=\"http://eswarihomes.com\">2 bhk Flats for sale in CHINNAMUSHIDIWADA</a> . Invest in Vuda colony properties &amp; buy <a href=\"http://eswarihomes.com\">Residential Luxury Apartments in CHINNAMUSHIDIWADA</a> at an affordable prices. Dont miss this opportunity the wonderful chance to own beautiful and luxurious apartments with great amenities! <a href=\"http://eswarihomes.com\">2 BHK Flats for sale in CHINNAMUSHIDIWADA, Visakhapatnam</a>. Contact now! <a href=\"http://eswarihomes.com\">Flats for sale in Vizag</a></p>\r\n', 'Sold out', '', '', '', 1, '', '', 0, 0, '', 0, ''),
(35, 'RATNAVALLI\'S HOSHIK HEIGHTS', '2022-04-01 12:01:50', '2022-04-01 14:01:50', 1, 'YENDADA', 'YENDADA', 'Yendada is a neighbourhood situated on Visakhapatnam and Madhurawada road.', '3000', '3600', '4500', '5500', 'YENDADA', 'Vizag', 'Vizag', '530045', 'Andrapradesh', '<p>Ratnavall&#39;s Hoshik Heights a beautifully designed and constructed apartments In Yendada! Flats in Yendada Visakhapatnam. <a href=\"http://eswarihomes.com\">3 bhk Flats for sale in Yendada</a>. Invest in Ratnavall&#39;s Hoshik Heights properties &amp; buy Residential Luxury Apartments in Yendada at an affordable prices. Dont miss this opportunity the wonderful chance to own beautiful and luxurious apartment with great amenities! <a href=\"http://eswarihomes.com\">3 BHK Flats for sale in Yendada</a>, Visakhapatnam. Contact now! <a href=\"http://eswarihomes.com\">Flats for sale in Vizag</a></p>\r\n', 'Sold out', '', '', '', 1, '', '', 0, 0, '', 0, ''),
(37, 'Gayatri Residency', '2021-05-12 05:17:18', '2021-05-12 07:17:18', 1, 'PM PALEM', 'PM PALEM', 'Pothinamallayya Palem or PM Palem, is a part of Madhurawada situated in Visakhapatnam city in the Indian state of Andhra Pradesh. It is located in the Greater Visakhapatnam Municipal Corporation area. It is located north of Visakhapatnam city on National Highway 16 to Srikakulam.', '3000', '3300', '4000', '5000', 'PM PALEM', 'Vizag', 'Vizag', '530041', 'Andrapradesh', '<p>Gayatri Residency a beautiful man made wonderful apartments! <a href=\"http://eswarihomes.com\">Flats in PM Palem, Visakhapatnam</a>. 2 bhk Flats for sale in PM Palem. Invest in Gayatri Residency properties &amp; buy <a href=\"http://eswarihomes.com\">Residential Luxury Apartments in PM Palem</a> at an affordable prices. Dont miss this opportunity the wonderful chance to own beautiful and luxurious apartment with great amenities! <a href=\"http://eswarihomes.com\">2 BHK Flats for sale in PM Palem, Visakhapatnam</a>. Contact now! <a href=\"http://eswarihomes.com\">Flats for sale in Vizag</a></p>\r\n', 'Sold out', '', '', '', 1, '', '', 0, 0, '', 0, ''),
(38, 'Godavari Heights', '2021-09-13 12:15:23', '2021-03-18 08:06:17', 1, 'PM PALEM', 'PM PALEM', 'Pothinamallayya Palem or PM Palem, is a part of Madhurawada situated in Visakhapatnam city in the Indian state of Andhra Pradesh. It is located in the Greater Visakhapatnam Municipal Corporation area. It is located north of Visakhapatnam city on National Highway 16 to Srikakulam.', '3000', '3300', '4000', '5000', 'PM PALEM', 'Vizag', 'Vizag', '530041', 'Andrapradesh', '<p>Godavari Heughts a wonderfully crafted apartments! <a href=\"http://eswarihomes.com\">Flats in PM Palem, Visakhapatnam</a>. 3 bhk Flats for sale in PM Palem. Invest in Gadavari Heights properties &amp; buy Residential Luxury Apartments in PM Palem at an affordable prices. Dont miss this opportunity the wonderful chance to own beautiful and luxurious apartment with great amenities! <a href=\"http://eswarihomes.com\">3 BHK Flats for sale in PM Palem</a>, Visakhapatnam. Contact now! <a href=\"http://eswarihomes.com\">Flats for sale in Vizag</a></p>\r\n', 'Under Construction', '', '', '', 1, '', '', 0, 0, '', 1, 'GODAVARI HIGHTS CAR SHED.pdf'),
(43, 'NEW LAUNCHING, 3BHK LUXURIOUS FLATS ', '2021-03-18 06:11:22', '2021-02-23 11:40:08', 1, 'SEETHAMADHARA', 'SEETHAMADHARA', '', '', '', '', '', '', 'Vizag', 'Vizag', '530013', 'Andra Pradesh', '', 'Sold out', '', '', '', 1, '', '', 0, 0, '', 0, ''),
(44, 'PVR HANUMAN RESIDENCY', '2021-06-28 06:30:41', '2021-06-28 08:30:41', 1, '', 'MVP Colony', '', '', '', '', '', '', 'Vizag', 'Vizag', '530017', 'Andra Pradesh', '<p>PVR Hanuman a wonderfully designed apartments In MVP Colony! <a href=\"http://eswarihomes.com\">Flats in MVP Colony, Visakhapatnam</a>. 2 bhk Flats for sale in MVP Colony. Invest in PVR HANUMAN Properties &amp; buy Residential Luxury Apartments in MVP Colony at an affordable prices. Dont miss this opportunity the wonderful chance to own beautiful and luxurious apartment with great amenities! <a href=\"http://eswarihomes.com\">2 BHK Flats for sale in MVP Colony, Visakhapatnam</a>. Contact now! <a href=\"http://eswarihomes.com\">Flats for sale in Vizag</a></p>\r\n', 'Sold out', '', '', '', 1, '', '', 0, 0, '', 0, ''),
(46, 'AASHRITHA DELIGHT', '2021-06-28 06:30:03', '2021-06-28 08:30:03', 1, '', 'MVP Colony', '', '', '', '', '', '', 'Vizag', 'Vizag', '530017', 'Andra Pradesh', '<p>Ashritha Delight a fantastic apartment in Visakhapatnam. <a href=\"http://eswarihomes.com\">3BHK Flat for Sale in MVP Colony Visakhapatnam</a>. Get brand new Luxurious apartments for sale at an affordable budget with all the latest attractive architect designs and opulent amenities. Ashritha Delight is a <a href=\"http://eswarihomes.com\">best budget flats in Visakhapatnam</a>, Property in MVP Colony. Why late? Buy <a href=\"http://eswarihomes.com\">residential luxury apartments in MVP Colony</a>. Contact now Flats for Sale In Vizag.</p>\r\n', 'Sold out', '', '', '', 1, '', '', 0, 0, '', 0, ''),
(47, 'GK SADAN', '2021-07-20 10:13:32', '2021-07-20 12:13:32', 1, '', 'LAWSON\'S BAY COLONY', '', '', '', '', '', '', 'Vizag', 'Vizag', '530017', 'Andra Pradesh', '<p>GK Sadan a beautifully Constructed luxurious apartments! <a href=\"http://eswarihomes.com\">Flats in Lawson&#39;s Bay Colony, Visakhapatnam</a>. 3 bhk Flats for sale in Lawson&#39;s Bay Colony. Invest in GK Sadan properties &amp; buy <a href=\"http://eswarihomes.com\">Residential Luxury Apartments in Lawson&#39;s Bay Colony</a> at an affordable prices. Dont miss this opportunity the wonderful chance to own beautiful and luxurious apartment with great amenities! 3 BHK Flats for sale in Lawson&#39;s bay colony, Visakhapatnam. Contact now! <a href=\"http://eswarihomes.com\">Flats for sale in Vizag</a></p>\r\n', 'Sold out', '', '', '', 1, '', '', 0, 0, '', 0, ''),
(48, 'NARAYANAMMA RESIDENCY', '2021-06-28 06:32:01', '2021-06-28 08:32:01', 1, '', 'PENDURTHI', '', '', '', '', '', '', 'Vizag', 'Vizag', '530047', 'Andra Pradesh', '<p>Narayanamma Residency a beautifully crafted apartments In Visakhapatnam! Flats in Pendurthi, Visakhapatnam. <a href=\"http://eswarihomes.com\">2 bhk Flats for sale in Pendurthi</a>. Invest in Narayanamma Residency properties &amp; buy Residential Luxury Apartments in Pendurthi at an affordable prices. Dont miss this opportunity the wonderful chance to own beautiful and luxurious apartment with great amenities! <a href=\"http://eswarihomes.com\">2 BHK Flats for sale in Pendurthi, Visakhapatnam</a>. Contact now! <a href=\"http://eswarihomes.com\">Flats for sale in Vizag</a></p>\r\n', 'Sold out', '', '', '', 1, '', '', 0, 0, '', 0, ''),
(51, 'FLORA BEAU FORT', '2022-04-01 11:59:18', '2022-04-01 13:59:18', 1, '', 'MADHURAWADA', '', '', '', '', '', '', 'Vizag', 'Vizag', '530048', 'Andra Pradesh', '<p>flora beau fort a beautiful man made wonderful apartments! Flats in Madhurwada, Visakhapatnam. <a href=\"http://eswarihomes.com\">3 bhk Flats for sale in Madhurawada</a>. Invest in Flora Beau Fort properties &amp; buy Residential Luxury Apartments in Madhurwada at an affordable prices. Dont miss this opportunity the wonderful chance to own beautiful and luxurious apartment with great amenities! <a href=\"http://eswarihomes.com\">3 BHK Flats for sale in Madhurwada</a>, Visakhapatnam. Contact now! <a href=\"http://eswarihomes.com\">Flats for sale in Vizag</a></p>\r\n', 'Sold out', '', '', '', 1, '', '', 0, 0, '', 1, 'FLORA BURO.pdf'),
(55, 'SAI VENKAT RESIDENCY', '2021-03-24 11:26:41', '2021-03-24 12:26:41', 1, '', 'MADHURAWADA', '', '', '', '', '', '', 'Vizag', 'Vizag', '530048', 'Andra Pradesh', '<p>Sai Venkat Residency a well designed and beautufully constructed apartments In Madhurawada! Flats in Madhurawada Visakhapatnam. <a href=\"http://eswarihomes.com\">2 bhk Flats for sale in Madhurawada</a>. Invest in Sai Venkat Residency Properties &amp; buy Residential Luxury Apartments in Madhurawada at an affordable prices. Dont miss this opportunity the wonderful chance to own beautiful and luxurious apartment with great amenities!<a href=\"http://eswarihomes.com\"> 2 BHK Flats for sale in Madhurawada, Visakhapatnam</a>. Contact now! <a href=\"http://eswarihomes.com\">Flats for sale in Vizag</a></p>\r\n', 'Sold out', '', '', '', 1, '', '', 0, 0, '', 0, ''),
(56, 'DASAPALLA LAYOUT', '2022-04-01 11:58:47', '2022-04-01 13:58:47', 1, '', 'Yendada', '', '', '', '', '', '', 'Vizag', 'Vizag', '530045', 'Andra Pradesh', '<p>Daspalla Layout&nbsp; Flats in Yendada, Visakhapatnam. <a href=\"http://eswarihomes.com\">3 bhk Flats for sale in Yendada</a>. Invest in Daspalla Layout properties &amp; buy Residential Luxury Apartments in Yendada at an affordable prices. Dont miss this opportunity the wonderful chance to own beautiful and luxurious apartment with great amenities! <a href=\"http://eswarihomes.com\">3 BHK Flats for sale in Yendada</a>, Visakhapatnam.Contact now! <a href=\"http://eswarihomes.com\">Flats for sale in Vizag</a></p>\r\n', 'Sold out', '', '', '', 1, '', '', 0, 0, '', 1, 'Yendada Daspalla Layout.pdf'),
(57, 'SDM VINAYAKA NIVAS', '2021-04-10 05:56:20', '2021-04-10 07:56:20', 1, '', 'PM PALEM', '', '', '', '', '', '', 'Vizag', 'Vizag', '530041', 'Andra Pradesh', '<p>SDM VINAYAKA NIVAS a well crafted and beautufully constructed apartments In PM Palem! Flats in PM Palem Visakhapatnam. <a href=\"http://eswarihomes.com\">2 bhk Flats for sale in PM Palem</a>. Invest in SDM VINAYAKA NIVAS Properties &amp; buy Residential Luxury Apartments in PM palem at an affordable prices. Dont miss this opportunity the wonderful chance to own beautiful and luxurious apartments with great amenities! <a href=\"http://eswarihomes.com\">2 BHK Flats for sale in PM palem, Visakhapatnam</a>. Contact now! <a href=\"http://eswarihomes.com\">Flats for sale in Vizag</a></p>\r\n', 'Sold out', '', '', '', 1, '', '', 0, 0, '', 0, ''),
(64, 'Priya Towers', '2022-04-01 12:01:27', '2022-04-01 14:01:27', 1, '', 'Nandhamuri Nagar', '', '', '', '', '', '', 'Vijayawada', 'Vijayawada', '520015', 'Andhra Pradesh', '<p>Priya Towers a wonderfully crafted apartments In Vijayawada! <a href=\"http://eswarihomes.com\">Flats in Nandamuri Nagar</a>, Vijayawada. 3 bhk Flats for sale in Nandamuri Nagar. Invest in Priya Towers properties &amp; buy Residential Luxury Apartments in Nandamuri Nagar at an affordable prices. Dont miss this opportunity the wonderful chance to own beautiful and luxurious apartment with great amenities! <a href=\"http://eswarihomes.com\">3 BHK Flats for sale in Nandamuri Nagar</a>, Vijayawada. Contact now! <a href=\"http://eswarihomes.com\">Flats for sale in Vijayawada</a>.</p>\r\n', 'Sold out', '', '', '', 1, '', '', 0, 0, '', 0, ''),
(65, 'SVR Padmaja Residency', '2021-03-22 11:23:50', '2021-03-22 12:23:50', 1, '', 'PM PALEM', '', '', '', '', '', '', 'Vizag', 'Vizag', '530041', 'Andra Pradesh', '<p>SVR Padmaja Residency a well crafted and beautufully constructed apartments In PM palem ! Flats in PM Palem Visakhapatnam. <a href=\"http://eswarihomes.com\">3 bhk Flats for sale in PM palem</a> . Invest in SVR Padmaja Residency properties &amp; buy <a href=\"http://eswarihomes.com\">Residential Luxury Apartments in PM palem</a> at an affordable prices. Dont miss this opportunity the wonderful chance to own beautiful and luxurious apartments with great amenities! <a href=\"http://eswarihomes.com\">3 BHK Flats for sale in PM palem, Visakhapatnam</a>. Contact now! <a href=\"http://eswarihomes.com\">Flats for sale in Vizag</a></p>\r\n', 'Sold out', '', '', '', 1, '', '', 0, 0, '', 0, ''),
(69, 'Aditya hill view', '2021-03-18 06:11:22', '2021-02-18 08:13:27', 1, '', 'PM PALEM', '', '', '', '', '', '', 'Vizag', 'Vizag', '530041', 'Andra Pradesh', '', 'Sold out', '', '', '', 1, '', '', 0, 0, '', 0, ''),
(70, 'Akkayyapalem Abidnagar', '2021-03-18 06:11:22', '2021-02-18 08:16:45', 1, '', 'Akkayyapalem', '', '', '', '', '', '', 'Vizag', 'Vizag', '530016', 'Andra Pradesh', '', 'Sold out', '', '', '', 1, '', '', 0, 0, '', 0, ''),
(71, 'Bhagyalakshmi Nivas', '2021-03-18 06:11:22', '2021-02-18 08:18:55', 1, '', 'Akkayyapalem', '', '', '', '', '', '', 'Vizag', 'Vizag', '530016', 'Andra Pradesh', '', 'Sold out', '', '', '', 1, '', '', 0, 0, '', 0, ''),
(72, 'Ashok Residency', '2021-03-18 06:11:22', '2021-02-18 08:20:39', 1, '', 'PM PALEM', '', '', '', '', '', '', 'Vizag', 'Vizag', '530041', 'Andra Pradesh', '', 'Sold out', '', '', '', 1, '', '', 0, 0, '', 0, ''),
(73, 'Sai Brundavanam', '2021-03-18 06:11:22', '2021-02-18 08:22:25', 1, '', 'SEETHAMMADHARA', '', '', '', '', '', '', 'Vizag', 'Vizag', '530013', 'Andra Pradesh', '', 'Sold out', '', '', '', 1, '', '', 0, 0, '', 0, ''),
(74, 'SAI VIHAR', '2021-03-18 06:11:22', '2021-02-18 08:49:47', 1, '', 'MIDDILAPURI COLONY', '', '', '', '', '', '', 'Vizag', 'Vizag', '530041', 'Andra Pradesh', '', 'Sold out', '', '', '', 1, '', '', 0, 0, '', 0, ''),
(75, 'Vigneswara Kusumam', '2021-03-18 06:11:22', '2021-02-18 08:54:23', 1, '', 'MIDHILAPURI COLONY', '', '', '', '', '', '', 'Vizag', 'Vizag', '530041', 'Andra Pradesh', '', 'Sold out', '', '', '', 1, '', '', 0, 0, '', 0, ''),
(76, 'Visalakshi Nagar', '2021-03-18 06:11:22', '2021-02-18 08:56:18', 1, '', 'Visalakshi Nagar', '', '', '', '', '', '', 'Vizag', 'Vizag', '530043', 'Andra Pradesh', '', 'Sold out', '', '', '', 1, '', '', 0, 0, '', 0, ''),
(77, 'Ashritha Nilayam', '2021-03-18 06:11:22', '2021-02-18 08:58:47', 1, '', 'MVP Colony', '', '', '', '', '', '', 'Vizag', 'Vizag', '530017', 'Andra Pradesh', '', 'Sold out', '', '', '', 1, '', '', 0, 0, '', 0, ''),
(81, 'Aavaas (Semi Gated Community)', '2022-04-01 11:55:02', '2022-04-01 13:55:02', 1, '', 'Purushottapuram', '', '', '', '', '', '', 'Vizag', 'Vizag', '532190', 'Andra Pradesh', '<p>Aavaas Flats in Purushothapuram, Visakhapatnam. <a href=\"http://eswarihomes.com\">2 bhk Flats for sale in Purushothapuram</a>, a brand new semigated community in Purushothapuram. Invest in Aavaas properties &amp; buy <a href=\"http://eswarihomes.com\">Residential Luxury Apartments in Purushothapuram</a> at an affordable cost. Dont miss this opportunity the wonderful chance to own! <a href=\"http://eswarihomes.com\">3 BHK Flats for sale in Purushothapuram, Visakhapatnam</a>. Contact now! Flats for sale in Vizag</p>\r\n', 'Sold out', '', '', '', 1, '', '', 0, 0, '', 1, 'AAVASS PURUSHOTHAPURAM.pdf'),
(82, 'SAI PRIYA GARDENS', '2021-09-13 12:15:13', '2021-03-18 08:15:27', 1, '', 'MADHURAWADA', '', '', '', '', '', '', 'Vizag', 'Vizag', '530048', 'Andra Pradesh', '<p>Sai Priya Gardens a beautifully designed and constructed apartments In Madhurawada! Flats in Madhurawada Visakhapatnam. <a href=\"http://eswarihomes.com\">3 bhk Flats for sale in Madhurawada</a>. Invest in Sai Priya Gardens Properties &amp; buy Residential Luxury Apartments in Madhurawada at an affordable prices. Dont miss this opportunity the wonderful chance to own beautiful and luxurious apartment with great amenities! <a href=\"http://eswarihomes.com\">3 BHK Flats for sale in Madhurawada</a>, Visakhapatnam. Contact now! <a href=\"http://eswarihomes.com\">Flats for sale in Vizag</a></p>\r\n', 'Under Construction', '', '', '', 1, '', '', 0, 0, '', 1, 'SAIPRIYA GARDEN ELEVATION 11 copy-converted.pdf'),
(84, 'MANCHUKONDA PRIDE', '2021-07-09 10:32:45', '2021-07-09 12:32:45', 1, '', 'LAWSON\'S BAY COLONY', '', '', '', '', '', '', 'Vizag', 'Vizag', '530017', 'Andra Pradesh', '<p>Manchukonda a well crafted and beautufully constructed apartments In Lawson&#39;s Bay Colony! Flats in Lawson&#39;s bay colony, Visakhapatnam. <a href=\"http://eswarihomes.com/\">3 bhk Flats for sale in Lawson&#39;s bay colony</a> . Invest in Manchukonda properties &amp; buy Residential Luxury Apartments in Lawson&#39;s bay Colony at an affordable prices. Dont miss this opportunity the wonderful chance to own beautiful and luxurious apartments with great amenities! <a href=\"http://eswarihomes.com/\">3 BHK Flats for sale</a> in lawson&#39;s bay colony, Visakhapatnam. Contact now! <a href=\"http://eswarihomes.com/\">Flats for sale in Vizag</a></p>\r\n', 'Sold out', '', '', '', 1, '', '', 0, 0, '', 0, ''),
(85, 'Girija Nivas', '2022-05-19 11:16:03', '2022-05-19 13:16:03', 1, '', 'Gopalapatnam', '', '', '', '', '', '', 'Vizag', 'Vizag', '530027', 'Andra Pradesh', '<p>Girija Nivas a well crafted and beautufully constructed apartments In Gopalapatnam! Flats in Gopalapatnam, Visakhapatnam. <a href=\"http://eswarihomes.com/\">2 bhk Flats for sale in Gopalapatnam</a>. Invest in Girija Nivas properties &amp; buy Residential Luxury Apartments in GopalaPatnam at an affordable prices. Dont miss this opportunity the wonderful chance to own beautiful and luxurious apartments with great amenities! <a href=\"http://eswarihomes.com/\">2 BHK Flats for sale in Gopalapatnam</a>, Visakhapatnam. Contact now! <a href=\"http://eswarihomes.com/\">Flats for sale in Vizag</a></p>\r\n', 'Sold out', '', '', '', 1, '', '', 0, 0, '', 1, 'Gopalapatnam new peroject elevation.pdf'),
(86, 'Taruni Royale', '2022-05-19 11:37:50', '2022-05-19 13:37:50', 1, '', 'MVP Colony', '', '', '', '', '', '', 'Vizag', 'Vizag', '530017', 'Andra Pradesh', '<p>Taruni Royale a well crafted and beautufully constructed apartments In MVP sector-9 near DRDO office ! Flats in MVP Colony, Visakhapatnam. <a href=\"http://eswarihomes.com/\">2 bhk Flats for sale in MVP Colony</a>. Invest in Tarun Royale properties &amp; buy Residential Luxury Apartments in MVP Colony sector-9 near DRDO Office at an affordable prices. Dont miss this opportunity the wonderful chance to own beautiful and <a href=\"http://eswarihomes.com/\">luxurious apartments</a> with great amenities! <a href=\"http://eswarihomes.com/\">2 BHK Flats for sale in MVP Colony</a>, Visakhapatnam. Contact now! <a href=\"http://eswarihomes.com/\">Flats for sale in Vizag</a></p>\r\n', 'Under Construction', '', '', '', 1, '', '', 0, 0, '', 1, 'Taruni Royale new_page-0001 copy-converted.pdf'),
(87, 'Vaihnavi\'s Sai Nilayam', '2022-04-01 12:05:02', '2022-04-01 14:05:02', 1, '', 'KCP Colony, Poranki', '', '', '', '', '', '', 'Vijayawada', 'Vijayawada', '521137', 'Andra Pradesh', '<p>Vaihnavi&#39;s Sai Nilayam a well crafted and beautufully constructed apartments In KCP Colony Poranki ! Flats in KCP Colony Poranki Vijayawada. 3 bhk Flats for sale in KCP Colony Poranki . Invest in Vaihnavi&#39;s Sai Nilayam properties &amp; buy <a href=\"http://eswarihomes.com/\">Residential Luxury Apartments in KCP Colony Poranki</a> at an affordable prices. Dont miss this opportunity the wonderful chance to own beautiful and luxurious apartments with great amenities!<a href=\"http://eswarihomes.com/\"> 3 BHK Flats for sale in KCP Colony Poranki</a>, Vijayawada. Contact now! <a href=\"http://eswarihomes.com/\">Flats for sale in Vijayawada</a></p>\r\n', 'Sold out', '', '', '', 1, '', '', 0, 0, '', 1, 'Vaihnavis Sai Nilayam plan KCP ColonyPoranki-converted.pdf'),
(88, 'Brand New 3 BHK Flats @  SBI clony , Siddhartha Nagar', '2022-04-01 11:58:00', '2022-04-01 13:58:00', 1, '', 'SBI clony , Siddhartha Nagar', '', '', '', '', '', '', 'Vijayawada', 'Vijayawada', '520010', 'Andra Pradesh', '<p>Brand New 3 BHK Flats at SBI Colony one of the best constructed and beautifully crafted apartments In SBI Colony, Siddhartha Nagar! <a href=\"http://eswarihomes.com/\">Flats in SBI Colony, Siddhartha Nagar Vijayawada</a>. 3 bhk Flats for sale in SBI Colony, Siddhartha Nagar . Invest in Brand New 3 BHK properties &amp; buy Residential Luxury Apartments in SBI Colony, Siddhartha Nagar at an affordable prices. Dont miss this opportunity the wonderful chance to own beautiful and luxurious apartments with great amenities! <a href=\"http://eswarihomes.com/\">3 BHK Flats for sale in SBI Colony, Siddhartha Nagar</a>, Vijayawada. Contact now! <a href=\"http://eswarihomes.com/\">Flats for sale in Vijayawada</a></p>\r\n', 'Sold out', '', '', '', 1, '', '', 0, 0, '', 1, 'vijayawada SBI clony Siddhartha Nagar elevation-converted.pdf'),
(90, 'Sundara Lakshmi Nrusimha Residency', '2021-11-15 05:51:16', '2021-11-15 06:51:16', 1, '', 'PM PALEM', '', '', '', '', '', '', 'Vizag', 'Vizag', '530041', 'Andra Pradesh', '<p>Sundara Lakshmi Nrusimha Residency&nbsp;a well crafted and beautufully constructed <a href=\"http://eswarihomes.com/\">apartments In PM palem</a> ! Flats in PM Palem Visakhapatnam. <a href=\"http://eswarihomes.com/\">2 bhk Flats for sale in PM palem</a> . Invest in Sundara Lakshmi Nrusimha Residency&nbsp;&amp; buy Residential Luxury Apartments in PM palem at an affordable prices. Dont miss this opportunity the wonderful chance to own beautiful and luxurious apartments with great amenities! <a href=\"http://eswarihomes.com/\">2 BHK Flats for sale in PM palem</a>, Visakhapatnam. Contact now! <a href=\"http://eswarihomes.com/\">Flats for sale in Vizag</a></p>\r\n', 'Sold out', '', '', '', 1, '', '', 0, 0, '', 1, 'sundra lakshmi residency pm plm.pdf'),
(91, 'SRI MUKHA HOUSING', '2022-05-19 11:37:33', '2022-05-19 13:37:33', 1, '', 'PM PALEM', '', '', '', '', '', '', 'Vizag', 'Vizag', '530041', 'Andra Pradesh', '<p>Sreemukha Avenue Housing is a well crafted and beautufully constructed apartments In PM palem ! <a href=\"http://eswarihomes.com/\">Flats in PM Palem Visakhapatnam</a>. 3 bhk Flats for sale in PM Palem . Invest in Sreemukha Avenue Housing properties &amp; buy Residential <a href=\"http://eswarihomes.com/\">Luxury Apartments in PM palem</a> at an affordable prices. Dont miss this opportunity the wonderful chance to own beautiful and luxurious apartments with great amenities! <a href=\"http://eswarihomes.com/\">3 BHK Flats for sale in PM palem</a>, Visakhapatnam. Contact now! <a href=\"http://eswarihomes.com/\">Flats for sale in Vizag</a></p>\r\n', 'Sold out', '', '', '', 1, '', '', 0, 0, '', 1, 'SRI MUKHA  ELEVATION.pdf'),
(92, 'Gopala Krishna Brundavanam', '2021-07-24 07:57:11', '2021-07-24 09:57:11', 1, '', 'KURMANNAPALEM', '', '', '', '', '', '', 'Vizag', 'Vizag', '530046', 'Andra Pradesh', '<p>Gopala Krishna Brundavanam is a well crafted and beautufully constructed apartments In KURMANNAPALEM ! Flats in KURMANNAPALEM Visakhapatnam. <a href=\"http://eswarihomes.com/\">2 bhk Flats for sale in KURMANNAPALEM</a> . Invest in Gopala Krishna Brundavanam properties &amp; buy Residential Luxury Apartments in KURMANNAPALEM at an affordable prices. Dont miss this opportunity the wonderful chance to own beautiful and luxurious apartments with great amenities! <a href=\"http://eswarihomes.com/\">2 BHK Flats for sale in KURMANNAPALEM</a>, Visakhapatnam. Contact now! <a href=\"http://eswarihomes.com/\">Flats for sale in Vizag</a></p>\r\n', 'Sold out', '', '', '', 1, '', '', 0, 0, '', 0, ''),
(94, 'Balaji Srinikethan', '2021-07-24 08:01:20', '2021-07-24 10:01:20', 1, '', 'KURMANNAPALEM', '', '', '', '', '', '', 'Vizag', 'Vizag', '530046', 'Andra Pradesh', '<p>Balaji Srinikethan is a beautifully crafted and well designed apartments In KURMANNAPALEM, Flats in KURMANNAPALEM Visakhapatnam. <a href=\"http://eswarihomes.com/\">2&amp; 3 bhk Flats for sale in KURMANNAPALEM</a> . Invest in Balaji Srinikethan properties &amp; buy Residential Luxury Apartments in KURMANNAPALEM at an affordable prices. Dont miss this opportunity the wonderful chance to own beautiful and luxurious apartments with great amenities! <a href=\"http://eswarihomes.com/\">2 &amp; 3 BHK Flats for sale in KURMANNAPALEM</a>, Visakhapatnam. Contact now! <a href=\"http://eswarihomes.com/\">Flats for sale in Vizag</a></p>\r\n', 'Sold out', '', '', '', 1, '', '', 0, 0, '', 0, ''),
(95, 'Manoj Homes', '2022-04-01 12:00:44', '2022-04-01 14:00:44', 1, '', 'Gajuwaka', '', '', '', '', '', '', 'Vizag', 'Vizag', '530018', 'Andra Pradesh', '<p>Manoj Homes is a beautifully crafted and well designed apartments In VUDA COLONY, Flats in VUDA COLONY Visakhapatnam. <a href=\"http://eswarihomes.com/\">3 bhk Flats for sale in VUDA COLONY</a> . Invest in Manoj Homes properties &amp; buy Residential Luxury Apartments in VUDA COLONY at an affordable prices. Dont miss this opportunity the wonderful chance to own beautiful and luxurious apartments with great amenities! <a href=\"http://eswarihomes.com/\">3 BHK Flats for sale in VUDA COLONY</a>, Visakhapatnam. Contact now! <a href=\"http://eswarihomes.com/\">Flats for sale in Vizag</a></p>\r\n', 'Sold out', '', '', '', 1, '', '', 0, 0, '', 1, 'MANOJ HOMES.pdf'),
(96, 'Sri Sai Krishna Enclave', '2021-11-12 11:33:14', '2021-11-12 12:33:14', 1, '', 'Gajuwaka', '', '', '', '', '', '', 'Vizag', 'Vizag', '530018', 'Andra Pradesh', '<p>Sri Sai Krishna Enclave is a beautifully crafted and well designed apartments In VUDA COLONY, Flats in VUDA COLONY Visakhapatnam. <a href=\"http://eswarihomes.com/\">3 bhk Flats for sale in VUDA COLONY</a> . Invest in Sri Sai Krishna Enclave properties &amp; buy Residential Luxury Apartments in VUDA COLONY at an affordable prices. Dont miss this opportunity the wonderful chance to own beautiful and luxurious apartments with great amenities! <a href=\"http://eswarihomes.com/\">3 BHK Flats for sale in VUDA COLONY, Visakhapatnam</a>. Contact now! <a href=\"http://eswarihomes.com/\">Flats for sale in Vizag</a></p>\r\n', 'Sold out', '', '', '', 1, '', '', 0, 0, '', 1, 'sai krishna enclave.pdf'),
(98, 'Econest', '2021-11-12 11:32:49', '2021-11-12 12:32:49', 1, '', 'Gajuwaka', '', '', '', '', '', '', 'Vizag', 'Vizag', '535592', 'Andra Pradesh', '<p>Econest is a well crafted and beautufully constructed apartments In Thunglam, Flats in Thunglam Visakhapatnam. <a href=\"http://eswarihomes.com/\">2 bhk Flats for sale in Thunglam</a> . Invest in Econest properties &amp; buy Residential Luxury Apartments in Thunglam at an affordable prices. Dont miss this opportunity the wonderful chance to own beautiful and luxurious apartments with great amenities! <a href=\"http://eswarihomes.com/\">2 BHK Flats for sale in Thunglam</a>, Visakhapatnam. Contact now! <a href=\"http://eswarihomes.com/\">Flats for sale in Vizag</a></p>\r\n', 'Sold out', '', '', '', 1, '', '', 0, 0, '', 1, 'Econest.pdf'),
(100, 'Sri Ganesh Enclave', '2022-04-01 12:03:52', '2022-04-01 14:03:52', 1, '', 'Gajuwaka', '', '', '', '', '', '', 'Vizag', 'Vizag', '530026', 'Andra Pradesh', '<p>Sri Ganesh Enclave is a well crafted and beautifully constructed apartments In Gajuwaka near Samatha Nagar Bus stop! <a href=\"http://eswarihomes.com/\">Flats in Gajuwaka</a> Visakhapatnam. <a href=\"http://eswarihomes.com/\">2 bhk flats for sale in Gajuwaka</a>. Invest in Sri Ganesh Enclave properties &amp; buy Residential Luxury Apartments in Gajuwaka at affordable prices. Don&#39;t miss this opportunity wonderful chance to own beautiful and luxurious apartments with great amenities! <a href=\"http://eswarihomes.com/\">2 BHK Flats for sale in gajuwaka</a>, Visakhapatnam. Contact now! <a href=\"http://eswarihomes.com/\">Flats for sale in Vizag</a></p>\r\n', 'Sold out', '', '', '', 1, '', '', 0, 0, '', 1, 'sai ganesh enclave.pdf'),
(101, 'Samhita Splendid Homes', '2021-09-14 06:56:07', '2021-08-13 07:15:03', 1, '', 'Tadepalli', '', '', '', '', '', '', 'Vijayawada', 'Vijayawada', '522501', 'Andra Pradesh', '<p>Samhita Splendid Homes a well crafted and beautufully constructed apartments In Tadepalli, Vijayawada ! <a href=\"http://eswarihomes.com/\">Flats in Tadepalli Vijayawada</a>. <a href=\"http://eswarihomes.com/\">3 bhk Flats for sale in Tadepalli, Vijayawada</a> . Invest in Samhita Splendid Homes properties &amp; buy&nbsp;Tadepalli&nbsp;at an affordable prices. Dont miss this opportunity the wonderful chance to own beautiful and luxurious apartments with great amenities!<a href=\"http://eswarihomes.com/\">&nbsp;3 BHK Flats for sale in Tadepalli , Vijayawada</a>. Contact now!&nbsp;<a href=\"http://eswarihomes.com/\">Flats for sale in Vijayawada</a></p>\r\n', 'READY TO MOVE', '', '', '', 1, '', '', 0, 0, '', 1, 'samhita project pdf.pdf'),
(102, 'Vindhya Castle', '2022-04-01 12:06:40', '2022-04-01 14:06:40', 1, '', 'Gajuwaka', '', '', '', '', '', '', 'Vizag', 'Vizag', '530026', 'Andra Pradesh', '<p>Vindhya Castle is a well crafted and beautufully constructed apartments In Thunglam, Flats in Vuda colony, Gajuwaka Visakhapatnam.&nbsp;<a href=\"http://eswarihomes.com/\">2 bhk Flats for sale in Vuda colony, Gajuwaka</a>&nbsp;. Invest in Vindhya Castle properties &amp; buy Residential Luxury Apartments in Vuda colony, Gajuwaka at an affordable prices. Dont miss this opportunity the wonderful chance to own beautiful and luxurious apartments with great amenities!&nbsp;<a href=\"http://eswarihomes.com/\">2 BHK Flats for sale in Vuda colony</a>, Gajuwaka, Visakhapatnam. Contact now!&nbsp;<a href=\"http://eswarihomes.com/\">Flats for sale in Vizag</a></p>\r\n', 'Sold out', '', '', '', 1, '', '', 0, 0, '', 1, 'VINDHYA CASTLE.pdf'),
(103, 'Satya Residency (Beside Petrol Bunk) ', '2022-05-19 11:19:51', '2022-05-19 13:19:51', 1, '', 'Yendada', '', '', '', '', '', '', 'Vizag', 'Vizag', '530045', 'Andra Pradesh', '<p>-</p>\r\n', 'Sold out', '', '', '', 1, '', '', 0, 0, '', 1, 'satya residency 1.pdf'),
(104, 'BRAND NEW PROJECT BOOKINGS OPENED @ MADHURAWADA', '2021-10-25 06:59:16', '2021-10-25 08:59:16', 1, '', 'MADHURAWADA', '', '', '', '', '', '', 'Vizag', 'Vizag', '530048', 'Andra Pradesh', '<p>-</p>\r\n', 'Sold out', '', '', '', 1, '', '', 0, 0, '', 1, 'madhurawada new project 1100 sft &1050 sft  elevation.pdf'),
(105, 'BRAND NEW PROJECT @ MADHURAWADA KOMMADHI', '2021-10-25 06:58:15', '2021-10-25 08:58:15', 1, '', 'KOMMADI', '', '', '', '', '', '', 'Vizag', 'Vizag', '530048', 'Andra Pradesh', '<p>KOMMADHI Project, Visakhapatnam. <a href=\"http://eswarihomes.com/\">2 bhk Flats for sale in K</a><a href=\"https://eswarihomes.com/\">ommadhi</a>, a brand new project in Kommadhi. Invest in Kommadhi properties & buy <a href=\"http://eswarihomes.com/\">Residential Luxury Apartments in </a><a href=\"https://eswarihomes.com/\">Kommadh</a>i at an affordable cost. Dont miss this opportunity the wonderful chance to own! <a href=\"https://eswarihomes.com/\">2BHK Flats for sale in Kommadhi, Visakhapatnam</a>. Contact now! Flats for sale in Vizag</p>\r\n', 'Sold out', '', '', '', 1, '', '', 0, 0, '', 1, 'madhurawada 925  sft elevation  honda showroom.pdf'),
(106, 'BRAND NEW PROJECT @ DWARAKANAGAR , JUST 50MTS FROM MAIN ROAD.', '2022-04-01 11:58:25', '2022-04-01 13:58:25', 1, '', 'DWARAKANAGAR', '', '', '', '', '', '', 'Vizag', 'Vizag', '530016', 'Andra Pradesh', '<p>This Project is a well crafted and beautufully constructed apartments In Dwarakanagar, Flats in Dwarakanagar, Visakhapatnam. <a href=\"http://eswarihomes.com/\">3&nbsp;bhk Flats for sale in Dwarakanagar, Visakhapatnam</a>&nbsp;. Invest in this properties &amp; buy Residential Luxury Apartments in Dwarakanagar, Visakhapatnam(JUust&nbsp;50min&nbsp;from&nbsp;main road) at an affordable prices. Dont miss this opportunity the wonderful chance to own beautiful and luxurious apartments with great amenities!<a href=\"http://eswarihomes.com/\"> 3&nbsp;BHK Flats for sale in Dwarakanagar, Visakhapatnam</a>. Contact now!&nbsp;<a href=\"http://eswarihomes.com/\">Flats for sale in Vizag</a></p>\r\n', 'Sold out', '', '', '', 1, '', '', 0, 0, '', 1, 'dwarakanager.pdf'),
(107, 'Golden Pride @near cricket stadium just 50mts highway', '2022-05-19 11:30:20', '2022-05-19 13:30:20', 1, '', 'PM PALEM', '', '', '', '', '', '', 'Vizag', 'Vizag', '530041', 'Andra Pradesh', '<p>Golden Pride is a well crafted and beautufully constructed apartments In PM PALEM, Flats in PM PALEM, Visakhapatnam.&nbsp;<a href=\"http://eswarihomes.com/\">2&amp;3 bhk Flats for sale in PM PALEM, Visakhapatnam</a>&nbsp;. Invest in this properties &amp; buy Residential Luxury Apartments in PM PALEM, Visakhapatnam(near cricket stadium just 50mts highway) at an affordable prices. Dont miss this opportunity the wonderful chance to own beautiful and luxurious apartments with great amenities!&nbsp;<a href=\"http://eswarihomes.com/\">2 &amp;3 BHK Flats for sale in PM PALEM, Visakhapatnam</a>. Contact now!&nbsp;<a href=\"http://eswarihomes.com/\">Flats for sale in Vizag</a></p>\r\n', 'Sold out', '', '', '', 1, '', '', 0, 0, '', 1, 'GOLDEN PRIDE CAR SHED -PMPALEM ELEVATION copy-converted.pdf'),
(108, 'Flora Heights', '2022-04-01 11:59:41', '2022-04-01 13:59:41', 1, '', 'PM PALEM', '', '', '', '', '', '', 'Vizag', 'Vizag', '530041', 'Andra Pradesh', '<p>Flora Heights(Gated community) is a well crafted and beautufully constructed apartments In PM PALEM, Flats in PM PALEM, Visakhapatnam.&nbsp;<a href=\"http://eswarihomes.com/\">3&nbsp;bhk Flats for sale in PM PALEM, Visakhapatnam</a>&nbsp;. Invest in this properties &amp; buy Residential Luxury Apartments in PM PALEM, Visakhapatnam at an affordable prices. Dont miss this opportunity the wonderful chance to own beautiful and luxurious apartments with great amenities!<a href=\"http://eswarihomes.com/\">&nbsp;3&nbsp;BHK Flats for sale in PM PALEM, Visakhapatnam</a>. Contact now!&nbsp;<a href=\"http://eswarihomes.com/\">Flats for sale in Vizag</a></p>\r\n', 'Sold out', '', '', '', 1, '', '', 0, 0, '', 1, 'Flora Heights.pdf'),
(109, 'Gayatri Enclave', '2021-09-25 05:56:27', '2021-09-02 13:02:26', 1, '', 'Gajuwaka', '', '', '', '', '', '', 'Vizag', 'Vizag', '530044', 'Andra Pradesh', '<p>This Project is a well crafted and beautufully constructed apartments In Gajuwaka, Flats in Gajuwaka, Visakhapatnam. <a href=\"https://eswarihomes.com/\">2&nbsp;bhk Flats for sale in Gajuwaka, Visakhapatnam</a>&nbsp;. Invest in this properties &amp; buy Residential Luxury Apartments in Gajuwaka, Visakhapatnam at an affordable prices. Dont miss this opportunity the wonderful chance to own beautiful and luxurious apartments with great amenities!<a href=\"http://eswarihomes.com/\">&nbsp;2&nbsp;BHK Flats for sale in </a><a href=\"https://eswarihomes.com/\">Gajuwaka, Visakhapatnam</a>. Contact now!&nbsp;<a href=\"http://eswarihomes.com/\">Flats for sale in Vizag</a></p>\r\n', 'New Launch', '', '', '', 1, '', '', 0, 0, '', 1, 'pedagantyada.pdf'),
(110, 'Vijaya Bharathi Nirman', '2022-04-01 12:05:49', '2022-04-01 14:05:49', 1, '', 'Gajuwaka', '', '', '', '', '', '', 'Vizag', 'Vizag', '530026', 'Andra Pradesh', '<p>Vijaya Bharathi Nirman is a well crafted and beautufully constructed apartments In Gajuwaka(Official Colony), Flats in Gajuwaka, Visakhapatnam.&nbsp;<a href=\"https://eswarihomes.com/\">2&amp;3 bhk Flats for sale in Gajuwaka, Visakhapatnam</a>&nbsp;. Invest in this properties &amp; buy Residential Luxury Apartments in Gajuwaka, Visakhapatnam at an affordable prices. Dont miss this opportunity the wonderful chance to own beautiful and luxurious apartments with great amenities!<a href=\"http://eswarihomes.com/\">&nbsp;2&nbsp;BHK Flats for sale in&nbsp;</a><a href=\"https://eswarihomes.com/\">Gajuwaka, Visakhapatnam</a>. Contact now!&nbsp;<a href=\"http://eswarihomes.com/\">Flats for sale in Vizag</a></p>\r\n', 'Sold out', '', '', '', 1, '', '', 0, 0, '', 1, 'Vijaya Bharathi Nirman.pdf'),
(111, 'Gayatri Towers', '2021-09-20 11:02:07', '2021-09-20 13:02:07', 1, '', 'Gajuwaka', '', '', '', '', '', '', 'Vizag', 'Vizag', '530053', 'Andra Pradesh', '<p>Gayatri Towers is a well crafted and beautufully constructed apartments In Gajuwaka(Aganampudi), Flats in Gajuwaka, Visakhapatnam.&nbsp;<a href=\"https://eswarihomes.com/\">2bhk Flats for sale in Gajuwaka, Visakhapatnam</a>&nbsp;. Invest in this properties &amp; buy Residential Luxury Apartments in Gajuwaka(Aganampudi), Visakhapatnam at an affordable prices. Dont miss this opportunity the wonderful chance to own beautiful and luxurious apartments with great amenities!<a href=\"http://eswarihomes.com/\">&nbsp;2&nbsp;BHK Flats for sale in&nbsp;</a><a href=\"https://eswarihomes.com/\">Gajuwaka, Visakhapatnam</a>. Contact now!&nbsp;<a href=\"http://eswarihomes.com/\">Flats for sale in Vizag</a></p>\r\n', 'New Launch', '', '', '', 1, '', '', 0, 0, '', 0, ''),
(112, 'Naidu Projects', '2022-04-01 12:01:08', '2022-04-01 14:01:08', 1, '', 'MVP Colony', '', '', '', '', '', '', 'Vizag', 'Vizag', '530017', 'Andra Pradesh', '<p>Naidu Projects a well crafted and beautufully constructed apartments In MVP Colony Sector-2&nbsp;site area 289sq.yrds ! Flats in MVP Colony, Visakhapatnam.&nbsp;<a href=\"https://eswarihomes.com/\">3 bhk Flats for sale in MVP Colony</a>. Invest in Naidu Projects &amp; buy Residential Luxury Apartments in MVP Colony Sector-2&nbsp;at an affordable prices. Dont miss this opportunity the wonderful chance to own beautiful and&nbsp;<a href=\"https://eswarihomes.com/\">luxurious apartments</a>&nbsp;with great amenities!&nbsp;<a href=\"https://eswarihomes.com/\">3 BHK Flats for sale in MVP Colony</a>, Visakhapatnam. Contact now!&nbsp;<a href=\"https://eswarihomes.com/\">Flats for sale in Vizag</a></p>\r\n', 'Sold out', '', '', '', 1, '', '', 0, 0, '', 0, ''),
(113, 'Sri Balaji Enclave', '2022-04-01 12:03:30', '2022-04-01 14:03:30', 1, '', 'Gajuwaka', '', '', '', '', '', '', 'Vizag', 'Vizag', '530046', 'Andra Pradesh', '<p>Sri Balaji Enclave is a well crafted and beautufully constructed apartments In Gajuwaka(Vadlapudi), Flats in Gajuwaka, Visakhapatnam.&nbsp;<a href=\"https://eswarihomes.com/\">2 bhk Flats for sale in Gajuwaka, Visakhapatnam</a>&nbsp;. Invest in this properties &amp; buy Residential Luxury Apartments in Gajuwaka, Visakhapatnam at an affordable prices. Dont miss this opportunity the wonderful chance to own beautiful and luxurious apartments with great amenities! <a href=\"http://eswarihomes.com/\">2 BHK Flats for sale in&nbsp;</a><a href=\"https://eswarihomes.com/\">Gajuwaka, Visakhapatnam</a>. Contact now!&nbsp;<a href=\"http://eswarihomes.com/\">Flats for sale in Vizag</a></p>\r\n', 'Sold out', '', '', '', 1, '', '', 0, 0, '', 0, ''),
(114, 'Sai Gayathri Nilayam', '2021-10-09 03:58:43', '2021-10-09 05:58:43', 1, '', 'SEETHAMADHARA', '', '', '', '', '', '', 'Vizag', 'Vizag', '530013', 'Andra pradesh', '<p>Sai Gayathri Nilayam&nbsp; Flats in Seethamadhara(Just 50mts from double Road), Visakhapatnam.&nbsp;<a href=\"http://eswarihomes.com/\">3 bhk Flats for sale in </a><a href=\"https://eswarihomes.com/\">Seethamadhara</a>. Invest in Seethamadhara Layout properties &amp; buy Residential Luxury Apartments in Seethamadhara at an affordable prices. Dont miss this opportunity the wonderful chance to own beautiful and luxurious apartment with great amenities!&nbsp;<a href=\"http://eswarihomes.com/\">3 BHK Flats for sale in</a><a href=\"https://eswarihomes.com/\">&nbsp;Seethamadhara</a>, Visakhapatnam.Contact now!&nbsp;<a href=\"http://eswarihomes.com/\">Flats for sale in Vizag</a></p>\r\n', 'Under Construction', '', '', '', 1, '', '', 0, 0, '', 0, ''),
(115, 'Balaji Enclave', '2022-04-01 11:56:47', '2022-04-01 13:56:47', 1, '', 'MARRIPALEM', '', '', '', '', '', '', 'Vizag', 'Vizag', '530018', 'Andra pradesh', '<p>Balaji Enclave&nbsp; Flats in Marripalem(&nbsp;R &amp; B , Near to Vuda Function hall&nbsp;), Visakhapatnam. <a href=\"https://eswarihomes.com/\">2&amp;3 bhk Flats for sale in Marripalem</a>. Invest in Balaji Enclave Layout properties &amp; buy Residential Luxury Apartments in Marripalem at an affordable prices. Dont miss this opportunity the wonderful chance to own beautiful and luxurious apartment with great amenities! <a href=\"https://eswarihomes.com/\">2&amp;3 BHK Flats for sale in Marripalem</a>, Visakhapatnam.Contact now!&nbsp;<a href=\"http://eswarihomes.com/\">Flats for sale in Vizag</a></p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><a href=\"https://eswarihomes.com/uploads/brochures/Yendada%20Daspalla%20Layout.pdf\" target=\"_blank\">Click here for Brochure</a></p>\r\n', 'Sold out', '', '', '', 1, '', '', 0, 0, '', 0, ''),
(116, 'Anuradha Arcade', '2021-10-23 09:15:11', '2021-10-23 11:15:11', 1, '', 'PM PALEM', '', '', '', '', '', '', 'Vizag', 'Vizag', '530041', 'Andra Pradesh', '<p>Anuradha Arcade is a well crafted and beautufully constructed apartments In PM PALEM, Flats in PM PALEM, Visakhapatnam. <a href=\"https://eswarihomes.com/\">2&nbsp;bhk Flats for sale in PM PALEM, Visakhapatnam</a>&nbsp;. Invest in this properties &amp; buy Residential Luxury Apartments in PM PALEM, Visakhapatnam at an affordable prices. Dont miss this opportunity the wonderful chance to own beautiful and luxurious apartments with great amenities!<a href=\"https://eswarihomes.com/\">&nbsp;2&nbsp;BHK Flats for sale in PM PALEM, Visakhapatnam</a>. Contact now!&nbsp;<a href=\"http://eswarihomes.com/\">Flats for sale in Vizag</a></p>\r\n', 'Under Construction', '', '', '', 1, '', '', 0, 0, '', 0, ''),
(117, 'Koganti\'s Crystal', '2021-10-29 09:52:53', '2021-10-29 11:52:53', 1, '', 'Poranki', '', '', '', '', '', '', 'Vijayawada', 'Vijayawada', '521137', 'Andra Pradesh', '<p>Kogantis Crystal a well crafted and beautufully constructed apartments In&nbsp; Poranki ! Flats in&nbsp;Poranki Vijayawada. 2&amp;3 bhk Flats for sale in&nbsp;Poranki . Invest in Kogantis Crystal properties &amp; buy&nbsp;<a href=\"http://eswarihomes.com/\">Residential Luxury Apartments in&nbsp;Poranki</a>&nbsp;at an affordable prices. Dont miss this opportunity the wonderful chance to own beautiful and luxurious apartments with great amenities!<a href=\"http://eswarihomes.com/\">&nbsp;2&amp;3 BHK Flats for sale in&nbsp;Poranki</a>, Vijayawada. Contact now!&nbsp;<a href=\"http://eswarihomes.com/\">Flats for sale in Vijayawada</a></p>\r\n', 'Under Construction', '', '', '', 1, '', '', 0, 0, '', 0, ''),
(118, 'AMARAVATHI ICON', '2021-10-29 10:56:42', '2021-10-29 12:23:29', 1, '', 'Tadepalli', '', '', '', '', '', '', 'Vijayawada', 'Vijayawada', '585304', 'Andra Pradesh', '<p>AMARAVATHI ICON a well crafted and beautufully constructed apartments In Gated community&nbsp; Tadepalli ! Flats in&nbsp;Tadepalli Vijayawada. 2&amp;3 bhk Flats for sale in&nbsp;Tadepalli. Invest in AMARAVATHI ICON properties &amp; buy&nbsp;<a href=\"http://eswarihomes.com/\">Residential Luxury Apartments in</a><a href=\"https://eswarihomes.com/\">&nbsp;Tadepalli</a> at an affordable prices. Dont miss this opportunity the wonderful chance to own beautiful and luxurious apartments with great amenities!<a href=\"http://eswarihomes.com/\">&nbsp;2&amp;3 BHK Flats for sale in&nbsp;Tadepalli</a>, Vijayawada. Contact now!&nbsp;<a href=\"http://eswarihomes.com/\">Flats for sale in Vijayawada</a></p>\r\n', 'READY TO MOVE', '', '', '', 1, '', '', 0, 0, '', 0, ''),
(119, 'Samruddhi', '2022-04-01 12:02:37', '2022-04-01 14:02:37', 1, '', 'Tadepalli', '', '', '', '', '', '', 'Vijayawada', 'Vijayawada', '585304', 'Andra Pradesh', '<p>Samruddhi a well crafted and beautufully constructed apartments In Gated community&nbsp; Tadepalli ! Flats in&nbsp;Tadepalli Vijayawada. 2&amp;3 bhk Flats for sale in&nbsp;Tadepalli. Invest in Samruddhi properties &amp; buy&nbsp;<a href=\"http://eswarihomes.com/\">Residential Luxury Apartments in</a><a href=\"https://eswarihomes.com/\">&nbsp;Tadepalli</a>&nbsp;at an affordable prices. Dont miss this opportunity the wonderful chance to own beautiful and luxurious apartments with great amenities!<a href=\"http://eswarihomes.com/\">&nbsp;2&amp;3 BHK Flats for sale in&nbsp;Tadepalli</a>, Vijayawada. Contact now!&nbsp;<a href=\"http://eswarihomes.com/\">Flats for sale in Vijayawada</a></p>\r\n', 'Sold out', '', '', '', 1, '', '', 0, 0, '', 0, ''),
(120, 'Gayatri Nilayam', '2021-11-15 05:11:32', '2021-11-15 06:05:05', 1, '', 'Gajuwaka', '', '', '', '', '', '', 'Vizag', 'Vizag', '530026', 'Andra Pradesh', '<p>Gayatri Nilayam is a well crafted and beautufully constructed apartments In BC Road (near Sub Registrar office) , Flats in BC Road (near Sub Registrar office) , Gajuwaka Visakhapatnam.&nbsp;<a href=\"http://eswarihomes.com/\">2 bhk Flats for sale in Vuda colony, Gajuwaka</a>&nbsp;. Invest in Gayatri Nilayam properties &amp; buy Residential Luxury Apartments in BC Road (near Sub Registrar office) , Gajuwaka at an affordable prices. Dont miss this opportunity the wonderful chance to own beautiful and luxurious apartments with great amenities!&nbsp;<a href=\"http://eswarihomes.com/\">2 BHK Flats for sale in </a><a href=\"https://eswarihomes.com/\">BC Road (near Sub Registrar office)</a> , Gajuwaka, Visakhapatnam. Contact now!&nbsp;<a href=\"http://eswarihomes.com/\">Flats for sale in Vizag</a></p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>Project Highlights :</strong></p>\r\n\r\n\r\n<ul>\r\n	<li>&nbsp;North - East Corner Property ( Near to Main Road ) &nbsp;</li>\r\n	<li>&nbsp;Luxurious &amp; &nbsp;Spacious floor Plan ,&nbsp;</li>\r\n	<li>&nbsp;Full of security, &nbsp;bounded with Greenary&nbsp;</li>\r\n	<li>&nbsp;Fully power backup and Secured with CC cameras .</li>\r\n	<li>&nbsp;Very Near to all Facilitates like schools, Bus stops, &nbsp;Banks, Hotels and Department stores etc.&nbsp;</li>\r\n</ul>\r\n', 'Under Construction', '', '', '', 1, '', '', 0, 0, '', 0, '');
INSERT INTO `property` (`id`, `title`, `created`, `modified`, `status`, `address`, `area`, `about_area`, `2017_price`, `2018_price`, `2019_price`, `2020_price`, `street`, `city`, `district`, `pincode`, `state`, `about_property`, `property_status`, `budget_from`, `budget_to`, `price_sqft`, `added_by`, `features`, `nearby`, `modified_by`, `bed_rooms`, `property_type`, `brochure_status`, `brochure_name`) VALUES
(121, 'Gayatri Residency', '2021-11-15 05:48:10', '2021-11-15 06:32:47', 1, '', 'Vidyuth Nagar', '', '', '', '', '', '', 'Rajahmundry', 'Rajahmundry', '533106', 'Andra Pradesh', '<p>Gayatri Residency is a well crafted and beautufully constructed apartments In Vidyuth Nagar (near Ganesh temple) , Flats in Vidyuth Nagar (near Ganesh temple) , Rajahmundry .&nbsp;<a href=\"http://eswarihomes.com/\">3 bhk Flats for sale in </a><a href=\"https://eswarihomes.com/\">Vidyuth Nagar,&nbsp;Rajahmundry</a>&nbsp;. Invest in Gayatri Residency properties &amp; buy Residential Luxury Apartments in Vidyuth Nagar (near Ganesh temple) , Rajahmundry at an affordable prices. Dont miss this opportunity the wonderful chance to own beautiful and luxurious apartments with great amenities!&nbsp;<a href=\"http://eswarihomes.com/\">3 BHK Flats for sale in&nbsp;</a><a href=\"https://eswarihomes.com/\">Vidyuth Nagar,&nbsp;Rajahmundry</a>. Contact now!&nbsp;<a href=\"http://eswarihomes.com/\">Flats for sale in&nbsp;</a><a href=\"https://eswarihomes.com/\">Rajahmundry</a></p>\r\n\r\n<p><strong>Project Highlights :&nbsp;</strong></p>\r\n\r\n<ul>\r\n	<li>&nbsp;North Facing - 100% Vasthu Property ( Near to Highway ) &nbsp;</li>\r\n	<li>&nbsp;Individual Floor Plan &amp; Luxurious Designs and elevation.</li>\r\n	<li>&nbsp;Full of security, &nbsp;bounded with Greenary&nbsp;</li>\r\n	<li>&nbsp;Fully power backup and Secured with CC cameras .</li>\r\n	<li>&nbsp;Very Near to all Facilitates like schools, Bus stops, &nbsp;Banks, Hotels and Department stores etc.&nbsp;</li>\r\n</ul>\r\n', 'Under Construction', '', '', '', 1, '', '', 0, 0, '', 0, ''),
(122, 'Vinayak Arcade', '2022-04-01 12:06:15', '2022-04-01 14:06:15', 1, '', 'Gajuwaka', '', '', '', '', '', '', 'Vizag', 'Vizag', '531021', 'Andra Pradesh', '<p>Vinayak Arcade is a well crafted and beautufully constructed apartments In Gajuwaka(Desapatrunipalem), Flats in Gajuwaka, Visakhapatnam. <a href=\"https://eswarihomes.com/\">3&nbsp;bhk Flats for sale in Gajuwaka, Visakhapatnam</a>&nbsp;. Invest in this properties &amp; buy Residential Luxury Apartments in Gajuwaka, Visakhapatnam at an affordable prices. Dont miss this opportunity the wonderful chance to own beautiful and luxurious apartments with great amenities!<a href=\"http://eswarihomes.com/\">&nbsp;3&nbsp;BHK Flats for sale in&nbsp;</a><a href=\"https://eswarihomes.com/\">Gajuwaka, Visakhapatnam</a>. Contact now!&nbsp;<a href=\"http://eswarihomes.com/\">Flats for sale in Vizag</a></p>\r\n\r\n<ul>\r\n	<li>Secured &amp; &nbsp;Spacious floor Plan.</li>\r\n	<li>Full of security, bounded with Greenary.</li>\r\n	<li>Fully powerbackup and Secured with CC cameras .</li>\r\n</ul>\r\n', 'Sold out', '', '', '', 1, '', '', 0, 0, '', 0, ''),
(123, 'Swarna Sai Enclave', '2022-04-01 12:04:23', '2022-04-01 14:04:23', 1, '', 'Gajuwaka', '', '', '', '', '', '', 'Vizag', 'Vizag', '530011', 'Andra Pradesh', '<p><strong>Swarna Sai Enclave </strong>is a well crafted and beautufully constructed apartments In <strong>Gajuwaka(Near police station)</strong>, Flats in Gajuwaka, Visakhapatnam.&nbsp;<strong><a href=\"https://eswarihomes.com/\">2 &amp; 3 bhk Flats for sale in Gajuwaka, Visakhapatnam</a></strong>&nbsp;. Invest in this properties &amp; buy Residential Luxury Apartments in Gajuwaka, Visakhapatnam at an affordable prices. Dont miss this opportunity the wonderful chance to own beautiful and luxurious apartments with great amenities!&nbsp;<strong><a href=\"http://eswarihomes.com/\">2 &amp; 3&nbsp;BHK Flats for sale in&nbsp;</a><a href=\"https://eswarihomes.com/\">Gajuwaka, Visakhapatnam</a></strong>. Contact now!&nbsp;<strong><a href=\"http://eswarihomes.com/\">Flats for sale in Vizag</a></strong></p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>Project Highlights :&nbsp;</strong></p>\r\n\r\n<ul>\r\n	<li>&nbsp;GVMC Approved life style project</li>\r\n	<li>&nbsp;North, South, East &amp; West Facing Flats</li>\r\n	<li>&nbsp;Super Deluxe Construction</li>\r\n	<li>&nbsp;100% Vaastu</li>\r\n	<li>3 Lifts of 6 passenger capacity</li>\r\n	<li>&nbsp;Temple</li>\r\n	<li>Swimming pool</li>\r\n	<li>Meditation Hall</li>\r\n	<li>Modern Gymnasium</li>\r\n	<li>Mini Function Hall</li>\r\n</ul>\r\n', 'Sold out', '', '', '', 1, '', '', 0, 0, '', 0, ''),
(125, 'Sai Surya Vinayagar', '2021-12-27 10:42:19', '2021-12-27 11:42:19', 1, '', 'Gajuwaka', '', '', '', '', '', '', 'Vizag', 'Vizag', '530046', 'Andra Pradesh', '<p>Sai Surya Vinayagar Flats in Vadlapudi (Gajuwaka), Visakhapatnam. <a href=\"https://eswarihomes.com/\">2&nbsp;bhk Flats for sale in&nbsp;Vadlapudi , Gajuwaka</a>. Invest in Sai Surya Vinayagar properties &amp; buy&nbsp;<a href=\"http://eswarihomes.com/\">Residential Luxury Apartments in Vadlapudi , Gajuwaka</a>&nbsp;at an affordable cost. Dont miss this opportunity the wonderful chance to own! <a href=\"https://eswarihomes.com/\">2&nbsp;BHK Flats for sale in Vadlapudi , Gajuwaka, Visakhapatnam</a>. Contact now! Flats for sale in Vizag.</p>\r\n\r\n<ul>\r\n	<li>&nbsp;2 BHK flats - 1000sft &amp; 950 &amp; 910sft&nbsp;</li>\r\n	<li>&nbsp;Total 15 flats&nbsp;</li>\r\n	<li>North &amp; South Facing Flats.</li>\r\n	<li>&nbsp;Secured &amp; &nbsp;Spacious floor Plan. 100% Vasthu</li>\r\n	<li>&nbsp;Car Parking , Prime Location</li>\r\n	<li>&nbsp; Secured with CC cameras .</li>\r\n</ul>\r\n', 'Under Construction', '', '', '', 1, '', '', 0, 0, '', 0, ''),
(126, 'Varshini Nivas', '2022-04-01 12:05:27', '2022-04-01 14:05:27', 1, '', 'Narsimha nagar', '', '', '', '', '', '', 'Vizag', 'Vizag', '530024', 'Andra Pradesh', '<p>Varshini Nivas Flats in Narsimha nagar (Near Highway), Visakhapatnam. <a href=\"https://eswarihomes.com/\">3&nbsp;bhk Flats for sale in&nbsp;Narsimha nagar (Near Highway)</a>. Invest in Varshini Nivas properties &amp; buy&nbsp;<a href=\"http://eswarihomes.com/\">Residential Luxury Apartments in </a><a href=\"https://eswarihomes.com/\">Narsimha nagar (Near Highway</a>)&nbsp;at an affordable cost. Dont miss this opportunity the wonderful chance to own! <a href=\"https://eswarihomes.com/\">3&nbsp;BHK Flats for sale in Narsimha nagar (Near Highway), Visakhapatnam</a>. Contact now! Flats for sale in Vizag.</p>\r\n\r\n<ul>\r\n	<li>&nbsp;3 BHK flats - 2271sft</li>\r\n	<li>&nbsp;Total 5 flats&nbsp;</li>\r\n	<li>&nbsp;East Facing Flats.</li>\r\n	<li>&nbsp;Secured &amp; &nbsp;Spacious floor Plan. 100% Vasthu</li>\r\n	<li>&nbsp;Car Parking , Prime Location</li>\r\n	<li>&nbsp;Fully powerbackup and Secured with CC cameras .</li>\r\n</ul>\r\n', 'Sold out', '', '', '', 1, '', '', 0, 0, '', 0, ''),
(127, 'Adhitya Residency', '2022-01-22 06:22:45', '2022-01-22 07:22:45', 1, '', 'PM PALEM', '', '', '', '', '', '', 'Vizag', 'Vizag', '530041', 'Andra Pradesh', '<p>Adhitya Residency is a well crafted and beautufully constructed apartments In PM PALEM(near Stadium occupency), Flats in PM PALEM, Visakhapatnam.&nbsp;<a href=\"https://eswarihomes.com/\">2&nbsp;bhk Flats for sale in PM PALEM, Visakhapatnam</a>&nbsp;. Invest in this properties &amp; buy Residential Luxury Apartments in PM PALEM, Visakhapatnam at an affordable prices. Dont miss this opportunity the wonderful chance to own beautiful and luxurious apartments with great amenities!<a href=\"https://eswarihomes.com/\">&nbsp;2&nbsp;BHK Flats for sale in PM PALEM, Visakhapatnam</a>. Contact now!&nbsp;<a href=\"http://eswarihomes.com/\">Flats for sale in Vizag</a></p>\r\n\r\n<ul>\r\n	<li>&nbsp;2 BHK flats - 900sft &amp; 950sft&nbsp;</li>\r\n	<li>&nbsp;Total 10 flats&nbsp;</li>\r\n	<li>&nbsp;NORTH &amp; SOUTH Facing Flats.</li>\r\n	<li>&nbsp;Except 1st floor all Available</li>\r\n	<li>&nbsp;Secured &amp; &nbsp;Spacious floor Plan. 100% Vasthu</li>\r\n	<li>&nbsp;Car Parking , Prime Location</li>\r\n</ul>\r\n', 'Under Construction', '', '', '', 1, '', '', 0, 0, '', 0, ''),
(128, 'Sri Srinivasa Residence', '2022-01-22 06:31:36', '2022-01-22 07:31:36', 1, '', 'PM PALEM', '', '', '', '', '', '', 'Vizag', 'Vizag', '530041', 'Andra Pradesh', '<p>Sri Srinivasa Residence is a well crafted and beautufully constructed apartments In PM PALEM(near Stadium), Flats in PM PALEM, Visakhapatnam.&nbsp;<a href=\"https://eswarihomes.com/\">2&amp;3 bhk Flats for sale in PM PALEM, Visakhapatnam</a>&nbsp;. Invest in this properties &amp; buy Residential Luxury Apartments in PM PALEM, Visakhapatnam at an affordable prices. Dont miss this opportunity the wonderful chance to own beautiful and luxurious apartments with great amenities!<a href=\"https://eswarihomes.com/\">&nbsp;2&amp;3 BHK Flats for sale in PM PALEM, Visakhapatnam</a>. Contact now!&nbsp;<a href=\"http://eswarihomes.com/\">Flats for sale in Vizag</a></p>\r\n\r\n<ul>\r\n	<li>&nbsp;2 BHK flats - 1090sft &amp; 1130sft - East Facing&nbsp;</li>\r\n	<li>&nbsp;3 BHK flats - 1400 sft - West Facing&nbsp;</li>\r\n	<li>&nbsp;Total 15 flats&nbsp;</li>\r\n	<li>EAST &amp; WEST Facing Flats.</li>\r\n	<li>&nbsp;Secured &amp; &nbsp;Spacious floor Plan. 100% Vasthu</li>\r\n	<li>&nbsp;Car Parking , Prime Location</li>\r\n</ul>\r\n', 'Under Construction', '', '', '', 1, '', '', 0, 0, '', 0, ''),
(129, 'Vinayaka Residency', '2022-05-23 09:46:22', '2022-05-23 11:46:22', 1, '', 'Madhurawada', '', '', '', '', '', '', 'Vizag', 'Vizag', '530048', 'Andra Pradesh', '<p>Vinayak Residency a beautifully designed and constructed apartments In Madhurawada (Opp Tiles Mart)! Flats in Madhurawada Visakhapatnam.&nbsp;<a href=\"https://eswarihomes.com/\">3 bhk Flats for sale in Madhurawada</a>. Invest in Vinayak Residency Properties &amp; buy Residential Luxury Apartments in Madhurawada at an affordable prices. Dont miss this opportunity the wonderful chance to own beautiful and luxurious apartment with great amenities!&nbsp;<a href=\"https://eswarihomes.com/\">3 BHK Flats for sale in Madhurawada</a>, Visakhapatnam. Contact now!&nbsp;<a href=\"https://eswarihomes.com/\">Flats for sale in Vizag</a></p>\r\n\r\n<ul>\r\n	<li>&nbsp;Brand New Construction Project in Madhurawada , Opp Tiles Mart .</li>\r\n	<li>1800 + 80sft Car parking&nbsp;</li>\r\n	<li>&nbsp;East &nbsp;Facing flat , Single Flat per Floor</li>\r\n	<li>&nbsp;Lift , Generator , Municipal water and Car Parking.</li>\r\n	<li>&nbsp;Available in 1st(m) , 3rd , 4th and 5th Floor</li>\r\n</ul>\r\n', 'Under Construction', '', '', '', 1, '', '', 0, 0, '', 0, ''),
(130, 'Sai Priya Layout', '2022-04-11 07:25:47', '2022-04-11 09:22:04', 1, '', 'Madhurawada', '', '', '', '', '', '', 'Vizag', 'Vizag', '530048', 'Andra Pradesh', '<p>Sai Priya Layout a beautifully designed and constructed apartments In Madhurawada (near Stadium&nbsp;)! Flats in Madhurawada Visakhapatnam.&nbsp;<a href=\"https://eswarihomes.com/\">3 bhk Flats for sale in Madhurawada</a>. Invest in Sai Priya Layout Properties &amp; buy Residential Luxury Apartments in Madhurawada at an affordable prices. Dont miss this opportunity the wonderful chance to own beautiful and luxurious apartment with great amenities!&nbsp;<a href=\"https://eswarihomes.com/\">3 BHK Flats for sale in Madhurawada</a>, Visakhapatnam. Contact now!&nbsp;<a href=\"https://eswarihomes.com/\">Flats for sale in Vizag</a></p>\r\n\r\n<ul>\r\n	<li>1800 + 80sft Car parking&nbsp;</li>\r\n	<li>&nbsp;East &nbsp;Facing flat , Single Flat per Floor</li>\r\n	<li>&nbsp;Lift , Generator , Municipal water and Car Parking.</li>\r\n	<li>Only 1 Flat Available in 4th Floor</li>\r\n</ul>\r\n', 'READY TO MOVE', '', '', '', 1, '', '', 0, 0, '', 0, ''),
(131, 'LV Homes', '2022-05-23 09:51:47', '2022-05-23 11:51:47', 1, '', 'Kolanukonda', '', '', '', '', '', '', 'Vijayawada', 'Vijayawada', '522502', 'Andra Pradesh', '<p>LV Homes a well crafted and beautufully constructed apartments in Kolanukonda ! Flats in&nbsp;Kolanukonda Vijayawada. 2&amp;3 bhk Flats for sale in&nbsp;Kolanukonda. Invest in LV Homes properties &amp; buy&nbsp;<a href=\"http://eswarihomes.com/\">Residential Luxury Apartments in</a><a href=\"https://eswarihomes.com/\">&nbsp;LV Homes</a>&nbsp;at an affordable prices. Dont miss this opportunity the wonderful chance to own beautiful and luxurious apartments with great amenities!<a href=\"https://eswarihomes.com/\">&nbsp;2&amp;3 BHK Flats for sale in&nbsp;LV Homes</a>, Vijayawada. Contact now!&nbsp;<a href=\"https://eswarihomes.com/\">Flats for sale in Vijayawada</a></p>\r\n', 'READY TO MOVE', '', '', '', 1, '', '', 0, 0, '', 0, ''),
(132, 'RR\'s Rachana', '2022-05-23 09:54:04', '2022-05-23 11:54:04', 1, '', 'Kolanukonda', '', '', '', '', '', '', 'Vijayawada', 'Vijayawada', '522502', 'Andra Pradesh', '<p>RR&#39;s Rachana a well crafted and beautufully constructed apartments in Kolanukonda ! Flats in&nbsp;Kolanukonda Vijayawada. 2&amp;3 bhk Flats for sale in&nbsp;Kolanukonda. Invest in RR&#39;s Rachana properties &amp; buy&nbsp;<a href=\"http://eswarihomes.com/\">Residential Luxury Apartments in</a><a href=\"https://eswarihomes.com/\">&nbsp;RR&#39;s Rachana</a>&nbsp;at an affordable prices. Dont miss this opportunity the wonderful chance to own beautiful and luxurious apartments with great amenities!<a href=\"https://eswarihomes.com/\">&nbsp;2&amp;3 BHK Flats for sale in&nbsp;RR&#39;s Rachana</a>, Vijayawada. Contact now!&nbsp;<a href=\"https://eswarihomes.com/\">Flats for sale in Vijayawada</a></p>\r\n', 'READY TO MOVE', '', '', '', 1, '', '', 0, 0, '', 0, ''),
(133, 'NorthFace - Lava Kusa', '2022-05-23 09:42:09', '2022-05-23 11:42:09', 1, '', 'Guntupalli', '', '', '', '', '', '', 'Vijayawada', 'Vijayawada', '521241', 'Andra Pradesh', '<p>NorthFace - Lava Kusa a well crafted and beautufully constructed apartments in Guntupalli ! Flats in&nbsp;Guntupalli Vijayawada. 2&amp;3 bhk Flats for sale in&nbsp;Guntupalli. Invest in NorthFace - Lava Kusa properties &amp; buy&nbsp;<a href=\"http://eswarihomes.com/\">Residential Luxury Apartments in</a><a href=\"https://eswarihomes.com/\">&nbsp;NorthFace - Lava Kusa</a>&nbsp;at an affordable prices. Dont miss this opportunity the wonderful chance to own beautiful and luxurious apartments with great amenities!<a href=\"https://eswarihomes.com/\">&nbsp;2&amp;3 BHK Flats for sale in&nbsp;NorthFace - Lava Kusa</a>, Vijayawada. Contact now!&nbsp;<a href=\"https://eswarihomes.com/\">Flats for sale in Vijayawada</a></p>\r\n', 'READY TO MOVE', '', '', '', 1, '', '', 0, 0, '', 0, ''),
(134, 'NorthFace - Grandeur', '2022-05-23 09:46:03', '2022-05-23 11:46:03', 1, '', 'Gollapudi', '', '', '', '', '', '', 'Vijayawada', 'Vijayawada', '520012', 'Andra Pradesh', '<p>NorthFace - Grandeura well crafted and beautufully constructed apartments in Gollapudi ! Flats in&nbsp;Gollapudi Vijayawada. 2&amp;3 bhk Flats for sale in&nbsp;Gollapudi. Invest in NorthFace - Grandeur properties &amp; buy&nbsp;<a href=\"http://eswarihomes.com/\">Residential Luxury Apartments in</a><a href=\"https://eswarihomes.com/\">&nbsp;NorthFace - Grandeur</a>&nbsp;at an affordable prices. Dont miss this opportunity the wonderful chance to own beautiful and luxurious apartments with great amenities!<a href=\"https://eswarihomes.com/\">&nbsp;2&amp;3 BHK Flats for sale in&nbsp;NorthFace - Grandeur</a>, Vijayawada. Contact now!&nbsp;<a href=\"https://eswarihomes.com/\">Flats for sale in Vijayawada</a></p>\r\n', 'READY TO MOVE', '', '', '', 1, '', '', 0, 0, '', 0, ''),
(135, 'AARNIKA ', '2022-05-23 09:35:54', '2022-05-23 11:35:54', 1, '', 'Tadepalli', '', '', '', '', '', '', 'Vijayawada', 'Vijayawada', '522501', 'Andra Pradesh', '<p>AARNIKA a well crafted and beautufully constructed apartments Tadepalli ! Flats in&nbsp;Tadepalli Vijayawada. 2&amp;3 bhk Flats for sale in&nbsp;Tadepalli. Invest in AARNIKA properties &amp; buy&nbsp;<a href=\"http://eswarihomes.com/\">Residential Luxury Apartments in</a><a href=\"https://eswarihomes.com/\">&nbsp;Tadepalli</a>&nbsp;at an affordable prices. Dont miss this opportunity the wonderful chance to own beautiful and luxurious apartments with great amenities!<a href=\"https://eswarihomes.com/\">&nbsp;2&amp;3 BHK Flats for sale in&nbsp;Tadepalli</a>, Vijayawada. Contact now!&nbsp;<a href=\"https://eswarihomes.com/\">Flats for sale in Vijayawada</a></p>\r\n', 'READY TO MOVE', '', '', '', 1, '', '', 0, 0, '', 0, ''),
(136, 'Gayatri Nivas', '2022-05-31 07:10:05', '2022-05-31 09:10:05', 1, '', 'Gajuwaka', '', '', '', '', '', '', 'Vizag', 'Vizag', '530026', 'Andra Pradesh', '<p>Gayatri Nivas is a well crafted and beautufully constructed apartments In HB Colony , Flats in Gajuwaka Visakhapatnam.&nbsp;<a href=\"https://eswarihomes.com/\">2 bhk Flats for sale in HB Colony, Gajuwaka</a>&nbsp;. Invest in Gayatri Nivas properties &amp; buy Residential Luxury Apartments in HB Colony , Gajuwaka at an affordable prices. Dont miss this opportunity the wonderful chance to own beautiful and luxurious apartments with great amenities!&nbsp;<a href=\"http://eswarihomes.com/\">2 BHK Flats for sale in&nbsp;</a><a href=\"https://eswarihomes.com/\">HB Colony</a>, Gajuwaka, Visakhapatnam. Contact now!&nbsp;<a href=\"https://eswarihomes.com/\">Flats for sale in Vizag</a></p>\r\n', 'Under Construction', '', '', '', 1, '', '', 0, 0, '', 0, ''),
(137, 'KBS towers', '2022-09-16 07:14:58', '2022-09-16 09:14:58', 1, '', 'Moghalrajpuram', '', '', '', '', '', '', 'Vijayawada', 'Vijayawada', '520010', ' Andhra Pradesh', '<p>KBS towers a well crafted and beautufully constructed apartments Moghalrajpuram! Flats in&nbsp;Moghalrajpuram Vijayawada. 3 bhk Flats for sale in&nbsp;Moghalrajpuram. Invest in KBS towers &amp; buy&nbsp;<a href=\"http://eswarihomes.com/\">Residential Luxury Apartments in</a><a href=\"https://eswarihomes.com/\">&nbsp;Moghalrajpuram</a>&nbsp;at an affordable prices. Dont miss this opportunity the wonderful chance to own beautiful and luxurious apartments with great amenities!<a href=\"https://eswarihomes.com/\">&nbsp;3 BHK Flats for sale in&nbsp;Moghalrajpuram</a>, Vijayawada. Contact now!&nbsp;<a href=\"https://eswarihomes.com/\">Flats for sale in Vijayawada</a></p>\r\n', 'Ready to Move', '', '', '', 1, '', '', 0, 0, '', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `property_bkp_21102020`
--

CREATE TABLE `property_bkp_21102020` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `modified` datetime NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '1=Active | 0=Inactive',
  `address` text NOT NULL,
  `area` varchar(255) NOT NULL,
  `street` varchar(255) NOT NULL,
  `city` varchar(100) NOT NULL,
  `district` varchar(100) NOT NULL,
  `pincode` varchar(20) NOT NULL,
  `state` varchar(55) NOT NULL,
  `about_property` text NOT NULL,
  `property_status` varchar(55) NOT NULL,
  `budget_from` varchar(20) NOT NULL,
  `budget_to` varchar(20) NOT NULL,
  `price_sqft` varchar(20) NOT NULL,
  `added_by` int(11) NOT NULL,
  `features` varchar(255) NOT NULL,
  `nearby` varchar(255) NOT NULL,
  `modified_by` int(11) NOT NULL,
  `bed_rooms` int(11) NOT NULL,
  `property_type` varchar(55) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `property_bkp_21102020`
--

INSERT INTO `property_bkp_21102020` (`id`, `title`, `created`, `modified`, `status`, `address`, `area`, `street`, `city`, `district`, `pincode`, `state`, `about_property`, `property_status`, `budget_from`, `budget_to`, `price_sqft`, `added_by`, `features`, `nearby`, `modified_by`, `bed_rooms`, `property_type`) VALUES
(19, 'SAI BRUDAVANAM (KSHETRAYA KALYAN MANDAPAM)', '2020-08-10 09:29:06', '2020-08-10 11:29:06', 1, 'SEETHAMMADARA', 'SEETHAMMADARA', 'SEETHAMMADARA', 'Vizag', 'Vizag', '530013', 'Andrapradesh', 'SAI BRUDAVANAM (KSHETRAYA KALYAN MANDAPAM)', '', '', '', '', 1, '', '', 0, 0, ''),
(20, 'Aastha project', '2020-08-10 09:25:41', '2020-08-10 11:25:41', 1, 'MVP COLONY', 'MVP COLONY', 'MVP COLONY', 'Vizag', 'Vizag', '530017', 'Andrapradesh', 'Aastha project', '', '', '', '', 1, '', '', 0, 0, ''),
(21, 'Ashritha Nilayam', '2020-08-10 09:23:13', '2020-08-10 11:23:13', 1, 'MVP COLONY', 'MVP COLONY', 'MVP COLONY', 'Vizag', 'Vizag', '530017', 'Andrapradesh', 'Ashritha Nilayam', '', '', '', '', 1, '', '', 0, 0, ''),
(23, 'Akkayyapalem Abidnagar', '2020-08-10 10:51:10', '2020-08-10 12:51:10', 1, 'AKKAYYAPALEM', 'AKKAYYAPALEM', 'AKKAYYAPALEM', 'Vizag', 'Vizag', '530016', 'Andrapradesh', 'Akkayyapalem Abidnagar', '', '', '', '', 1, '', '', 0, 0, ''),
(24, 'Akkayyapalem IOB lane', '2020-08-10 10:55:54', '2020-08-10 12:55:54', 1, 'AKKAYYAPALEM', 'AKKAYYAPALEM', 'AKKAYYAPALEM', 'Vizag', 'Vizag', '530016', 'Andrapradesh', 'Akkayyapalem IOB lane', '', '', '', '', 1, '', '', 0, 0, ''),
(25, 'New Project', '2020-08-10 09:08:44', '2020-08-10 11:08:44', 1, 'LAWSON\'S BAY COLONY', 'LAWSON\'S BAY COLONY', 'LAWSON\'S BAY COLONY', 'Vizag', 'Vizag', '530017', 'Andrapradesh', 'New Project', '', '', '', '', 1, '', '', 0, 0, ''),
(26, 'New Project (Opp. AU Out Gate)', '2020-08-10 08:46:14', '2020-08-10 10:46:14', 1, 'CHINNAWALTER', 'CHINNAWALTER', 'CHINNAWALTER', 'Vizag', 'Vizag', '530017', 'Andrapradesh', 'New Project (Opp. AU Out Gate)', '', '', '', '', 1, '', '', 0, 0, ''),
(28, 'Opp SBI Bank VUDA Layout', '2020-08-10 09:13:03', '2020-08-10 11:13:03', 1, 'MARRIPALEM', 'MARRIPALEM', 'MARRIPALEM', 'Vizag', 'Vizag', '530018', 'Andrapradesh', 'Opp SBI Bank VUDA Layout', '', '', '', '', 1, '', '', 0, 0, ''),
(29, 'Vishalakshi nagar', '2020-08-10 09:34:24', '2020-08-10 11:34:24', 1, 'Vishalakshi nagar', 'Vishalakshi nagar', 'Vishalakshi nagar', 'Vizag', 'Vizag', '530043', 'Andrapradesh', 'Vishalakshi nagar', '', '', '', '', 1, '', '', 0, 0, ''),
(31, 'Abhinav Arcade', '2020-08-10 09:46:54', '2020-08-10 11:46:54', 1, 'SUJATANAGAR', 'SUJATANAGAR', 'SUJATANAGAR', 'Vizag', 'Vizag', '530051', 'Andrapradesh', 'Abhinav Arcade', '', '', '', '', 1, '', '', 0, 0, ''),
(32, 'VUDA Colony', '2020-08-10 09:42:11', '2020-08-10 11:42:11', 1, 'CHINNAMUSHIDIWADA', 'CHINNAMUSHIDIWADA', 'CHINNAMUSHIDIWADA', 'Vizag', 'Vizag', '531173', 'Andrapradesh', 'VUDA Colony', '', '', '', '', 1, '', '', 0, 0, ''),
(34, 'Ashritha Nilayam', '2020-08-10 10:16:24', '2020-08-10 12:16:24', 1, 'YENDADA', 'YENDADA', 'YENDADA', 'Vizag', 'Vizag', '530045', 'Andrapradesh', 'Ashritha Nilayam', '', '', '', '', 1, '', '', 0, 0, ''),
(35, 'Petrol Bunk lane', '2020-08-10 10:21:03', '2020-08-10 12:21:03', 1, 'YENDADA', 'YENDADA', 'YENDADA', 'Vizag', 'Vizag', '530045', 'Andrapradesh', 'Petrol Bunk lane', '', '', '', '', 1, '', '', 0, 0, ''),
(36, 'Sri Bhaghavan Hill View', '2020-08-07 05:27:20', '2020-08-07 07:27:20', 1, 'PM PALEM', 'PM PALEM', 'PM PALEM', 'Vizag', 'Vizag', '530041', 'Andrapradesh', 'Sri Bhaghavan Hill View', '', '', '', '', 1, '', '', 0, 0, ''),
(37, 'Gayatri Residency', '2020-10-03 09:47:36', '2020-10-03 11:47:36', 1, 'PM PALEM', 'PM PALEM', 'PM PALEM', 'Vizag', 'Vizag', '530041', 'Andrapradesh', 'Gayatri Residency', '', '', '', '', 1, '', '', 0, 0, ''),
(38, 'Godavari Heights Car Shed Jn', '2020-08-10 10:01:26', '2020-08-10 12:01:26', 1, 'PM PALEM', 'PM PALEM', 'PM PALEM', 'Vizag', 'Vizag', '530041', 'Andrapradesh', 'Godavari Heights Car Shed Jn', '', '', '', '', 1, '', '', 0, 0, ''),
(39, 'Sai Vihar', '2020-08-10 10:04:30', '2020-08-10 12:04:30', 1, 'MIDDILAPURI COLONY', 'MIDDILAPURI COLONY', 'MIDDILAPURI COLONY', 'Vizag', 'Vizag', '530041', 'Andrapradesh', 'Sai Vihar', '', '', '', '', 1, '', '', 0, 0, ''),
(40, 'Ashoka Residency', '2020-08-07 05:22:15', '2020-08-07 07:22:15', 1, 'MADHURAWADA', 'MADHURAWADA', 'MADHURAWADA', 'Vizag', 'Vizag', '530048', 'Andrapradesh', 'Ashoka Residency', '', '', '', '', 1, '', '', 0, 0, ''),
(42, 'Pavan Mitra', '2020-09-07 11:45:15', '2020-09-07 13:45:15', 1, 'KOMMADI', 'KOMMADI', 'KOMMADI', 'Vizag', 'Vizag', '530048', 'Andrapradesh', 'Pavan Mitra', '', '', '', '', 1, '', '', 0, 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `property_comments`
--

CREATE TABLE `property_comments` (
  `id` int(11) NOT NULL,
  `property_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `comment` text NOT NULL,
  `added_on` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `property_comments`
--

INSERT INTO `property_comments` (`id`, `property_id`, `user_id`, `comment`, `added_on`) VALUES
(1, 49, 26, 'Nice Looking. Thank you Eswarihomes..', '21-12-2020 06:26:02am'),
(2, 49, 26, 'Reasonable Price...', '21-12-2020 06:27:12am'),
(3, 135, 13, 'asdf qwerty', '11-01-2023 07:06:15am');

-- --------------------------------------------------------

--
-- Table structure for table `property_details`
--

CREATE TABLE `property_details` (
  `id` int(11) NOT NULL,
  `property_id` int(11) NOT NULL,
  `floor` varchar(55) NOT NULL,
  `bhk` varchar(20) NOT NULL,
  `availability` varchar(20) NOT NULL,
  `facing` varchar(20) NOT NULL,
  `flat_sqft` int(20) NOT NULL,
  `undivide_share` varchar(20) NOT NULL,
  `totalbuilding_sqyard` int(20) NOT NULL,
  `price_sqft` varchar(20) NOT NULL,
  `amitities` varchar(20) NOT NULL,
  `project_status` varchar(100) NOT NULL,
  `unit_sale_closedby` varchar(55) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `property_details`
--

INSERT INTO `property_details` (`id`, `property_id`, `floor`, `bhk`, `availability`, `facing`, `flat_sqft`, `undivide_share`, `totalbuilding_sqyard`, `price_sqft`, `amitities`, `project_status`, `unit_sale_closedby`) VALUES
(1, 19, '3rd', '3BHK', '1', 'EAST', 2100, '75', 375, '6800', '3 LAKHS', '4 Months Possession', ''),
(2, 19, '5th', '3BHK', '1', 'EAST', 2100, '75', 375, '6800', '3 LAKHS', '4 months possession', ''),
(3, 20, '4th', '3 BHK', '1', 'NORTH', 1340, '40', 167, '7200', '2 LAKHS', 'Under Construction', ''),
(4, 21, '3rd', '3 BHK', '1', 'EAST', 2305, '75', 375, '7500', '2 LAKHS', 'Under Construction', ''),
(5, 21, '4th', '3BHK', '1', 'EAST', 2305, '75', 375, '7500', '2 LAKHS', 'Under Construction', ''),
(6, 21, '5th', '3 BHK', '1', 'EAST', 2305, '75', 375, '7500', '2 LAKHS', 'Under Construction', ''),
(7, 22, '1st', '3 BHK', '1', 'NORTH', 1350, '0', 0, '7500', '3 LAKHS', 'READY TO MOVE', ''),
(8, 22, '3rd', '3BHK', '1', 'SOUTH', 1440, '0', 0, '7500', '3 LAKHS', 'READY TO MOVE', ''),
(9, 23, '2nd', '3 BHK', '1', 'WEST', 1650, '66', 666, '7300', '3  LAKHS', 'Under Construction', ''),
(10, 23, '5th', '3BHK', '1', 'WEST', 1650, '66', 666, '7300', '3 LAKHS', 'Under Construction', ''),
(11, 23, '5th', '3 BHK', '1', 'EAST', 1650, '66', 666, '7300', '3 LAKHS', 'Under Construction', ''),
(12, 24, '2nd', '2 BHK', '1', 'NORTH', 1100, '0', 0, '6500', '2 LAKHS', 'Under Construction', ''),
(13, 24, '3rd', '2 BHK', '1', 'NORTH', 900, '0', 0, '6500', '2 LAKHS', 'Under Construction', ''),
(14, 25, '1st', '3 BHK', '1', 'SOUTH', 1325, '45', 450, '7800', '3 LAKHS', 'Under Construction', ''),
(15, 25, '4th', '3BHK', '1', 'NORTH', 2650, '90', 450, '7800', '3 LAKHS', 'Under Construction', ''),
(16, 25, '5th', '3 BHK', '1', 'NORTH', 2650, '90', 450, '7800', '3 LAKHS', 'Under Construction', ''),
(17, 26, 'Top', '3 BHK', '1', 'EAST', 2400, '80', 400, '7800', '4 LAKHS', 'Under Construction', ''),
(21, 27, '2nd', '2 BHK', '1', 'WEST', 1000, '28.5', 285, '6000', '2 LAKHS', 'READY TO MOVE', ''),
(22, 28, '4th', '2 BHK', '1', 'SOUTH', 1100, '33', 407, '6800', '2 LAKHS', 'Under Construction', ''),
(23, 28, '5th', '3 BHK', '1', 'NORTH', 1580, '47', 407, '6800', '2 LAKHS', 'Under Construction', ''),
(28, 29, '2nd', '2 BHK', '1', 'SOUTH', 1000, '33.5', 365, '6000', '2 LAKHS', 'Under Construction', ''),
(29, 29, '4th', '2 BHK', '1', 'SOUTH', 1000, '33.5', 365, '6000', '2 LAKHS', 'Under Construction', ''),
(30, 30, '5th', '2 BHK', '1', 'EAST', 900, '', 0, '4600', '2 LAKHS', 'READY TO MOVE', ''),
(31, 30, '5th', '2 BHK', '1', 'WEST', 1000, '', 0, '4600', '2 LAKHS', 'READY TO MOVE', ''),
(32, 31, '4th', '2 BHK', '1', 'NORTH', 1050, '', 0, '3800', '2 LAKHS', 'Under Construction', ''),
(33, 31, '5th', '2 BHK', '1', 'SOUTH', 1050, '', 0, '3800', '2 LAKHS', 'Under Construction', ''),
(34, 31, '5th', '2 BHK', '1', 'NORTH', 1050, '', 0, '3800', '2 LAKHS', 'Under Construction', ''),
(35, 32, '1st ,2nd, 3rd', '2 BHK', '1', 'NORTH', 1015, '', 896, '3500', '2 LAKHS', 'Under Construction', ''),
(36, 32, '5th', '2 BHK', '2', 'NORTH', 1015, '', 896, '3500', '2 LAKHS', 'Under Construction', ''),
(45, 33, 'ALL', '2 BHK', '10', 'EAST/WEST', 0, '', 0, '3800', '3 LAKHS', 'Under Construction', ''),
(46, 34, '3rd', '3 BHK', '1 Hold', 'EAST', 1950, '55', 275, '4300', '2.5 LAKHS', 'Under Construction', ''),
(47, 34, '4th', '3BHK', '1', 'EAST', 1950, '55', 275, '4300', '2.5 LAKHS', 'Under Construction', ''),
(48, 34, '5th', '3 BHK', '1', 'EAST', 1950, '55', 275, '4300', '2.5 LAKHS', 'Under Construction', ''),
(49, 35, '2nd, 3rd, 5th', '3 BHK', 'ALL', 'EAST&WEST', 1780, '61', 895, '4600', '2.5 LAKHS', 'Under Construction', ''),
(50, 35, '3rd, 5th', '3BHK', 'ALL', 'NORTH', 1680, '57', 895, '4600', '2.5 LAKHS', 'Under Construction', ''),
(51, 36, '4th (403)', '2 BHK', '1', 'EAST', 1155, '50', 1630, '4000', '2 LAKHS', 'READY TO MOVE', ''),
(52, 36, '4th (405)', '2 BHK', '1', 'EAST', 1155, '50', 1630, '4000', '2 LAKHS', 'READY TO MOVE', ''),
(54, 37, '4th (402)', '2 BHK', '1', 'SOUTH', 1100, '38.5', 311, '4000', '2 LAKHS', 'Under Construction', ''),
(55, 38, '5th', '3 BHK', '1', 'EAST', 1427, '37', 427, '4800', '2 LAKHS', 'Under Construction', ''),
(56, 39, '1st', '3 BHK', '1', 'EAST', 1050, '40', 0, '4500', '2 LAKHS', 'Under Construction', ''),
(57, 39, '3rd', '3BHK', '1', 'WEST', 1050, '60', 0, '4500', '2 LAKHS', 'Under Construction', ''),
(58, 39, '4th', '2 BHK', '1', 'WEST', 1550, '60', 0, '4500', '2 LAKHS', 'Under Construction', ''),
(59, 39, '5th', '2 BHK', '2 (M)', 'EAST', 1050, '40', 0, '4500', '2 LAKHS', 'Under Construction', ''),
(60, 39, '5th', '3 BHK', '1', 'WEST', 1550, '60', 0, '4500', '2 LAKHS', 'Under Construction', ''),
(61, 40, '5th', '3 BHK', '1', 'EAST', 1200, '43.5', 435, '4300', '2 LAKHS', '2 months possission', ''),
(62, 40, '5th', '3BHK', '1', 'WEST', 1200, '43.5', 435, '4300', '2 LAKHS', '3 months possission', 'BULIDER'),
(63, 41, '3rd', '2 BHK', '1', 'EAST', 1000, '38.25', 306, '3800', '2 LAKHS', 'READY TO MOVE', ''),
(64, 41, '3rd', '2 BHK', '1', 'WEST', 1000, '38.25', 306, '3800', '2 LAKHS', 'READY TO MOVE', ''),
(65, 42, '3rd', '2 BHK', '14', 'EAST', 895, '', 6921, '3500', '3 LAKHS', 'Under Construction', ''),
(66, 42, '3rd', '2 BHK', '14', 'WEST', 1050, '', 6921, '3500', '3 LAKHS', 'Under Construction', ''),
(67, 42, '4th', '2 BHK', '14', 'EAST', 895, '', 6921, '3500', '3 LAKHS', 'Under Construction', ''),
(68, 42, '4th', '2 BHK', '14', 'WEST', 1050, '', 6921, '3500', '3 LAKHS', 'Under Construction', ''),
(69, 42, '5th', '2 BHK', '14', 'EAST', 895, '', 6921, '3500', '3 LAKHS', 'Under Construction', ''),
(70, 42, '5th', '2 BHK', '14', 'WEST', 1050, '', 6921, '3500', '3 LAKHS', 'Under Construction', ''),
(71, 42, '7th', '2 BHK', '14', 'EAST', 895, '', 6921, '3500', '3 LAKHS', 'Under Construction', ''),
(72, 42, '7th', '2 BHK', '14', 'WEST', 1050, '', 6921, '3500', '3 LAKHS', 'Under Construction', ''),
(73, 42, '8th', '2 BHK', '14', 'EAST', 895, '', 6921, '3500', '3 LAKHS', 'Under Construction', ''),
(74, 42, '8th', '2 BHK', '14', 'WEST', 1050, '', 6921, '3500', '3 LAKHS', 'Under Construction', ''),
(76, 43, '5TH', '3 BHK', '1', 'NORTH', 1400, '', 0, '7500', '3 LAKHS', 'Under Construction', ''),
(77, 44, '2 nd', '2 BHK', '1', 'EAST', 1050, '26', 213, '6600', '2 LAKHS', 'Under Construction', ''),
(78, 44, '1st', '2 BHK', '1', 'EAST', 1050, '26', 213, '6600', '2 LAKHS', 'Under Construction', ''),
(79, 44, '4th DC', '2 BHK', '1', 'EAST', 1050, '26', 213, '6600', '2 LAKHS', 'Under Construction', ''),
(80, 44, '4thDC', '2 BHK', '1', 'WEST', 1050, '26', 213, '6600', '2 LAKHS', 'Under Construction', ''),
(82, 45, '3rd', '2 BHK', '1', 'EAST', 800, '', 0, '5600', '1.5 LAKHS', 'READY TO MOVE', ''),
(84, 46, '3,5', '3BHK', '3', 'NORTH', 2000, '', 289, '7500', '4 LAKHS', 'New Launch', ''),
(85, 47, '3rd', '3BHK', '1', 'NORTH', 1650, '', 267, '6200', '3 LAKHS', 'Under Construction', ''),
(86, 48, '2nd, 3rd', '2 BHK', '1', 'EAST/WEST ', 1200, '36', 726, '3500', '2 LAKHS', 'Under Construction', ''),
(89, 49, '5th', '2 BHK', '1', 'WEST', 1050, '', 0, '4200', '2 LAKHS', 'Under Construction', ''),
(90, 50, '103', '2 BHK', '1', 'NORTH', 1015, '', 0, '4000', '2 LAKHS', 'Under Construction', ''),
(91, 50, '1', '2 BHK ', '1', 'NORTH', 1020, '', 0, '4000', '2 LAKHS', 'Under Construction', ''),
(93, 50, '1', '3 BHK', '1', 'NORTH', 1365, '', 0, '4000', '2 LAKHS', 'Under Construction', ''),
(94, 50, '202', '3 BHK', '1', 'NORTH', 1370, '', 0, '4000', '2 LAKHS', 'Under Construction', ''),
(95, 50, '2', '3 BHK', '1', 'SOUTH', 1385, '', 0, '4000', '2 LAKHS', 'Under Construction', ''),
(96, 50, '108', '3 BHK', '1', 'SOUTH', 1385, '', 0, '4000', '2 LAKHS', 'Under Construction', ''),
(97, 50, '109', '3 BHK', '1', 'SOUTH', 1385, '', 0, '4000', '2 LAKHS', 'Under Construction', ''),
(98, 50, '302', '3 BHK', '1', 'SOUTH', 1385, '', 0, '4000', '2 LAKHS', 'Under Construction', ''),
(99, 50, '308', '3 BHK', '1', 'SOUTH', 1675, '', 0, '4000', '2 LAKHS', 'Under Construction', ''),
(104, 52, '1 st', '2 BHK', '2', 'EAST', 930, '33', 534, '4000', '2 LAKHS', 'Under Construction', ''),
(105, 52, '1 st', '3 BHK', '1', 'WEST', 1250, '43', 534, '4000', '2 LAKHS', 'Under Construction', ''),
(106, 52, '2 nd', '2 BHK', '2', 'EAST', 930, '33', 534, '4000', '2 LAKHS', 'Under Construction', ''),
(107, 52, '2 nd ', '3 BHK', '1', 'WEST', 1250, '43', 534, '4000', '2 LAKHS', 'Under Construction', ''),
(108, 52, '3 rd', '2 BHK', '2', 'EAST', 930, '33', 534, '4000', '2 LAKHS', 'Under Construction', ''),
(109, 52, '3 rd', '3 BHK', '1', 'WEST', 1250, '43', 534, '4000', '2 LAKHS', 'Under Construction', ''),
(110, 52, '4 th', '2 BHK', '2', 'EAST', 930, '33', 534, '4000', '2 LAKHS', 'Under Construction', ''),
(111, 52, '4 th', '3 BHK', '1', 'WEST', 1250, '43', 534, '4000', '2 LAKHS', 'Under Construction', ''),
(112, 52, '5 th(M)', '2 BHK', '1', 'EAST', 930, '33', 534, '4000', '2 LAKHS', 'Under Construction', ''),
(113, 52, '5 th', '2 BHK', '1', 'EAST', 930, '33', 534, '4000', '2 LAKHS', 'Under Construction', ''),
(114, 52, '5 th (M)', '3 BHK', '1', 'WEST', 1250, '43', 534, '4000', '2 LAKHS', 'Under Construction', ''),
(116, 53, '3rd', '2BHK', '1', 'EAST', 860, '', 0, '4500', '2 LAKHS', 'Under Construction', ''),
(117, 54, '2nd', '3BHK', '1', 'EAST', 1400, '', 0, '5800', '2 LAKHS', 'READY TO MOVE', ''),
(119, 54, '3rd', '3BHK', '1', 'EAST', 1400, '', 0, '5800', '2 LAKHS', 'READY TO MOVE', ''),
(121, 55, 'ALL', '2 BHK', '1', 'NORTH/SOUTH', 1170, '', 0, '4000', '2 LAKHS', 'New Launch', ''),
(122, 56, '1, 2, 5 Floors Avail', '3BHK', '1', 'EAST', 2365, '', 0, '4800', '3L Till Pongal later', 'New Launch', ''),
(123, 57, '5th', '2BHK', '1', 'NORTH', 950, '', 0, '4000', '2 LAKHS', 'New Launch', ''),
(124, 58, 'G', '2 BHK', '5', 'EAST/WEST', 1080, '', 0, '3800', '2 LAKHS', 'Under Construction', ''),
(125, 58, '1', '2 BHK', '5', 'EAST/WEST', 1080, '', 0, '3800', '2 LAKHS', 'Under Construction', ''),
(126, 58, '2', '2 BHK', '5', 'EAST/WEST', 1080, '', 0, '3800', '2 LAKHS', 'Under Construction', ''),
(127, 58, '3', '2 BHK', '5', 'EAST/WEST', 1080, '', 0, '3800', '2 LAKHS', 'Under Construction', ''),
(128, 58, '4', '2 BHK', '5', 'EAST/WEST', 1080, '', 0, '3800', '2 LAKHS', 'Under Construction', ''),
(129, 59, 'Top', '3BHK', '3', 'SOUTH', 1475, '', 0, '4400', '1.5 LAKH', 'READY TO MOVE', ''),
(130, 60, '5th', '3 BHK', '-', 'EAST', 1175, '', 0, '3000', '1 LAKH', 'READY TO MOVE', ''),
(131, 60, '4th ', '3 BHK', '-', 'WEST', 1625, '', 0, '3000', '1 LAKH', 'READY TO MOVE', ''),
(132, 60, '5th ', '2 BHK', '-', 'EAST', 1175, '', 0, '3000', '1 LAKH', 'READY TO MOVE', ''),
(133, 61, 'Group2-Block-A', 'Group2-Block-A(3,4,5', '-', 'WEST', 1770, '', 0, '3000', '1 LAKH', 'Under Construction', ''),
(134, 61, 'Group2-Block-B', 'Group2-Block-B(3BHK ', '-', 'EAST', 1450, '', 0, '3000', '1 LAKH', 'Under Construction', ''),
(135, 61, 'Group2-Block-B', 'Group2-Block-B(3BHK ', '-', 'WEST', 1705, '', 0, '3000', '1 LAKH', 'Under Construction', ''),
(136, 61, 'Group2-Block-C', '3BHK', '201', 'WEST', 1725, '', 0, '3000', '1 LAKH', 'Under Construction', ''),
(137, 61, 'Group2-Block-C', 'Group2-Block-C(3BHK ', '301', 'WEST', 1725, '', 0, '3000', '1 LAKH', 'Under Construction', ''),
(138, 61, 'Group2-Block-C', 'Group2-Block-C(3BHK ', '401', 'WEST', 1725, '', 0, '3000', '1 LAKH', 'Under Construction', ''),
(139, 61, 'Group2-Block-C', 'Group2-Block-C(3BHK ', '501', 'WEST', 1725, '', 0, '3000', '1 LAKH', 'Under Construction', ''),
(140, 61, 'Group2-Block-C', 'Group2-Block-C(3BHK ', '203', 'EAST', 1450, '', 0, '3000', '1 LAKH', 'Under Construction', ''),
(141, 61, 'Group2-Block-C', 'Group2-Block-C(3BHK ', '303', 'EAST', 1450, '', 0, '3000', '1 LAKH', 'Under Construction', ''),
(142, 61, 'Group2-Block-C', 'Group2-Block-C(3BHK ', '202', 'EAST', 1450, '', 0, '3000', '1 LAKH', 'Under Construction', ''),
(143, 61, 'Group2-Block-C', 'Group2-Block-C(3BHK ', '302', 'EAST', 1450, '', 0, '3000', '1 LAKH', 'Under Construction', ''),
(144, 61, 'Group2-Block-C', 'Group2-Block-C(3BHK ', '502', 'EAST', 1450, '', 0, '3000', '1 LAKH', 'Under Construction', ''),
(145, 62, '1ST', '2BHK', '1', 'NORTH', 1080, '', 0, '3500', '1.5 LAKH', 'Under Construction', ''),
(146, 62, 'TOP ', '2BHK', '2', 'NORTH,SOUTH', 1080, '', 0, '3500', '1.5 LAKH', 'Under Construction', ''),
(147, 63, '5th', '2BHK', '2', 'SOUTH', 1050, '', 0, '4500', '1.5 LAKH', 'READY TO MOVE', ''),
(151, 36, '5th', '2 BHK', '1', 'WEST', 1155, '-', 0, '4000', '2 LAKHS', 'READY TO MOVE', ''),
(152, 36, '3rd', '3 BHK', '1', 'WEST', 1455, '-', 0, '4000', '2 LAKHS', 'READY TO MOVE', ''),
(153, 36, '5th(506)', '2 BHK', '1', 'WEST', 1155, '-', 0, '4000', '2 LAKHS', 'READY TO MOVE', ''),
(154, 64, '2 nd', '3 BHK', '1', 'EAST', 1532, '', 1532, '4200', '2 LAKHS', 'New Launch', '-'),
(155, 64, '3rd', '3 BHK', '1', 'EAST', 1532, '', 1532, '4200', '2 LAKHS', 'New Launch', ''),
(156, 64, '4th', '3 BHK', '1', 'EAST', 1532, '', 1532, '4200', '2 LAKHS', 'New Launch', ''),
(157, 65, '1st(M)', '3 BHK', '1', 'NORTH', 1700, '-', 0, '4500', '2 LAKHS', 'Under Construction', '-'),
(158, 65, '3rd', '3 BHK', '1', 'NORTH', 1700, '-', 0, '4500', '2 LAKHS', 'Under Construction', '-'),
(159, 66, '2nd,4th,5th(m)', '2 BHK', '-', 'EAST', 1160, '-', 0, '6300', '3 LAKHS', 'Under Construction', '-'),
(160, 66, '1st, 3rd, 4th', '2 BHK', '-', 'WEST', 920, '-', 0, '6300', '3 LAKHS', 'Under Construction', '-'),
(164, 51, '1st(109)', '3 BHK', '1', 'EAST', 1640, '-', 0, '4200', '3 LAKHS', 'Under Construction', '-'),
(165, 79, '2nd, 3rd', '3 BHK', '2', 'EAST', 1700, '-', 0, '7300', '3 LAKHS', 'New Launch', '-'),
(166, 80, '3rd, 4th, 5th', '2 BHK / 3 BHK', '1', 'NORTH', 1145, '-', 0, '4600', '2 LAKHS', 'Under Construction', '-'),
(167, 81, 'Ground(104,106)', '2 BHK', '3', 'EAST', 1050, '-', 0, '4200', '2 LAKHS', 'Under Construction', '-'),
(168, 81, 'Ground(103,105)', '2 BHK', '3', 'WEST', 1050, '-', 0, '4200', '2 LAKHS', 'Under Construction', '-'),
(169, 81, 'Ground-(107,108,109,110)', '3 BHK', '4', 'NORTH', 1350, '-', 0, '4200', '2 LAKHS', 'Under Construction', '-'),
(170, 81, 'Ground(111)', '2 BHK', '1', 'SOUTH', 1230, '-', 0, '4200', '2 LAKHS', 'Under Construction', '-'),
(171, 81, '1st(206)', '2 BHK', '2', 'EAST', 1050, '-', 0, '4200', '2 LAKHS', 'Under Construction', '-'),
(172, 81, '1st(203)', '2 BHK', '1', 'WEST', 1050, '-', 0, '4200', '2 LAKHS', 'Under Construction', '-'),
(173, 81, '1st(208,209)', '3 BHK', '2', 'NORTH', 1350, '-', 0, '4200', '2 LAKHS', 'Under Construction', '-'),
(175, 81, '2nd(303)', '2 BHK', '2', 'WEST', 1050, '-', 0, '4200', '2 LAKHS', 'Under Construction', '-'),
(180, 81, '3rd(411)', '2 BHK', '1', 'SOUTH', 1230, '-', 0, '4200', '2 LAKHS', 'Under Construction', '-'),
(182, 81, '4th(503,505)', '2 BHK', '2', 'WEST', 1050, '-', 0, '4200', '2 LAKHS', 'Under Construction', '-'),
(183, 81, '4th(507,508)', '3 BHK', '2', 'NORTH', 1350, '-', 0, '4200', '2 LAKHS', 'Under Construction', '-'),
(185, 82, '2nd(207)', '3 BHK', '1', 'WEST', 1390, '-', 0, '4800', '3 LAKHS', 'Under Construction', '-'),
(186, 82, '3rd(307)', '3 BHK', '1', 'WEST', 1390, '-', 0, '4800', '3 LAKHS', 'Under Construction', '-'),
(187, 82, '2nd(208)', '3 BHK', '1', 'SOUTH', 1420, '-', 0, '4800', '3 LAKHS', 'Under Construction', '-'),
(188, 82, '4th(408)', '3 BHK', '1', 'SOUTH', 1420, '-', 0, '4800', '3 LAKHS', 'Under Construction', '-'),
(189, 82, '3rd(309)', '3 BHK', '1', 'NORTH', 1420, '-', 0, '4800', '3 LAKHS', 'Under Construction', '-'),
(190, 82, '4th(404)', '3 BHK', '1', 'EAST', 1520, '-', 0, '4800', '3 LAKHS', 'Under Construction', '-'),
(191, 82, '5th(504)', '3 BHK', '1', 'EAST', 1520, '-', 0, '4800', '3 LAKHS', 'Under Construction', '-'),
(192, 82, '3rd(301)', '3BHK', '1', 'WEST', 1520, '-', 0, '4800', '3 LAKHS', 'Under Construction', '-'),
(193, 82, '4th(401)', '3BHK', '1', 'WEST', 1520, '-', 0, '4800', '3 LAKHS', 'Under Construction', '-'),
(194, 82, '5th(501)', '3 BHK', '1', 'WEST', 1520, '-', 0, '4800', '3 LAKHS', 'Under Construction', '-'),
(195, 83, '1st', '3 BHK', '1', 'EAST/WEST', 1550, '-', 0, '7600', '3 LAKHS', 'Under Construction', '-'),
(196, 84, 'Ground, 2nd', '3 BHK', '2', 'WEST', 1500, '44', 440, '7500', '3 LAKHS', 'Under Construction', '-'),
(197, 85, '2nd, 4th', '2 BHK / 3 BHK', '4', 'NORTH', 1140, '31', 155, '4600', '2 LAKHS', 'Under Construction', '-'),
(198, 86, '1st, 4th', '2 BHK', '1', 'SOUTH', 1000, '-', 200, '6800', '2 LAKHS', 'Under Construction', '-'),
(199, 87, '2nd, 3rd, 4th', '3 BHK', '1', 'EAST/WEST', 2527, '-', 0, '7500', '2 LAKHS', 'Under Construction', '-'),
(200, 88, '1st, 2nd, 3rd, 4th, 5th', '3 BHK', '1', 'WEST', 2569, '-', 0, '7500', '2 LAKHS', 'Under Construction', '-'),
(201, 90, '5th(501)', '2 BHK', '1', 'EAST', 1125, '-', 886, '4200', '2 LAKHS', 'Under Construction', '-'),
(202, 90, '2nd(203), 4th(403), 5th(504)', '2 BHK', '1', 'WEST', 1125, '-', 886, '4200', '2 LAKHS', 'Under Construction', '-'),
(203, 54, '4th', '3BHK', '1', 'EAST', 1400, '-', 0, '5800', '2 LAKHS', 'READY TO MOVE', '-'),
(204, 91, '2nd (202)', '3 BHK', '1', 'NORTH', 1325, '-', 0, '4500', '2.5 Lakhs', 'Under Construction', '-'),
(205, 91, '4th (404)', '3 BHK', '1', 'NORTH', 1550, '-', 0, '4500', '2.5 Lakhs', 'Under Construction', '-'),
(206, 91, '4th (405)', '3 BHK', '1', 'SOUTH', 1500, '-', 0, '4550', '2.5 Lakhs', 'Under Construction', '-'),
(209, 48, '1st(102) , 4th(402), 5th(502(M))', '2 BHK', '1', 'EAST', 1200, '-', 0, '3600', '2 LAKHS', 'Under Construction', '-'),
(210, 48, '5th(503(m))', '2 BHK', '1', 'WEST', 1200, '-', 0, '3600', '2 LAKHS', 'Under Construction', '-'),
(211, 92, '5th', '2 BHK', '1', 'EAST', 1180, '-', 2100, '3500', '2 LAKHS', 'READY TO MOVE', '-'),
(212, 93, 'Ground', '3 BHK', '1', 'EAST', 1425, '-', 0, '3500', '2 LAKHS', 'Under Construction', '-'),
(216, 94, '5th', '3 BHK', '1', 'EAST', 1660, '-', 722, '3800', '2 LAKHS', 'Under Construction', '-'),
(217, 94, '5th', '2 BHK', '1', 'NORTH', 1210, '-', 722, '3800', '2 LAKHS', 'Under Construction', '-'),
(218, 95, '2nd, 3rd, 4th', '3 BHK', '6', 'WEST', 1380, '-', 0, '4800', '2 LAKHS', 'Under Construction', '-'),
(219, 95, '2nd, 3rd, 4th', '3 BHK', '6', 'EAST', 1450, '-', 0, '4800', '2 LAKHS', 'Under Construction', '-'),
(220, 96, '2nd', '3 BHK', '2', 'NORTH', 2100, '-', 0, '3500', '2 LAKHS', 'READY TO MOVE', '-'),
(222, 98, '3rd (Block B)', '2 BHK', '1', 'EAST', 1075, '-', 0, '3500', '2 LAKHS', 'Under Construction', '-'),
(224, 98, '3rd (Block C)', '2 BHK', '1', 'EAST', 1120, '-', 0, '3500', '2 LAKHS', 'Under Construction', '-'),
(225, 98, '1st (Block D)', '2 BHK', '1', 'EAST', 1120, '-', 0, '3500', '2 LAKHS', 'Under Construction', '-'),
(226, 98, '3rd (Block D)', '2 BHK', '1', 'EAST', 1150, '-', 0, '3500', '2 LAKHS', 'Under Construction', '-'),
(229, 100, '1st', '2 BHK', '1', 'NORTH', 1000, '-', 234, '4400', '2 LAKHS', 'Under Construction', '-'),
(230, 100, '2nd', '2 BHK', '1', 'North & South', 1000, '-', 234, '4400', '2 LAKHS', 'Under Construction', '-'),
(231, 100, '3rd', '2 BHK', '1', 'North & South', 1000, '-', 234, '4400', '2 LAKHS', 'Under Construction', '-'),
(232, 97, '1st', '2BHK', '1', 'SOUTH', 1200, '-', 0, '3500', '2 LAKHS', 'Under Construction', '-'),
(233, 97, '4th, 5th', '2BHK', '1', 'NORTH & SOUTH', 1200, '-', 0, '3500', '2 LAKHS', 'Under Construction', '-'),
(234, 98, '1st (Block B)', '2 BHK', '1', 'EAST', 1120, '-', 0, '3500', '2 LAKHS', 'Under Construction', '-'),
(235, 51, '1st (101)', '2 BHK', '1', 'WEST', 1260, '-', 0, '4200', '3 LAKHS', 'Under Construction', '-'),
(236, 51, '1st (103)', '2 BHK', '1', 'WEST', 1230, '-', 0, '4200', '3 LAKHS', 'Under Construction', '-'),
(237, 51, '1st (107)', '2 BHK', '1', 'WEST', 1230, '-', 0, '4200', '3 LAKHS', 'Under Construction', '-'),
(238, 51, '6th (601)', '3 BHK', '1', 'WEST', 1230, '-', 0, '4200', '3 LAKHS', 'Under Construction', '-'),
(239, 101, '1st & 3rd & 4th & 5th', '2 BHK', '1', 'EAST & WEST', 1155, '-', 0, '4000', '5 Lakhs', 'READY TO MOVE', '-'),
(240, 101, '2nd & 5th', '2 BHK', '1', 'NORTH', 1240, '-', 0, '4000', '5 Lakhs', 'READY TO MOVE', '-'),
(241, 101, '2nd & 3rd & 5th', '3 BHK', '1', 'EAST & WEST', 1525, '-', 0, '4000', '5 Lakhs', 'READY TO MOVE', '-'),
(242, 101, '2nd & 3rd & 4th & 5th', '3 BHK', '1', 'EAST & WEST', 1680, '-', 0, '4000', '5 Lakhs', 'READY TO MOVE', '-'),
(243, 101, '1st & 3rd & 4th & 5th', '3 BHK', '1', 'EAST & WEST', 1530, '-', 0, '4000', '5 Lakhs', 'READY TO MOVE', '-'),
(244, 101, '2nd & 5th', '3 BHK', '1', 'EAST', 1850, '-', 0, '4000', '5 Lakhs', 'READY TO MOVE', '-'),
(245, 102, '2nd', '2 BHK', '1', 'EAST & WEST', 1050, '-', 0, '5100', '2.5 Lakhs', 'Under Construction', '-'),
(246, 102, '3rd', '2 BHK', '1', 'WEST', 1050, '-', 0, '5100', '2.5 Lakhs', 'Under Construction', '-'),
(247, 102, '4th', '2 BHK', '1', 'EAST', 1050, '-', 0, '5100', '2.5 Lakhs', 'Under Construction', '-'),
(248, 102, '5th', '2 BHK', '1', 'EAST & WEST', 1050, '-', 0, '5100', '2.5 Lakhs', 'Under Construction', '-'),
(249, 103, 'ALL', '3 BHK', '1', 'NORTH', 1820, '-', 0, '4800', '2 LAKHS', 'Under Construction', '-'),
(250, 104, 'ALL', '2 BHK', '1', 'NORTH', 1050, '-', 0, '3500', '2 LAKHS', 'Under Construction', '-'),
(251, 104, 'ALL', '2 BHK', '1', 'NORTH', 1015, '-', 0, '3500', '2 LAKHS', 'Under Construction', '-'),
(252, 104, 'ALL', '2 BHK', '1', 'SOUTH', 1100, '-', 0, '3500', '2 LAKHS', 'Under Construction', '-'),
(253, 105, 'ALL', '2 BHK', '1', 'North & South', 925, '-', 0, '3600', '2 LAKHS', 'New Launch', '-'),
(254, 106, '3rd, 4th, 5th', '3 BHK', '1', 'NORTH', 2350, '-', 0, '7600', '4 LAKHS', 'Under Construction', '-'),
(255, 106, '2nd (Commercial)', '3 BHK', '1', 'NORTH', 2350, '-', 0, '9500', '5 Lakhs', 'Under Construction', '-'),
(256, 107, 'Ground(102)', '2 BHK', '1', 'WEST', 1120, '-', 0, '4700', '2.5 Lakhs', 'Under Construction', '-'),
(257, 107, 'Ground (105)', '3 BHK', '1', 'WEST', 1375, '-', 0, '4700', '2.5 Lakhs', 'Under Construction', '-'),
(258, 107, '1st(203)', '2 BHK', '1', 'WEST', 1120, '-', 0, '4700', '2.5 Lakhs', 'Under Construction', '-'),
(259, 107, '1st(205)', '3 BHK', '1', 'WEST', 1375, '-', 0, '4700', '2.5 Lakhs', 'Under Construction', '-'),
(260, 107, '1st(206)', '3 BHK', '1', 'EAST', 1420, '-', 0, '4700', '2.5 Lakhs', 'Under Construction', '-'),
(261, 107, '2nd(302)', '2 BHK', '1', 'WEST', 1120, '-', 0, '4700', '2.5 Lakhs', 'Under Construction', '-'),
(262, 107, '2nd(303)', '2 BHK', '1', 'WEST', 1120, '-', 0, '4700', '2.5 Lakhs', 'Under Construction', '-'),
(263, 107, '2nd(304)', '2 BHK', '1', 'WEST', 1100, '-', 0, '4700', '2.5 Lakhs', 'Under Construction', '-'),
(264, 107, '2nd(305)', '3 BHK', '1', 'WEST', 1375, '-', 0, '4700', '2.5 Lakhs', 'Under Construction', '-'),
(265, 107, '2nd(306)', '3 BHK', '1', 'EAST', 1420, '-', 0, '4700', '2.5 Lakhs', 'Under Construction', '-'),
(266, 107, '3rd(403)', '2 BHK', '1', 'WEST', 1120, '-', 0, '4700', '2.5 Lakhs', 'Under Construction', '-'),
(267, 107, '3rd(405)', '3 BHK', '1', 'WEST', 1375, '-', 0, '4700', '2.5 Lakhs', 'Under Construction', '-'),
(268, 107, '3rd(406)', '3 BHK', '1', 'EAST', 1420, '-', 0, '4700', '2.5 Lakhs', 'Under Construction', '-'),
(269, 107, '3rd(407)', '3 BHK', '1', 'EAST', 1410, '-', 0, '4700', '2.5 Lakhs', 'Under Construction', '-'),
(270, 107, '4th(501)', '3 BHK', '1', 'EAST', 1375, '-', 0, '4700', '2.5 Lakhs', 'Under Construction', '-'),
(271, 107, '4th(503)', '2 BHK', '1', 'WEST', 1120, '-', 0, '4700', '2.5 Lakhs', 'Under Construction', '-'),
(272, 107, '4th(506)', '3 BHK', '1', 'EAST', 1420, '-', 0, '4700', '2.5 Lakhs', 'Under Construction', '-'),
(273, 108, '2nd', '3 BHK', '1', 'WEST', 2100, '-', 0, '4300', '5 Lakhs', 'New Launch', '-'),
(274, 108, '4th', '3 BHK', '1', 'NORTH', 1750, '-', 0, '4300', '5 Lakhs', 'New Launch', '-'),
(275, 108, '7th', '3 BHK', '1', 'NORTH', 1750, '-', 0, '4300', '5 Lakhs', 'New Launch', '-'),
(276, 108, '8th', '2 BHK', '1', 'NORTH', 1155, '-', 0, '4300', '5 Lakhs', 'New Launch', '-'),
(277, 109, '2nd', '2 BHK', '1', 'EAST', 860, '-', 0, '3300', '2 LAKHS', 'New Launch', '-'),
(278, 109, '3rd', '2 BHK', '1', 'NORTH', 850, '-', 0, '3300', '2 LAKHS', 'New Launch', '-'),
(279, 110, 'Ground(101)', '3BHK', '1', 'EAST', 1415, '-', 0, '3500', '2 LAKHS', 'Under Construction', '-'),
(280, 110, 'Ground(102)', '2 BHK', '1', 'NORTH', 1030, '-', 0, '3500', '2 LAKHS', 'Under Construction', '-'),
(281, 110, 'Ground(103)', '2BHK', '1', 'WEST', 1050, '-', 0, '3500', '2 LAKHS', 'Under Construction', '-'),
(282, 110, '1st(201)', '3 BHK', '1', 'EAST', 1415, '', 0, '3500', '2 LAKHS', 'Under Construction', '-'),
(283, 110, '1st(202)', '2 BHK', '1', 'NORTH', 1030, '-', 0, '3500', '2 LAKHS', 'Under Construction', '-'),
(284, 110, '5th(601)', '3 BHK', '1', 'EAST', 1415, '-', 0, '3500', '2 LAKHS', 'Under Construction', '-'),
(285, 110, '5th(602)', '2 BHK', '1', 'NORTH', 1030, '-', 0, '3500', '2 LAKHS', 'Under Construction', '-'),
(286, 110, '5th(603)', '2 BHK', '1', 'WEST', 1050, '-', 0, '3500', '2 LAKHS', 'Under Construction', '-'),
(287, 111, '1st', '2 BHK', '1', 'EAST & WEST', 1040, '-', 0, '3500', '-', 'New Launch', '-'),
(288, 111, '3rd', '2 BHK', '1', 'EAST & WEST', 1040, '-', 0, '3500', '-', 'New Launch', '-'),
(289, 111, '5th', '2 BHK', '1', 'EAST & WEST', 1040, '-', 0, '3500', '-', 'New Launch', '-'),
(290, 112, '2nd, 3rd, 5th', '3 BHK', '1', 'NORTH', 2000, '-', 0, '7500', '4 LAKHS', 'Under Construction', '-'),
(291, 113, 'Ground', '2 BHK', '1', 'EAST', 1289, '-', 0, '3200', '1 LAKH', 'Under Construction', '-'),
(292, 114, '1st, 3rd', '3 BHK', '1', 'North', 1750, '-', 0, '8000', '3 LAKHS', 'Under Construction', '-'),
(293, 115, '1st, 2nd, 3rd, 4th, 5th', '2 BHK', '1', 'North', 1150, '-', 0, '5800', '2 LAKHS', 'Under Construction', '-'),
(294, 115, '1st, 3rd, 4th, 5th', '3 BHK', '1', 'South', 1435, '-', 0, '5800', '2 LAKHS', 'Under Construction', '-'),
(295, 116, '1st(102), 2nd(202), 4th(402), 5th(501,502)', '2 BHK', '10', 'East', 1035, '-', 0, '4300', '2 Lakhs', 'Under Construction', '-'),
(296, 117, 'All', '2 BHK', '1', 'East', 1375, '-', 0, '4000', '-', 'Under Construction', '-'),
(297, 117, 'All', '3 BHK', '1', 'North', 1650, '-', 0, '4000', '-', 'Under Construction', '-'),
(298, 118, '2nd (Block-B)', '3 BHK', '1', 'West', 1538, '-', 0, '4500', '-', 'Ready to move', '-'),
(299, 118, '1st, 2nd, 3rd, 4th, 5th (Block-C)', '2 BHK', '1', 'West', 1193, '-', 0, '4500', '-', 'Ready to move', '-'),
(300, 118, '1st, 3rd (Block-C)', '3 BHK', '1', 'East', 1586, '-', 0, '4500', '-', 'Ready to move', '-'),
(301, 118, '1st, 2nd, 3rd, 4th, 5th (Block-D)', '2 BHK', '1', 'West', 1233, '-', 0, '4500', '-', 'Ready to move', '-'),
(302, 118, '1st, 2nd, 3rd, 4th, 5th (Block-D)', '2 BHK', '1', 'East', 1211, '-', 0, '4500', '-', 'Ready to move', '-'),
(303, 118, '1st, 2nd, 3rd, 4th, 5th (Block-D)', '3 BHK', '1', 'West', 1573, '-', 0, '4500', '-', 'Ready to move', '-'),
(304, 118, '1st, 2nd, 3rd, 4th, 5th (Block-D)', '3 BHK', '1', 'East', 1573, '-', 0, '4500', '-', 'Ready to move', '-'),
(305, 118, '1st, 2nd, 3rd, 4th, 5th (Block-D)', '3 BHK', '1', 'North', 1630, '-', 0, '4500', '-', 'Ready to move', '-'),
(306, 118, '1st, 2nd, 3rd, 4th, 5th (Block-E)', '3 BHK', '1', 'North', 1630, '-', 0, '4500', '-', 'Ready to move', '-'),
(307, 119, '2nd (Block-A)', '3 BHK', '1', 'West', 2465, '-', 0, '3500', '2.5 Lakhs', 'Ready to move', '-'),
(308, 119, '1st (Block-C)', '3 BHK', '1', 'West', 1769, '-', 0, '3500', '2.5 Lakhs', 'Ready to move', '-'),
(309, 119, '5th (Block-C)', '3 BHK', '1', 'West', 1769, '-', 0, '3500', '2.5 Lakhs', 'Ready to move', '-'),
(310, 119, '1st, 2nd, 3rd, 4th, 5th (Block-D)', '3 BHK', '1', 'West', 1769, '-', 0, '3500', '2.5 Lakhs', 'Ready to move', '-'),
(311, 119, '5th (Block-E)', '2 BHK', '1', 'West', 1166, '-', 0, '3500', '2.5 Lakhs', 'Ready to move', '-'),
(312, 119, '4th, 5th (Block-F)', '2 BHK', '1', 'East', 1166, '-', 0, '3500', '2.5 Lakhs', 'Under Construction', '-'),
(313, 119, '1st, 3rd, 5th (Block-F)', '2 BHK', '1', 'West', 1166, '-', 0, '3500', '2.5 Lakhs', 'Under Construction', '-'),
(314, 119, '2nd, 3rd, 4th, 5th (Block-G)', '2 BHK', '1', 'East', 1166, '-', 0, '3500', '2.5 Lakhs', 'Under Construction', '-'),
(315, 119, '1st, 2nd, 3rd, 4th, 5th (Block-G)', '2 BHK', '1', 'West', 1166, '-', 0, '3500', '2.5 Lakhs', 'Under Construction', '-'),
(316, 119, '4th (Block-I)', '3 BHK', '1', 'East', 2695, '-', 0, '3500', '2.5 Lakhs', 'Under Construction', '-'),
(317, 120, 'All', '2BHK', '1', 'East & West', 920, '-', 0, '4500', '2 Lackhs', 'Under Construction', '-'),
(318, 121, 'All', '3 BHK', '1', 'North', 1550, '-', 0, '4825', '2 Lackhs', 'Under Construction', '-'),
(319, 122, 'All', '3 BHK', '1', 'East & West', 1050, '-', 0, '3300', '2 Lakhs', 'Under Construction', '-'),
(320, 123, '-', '3 BHK', '1', 'North', 1435, '-', 0, '4200', '4 Lakhs', 'Under Construction', '-'),
(321, 123, '-', '3 BHK', '1', 'West', 1360, '-', 0, '4200', '4 Lakhs', 'Under Construction', '-'),
(322, 123, '-', '2 BHK', '1', 'North', 1025, '-', 0, '4200', '4 Lakhs', 'Under Construction', '-'),
(323, 123, '-', '2 BHK', '1', 'West', 1040, '-', 0, '4200', '4 Lakhs', 'Under Construction', '-'),
(324, 123, '-', '2 BHK', '1', 'South', 1120, '-', 0, '4200', '4 Lakhs', 'Under Construction', '-'),
(325, 123, '-', '2 BHK', '1', 'West', 1140, '-', 0, '4200', '4 Lakhs', 'Under Construction', '-'),
(326, 124, 'All', '3 BHK', '1', 'East', 2271, '-', 0, '7800', '3 Lakhs', 'Under Construction', '-'),
(327, 125, '-', '2 BHK', '1', 'North & South', 1000, '-', 0, '3700', '2 Lakhs', 'Under Construction', '-'),
(328, 125, '-', '2 BHK', '1', 'North & South', 950, '-', 0, '3700', '2 Lakhs', 'Under Construction', '-'),
(329, 125, '-', '2 BHK', '1', 'North & South', 910, '-', 0, '3700', '2 Lakhs', 'Under Construction', '-'),
(330, 126, '-', '3 BHK', '1', 'East', 2271, '-', 0, '7800', '3 Lakhs', 'Under Construction', '-'),
(331, 127, '2nd, 4th, 5th', '2 BHK', '1', 'North & South', 900, '-', 0, '4500', '2 Lakhs', 'Under Construction', '-'),
(332, 127, '4th, 5th', '2 BHK', '1', 'North & South', 950, '-', 0, '4500', '2 Lakhs', 'Under Construction', '-'),
(333, 128, '2nd, 4th', '2 BHK', '1', 'East', 1090, '-', 0, '4500', '2 Lakhs', 'Under Construction', '-'),
(334, 128, '-', '2 BHK', '1', 'East', 1130, '-', 0, '4500', '2 Lakhs', 'Under Construction', '-'),
(335, 128, '-', '3 BHK', '1', 'West', 1400, '-', 0, '4500', '2 Lakhs', 'Under Construction', '-'),
(336, 129, '1st(m), 3rd, 4th, 5th', '3 BHK', '1', 'East', 1800, '-', 0, '4300', '2.5 Lacks', 'Under Construction', '-'),
(337, 130, '4th', '3 BHK', '1', 'East', 1800, '-', 0, '4800', '3 Lakhs', 'Ready to Move', '-'),
(338, 131, '3rd, 4th, 5th', '2 BHK', '1', 'East', 1319, '-', 0, '3600', '-', 'Ready to Move', '-'),
(339, 131, '3rd, 4th, 5th', '2 BHK', '1', 'West', 1411, '-', 0, '3600', '-', 'Ready to Move', '-'),
(340, 131, '2nd, 3rd, 4th, 5th', '3 BHK', '1', 'North', 1716, '-', 0, '3600', '-', 'Ready to Move', '-'),
(341, 132, '2nd, 3rd, 4th, 5th', '2 BHK', '1', 'East', 1310, '-', 0, '3600', '-', 'Ready to Move', '-'),
(342, 132, '2nd, 3rd, 4th, 5th', '2 BHK', '1', 'West', 1310, '-', 0, '3600', '-', 'Ready to Move', '-'),
(343, 133, '1st, 3rd, 4th, 5th', '2 BHK', '1', 'East', 1110, '-', 0, '3500', '-', 'Ready to Move', '-'),
(344, 133, '2nd, 4th, 5th', '3 BHK', '1', 'West', 1165, '-', 0, '3500', '-', 'Ready to Move', '-'),
(345, 133, '2nd,  4th, 5th', '3 BHK', '1', 'West', 1435, '-', 0, '3500', '-', 'Ready to Move', '-'),
(346, 133, '2nd,  4th, 5th', '3 BHK', '1', 'West', 1440, '-', 0, '3500', '-', 'Ready to Move', '-'),
(347, 134, '1st, 2nd, 4th', '2 BHK', '1', 'East', 1175, '-', 0, '4700', '-', 'Ready to Move', '-'),
(348, 134, '1st, 2nd, 4th', '2 BHK', '1', 'East', 1205, '-', 0, '4700', '-', 'Ready to Move', '-'),
(349, 134, '1st, 3rd, 5th', '3 BHK', '1', 'West', 1615, '-', 0, '4700', '-', 'Ready to Move', '-'),
(350, 134, '1st, 3rd, 5th', '3 BHK', '1', 'West', 1725, '-', 0, '4700', '-', 'Ready to Move', '-'),
(351, 134, '1st, 3rd, 5th', '3 BHK', '1', 'West', 2030, '-', 0, '4700', '-', 'Ready to Move', '-'),
(352, 135, '1st, 3rd,  4th, 5th', '2 BHK', '1', 'East', 1260, '-', 0, '4000', '-', 'Ready to Move', '-'),
(353, 135, '1st, 3rd,  4th, 5th', '2 BHK', '1', 'West', 1270, '-', 0, '4000', '-', 'Ready to Move', '-'),
(354, 135, '2nd, 4th, 5th', '3 BHK', '1', 'West, North', 1890, '-', 0, '4000', '-', 'Ready to Move', '-'),
(355, 132, '2nd, 3rd, 4th, 5th', '3 BHK', '1', 'North', 1675, '-', 0, '3600', '-', 'Ready to Move', '-'),
(356, 82, '5th(507)', '3 BHK', '1', 'WEST', 1390, '-', 0, '4800', '-', 'Under Construction', '-'),
(357, 82, '5th(509)', '3 BHK', '1', 'NORTH', 1420, '-', 0, '4800', '-', 'Under Construction', '-'),
(358, 136, '-', '2 BHK', '1', 'East & West', 865, '-', 0, '3500', '2.5 Lackhs', 'Under Construction', '-'),
(359, 137, 'All', '3BHK', '1', 'West', 2007, '-', 2007, '6500', '2Lakhs', 'Redy to move', '-'),
(360, 137, 'All', '3BHK', '1', 'East', 2232, '-', 2232, '6500', '2Lakhs', 'Redy to move', '-'),
(361, 137, 'All', '3BHK', '1', 'East', 2575, '-', 2575, '6500', '2Lakhs', 'Redy to move', '-');

-- --------------------------------------------------------

--
-- Table structure for table `property_images`
--

CREATE TABLE `property_images` (
  `id` int(11) NOT NULL,
  `property_id` int(11) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `uploaded_on` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `property_images`
--

INSERT INTO `property_images` (`id`, `property_id`, `file_name`, `uploaded_on`) VALUES
(40, 26, 'au_out_gate_priject_elevation.jpeg', '2020-08-10 10:46:14'),
(41, 26, 'REVISED_FLOOR_PLAN_-AU_OUTGATE_page-0001_copy.jpg', '2020-08-10 10:46:14'),
(45, 28, 'MARRIPALEM_PROJECT_ELEVATION.jpg', '2020-08-10 11:13:03'),
(46, 28, 'MARRIPALEM_PROJECT_PLAN.jpg', '2020-08-10 11:13:03'),
(59, 32, 'chinnamusidiwada_,vudacolony_elevetion.jpg', '2020-08-10 11:42:12'),
(60, 32, 'chinnamusidiwada_,vudacolony_plan.jpg', '2020-08-10 11:42:13'),
(61, 32, 'chinnamusidiwada_,vudacolony_spefications.jpg', '2020-08-10 11:42:14'),
(62, 31, 'sujatha_nager_1050_elevation.jpg', '2020-08-10 11:46:54'),
(63, 31, 'sujatha_nager_1050_sft_plan.jpg', '2020-08-10 11:46:54'),
(64, 38, 'new_godavari.jpg\r\n', '2020-08-10 12:01:26'),
(65, 38, 'CAR_SHED_JN_PLAN_copy.jpg', '2020-08-10 12:01:26'),
(66, 38, 'CAR_SHED_JN_PLAN.jpg', '2020-08-10 12:01:26'),
(67, 38, 'CAR_SHED_JN_SPEFICATION_copy.jpg', '2020-08-10 12:01:26'),
(77, 35, 'yendada_pettrol_bunk_line_elevetion.jpg', '2020-08-10 12:21:05'),
(79, 35, 'yendada_pettrol_bunk_line_spefications.jpg', '2020-08-10 12:21:07'),
(80, 35, 'yendada_pettrol_bunk_line_plan_jpje.jpg', '2020-08-10 12:21:09'),
(89, 37, '12.jpg', '2020-12-09 08:21:31'),
(90, 37, '21.jpg', '2020-12-09 08:21:31'),
(91, 37, '3.jpg', '2020-12-09 08:21:31'),
(99, 43, '1.jpeg', '2020-12-11 14:12:35'),
(100, 43, '27.jpg', '2020-12-11 14:12:35'),
(101, 44, '11.jpeg', '2020-12-11 14:28:12'),
(102, 44, '2.jpeg', '2020-12-11 14:28:12'),
(105, 46, '12.jpeg', '2020-12-11 14:56:51'),
(106, 46, '22.jpeg', '2020-12-11 14:56:51'),
(109, 48, '17.jpg', '2020-12-11 15:35:03'),
(110, 48, '29.jpg', '2020-12-11 15:35:05'),
(111, 48, '33.jpg', '2020-12-11 15:35:07'),
(112, 48, '4.jpg', '2020-12-11 15:35:09'),
(119, 51, '110.jpg', '2020-12-11 17:00:06'),
(120, 51, '212.jpg', '2020-12-11 17:00:06'),
(121, 51, '35.jpg', '2020-12-11 17:00:06'),
(122, 51, '42.jpg', '2020-12-11 17:00:06'),
(123, 51, '52.jpg', '2020-12-11 17:00:06'),
(133, 55, '14.jpeg', '2020-12-11 18:01:08'),
(134, 55, '24.jpeg', '2020-12-11 18:01:08'),
(137, 56, '16.jpeg', '2020-12-11 18:09:43'),
(138, 56, '26.jpeg', '2020-12-11 18:09:43'),
(139, 57, '17.jpeg', '2020-12-11 18:16:39'),
(140, 57, '27.jpeg', '2020-12-11 18:16:39'),
(145, 47, '114.jpg', '2020-12-12 05:36:19'),
(146, 47, '216.jpg', '2020-12-12 05:36:19'),
(168, 64, 'abc.jpeg', '2021-01-06 09:47:10'),
(169, 65, '18.jpeg', '2021-01-29 11:14:33'),
(170, 65, '28.jpeg', '2021-01-29 11:14:33'),
(171, 65, '31.jpeg', '2021-01-29 11:14:33'),
(182, 69, '13.jpg', '2021-02-18 08:13:29'),
(183, 69, '25.jpg', '2021-02-18 08:13:32'),
(184, 69, '31.jpg', '2021-02-18 08:13:33'),
(185, 70, '14.jpg', '2021-02-18 08:16:45'),
(186, 70, '26.jpg', '2021-02-18 08:16:45'),
(187, 71, '19.jpg', '2021-02-18 08:18:55'),
(188, 71, '211.jpg', '2021-02-18 08:18:55'),
(189, 72, '113.jpg', '2021-02-18 08:20:39'),
(190, 72, '215.jpg', '2021-02-18 08:20:39'),
(191, 72, '32.jpg', '2021-02-18 08:20:39'),
(192, 73, '116.jpg', '2021-02-18 08:22:27'),
(193, 73, '218.jpg', '2021-02-18 08:22:27'),
(194, 73, '37.jpg', '2021-02-18 08:22:29'),
(195, 74, '117.jpg', '2021-02-18 08:49:48'),
(196, 74, '219.jpg', '2021-02-18 08:49:50'),
(197, 74, '39.jpg', '2021-02-18 08:49:50'),
(198, 75, '118.jpg', '2021-02-18 08:54:25'),
(199, 75, '220.jpg', '2021-02-18 08:54:27'),
(200, 76, '119.jpg', '2021-02-18 08:56:18'),
(201, 76, '221.jpg', '2021-02-18 08:56:18'),
(202, 77, '19.jpeg', '2021-02-18 08:58:47'),
(203, 77, '222.jpg', '2021-02-18 08:58:47'),
(211, 81, '110.jpeg', '2021-03-12 07:09:40'),
(212, 81, '29.jpeg', '2021-03-12 07:09:40'),
(213, 81, '32.jpeg', '2021-03-12 07:09:41'),
(214, 81, '4.jpeg', '2021-03-12 07:09:41'),
(217, 82, '113.jpeg', '2021-03-12 12:21:39'),
(218, 82, '33.jpeg', '2021-03-12 12:21:39'),
(221, 84, '115.jpeg', '2021-04-05 07:11:38'),
(222, 84, '212.jpeg', '2021-04-05 07:11:38'),
(223, 85, '13.jpeg', '2021-04-14 13:41:35'),
(224, 85, '21.jpeg', '2021-04-14 13:41:35'),
(225, 85, '3.jpeg', '2021-04-14 13:41:35'),
(226, 86, '111.jpeg', '2021-04-23 08:44:59'),
(227, 86, '23.jpeg', '2021-04-23 08:44:59'),
(228, 86, '34.jpeg', '2021-04-23 08:44:59'),
(229, 86, '42.jpeg', '2021-04-23 08:44:59'),
(230, 87, '1111.jpeg', '2021-04-27 17:26:41'),
(231, 87, '1121.jpg', '2021-04-27 17:26:41'),
(232, 88, '211.jpeg', '2021-04-27 17:41:00'),
(233, 88, '2121.jpeg', '2021-04-27 17:41:00'),
(236, 90, '114.jpeg', '2021-04-30 07:44:42'),
(237, 90, '213.jpeg', '2021-04-30 07:44:42'),
(238, 90, '35.jpeg', '2021-04-30 07:44:42'),
(239, 91, '116.jpeg', '2021-05-05 08:21:54'),
(240, 91, '214.jpeg', '2021-05-05 08:21:54'),
(241, 92, '117.jpeg', '2021-05-19 05:47:01'),
(242, 92, '215.jpeg', '2021-05-19 05:47:01'),
(243, 92, '36.jpeg', '2021-05-19 05:47:01'),
(247, 94, '119.jpeg', '2021-05-19 06:11:04'),
(248, 94, '217.jpeg', '2021-05-19 06:11:04'),
(249, 94, '38.jpeg', '2021-05-19 06:11:04'),
(250, 95, '120.jpeg', '2021-05-19 06:21:45'),
(251, 95, '218.jpeg', '2021-05-19 06:21:45'),
(252, 95, '39.jpeg', '2021-05-19 06:21:45'),
(253, 96, '121.jpeg', '2021-05-19 06:31:01'),
(254, 96, '219.jpeg', '2021-05-19 06:31:01'),
(258, 98, '123.jpeg', '2021-05-19 06:48:54'),
(259, 98, '221.jpeg', '2021-05-19 06:48:54'),
(260, 98, '311.jpeg', '2021-05-19 06:48:54'),
(262, 100, '124.jpeg', '2021-06-03 05:12:07'),
(263, 100, '222.jpeg', '2021-06-03 05:12:07'),
(264, 100, '312.jpeg', '2021-06-03 05:12:07'),
(265, 101, '1111.png', '2021-06-29 16:38:16'),
(266, 101, '2.png', '2021-06-29 16:38:16'),
(267, 101, '3.png', '2021-06-29 16:38:16'),
(268, 101, '4.png', '2021-06-29 16:38:17'),
(269, 102, '125.jpeg', '2021-07-09 12:25:12'),
(270, 102, '223.jpeg', '2021-07-09 12:25:12'),
(271, 102, '313.jpeg', '2021-07-09 12:25:12'),
(272, 102, '43.jpeg', '2021-07-09 12:25:12'),
(273, 103, '126.jpeg', '2021-07-16 07:23:51'),
(274, 103, '224.jpeg', '2021-07-16 07:23:51'),
(275, 103, '314.jpeg', '2021-07-16 07:23:51'),
(276, 104, '127.jpeg', '2021-07-16 07:32:50'),
(277, 104, '225.jpeg', '2021-07-16 07:32:50'),
(278, 105, '128.jpeg', '2021-07-16 07:46:07'),
(279, 105, '226.jpeg', '2021-07-16 07:46:07'),
(280, 106, '129.jpeg', '2021-08-06 06:55:03'),
(281, 106, '227.jpeg', '2021-08-06 06:55:03'),
(282, 107, '130.jpeg', '2021-08-10 09:07:54'),
(283, 107, '228.jpeg', '2021-08-10 09:07:54'),
(284, 101, '1.png', '2021-08-13 07:15:03'),
(285, 108, '131.jpeg', '2021-08-27 13:35:19'),
(286, 108, '229.jpeg', '2021-08-27 13:35:19'),
(287, 108, '315.jpeg', '2021-08-27 13:35:19'),
(288, 108, '41.jpeg', '2021-08-27 13:35:19'),
(289, 108, '5.jpeg', '2021-08-27 13:35:19'),
(290, 109, '132.jpeg', '2021-09-02 13:02:26'),
(291, 109, '230.jpeg', '2021-09-02 13:02:26'),
(292, 110, '133.jpeg', '2021-09-18 07:21:01'),
(293, 110, '231.jpeg', '2021-09-18 07:21:01'),
(294, 110, '316.jpeg', '2021-09-18 07:21:01'),
(295, 111, '134.jpeg', '2021-09-20 13:02:07'),
(296, 111, '232.jpeg', '2021-09-20 13:02:07'),
(297, 111, '317.jpeg', '2021-09-20 13:02:07'),
(298, 112, '135.jpeg', '2021-09-25 08:33:12'),
(299, 112, '233.jpeg', '2021-09-25 08:33:12'),
(300, 113, '136.jpeg', '2021-09-30 14:30:57'),
(301, 113, '234.jpeg', '2021-09-30 14:30:57'),
(302, 114, '137.jpeg', '2021-10-09 05:58:44'),
(303, 114, '235.jpeg', '2021-10-09 05:58:44'),
(304, 114, '318.jpeg', '2021-10-09 05:58:44'),
(305, 114, '44.jpeg', '2021-10-09 05:58:44'),
(306, 114, '51.jpeg', '2021-10-09 05:58:44'),
(307, 115, '138.jpeg', '2021-10-09 06:16:54'),
(308, 115, '236.jpeg', '2021-10-09 06:16:54'),
(309, 115, '319.jpeg', '2021-10-09 06:16:54'),
(310, 116, '139.jpeg', '2021-10-23 11:15:11'),
(311, 116, '237.jpeg', '2021-10-23 11:15:11'),
(312, 116, '320.jpeg', '2021-10-23 11:15:11'),
(313, 116, '45.jpeg', '2021-10-23 11:15:11'),
(314, 117, '140.jpeg', '2021-10-29 11:52:53'),
(315, 117, '238.jpeg', '2021-10-29 11:52:54'),
(316, 117, '321.jpeg', '2021-10-29 11:52:54'),
(317, 118, '141.jpeg', '2021-10-29 12:23:29'),
(318, 118, '239.jpeg', '2021-10-29 12:23:29'),
(319, 118, '322.jpeg', '2021-10-29 12:23:29'),
(320, 118, '46.jpeg', '2021-10-29 12:23:29'),
(321, 118, '52.jpeg', '2021-10-29 12:23:29'),
(322, 118, '6.jpeg', '2021-10-29 12:23:29'),
(323, 118, '7.jpeg', '2021-10-29 12:23:29'),
(324, 118, '8.jpeg', '2021-10-29 12:23:29'),
(325, 118, '9.jpeg', '2021-10-29 12:23:29'),
(326, 118, '10.jpeg', '2021-10-29 12:23:29'),
(327, 119, '142.jpeg', '2021-10-29 13:06:59'),
(328, 119, '240.jpeg', '2021-10-29 13:06:59'),
(329, 119, '323.jpeg', '2021-10-29 13:06:59'),
(330, 119, '47.jpeg', '2021-10-29 13:06:59'),
(331, 119, '53.jpeg', '2021-10-29 13:06:59'),
(332, 119, '61.jpeg', '2021-10-29 13:06:59'),
(333, 120, '1180.jpeg', '2021-11-15 06:05:05'),
(334, 120, '216.jpeg', '2021-11-15 06:05:05'),
(335, 121, '122.jpeg', '2021-11-15 06:32:47'),
(336, 121, '220.jpeg', '2021-11-15 06:32:47'),
(337, 122, '143.jpeg', '2021-11-23 06:56:14'),
(338, 122, '241.jpeg', '2021-11-23 06:56:14'),
(339, 122, '37.jpeg', '2021-11-23 06:56:14'),
(340, 123, '144.jpeg', '2021-12-03 12:14:19'),
(341, 123, '242.jpeg', '2021-12-03 12:14:19'),
(342, 123, '310.jpeg', '2021-12-03 12:14:19'),
(345, 125, '145.jpeg', '2021-12-27 11:42:19'),
(346, 125, '243.jpeg', '2021-12-27 11:42:19'),
(347, 126, '146.jpeg', '2021-12-27 11:51:25'),
(348, 126, '244.jpeg', '2021-12-27 11:51:25'),
(349, 127, '147.jpeg', '2022-01-22 07:22:45'),
(350, 127, '245.jpeg', '2022-01-22 07:22:45'),
(351, 127, '324.jpeg', '2022-01-22 07:22:45'),
(352, 128, '148.jpeg', '2022-01-22 07:31:36'),
(353, 128, '246.jpeg', '2022-01-22 07:31:36'),
(354, 128, '325.jpeg', '2022-01-22 07:31:36'),
(358, 130, '150.jpeg', '2022-04-11 09:22:04'),
(359, 130, '248.jpeg', '2022-04-11 09:22:05'),
(398, 135, '15.jpg', '2022-05-23 11:35:54'),
(399, 135, '213.jpg', '2022-05-23 11:35:54'),
(400, 135, '36.jpg', '2022-05-23 11:35:55'),
(401, 135, '43.jpg', '2022-05-23 11:35:55'),
(402, 135, '51.jpg', '2022-05-23 11:35:55'),
(403, 135, '6.jpg', '2022-05-23 11:35:55'),
(404, 135, '72.jpg', '2022-05-23 11:35:55'),
(405, 135, '8.jpg', '2022-05-23 11:35:56'),
(406, 135, '9.jpg', '2022-05-23 11:35:56'),
(407, 135, '10.jpg', '2022-05-23 11:35:57'),
(408, 135, '111.jpg', '2022-05-23 11:35:57'),
(409, 135, '121.jpg', '2022-05-23 11:35:57'),
(410, 133, '112.jpg', '2022-05-23 11:42:09'),
(411, 133, '214.jpg', '2022-05-23 11:42:09'),
(412, 133, '38.jpg', '2022-05-23 11:42:10'),
(413, 133, '44.jpg', '2022-05-23 11:42:10'),
(414, 133, '53.jpg', '2022-05-23 11:42:10'),
(415, 133, '61.jpg', '2022-05-23 11:42:10'),
(416, 133, '73.jpg', '2022-05-23 11:42:11'),
(417, 133, '81.jpg', '2022-05-23 11:42:11'),
(418, 133, '91.jpg', '2022-05-23 11:42:12'),
(419, 134, '115.jpg', '2022-05-23 11:46:03'),
(420, 134, '217.jpg', '2022-05-23 11:46:03'),
(421, 134, '310.jpg', '2022-05-23 11:46:03'),
(422, 134, '45.jpg', '2022-05-23 11:46:04'),
(423, 134, '54.jpg', '2022-05-23 11:46:04'),
(424, 134, '6.gif', '2022-05-23 11:46:05'),
(425, 134, '74.jpg', '2022-05-23 11:46:05'),
(426, 134, '82.jpg', '2022-05-23 11:46:05'),
(427, 134, '92.jpg', '2022-05-23 11:46:05'),
(428, 134, '103.jpg', '2022-05-23 11:46:05'),
(429, 134, '1110.jpg', '2022-05-23 11:46:05'),
(430, 129, '149.jpeg', '2022-05-23 11:46:22'),
(431, 129, '247.jpeg', '2022-05-23 11:46:22'),
(432, 129, '326.jpeg', '2022-05-23 11:46:22'),
(433, 131, '120.jpg', '2022-05-23 11:51:47'),
(434, 131, '223.jpg', '2022-05-23 11:51:47'),
(435, 131, '311.jpg', '2022-05-23 11:51:47'),
(436, 132, '122.jpg', '2022-05-23 11:54:04'),
(437, 132, '224.jpg', '2022-05-23 11:54:04'),
(438, 132, '312.jpg', '2022-05-23 11:54:04'),
(439, 136, '151.jpeg', '2022-05-31 09:10:05'),
(440, 136, '248.jpeg', '2022-05-31 09:10:05'),
(443, 137, '123.jpg\r\n', '2022-09-16 09:14:58'),
(444, 137, '249.jpeg', '2022-09-16 09:14:58');

-- --------------------------------------------------------

--
-- Table structure for table `sales_link_to_customer`
--

CREATE TABLE `sales_link_to_customer` (
  `id` int(11) NOT NULL,
  `customer_name` varchar(255) NOT NULL,
  `customer_email` varchar(100) NOT NULL,
  `sent_by` int(11) NOT NULL,
  `sent_on` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sales_link_to_customer`
--

INSERT INTO `sales_link_to_customer` (`id`, `customer_name`, `customer_email`, `sent_by`, `sent_on`) VALUES
(1, 'ccc', 'c@gmail.com', 21, '18-03-2022'),
(2, 'ccc', 'c@gmail.com', 21, '18-03-2022'),
(3, 'cc2', 'c@gmail.com', 56, '18-03-2022'),
(4, 'chandu', 'chandhu418@gmail.com', 56, '18-03-2022'),
(5, 'chandu', 'chandhu418@gmail.com', 56, '18-03-2022');

-- --------------------------------------------------------

--
-- Table structure for table `selfie_pic`
--

CREATE TABLE `selfie_pic` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `pic` text NOT NULL,
  `project_name` varchar(255) NOT NULL,
  `flat_number` varchar(100) NOT NULL,
  `wish_to_buy_a_property` varchar(255) NOT NULL,
  `area` varchar(100) NOT NULL,
  `flat` varchar(100) NOT NULL,
  `budget` varchar(100) NOT NULL,
  `added_on` varchar(20) NOT NULL,
  `customer_type` varchar(20) NOT NULL,
  `contest` varchar(55) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `selfie_pic`
--

INSERT INTO `selfie_pic` (`id`, `name`, `mobile`, `email`, `pic`, `project_name`, `flat_number`, `wish_to_buy_a_property`, `area`, `flat`, `budget`, `added_on`, `customer_type`, `contest`) VALUES
(5, 'Dumpala Dharma Rao', '6300263284', 'ddrao1994@gmail.com', 'IMG-20180404-WA0006.jpg', '-', '-', 'I need 1900 sft 2 nd or 3rd floor preferable', '1900', '3BHK', 'Above 1 cr', '11-10-2021', 'New', 'dasara'),
(6, 'Suri Babu .N', '9550296840', 'ssdd21335@gmail.com', 'IMG20210214095318.jpg', 'Pedagantyada', '-', '-', '-', '-', '-', '11-10-2021', 'Existing', 'dasara'),
(7, 'karunakar', '7337023904', 'karunabocha@gmail.com', '', '-', '-', 'house', 'kacharapalm', '2BHK', 'Below 20 lakhs', '11-10-2021', 'New', 'dasara'),
(8, 'Swathi', '7731046470', 'swathirs143@gmail.com', '16339365162868879685185455008880.jpg', '-', '-', 'Madhavadhara', '-', '2BHK', '30 to 50 lakhs', '11-10-2021', 'New', 'dasara'),
(9, 'Naresh kottakota', '8297281686', 'nareshkumar1686@gmail.com', '16339359028814218658059595930752.jpg', '-', '-', '25lakh', 'Near gajuwaka', '2BHK', '20 to 30 lakhs', '11-10-2021', 'New', 'dasara'),
(10, 'Madhuri', '8328015152', 'liki.madhuri@gmail.com', '', '-', '-', 'Yes', 'Ayodhyanagar', '2BHK', '30 to 50 lakhs', '11-10-2021', 'New', 'dasara'),
(11, 'Naveen', '9160964523', 'Polimatinaveenprasad2015@gmail.com', '5738365C-4735-4881-85EB-4B7497986009.jpeg', '-', '-', 'Yes', 'Yendada', '3BHK', 'Upto 1 cr', '11-10-2021', 'New', 'dasara'),
(12, 'Rellisaritha ', '7989666058', 'Saritharelli@gmail.com ', '20210322_135202.jpg', '-', '-', '-', 'Scindia new Colony ', '2BHK', '30 to 50 lakhs', '11-10-2021', 'New', 'dasara'),
(13, 'D V CHANDRA SEKHAR', '9849523659', 'sekharchandrateja8@gmail.com', '', 'ARSHITHA PARADISE', '202', '-', '-', '-', '-', '12-10-2021', 'Existing', 'dasara'),
(14, 'Vijay M V KUPPILI', '9666140080', 'mohan.kuppili@gmail.com', 'IMG_20210915_060104.jpg', '-', '-', 'Not now', 'Tagarapuvalasa', '2BHK', '30 to 50 lakhs', '13-10-2021', 'New', 'dasara'),
(15, 'Vijay M V Kuppili', '9666140080', 'mohan.kuppili@gmail.com', 'photo.PNG', '-', '-', 'Not Now', 'Tagarapuvalasa', '2BHK', '30 to 50 lakhs', '13-10-2021', 'New', 'dasara'),
(16, 'Moningi Srinivas rao', '7702841080', 'srinumoningi27@gmail.com', '', '-', '-', '-', 'Vuda colony', '2BHK', '30 to 50 lakhs', '13-10-2021', 'New', 'dasara'),
(17, 'Thammineni Ravikumar', '8317621635', 'ravikumarthammineni123@gmail.com', 'Screenshot_2021-09-28-08-28-39-65_1c337646f29875672b5a61192b9010f9.jpg', '-', '-', 'Yes', 'Madhurawada', '2BHK', 'Upto 1 cr', '13-10-2021', 'New', 'dasara'),
(18, 'T Srinivas Reddy', '8096203237', 'tangiralasrinivasreddy@gmail.com', '20210320_113824.jpg', '-', '-', 'Yes', 'Tadepalli', '3BHK', 'Upto 1 cr', '13-10-2021', 'New', 'dasara'),
(19, 'Kovela Harika', '9618738824', 'Kovelaharika88@gmail.com', 'IMG-20211013-WA0006.jpg', '-', '-', 'Yes', 'Vijaywada', '2BHK', '30 to 50 lakhs', '13-10-2021', 'New', 'dasara'),
(20, 'Sravya Naidu Gopisetti', '7386293069', 'venkatalakshmigopisetti62@gmail.com', 'Snapchat-520241456.jpg', '-', '-', 'Thinking', 'Vijayawada', '2BHK', 'Below 20 lakhs', '13-10-2021', 'New', 'dasara'),
(21, 'Maneesha Sammeta', '8096489698', 'maneeshasammeta544@gmail.com', 'IMG_20211013_112733.jpg', '-', '-', 'Flat', 'RAMALINGESWARA NAGAR', '2BHK', 'Below 20 lakhs', '13-10-2021', 'New', 'dasara'),
(22, 'Giri.lakshmi devi', '9014979698', 'girilakshmi1928@gmail.com', 'Mahesh_(18).jpg', '-', '-', 'Yes', 'Poranki', '3BHK', '20 to 30 lakhs', '13-10-2021', 'New', 'dasara'),
(23, 'Tejaswi ketharaju', '9553156692', 'tejaprabhs666@gmail.com', '', '-', '-', '-', 'Gunadala', '-', '-', '13-10-2021', 'New', 'dasara'),
(24, 'Sowmya', '9441520639', 'venkatalakshmigopisetti62@gmail.com', 'IMG_6617-01_(1).jpeg', '-', '-', 'Thinking', 'Vijayawada', '2BHK', 'Below 20 lakhs', '13-10-2021', 'New', 'dasara'),
(25, 'M Krishna mohanarao', '9440578234', '9440578234mkm@gmail.com', '16341069186093461579962599698084.jpg', '-', '-', 'Appartment', 'PM PALEAM', '3BHK', '30 to 50 lakhs', '13-10-2021', 'New', 'dasara'),
(26, 'Lakshmi K', '+918886368638', 'HARILINKU143@GMAIL.COM', 'IMG_20170312_092118.jpg', '-', '-', '-', '-', '-', '-', '13-10-2021', 'New', 'dasara'),
(27, 'Lakshmi K', '+918886368638', 'HARILINKU143@GMAIL.COM', 'IMG_20170312_0921181.jpg', '-', '-', '-', '-', '-', '-', '13-10-2021', 'New', 'dasara'),
(28, 'Karimullasha Sayed', '09030560898', 'shahsk85@gmail.com', '16341072113865073130671516512719.jpg', '-', '-', '-', '-', '-', '-', '13-10-2021', 'New', 'dasara'),
(29, 'Roja', '09885233428', 'jonnalajaddaroja@gmail.com', '', '-', '-', '-', '5 km around vijayawada', '3BHK', '30 to 50 lakhs', '13-10-2021', 'New', 'dasara'),
(30, 'Rathna kumari.Dasari', '8500000472', 'dasariraja786@gmail.com', 'Remini20211013122813563.jpg', '-', '-', '-', 'Vijayawada', '3BHK', '30 to 50 lakhs', '13-10-2021', 'New', 'dasara'),
(31, 'A. V. SUBBARAO ', '9441582618', 'subbaraoaraveeti@gmail.com', '1634110283814750460802990193970.jpg', '-', '-', 'APPARTMNT ', '1700-2000 above ', '3BHK', '30 to 50 lakhs', '13-10-2021', 'New', 'dasara'),
(32, 'Rathna kumari.Dasari', '8500000472', 'dasariraja786@gmail.com', 'Remini202110131228135631.jpg', '-', '-', '-', 'Vijayawada', '3BHK', '30 to 50 lakhs', '13-10-2021', 'New', 'dasara'),
(33, 'Syamala', '9491373691', 'addankisyamala590@gmail.com', '', '-', '-', '-', '-', '-', '-', '13-10-2021', 'Existing', 'dasara'),
(34, 'Nani Pattnaik', '7995498898', 'Nanicivil128@gmail.com', '', '-', '-', 'Yes', 'Gajuwaka', '2BHK', '20 to 30 lakhs', '13-10-2021', 'New', 'dasara'),
(35, 'Ramesh kumar bhavani', '09642888119', 'rameshbhavani86@gmail.com', '', '-', '-', 'Yes', 'Gajuwaka', '3BHK', 'Above 1 cr', '13-10-2021', 'New', 'dasara'),
(36, 'Ramesh kumar bhavani', '09642888119', 'rameshbhavani86@gmail.com', '', '-', '-', 'Yes', 'Gajuwaka', '3BHK', 'Above 1 cr', '13-10-2021', 'New', 'dasara'),
(37, 'Madhuri', '8328015152', 'liki.madhuri@gmail.com', 'Screenshot_2021-10-13-12-10-41-31_6012fa4d4ddec268fc5c7112cbb265e7.jpg', '-', '-', 'Yes', 'Ayodhyanagar', '2BHK', '30 to 50 lakhs', '13-10-2021', 'New', 'dasara'),
(38, 'B SYAMALA RAO', '9866927878', 'borrasyamala.rao76@gmail.com', '', '-', '-', 'Yes', '-', '-', '-', '13-10-2021', 'New', 'dasara'),
(39, 'Hemanth ', '9666896359 ', 'Hemantharyan2001@gmail.com ', '', '-', '-', 'Yes', 'Vizag ', '3BHK', '20 to 30 lakhs', '13-10-2021', 'New', 'dasara'),
(40, 'Lalitha', '9441647290', 'lalithakameswari22@gmail.com', 'IMG20201223064313.jpg', 'Gayatri Towers', 'First floor', '-', '-', '-', '-', '13-10-2021', 'Existing', 'dasara'),
(41, 'Manne satyanarayana', '9885970487', 'mvvschowdary17760@gmail.com', '', '-', '-', 'Individual house', 'Kurmannapalem', '3BHK', '30 to 50 lakhs', '13-10-2021', 'New', 'dasara'),
(42, 'Naga sravanthi', '8464054085', 'Sravanthikuppala1226@gmail.com', '', '-', '-', 'Yes', 'Vijayawada', '2BHK', '20 to 30 lakhs', '13-10-2021', 'New', 'dasara'),
(43, '09182351570', '9182351570', 'ippalavalasaramesh7@gmail.com', 'IMG20211013150131.jpg', '-', '-', 'Home', 'Visakhapatnam', '2BHK', 'Upto 1 cr', '13-10-2021', 'New', 'dasara'),
(44, 'Chanti', '8464073877', 'Chanti@gmail.com', 'Screenshot_20211013-162755.png', '-', '-', 'Just for fun', 'Gandhi bomma', '2BHK', 'Below 20 lakhs', '13-10-2021', 'New', 'dasara'),
(45, 'Ramesh kumar bhavani', '09642888119', 'rameshbhavani86@gmail.com', '16341231453091253105174647470692.jpg', '-', '-', 'Yes', 'Gajuwaka', '3BHK', 'Above 1 cr', '13-10-2021', 'New', 'dasara'),
(46, 'Patnala .shanthi kumari', '9381556115', '8143174490', '20210821_014811.jpg', '-', '-', 'Yes', 'In isukathota', '2BHK', 'Below 20 lakhs', '13-10-2021', 'New', 'dasara'),
(47, 'Naga siva', '7997593763', 'Nagashiva066@.com', 'IMG-20211005-WA0004_1.jpg', '-', '-', 'S', 'Nellouru', '3BHK', 'Above 1 cr', '13-10-2021', 'New', 'dasara'),
(48, 'NAGA LOCHAN ', '8179230240', 'Sravanthikuppala1228@gmail.com', 'cfdc67f2-c424-4eb6-8ed2-36e25d474021.jpg', '-', '-', 'Yes', 'Vijayawada', '3BHK', '20 to 30 lakhs', '13-10-2021', 'New', 'dasara'),
(49, 'CH Srikar', '8499913500', 'srikarch81@gmail.com', 'IMG-20210605-WA0003.jpg', '-', '-', 'Wish to buy a property', 'Gajuwaka surroundings', '2BHK', '20 to 30 lakhs', '13-10-2021', 'New', 'dasara'),
(50, 'Pilli Kishore Kumar', '9493857253', 'pkk05031991@gmail.com', 'IMG_20201117_102813.jpg', '-', '-', 'No', 'No', '2BHK', 'Below 20 lakhs', '13-10-2021', 'New', 'dasara'),
(51, 'P Kishore Kumar', '9493857253', 'pkk05031991@gmail.com', 'IMG_20201117_1028131.jpg', '-', '-', 'No', 'No', '2BHK', 'Below 20 lakhs', '13-10-2021', 'New', 'dasara'),
(52, 'Ch. Govinda', '9701609433', 'govindahasini@gmail.com', 'IMG-20211013-WA0013.jpg', 'Sri balaji enclave', '402', '-', '-', '-', '-', '13-10-2021', 'Existing', 'dasara'),
(53, 'Viswa Doddi', '9959987477', 'viswa.jtd@gmail.com', 'Viswa_Profile_Pic.jpg', '-', '-', '3BHK Flat', 'Muralinagar or Marripalem', '3BHK', 'Upto 1 cr', '13-10-2021', 'New', 'dasara'),
(54, 'Santhosh Kumar', '8296560785', 'santhoshsanamallu8685@gmail.com', '', 'Gowri apparent', '301', '-', '-', '-', '-', '13-10-2021', 'Existing', 'dasara'),
(55, 'Santhosh Kumar', '8296560785', 'santhoshsanamallu8685@gmail.com', '', 'Gowri appartment', '301', '-', '-', '-', '-', '13-10-2021', 'Existing', 'dasara'),
(56, 'Sailu', '6304752276', 'msailaja96@gmail.com', 'IMG20211011094616.jpg', '-', '-', 'Yes', 'Tadepalli', '2BHK', '30 to 50 lakhs', '13-10-2021', 'New', 'dasara'),
(57, 'Ramyapilla', '8186855243', 'ramyamohan.pilla@gmail.com', '1634131930727637771411252661152.jpg', 'Gannavaram', 'R-186', '-', '-', '-', '-', '13-10-2021', 'Existing', 'dasara'),
(58, 'Venkatesh', '8328049382', 'venkyrocks9909@gmail.com', '089382B4-2CA9-43E1-9A17-BDFFD8F8C7BC.jpeg', '-', '-', 'Tadepalli', 'Hp petrol bunk', '2BHK', '30 to 50 lakhs', '13-10-2021', 'New', 'dasara'),
(59, 'Sireesha', '+91 95819 49595', 'sireeshakambhampati30415@gmail.com', 'C46EC98C-3E2E-4B09-A1E1-9D2461017237.jpeg', '-', '-', 'Koganti', 'Poranki', '3BHK', '30 to 50 lakhs', '13-10-2021', 'New', 'dasara'),
(60, 'Bharani', '+91 98498 33766', 'bharani.dbk@gmail.com', '72923552-C62E-49ED-BA0B-3F0A4BC25D64.jpeg', '-', '-', 'Satyanaranayapuram', 'Satyanarayanapuram', '2BHK', '20 to 30 lakhs', '13-10-2021', 'New', 'dasara'),
(61, 'Nagaraju', '+91 70135 71955', 'nagaraju.kommati1006@gmail.com', 'E4D27690-9E42-411D-A42B-40F6F3CAA681.jpeg', 'Samrudhi', '502', '-', '-', '-', '-', '13-10-2021', 'Existing', 'dasara'),
(62, 'Syamala', '7794018258', 'Syamalamikkli@gmail.com', 'IMG-20210616-WA0029.jpg', '-', '-', 'Koganti\'s project', 'Poranki', '2BHK', '30 to 50 lakhs', '13-10-2021', 'New', 'dasara'),
(63, 'Ch kiran', '8686490808', 'chennukiran808@yahoo.com', '2021_04_19_17_26_IMG_0836.JPEG', '-', '-', 'Yes', '1500', '3BHK', '30 to 50 lakhs', '13-10-2021', 'New', 'dasara'),
(64, 'LeelaMohanReddy', '9618969149', 'yerkareddy.leelamohan@yahoo.com', '16341362890575533111819333549560.jpg', '-', '-', '-', '-', '-', '-', '13-10-2021', 'New', 'dasara'),
(65, 'Narayan Rao A', '9160280530', 'narayan336@hotmail.com', 'IMG20190519174426.jpg', '-', '-', 'Yes', 'Gajuwaka', '2BHK', '30 to 50 lakhs', '13-10-2021', 'New', 'dasara'),
(66, 'Syamala', '9491373691', 'addankisyamala590@gmail.com', '', '-', '-', '-', '-', '-', '-', '14-10-2021', 'Existing', 'dasara'),
(67, 'D.kiran kumar', '9010690788', 'kirankumard.kumar07@gmail.com', 'IMG_20211008_103711339.jpg', '-', '-', 'Yes', 'Vizag', '2BHK', '20 to 30 lakhs', '14-10-2021', 'New', 'dasara'),
(68, 'Kondalarao', '9392222116', 'konda1980@yahoo.com', '1634181830599_.jpg', '-', '-', 'Yes', 'Any', '2BHK', '20 to 30 lakhs', '14-10-2021', 'New', 'dasara'),
(69, 'Roja', '9182668657', 'charandino6@gmail.com', '', '-', '-', '-', 'In and around vijayawada', '3BHK', '30 to 50 lakhs', '14-10-2021', 'New', 'dasara'),
(70, 'Sarath', '8142428171', 'sarathchandra4512@gmail.com', 'IMG_20211014_104237.jpg', '-', '-', 'Yes', 'Vijayawada', '2BHK', 'Below 20 lakhs', '14-10-2021', 'New', 'dasara'),
(71, 'K.yeswanth dath', '8465914552', 'ketharaju.yeswanthdath@gmail.com', '', '-', '-', 'Thinking', 'Vijayawada', '2BHK', 'Below 20 lakhs', '14-10-2021', 'New', 'dasara'),
(72, 'Sarath', '8142428171', 'sarathchandra4512@gmail.com', 'IMG_20211014_1042371.jpg', '-', '-', 'Yes', 'Vijayawada', '2BHK', 'Below 20 lakhs', '14-10-2021', 'New', 'dasara'),
(73, 'Tejaswi ketharaju', '9553156692', 'tejaprabhas666@gmail.com', 'received_4699209083441701.jpeg', '-', '-', 'Thinking', 'Vijayawada', '2BHK', 'Below 20 lakhs', '14-10-2021', 'New', 'dasara'),
(74, 'Deepa', '9652846706', 'deepakumari1931@gmail.com', '16341880638988323208093303832782.jpg', '-', '-', 'Thinking', 'Vijayawada', '2BHK', 'Below 20 lakhs', '14-10-2021', 'New', 'dasara'),
(75, 'Tejaswi ketharaju', '9553156692', 'tejaprabhas666@gmail.com', 'received_46992090834417011.jpeg', '-', '-', 'Thinking', '-', '2BHK', 'Below 20 lakhs', '14-10-2021', 'New', 'dasara'),
(76, 'Deepa', '9652846706', 'deepakumari1931@gmail.com', '20210819_122124.jpg', '-', '-', 'Thinking', 'Vijayawada', '2BHK', 'Below 20 lakhs', '14-10-2021', 'New', 'dasara'),
(77, 'Tejaswi ketharaju', '9553156692', 'tejaprabhas666@gmail.com', 'received_46992090834417012.jpeg', '-', '-', 'Thinking', 'Vijayawada', '2BHK', 'Below 20 lakhs', '14-10-2021', 'New', 'dasara'),
(78, 'JADHAV MAHESH', '9391973707', 'maheshjadhav9666307@gmail.com', 'IMG-20210524-WA0015.jpg', '-', '-', 'Wish to buy a property', 'Vijayawada', '2BHK', 'Below 20 lakhs', '14-10-2021', 'New', 'dasara'),
(79, 'Kalyani', '9705557883', 'Kalyaniambatipudi@gmail.com', '', '-', '-', 'Amaravaticone', 'Tadepalle', '-', '-', '14-10-2021', 'New', 'dasara'),
(80, 'Khasimbe', '6309070523', 'jakirirfan2@gmail.com', '27FD95AA-069F-483F-A7A5-8AE72CDD8EBC.jpeg', '-', '-', 'Thinking ', 'Vizag', '2BHK', '20 to 30 lakhs', '14-10-2021', 'New', 'dasara'),
(81, 'Shabana', '9494315129', 'jakirirfan2@gmail.com', '63BAA161-9968-4208-9629-F9F9DDD867FC.jpeg', '-', '-', 'Thinking ', 'Vijayawada ', '3BHK', '30 to 50 lakhs', '14-10-2021', 'New', 'dasara'),
(82, 'Vennela', '8985244065', 'usalavennela@gmail.com', '16341968993403680736427052272166.jpg', '-', '-', 'Buy a property', 'Kondayapalem', '2BHK', '30 to 50 lakhs', '14-10-2021', 'New', 'dasara'),
(83, 'Vennela', '8985244065', 'usalavennela@gmail.com', '16341977516472428960625869586832.jpg', '-', '-', 'Buy a property', 'Kondayapalem', '2BHK', '30 to 50 lakhs', '14-10-2021', 'New', 'dasara'),
(84, 'Janaki Rani', '09676525282', 'Janakirani.yakkala@gmail.com', 'IMG_20211014_132643.jpg', '-', '-', 'yes', 'any', '2BHK', 'Below 20 lakhs', '14-10-2021', 'New', 'dasara'),
(85, 'Janaki Rani', '09676525282', 'Janakirani.yakkala@gmail.com', 'IMG_20211014_1326431.jpg', '-', '-', 'yes', 'any', '2BHK', 'Below 20 lakhs', '14-10-2021', 'New', 'dasara'),
(86, 'Jayalakshmi Rangu', '8333050589', 'lakshmirangu1998@gmail.com', '20211014_131754.jpg', '-', '-', 'Vijayawada ', 'Tadepalli', '2BHK', '20 to 30 lakhs', '14-10-2021', 'New', 'dasara'),
(87, 'Lalitha', '6305090931', 'lalithachinni14@gmail.com', 'BeautyPlus_20210115133323493_save.jpg', '-', '-', '-', '-', '-', '-', '14-10-2021', 'New', 'dasara'),
(88, 'Priya Sagar', '09966942817', 'priyasagar0025@gmail.com', 'IMG_20210126_110728.jpg', '-', '-', '-', '-', '-', '-', '14-10-2021', 'New', 'dasara'),
(89, 'Karri Sita', '09848639102', 'nageswararao.karri@gmail.com', '20211014_144357288.jpg', 'Yellamachili Jeights', '406', '-', '-', '-', '-', '14-10-2021', 'Existing', 'dasara'),
(90, 'Anu mary', '8121784779', 'Anumary18@gmail.com', 'IMG-20211014-WA0045.jpg', '-', '-', 'Amaravaticone', 'Tadepalle', '2BHK', '20 to 30 lakhs', '14-10-2021', 'New', 'dasara'),
(91, 'Kalyani', '9705557883', 'Kalyaniambatipudi@gmail.com', 'IMG-20210510-WA0049.jpg', '-', '-', 'Amaravaticone', 'Tadepalle', '2BHK', '20 to 30 lakhs', '14-10-2021', 'New', 'dasara'),
(92, 'Syamala', '8790215099', 'Balu.annambhotla@gmail.com', 'IMG-20211014-WA0049.jpg', '-', '-', 'Amaravaticone', 'Tadepalle', '3BHK', '30 to 50 lakhs', '14-10-2021', 'New', 'dasara'),
(93, 'Velangini .m', '6300372945', '6300fally@gmail.com', 'IMG-20211014-WA0046.jpg', '-', '-', 'Koganti\'s project', 'Poranki', '2BHK', '20 to 30 lakhs', '14-10-2021', 'New', 'dasara'),
(94, 'Gracy.dieon', '8977865086', 'Rinitadeona@gmail.com', 'IMG-20211014-WA0051.jpg', '-', '-', 'Koganti\'s project', 'Poranki', '2BHK', '20 to 30 lakhs', '14-10-2021', 'New', 'dasara'),
(95, 'Nagasaradaserma', '9959826503', 'Nagasaradaserma96@gmail.com', 'IMG-20211014-WA0053.jpg', '-', '-', 'Sathyanarayan puram', 'Muthyalam padu', '2BHK', '20 to 30 lakhs', '14-10-2021', 'New', 'dasara'),
(96, 'Gracy.dieon', '8977865086', 'Rinitadeona@gmail.com', 'IMG-20211014-WA00511.jpg', '-', '-', 'Koganti\'s project', 'Poranki', '2BHK', '20 to 30 lakhs', '14-10-2021', 'New', 'dasara'),
(97, 'K Arunavathi', '9290908896', 'arunavathikolli@gmail.com', '163420924463369767437954632434.jpg', '-', '-', 'Yes', 'Near carshed', '3BHK', '30 to 50 lakhs', '14-10-2021', 'New', 'dasara'),
(98, 'Suresh Sridharala', '9885650456', 'sridharalasuresh@gmail.com', 'Screenshot_2021-10-14-23-39-19-547_com_whatsapp.jpg', 'Bhagavan hill view', '302', '-', '-', '-', '-', '14-10-2021', 'Existing', 'dasara'),
(100, 'D Pavan kumar', '8886042229', 'duvvuri6@gmail.com', 'D83294B6-E9E3-48E3-9A94-25039D716B2C.jpeg', 'Gayatri enclave ', '201', '-', '-', '-', '-', '28-10-2021', 'Existing', 'diwali'),
(101, 'Nakarapu Suribabu', '9550296840', 'ssdd21335@gmail.com', 'IMG20210729071539.jpg', 'Pedagantyada (Vizag)', '-', '-', '-', '-', '-', '28-10-2021', 'Existing', 'diwali'),
(103, 'Nagendra babu', '7995498898', 'Nanicivil128@gmail.com', 'Screenshot_20210902_204818.jpg', '-', '-', 'Yes', 'Gajuwaka', '2BHK', '20 to 30 lakhs', '30-10-2021', 'New', 'diwali'),
(104, 'D.Srinivas Kumar ', '8331019046 ', 'srinu.dabbiru@gmail.com', 'FB_IMG_1635386605246.jpg', '-', '-', 'Wanted a flat in 6o lakhs budget @ kurmannapalem', '318/B/sector 9,Ukkunagaram, vsp_32', '3BHK', 'Upto 1 cr', '30-10-2021', 'New', 'diwali'),
(105, 'Madhavi Latha', '9177181856', 'gonthinimadhavi@gmail.com', '89B299F4-484F-45EE-B365-FF90D501089B.jpeg', '-', '-', '-', 'Gajuwaka ', '2BHK', '30 to 50 lakhs', '30-10-2021', 'New', 'diwali'),
(106, 'Kiran Dasari', '09848366501', 'kirandasari78@gmail.com', '', '-', '-', '-', 'Kurmannapalem', '3BHK', '-', '30-10-2021', 'New', 'diwali'),
(107, 'Alluri Naga jyoshitha', '8374919319', 'sri.aswini7@gmail.com', 'IMG_20211012_164028.jpg', '-', '-', 'Yes', 'Kurmannapalem', '2BHK', '20 to 30 lakhs', '30-10-2021', 'New', 'diwali'),
(108, 'Lavanyakiran', '07036781968', 'lavanyakirand@gmail.com', '', '-', '-', 'Wish to buy a property', 'Vizag', '2BHK', '30 to 50 lakhs', '30-10-2021', 'New', 'diwali'),
(109, 'Ramesh Kumar Bhavani', '9642888119', 'rameshbhavani86@gmail.com', '16355796378163990621963314948659.jpg', '-', '-', 'Yes', 'Gajuwaka', '3BHK', 'Above 1 cr', '30-10-2021', 'New', 'diwali'),
(110, 'N.SURESH ', '9490261927', 'Sureshrailway1@gmail.com', '16355808751455653275487260058530.jpg', '-', '-', 'Yes ', 'Gopalapatnam ', '2BHK', 'Below 20 lakhs', '30-10-2021', 'New', 'diwali'),
(111, 'Ch chinnarao', '9494670813', 'chinnabhanu1995@gmail.com', 'Screenshot_2020-07-04-08-05-47-535_com_whatsapp.png', '-', '-', '-', 'Gajuwaka', '2BHK', '20 to 30 lakhs', '30-10-2021', 'New', 'diwali'),
(112, 'Hariprasad kamireddi ', '9703688855', 'nsil.reddy@gmail.com', '40344649-2742-4094-AB8E-4FDAC2AFA509.jpeg', '-', '-', 'Flat ', 'Aganam pudi ', '2BHK', '20 to 30 lakhs', '30-10-2021', 'New', 'diwali'),
(113, 'Gangu Naidu', '7050638511', 'naidu.2121@gmail.com', 'IMG_20200920_154231.jpg', '-', '-', 'Yes', 'Aganampudi', '2BHK', '20 to 30 lakhs', '30-10-2021', 'New', 'diwali'),
(114, 'Shiva penke', '9959907902', 'sivabhavya 10@gmail. come', '16356041298615996721753428215566.jpg', '-', '-', 'Flot ', 'Chinamushidivada', '2BHK', '20 to 30 lakhs', '30-10-2021', 'New', 'diwali'),
(115, 'Jayakanth', '9603049305', 'Jaykanthjai@gmail.com', '16356495496075303822340588353837.jpg', 'Eswari homes', '-', '-', '-', '-', '-', '31-10-2021', 'Existing', 'diwali'),
(116, 'Dasari. Ramu', '9396842864', 'Ramu. 12.dasari@gmail.com', '', '-', '-', 'Plot/Flats', 'Madhurwada/kommadhi jn\"', '2BHK', '20 to 30 lakhs', '31-10-2021', 'New', 'diwali'),
(117, 'Bhargava naresh', '7569824391', 'n.bhargava14@gmail.com', '16356504861941419702361976262644.jpg', '-', '-', 'Individual house', 'Kurmannapalem', '2BHK', '30 to 50 lakhs', '31-10-2021', 'New', 'diwali'),
(118, 'Madhavi Latha', '9177181856', 'gonthinimadhavi@gmail.com', '', '-', '-', '-', 'Gajuwaka ', '2BHK', '30 to 50 lakhs', '31-10-2021', 'New', 'diwali'),
(119, 'Nagu yadav', '7382920180', 'naguyadavronagala@gmail.com', '16356885731182720721598827719232.jpg', 'Sundara Lakshmi Nrusimha Residency', '304', '-', '-', '-', '-', '31-10-2021', 'Existing', 'diwali'),
(120, 'Kranthi Kumari', '8247625024', 'kranthi.t353@gmail.com', '2412B2A4-09B6-4D3E-B7ED-C3F01FBFEDDD.jpeg', 'Flora Beau Fort', '301', '-', '-', '-', '-', '01-11-2021', 'Existing', 'diwali'),
(121, 'Prakash ', '7893705895', 'sjprakash411@gmail.com', '', '-', '-', '-', '-', '-', '-', '01-11-2021', 'New', 'diwali'),
(122, 'Sravya Naidu Gopisetti', '7386293069', 'venkatalakshmigopisetti62@gmail.com', 'Snapchat-435703076.jpg', '-', '-', 'Thinking', 'Vijayawada', '2BHK', 'Below 20 lakhs', '03-11-2021', 'New', 'diwali'),
(123, 'Sravya Naidu Gopisetti', '7386293069', 'venkatalakshmigopisetti62@gmail.com', '20211023_184859.jpg', '-', '-', 'Thinking', 'Vijayawada', '2BHK', 'Below 20 lakhs', '03-11-2021', 'New', 'diwali'),
(124, 'Naga sravanthi', '8464054085', 'Sravanthikuppala1226@gmail.com', '', '-', '-', 'Thinking', 'Vijayawada', '-', '-', '03-11-2021', 'New', 'diwali'),
(125, 'Keerthi', '8297252577', 'keerthip80@gmail.com', 'WhatsApp_Image_2021-09-13_at_6_50_55_AM.jpeg', '-', '-', 'thinking', 'vijayawada', '2BHK', 'Below 20 lakhs', '03-11-2021', 'New', 'diwali'),
(126, 'Naga sravanthi', '8464054085', 'Sravanthikuppala1226@gmail.com', '', '-', '-', 'Thinking', 'Vijayawada', '2BHK', 'Below 20 lakhs', '03-11-2021', 'New', 'diwali'),
(127, 'Naga sravanthi', '8464054085', 'Sravanthikuppala1226@gmail.com', '', '-', '-', 'Thinking', 'Vijayawada', '2BHK', 'Below 20 lakhs', '03-11-2021', 'New', 'diwali'),
(128, 'Sai krishna', '9347105423', 'Ksaikrishnafci@gmail com', 'IMG_20210904_093727.jpg', '-', '-', 'Thinking', 'Vijayawada', '2BHK', 'Below 20 lakhs', '03-11-2021', 'New', 'diwali'),
(129, 'Dasari Raja', '8500000472', 'dasariraja786@gmail.com', '20210625_094835.jpg', '-', '-', '-', 'Vijayawada', '3BHK', '30 to 50 lakhs', '03-11-2021', 'New', 'diwali'),
(130, 'Sai krishna', '9347105423', 'Ksaikrishnafci@gmail com', 'IMG_20210904_0937271.jpg', '-', '-', 'Thinking', 'Vijayawada', '2BHK', 'Below 20 lakhs', '03-11-2021', 'New', 'diwali'),
(131, 'NAGA LOCHAN ', '8179230240', 'Sravanthikuppala1228@gmail.com', '', '-', '-', 'Thinking', 'Vijayawada', '3BHK', '30 to 50 lakhs', '03-11-2021', 'New', 'diwali'),
(132, 'Sai krishna', '9347105423', 'Ksaikrishnafci@gmail com', 'IMG_20210904_0937272.jpg', '-', '-', 'Thinking', 'Vijayawada', '2BHK', 'Below 20 lakhs', '03-11-2021', 'New', 'diwali'),
(133, 'NAGARAJU KANCHERLA ', '9866445906', 'nagarajukancherla9@gmail.com', '', '-', '-', '-', '-', '-', '-', '03-11-2021', 'New', 'diwali'),
(134, 'Addanki Syamala', '9491373691', 'addankisyamala590@gmail.com', '', '-', '-', '-', 'Vijayawada', '2BHK', 'Below 20 lakhs', '03-11-2021', 'New', 'diwali'),
(135, 'Dilip', '6305701061', 'sankurudilip123@gmail.com', 'IMG_20210929_135445.jpg', '-', '-', '-', 'Vijayawada', '3BHK', 'Upto 1 cr', '03-11-2021', 'New', 'diwali'),
(136, 'Anuhya gopisetty ', '9392773549', 'anuhyagopisetty@gmail.com', 'Screenshot_20211022-204949_WhatsApp.jpg', '-', '-', '2bhk', 'Vijayawada ', '2BHK', '20 to 30 lakhs', '03-11-2021', 'New', 'diwali'),
(137, 'Naveen danny', '9347846970', 'naveendanny111@gmail.com', 'IMG-20210813-WA0005.jpeg', '-', '-', '-', 'Guntur', '2BHK', '20 to 30 lakhs', '03-11-2021', 'New', 'diwali'),
(138, 'Akhilveer', '9515615599', 'akhilveer227@gmail.com', '', '-', '-', 'Komadhi', 'Komadhi', '2BHK', '30 to 50 lakhs', '03-11-2021', 'New', 'diwali'),
(139, 'Vamsi', '9346660445', 'vamsiram0103@gmail.com', 'passport_picture.jpg', '-', '-', '-', 'Vijayawada', '3BHK', 'Above 1 cr', '03-11-2021', 'New', 'diwali'),
(140, 'Raju', '9390571626', 'rajudokiparthi@gmail.com', 'IMG_20211023_100458.jpg', '-', '-', '-', 'Vijayawada', '3BHK', '30 to 50 lakhs', '03-11-2021', 'New', 'diwali'),
(141, 'Mohan chand chilakabattini', '7207553722', 'mohanchandchilakabattini@gmail.com', 'IMG-20211020-WA0068.jpg', '-', '-', '-', 'Vijayawada', '3BHK', '30 to 50 lakhs', '03-11-2021', 'New', 'diwali'),
(142, 'Ashok ', '7569892729', 'ashokkolanukonda@gmail.com', '', '-', '-', '-', 'Vijayawada ', '3BHK', '30 to 50 lakhs', '03-11-2021', 'New', 'diwali'),
(143, 'Mohan chand chilakabattini', '7207553722', 'mohanchandchilakabattini@gmail.com', 'IMG20211103115811.jpg', '-', '-', '-', 'Vijayawada', '3BHK', '30 to 50 lakhs', '03-11-2021', 'New', 'diwali'),
(144, 'Harikrishna Pasupuleti', '9059699576', 'krishna04062000@gmail.com', 'IMG20210905190514.jpg', '-', '-', 'Already have', 'Vijayawada', '2BHK', '30 to 50 lakhs', '03-11-2021', 'New', 'diwali'),
(145, 'Narayan Rao A', '9160280530', 'narayan336@hotmail.com', 'IMG20190414132354.jpg', '-', '-', 'Flat', 'seethamadhara', '2BHK', '30 to 50 lakhs', '03-11-2021', 'New', 'diwali'),
(146, 'Narayan Rao A', '9160280530', 'narayan336@hotmail.com', 'IMG201904141323541.jpg', '-', '-', 'Flat', 'Seethamadhara', '2BHK', '30 to 50 lakhs', '03-11-2021', 'New', 'diwali'),
(147, 'Narayan Rao A', '9160280530', 'narayan336@hotmail.com', 'IMG201904141323542.jpg', '-', '-', 'Yes', 'Seethamadhara', '2BHK', '30 to 50 lakhs', '03-11-2021', 'New', 'diwali'),
(148, 'P Lalitha', '9441647290', 'lalithakameswari22@gmail.com', 'IMG20201114182937.jpg', 'Gayatri Towers', 'First floor', '-', '-', '-', '-', '03-11-2021', 'Existing', 'diwali'),
(149, 'Mounika', '9985235682', 'Mounikahoney03249@gmail.com', '', '-', '-', 'Thinking ', 'Vijayawada ', '2BHK', 'Below 20 lakhs', '03-11-2021', 'New', 'diwali'),
(150, 'Nithin Aaron', '08096507275', 'nithinaaron25@gmail.com@gmail.com', 'Snapchat-1892729554.jpg', '-', '-', 'Flat', 'Vijayawada ', '3BHK', '20 to 30 lakhs', '03-11-2021', 'New', 'diwali'),
(151, 'Chalapathi ', '6302809884', 'Chinnuchalapathi7@gmail.com', '00D0E9DF-A1E8-4676-BEF4-7B8A0B596E7A.jpeg', '-', '-', 'Flat', 'Tadepalli ', '2BHK', '20 to 30 lakhs', '03-11-2021', 'New', 'diwali'),
(152, 'Harsha Vardhan Vipparla', '9059244467', 'harshavardhanvipparla@gmail.com', 'IMG_-cdl904.jpg', '-', '-', 'yes', 'guntur', '2BHK', 'Below 20 lakhs', '03-11-2021', 'New', 'diwali'),
(153, 'Vineetha', '8985874788', 'vineethanavuluri218@gmail.com', 'Snapchat-1729848186.jpg', '-', '-', '-', '-', '-', '-', '03-11-2021', 'New', 'diwali'),
(154, 'Vineetha', '8985874788', 'vineethanavuluri218@gmail.com', 'Snapchat-17298481861.jpg', '-', '-', '-', '-', '-', '-', '03-11-2021', 'New', 'diwali'),
(155, 'Chalapathi ', '6302809884', 'Chinnuchalapathi7@gmail.com', 'C6DBB1FF-33C0-4AD5-9339-6F1FE0943B91.jpeg', '-', '-', 'Flat', 'Tadepalli ', '2BHK', '20 to 30 lakhs', '03-11-2021', 'New', 'diwali'),
(156, 'Abhilash ', '9014133389 ', 'Dasarichinnu88@gmail.com', '1635936081111_.jpg', '-', '-', '-', 'Vijayawada ', '-', '-', '03-11-2021', 'New', 'diwali'),
(157, 'Rajendra ', '9701649839', 'Chintarajendra@gmail.com', '', '-', '-', 'Thinking ', 'Vijayawada ', '2BHK', 'Below 20 lakhs', '03-11-2021', 'New', 'diwali'),
(158, 'Saikiran', '9553312262', 'naidusanjay14@gmail.com', '', '-', '-', 'Vijayawada', 'Krishna lanka', '2BHK', 'Below 20 lakhs', '03-11-2021', 'New', 'diwali'),
(159, 'Pavan kalyan', '9505560174', 'pk9810340@gmail.com', '', '-', '-', '-', 'Rani gari thota', '3BHK', '30 to 50 lakhs', '03-11-2021', 'New', 'diwali'),
(160, 'Rani', '7993442421', 'Ranichinta@gmail.com', '', '-', '-', 'Thinking ', 'Vijayawada ', '2BHK', 'Below 20 lakhs', '03-11-2021', 'New', 'diwali'),
(161, 'K Prakash rao', '7893936409', 'Prakash Rao kommina @gmail.com', '', '-', '-', 'Thinking ', 'Vijayawada ', '2BHK', 'Below 20 lakhs', '03-11-2021', 'New', 'diwali'),
(162, 'Saikiran', '9553312262', 'naidusanjay14@gmail.com', '16359364006273133075252801373737.jpg', '-', '-', 'Vijayawada', 'Krishna lanka', '2BHK', 'Below 20 lakhs', '03-11-2021', 'New', 'diwali'),
(163, 'Abhilash ', '9014133389 ', 'Dasarichinnu88@gmail.com', '1635936403898_.jpg', '-', '-', '-', 'Vijayawada ', '-', '-', '03-11-2021', 'New', 'diwali'),
(164, 'Renuka', '9542977816', 'Renukachintha123@gmail.com', '', '-', '-', 'Thinking ', 'Vijayawada ', '2BHK', 'Below 20 lakhs', '03-11-2021', 'New', 'diwali'),
(165, 'Manoj', '9014155439', 'manojkumar1999143@gmail.com', 'Screenshot_2021-11-03-16-18-33-84_1c337646f29875672b5a61192b9010f9.jpg', '-', '-', 'Flat', 'Vijayawada', '2BHK', 'Below 20 lakhs', '03-11-2021', 'New', 'diwali'),
(166, 'Abhilash ', '9014133389 ', 'Dasarichinnu88@gmail.com', '1635936546704_.jpg', '-', '-', '-', 'Vijayawada ', '3BHK', 'Upto 1 cr', '03-11-2021', 'New', 'diwali'),
(167, 'K.mary', '99486 61701', 'Marykommina789@gmail.com', '', '-', '-', 'Thinking ', 'Vijayawada ', '2BHK', 'Below 20 lakhs', '03-11-2021', 'New', 'diwali'),
(168, 'Pallekond Chalapathi', '9908807646', 'charant148@gmail.com', 'Snapchat-523164902.jpg', '-', '-', '-', 'Nuthakki ', '2BHK', 'Below 20 lakhs', '03-11-2021', 'New', 'diwali'),
(169, 'Mounika', '9985235682', 'Mounikachinta03249@gmail.com', '', '-', '-', 'Thinking ', 'Vijayawada ', '2BHK', 'Below 20 lakhs', '03-11-2021', 'New', 'diwali'),
(170, 'Pallekond Chalapathi', '9908807646', 'charant148@gmail.com', 'Snapchat-5231649021.jpg', '-', '-', '-', 'Nuthakki', '2BHK', 'Below 20 lakhs', '03-11-2021', 'New', 'diwali'),
(171, 'Sai manikanta ', '+91 85238 73832', 'Sunnynaidu 03249@gmail.com', '', '-', '-', 'Thinking ', 'Vijayawada ', '2BHK', 'Below 20 lakhs', '03-11-2021', 'New', 'diwali'),
(172, 'N kumar', '8688156789', 'nagubandiharipriya@gmail.com', 'SAVE_20211103_163550.jpg', '-', '-', 'House', 'Mangalgiri', '2BHK', 'Below 20 lakhs', '03-11-2021', 'New', 'diwali'),
(173, 'Sarekukkavijay', '7993887222', 'vijayvijju056@gmail.com', 'IMG20211102160458.jpg', '-', '-', 'Yes', 'Amravati Raod', '3BHK', '30 to 50 lakhs', '03-11-2021', 'New', 'diwali'),
(174, 'Kumari ', '9848379215', 'Kumariderangula @gmail.com', '', '-', '-', 'Thinking ', 'Vijayawada ', '2BHK', 'Below 20 lakhs', '03-11-2021', 'New', 'diwali'),
(175, 'yesuratnam', '9985711644', 'yesuratnamvipparle@gmail.com', '', '-', '-', 'yes', 'guntur', '2BHK', 'Below 20 lakhs', '03-11-2021', 'New', 'diwali'),
(176, 'Pavan kalyan ', '9505560174', 'pk9810340@gmail.com', 'IMG_20210509_124522_282.jpg', '-', '-', 'Flat', 'Rani gari thota', '3BHK', '30 to 50 lakhs', '03-11-2021', 'New', 'diwali'),
(177, 'Kovela Harika', '9676448248', 'Kovelaharika88@gmail.com', 'IMG-20211103-WA0030.jpg', '-', '-', 'Yes', 'Vijaywada', '2BHK', '30 to 50 lakhs', '03-11-2021', 'New', 'diwali'),
(178, 'avinash', '9030207959', 'avinashvipparla@gmail.com', '', '-', '-', 'yes', 'guntur', '2BHK', 'Below 20 lakhs', '03-11-2021', 'New', 'diwali'),
(179, 'bharathi', '9703596079', 'bharathivipparla@gmail.com', '', '-', '-', 'yes', 'guntur', '2BHK', 'Below 20 lakhs', '03-11-2021', 'New', 'diwali'),
(180, 'hanumantha rao', '8074698551', 'hanumatharaovipparla@gmail.com', '', '-', '-', 'yes', 'guntur', '2BHK', 'Below 20 lakhs', '03-11-2021', 'New', 'diwali'),
(181, 'anjeneyulu', '9727710838', 'anjeneyulunukatoti@gmail.com', '', '-', '-', 'yes', 'guntur', '2BHK', 'Below 20 lakhs', '03-11-2021', 'New', 'diwali'),
(182, 'subhashini', '8143253195', 'subhashini@gmail.com', '', '-', '-', 'yes', 'guntur', '2BHK', 'Below 20 lakhs', '03-11-2021', 'New', 'diwali'),
(183, 'Sarekukkavijay', '7993887222', 'vijayvijju056@gmail.com', 'IMG202111021604581.jpg', '-', '-', 'Yes', 'Vizag', '3BHK', '30 to 50 lakhs', '03-11-2021', 'New', 'diwali'),
(184, 'tippu', '9182357569', 'tippusultan@gmail.com', '', '-', '-', 'yes', 'guntur', '2BHK', 'Below 20 lakhs', '03-11-2021', 'New', 'diwali'),
(185, 'sekhar', '8019730149', 'sekharnaidu@gmail.com', '', '-', '-', 'yes', 'guntur', '2BHK', 'Below 20 lakhs', '03-11-2021', 'New', 'diwali'),
(186, 'shyam ', '9391494451', 'shyamtelagathoti@gmail.com', '', '-', '-', 'yes', 'guntur', '2BHK', 'Below 20 lakhs', '03-11-2021', 'New', 'diwali'),
(187, 'sravanthi', '9493814663', 'sravanthi79@gmail.com', '', '-', '-', 'yes', 'guntur', '3BHK', '20 to 30 lakhs', '03-11-2021', 'New', 'diwali'),
(188, 'tagore ', '7671876648', 'tagoreannam@gmail.com', '', '-', '-', 'yes', 'guntur', '2BHK', 'Below 20 lakhs', '03-11-2021', 'New', 'diwali'),
(189, 'prasad', '8125492559', 'prasadvanukuri@gmail.com', '', '-', '-', 'yes', 'guntur', '2BHK', 'Below 20 lakhs', '03-11-2021', 'New', 'diwali'),
(190, 'Hareesh', '7382761542', 'hareeshjangam043@gmail', 'IMG_20211103_165902.jpg', '-', '-', 'Flat', 'Gunadala', '2BHK', 'Below 20 lakhs', '03-11-2021', 'New', 'diwali'),
(191, 'harika', '7013062599', 'harikareddy@gamil.com', '', '-', '-', 'yes', 'Vizag', '2BHK', 'Below 20 lakhs', '03-11-2021', 'New', 'diwali'),
(192, 'vasavi', '9676762605', 'vasavipasa@gmail.com', '', '-', '-', 'yes', 'guntur', '2BHK', 'Below 20 lakhs', '03-11-2021', 'New', 'diwali'),
(193, 'Panchumarthi Sivakumari', '8639660142', 'panchumarthigeethika@gmail.com', 'IMG_20180507_042810150.jpg', '-', '-', '-', 'Vijayawada ', '2BHK', '20 to 30 lakhs', '03-11-2021', 'New', 'diwali'),
(194, 'Sravani', '7382663999', 'sravanikolli3617@gmail.com', 'IMG_20211024_231615082_HDR.jpg', '-', '-', '-', 'Mangalagiri', '3BHK', '30 to 50 lakhs', '03-11-2021', 'New', 'diwali'),
(195, 'Vineeta kolli', '8331809999', 'vineeta.kolli99@gmail.com', '', '-', '-', 'Falt', 'Vijayawada', '2BHK', 'Below 20 lakhs', '03-11-2021', 'New', 'diwali'),
(196, 'Kumari ', '9848379215', 'Kumariderangula @gmail.com', '', '-', '-', 'Thinking ', 'Vijayawada ', '2BHK', 'Below 20 lakhs', '04-11-2021', 'New', 'diwali');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `adminusers`
--
ALTER TABLE `adminusers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blog`
--
ALTER TABLE `blog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blog_images`
--
ALTER TABLE `blog_images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bookingproject`
--
ALTER TABLE `bookingproject`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `careers`
--
ALTER TABLE `careers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cities`
--
ALTER TABLE `cities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contactus`
--
ALTER TABLE `contactus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `credai`
--
ALTER TABLE `credai`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `enquiry_form`
--
ALTER TABLE `enquiry_form`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `event`
--
ALTER TABLE `event`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `event_images`
--
ALTER TABLE `event_images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feedbackresult`
--
ALTER TABLE `feedbackresult`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `plot_booking_form`
--
ALTER TABLE `plot_booking_form`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `property`
--
ALTER TABLE `property`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `property_bkp_21102020`
--
ALTER TABLE `property_bkp_21102020`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `property_comments`
--
ALTER TABLE `property_comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `property_details`
--
ALTER TABLE `property_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `property_images`
--
ALTER TABLE `property_images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sales_link_to_customer`
--
ALTER TABLE `sales_link_to_customer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `selfie_pic`
--
ALTER TABLE `selfie_pic`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `adminusers`
--
ALTER TABLE `adminusers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `blog`
--
ALTER TABLE `blog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=77;

--
-- AUTO_INCREMENT for table `blog_images`
--
ALTER TABLE `blog_images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=92;

--
-- AUTO_INCREMENT for table `bookingproject`
--
ALTER TABLE `bookingproject`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `careers`
--
ALTER TABLE `careers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `cities`
--
ALTER TABLE `cities`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `contactus`
--
ALTER TABLE `contactus`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=155;

--
-- AUTO_INCREMENT for table `credai`
--
ALTER TABLE `credai`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT for table `enquiry_form`
--
ALTER TABLE `enquiry_form`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `event`
--
ALTER TABLE `event`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `event_images`
--
ALTER TABLE `event_images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=266;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `feedbackresult`
--
ALTER TABLE `feedbackresult`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=166;

--
-- AUTO_INCREMENT for table `plot_booking_form`
--
ALTER TABLE `plot_booking_form`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `property`
--
ALTER TABLE `property`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=138;

--
-- AUTO_INCREMENT for table `property_bkp_21102020`
--
ALTER TABLE `property_bkp_21102020`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `property_comments`
--
ALTER TABLE `property_comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `property_details`
--
ALTER TABLE `property_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=362;

--
-- AUTO_INCREMENT for table `property_images`
--
ALTER TABLE `property_images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=445;

--
-- AUTO_INCREMENT for table `sales_link_to_customer`
--
ALTER TABLE `sales_link_to_customer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `selfie_pic`
--
ALTER TABLE `selfie_pic`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=197;
--
-- Database: `eswarigroup_visitordata`
--
CREATE DATABASE IF NOT EXISTS `eswarigroup_visitordata` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `eswarigroup_visitordata`;

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `uid` int(10) NOT NULL,
  `name` varchar(50) NOT NULL,
  `mobile` bigint(11) NOT NULL,
  `email` varchar(50) DEFAULT NULL,
  `password` varchar(50) NOT NULL,
  `user_type` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`uid`, `name`, `mobile`, `email`, `password`, `user_type`) VALUES
(1, 'test', 1234567890, 'test@ase.eg', 'ase', 'admin'),
(2, 'qwerty', 9876543210, 'info@eswarigroup.com', 'qwerty', 'user');

-- --------------------------------------------------------

--
-- Table structure for table `visitordata`
--

CREATE TABLE `visitordata` (
  `vid` int(3) NOT NULL,
  `name` varchar(50) NOT NULL,
  `mobile` bigint(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `need` varchar(50) NOT NULL,
  `message` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `visitordata`
--

INSERT INTO `visitordata` (`vid`, `name`, `mobile`, `email`, `need`, `message`) VALUES
(1, 'test', 7410852369, 'test@ase.eg', 'For Technologies', 'Web Development'),
(2, 'test2', 0, 'value-4', 'value-5', 'value-6');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD PRIMARY KEY (`uid`),
  ADD UNIQUE KEY `mobile` (`mobile`);

--
-- Indexes for table `visitordata`
--
ALTER TABLE `visitordata`
  ADD PRIMARY KEY (`vid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `registration`
--
ALTER TABLE `registration`
  MODIFY `uid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `visitordata`
--
ALTER TABLE `visitordata`
  MODIFY `vid` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- Database: `hii`
--
CREATE DATABASE IF NOT EXISTS `hii` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `hii`;

-- --------------------------------------------------------

--
-- Table structure for table `comment_box`
--

CREATE TABLE `comment_box` (
  `s.no` int(10) NOT NULL,
  `name` varchar(20) NOT NULL,
  `email` varchar(30) NOT NULL,
  `comment` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `name` varchar(20) NOT NULL,
  `number` bigint(11) NOT NULL,
  `dob` date NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(11) NOT NULL,
  `gender` varchar(11) NOT NULL,
  `language` varchar(11) NOT NULL,
  `emergency` bigint(12) NOT NULL,
  `address` text NOT NULL,
  `user_type` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`name`, `number`, `dob`, `email`, `password`, `gender`, `language`, `emergency`, `address`, `user_type`) VALUES
('hareesh', 576348, '2021-11-03', 'dg@hvfhd.sdhcv', 'dfrg', 'on', 'Telugu', 46547, 'trgtrg', 0),
('dsv', 3253, '0000-00-00', 'f@dfv.dcvg', 'fegv', 'on', 'Telugu', 346, 'hbsgn', 0),
('Heramba', 9872364587, '2021-11-06', 'ghsfd@vfhjv.gd', 'fguhlvfhu', 'on', 'Telugu', 43789, 'fzghjuuhygtfrds vgrd vre', 0),
('Hareesh', 8985884602, '0000-00-00', 'm.hareesh2504@gmail.com', 'hareesh', 'male', 'telugu', 9876543210, 'Tech Mahendra Foundation Smart Academy', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `comment_box`
--
ALTER TABLE `comment_box`
  ADD PRIMARY KEY (`s.no`);

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD PRIMARY KEY (`email`);
--
-- Database: `phpmyadmin`
--
CREATE DATABASE IF NOT EXISTS `phpmyadmin` DEFAULT CHARACTER SET utf8 COLLATE utf8_bin;
USE `phpmyadmin`;

-- --------------------------------------------------------

--
-- Table structure for table `pma__bookmark`
--

CREATE TABLE `pma__bookmark` (
  `id` int(10) UNSIGNED NOT NULL,
  `dbase` varchar(255) NOT NULL DEFAULT '',
  `user` varchar(255) NOT NULL DEFAULT '',
  `label` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `query` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Bookmarks';

-- --------------------------------------------------------

--
-- Table structure for table `pma__central_columns`
--

CREATE TABLE `pma__central_columns` (
  `db_name` varchar(64) NOT NULL,
  `col_name` varchar(64) NOT NULL,
  `col_type` varchar(64) NOT NULL,
  `col_length` text DEFAULT NULL,
  `col_collation` varchar(64) NOT NULL,
  `col_isNull` tinyint(1) NOT NULL,
  `col_extra` varchar(255) DEFAULT '',
  `col_default` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Central list of columns';

-- --------------------------------------------------------

--
-- Table structure for table `pma__column_info`
--

CREATE TABLE `pma__column_info` (
  `id` int(5) UNSIGNED NOT NULL,
  `db_name` varchar(64) NOT NULL DEFAULT '',
  `table_name` varchar(64) NOT NULL DEFAULT '',
  `column_name` varchar(64) NOT NULL DEFAULT '',
  `comment` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `mimetype` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `transformation` varchar(255) NOT NULL DEFAULT '',
  `transformation_options` varchar(255) NOT NULL DEFAULT '',
  `input_transformation` varchar(255) NOT NULL DEFAULT '',
  `input_transformation_options` varchar(255) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Column information for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__designer_settings`
--

CREATE TABLE `pma__designer_settings` (
  `username` varchar(64) NOT NULL,
  `settings_data` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Settings related to Designer';

-- --------------------------------------------------------

--
-- Table structure for table `pma__export_templates`
--

CREATE TABLE `pma__export_templates` (
  `id` int(5) UNSIGNED NOT NULL,
  `username` varchar(64) NOT NULL,
  `export_type` varchar(10) NOT NULL,
  `template_name` varchar(64) NOT NULL,
  `template_data` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Saved export templates';

-- --------------------------------------------------------

--
-- Table structure for table `pma__favorite`
--

CREATE TABLE `pma__favorite` (
  `username` varchar(64) NOT NULL,
  `tables` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Favorite tables';

-- --------------------------------------------------------

--
-- Table structure for table `pma__history`
--

CREATE TABLE `pma__history` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `username` varchar(64) NOT NULL DEFAULT '',
  `db` varchar(64) NOT NULL DEFAULT '',
  `table` varchar(64) NOT NULL DEFAULT '',
  `timevalue` timestamp NOT NULL DEFAULT current_timestamp(),
  `sqlquery` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='SQL history for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__navigationhiding`
--

CREATE TABLE `pma__navigationhiding` (
  `username` varchar(64) NOT NULL,
  `item_name` varchar(64) NOT NULL,
  `item_type` varchar(64) NOT NULL,
  `db_name` varchar(64) NOT NULL,
  `table_name` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Hidden items of navigation tree';

-- --------------------------------------------------------

--
-- Table structure for table `pma__pdf_pages`
--

CREATE TABLE `pma__pdf_pages` (
  `db_name` varchar(64) NOT NULL DEFAULT '',
  `page_nr` int(10) UNSIGNED NOT NULL,
  `page_descr` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='PDF relation pages for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__recent`
--

CREATE TABLE `pma__recent` (
  `username` varchar(64) NOT NULL,
  `tables` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Recently accessed tables';

--
-- Dumping data for table `pma__recent`
--

INSERT INTO `pma__recent` (`username`, `tables`) VALUES
('root', '[{\"db\":\"eswarigroup_visitordata\",\"table\":\"visitordata\"},{\"db\":\"eswarigroup_visitordata\",\"table\":\"registration\"},{\"db\":\"eswarigroup_eswarihomes\",\"table\":\"adminusers\"},{\"db\":\"e-commerce_sales_inventory-system\",\"table\":\"manager\"},{\"db\":\"e-commerce_sales_inventory-system\",\"table\":\"employee\"},{\"db\":\"e-commerce_sales_inventory-system\",\"table\":\"category\"},{\"db\":\"e-commerce_dairyfarmshop-mng-sys\",\"table\":\"tbladmin\"},{\"db\":\"dental_clinic\",\"table\":\"contact_form\"},{\"db\":\"construction_monitering-systems\",\"table\":\"admin\"},{\"db\":\"hii\",\"table\":\"comment_box\"}]');

-- --------------------------------------------------------

--
-- Table structure for table `pma__relation`
--

CREATE TABLE `pma__relation` (
  `master_db` varchar(64) NOT NULL DEFAULT '',
  `master_table` varchar(64) NOT NULL DEFAULT '',
  `master_field` varchar(64) NOT NULL DEFAULT '',
  `foreign_db` varchar(64) NOT NULL DEFAULT '',
  `foreign_table` varchar(64) NOT NULL DEFAULT '',
  `foreign_field` varchar(64) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Relation table';

-- --------------------------------------------------------

--
-- Table structure for table `pma__savedsearches`
--

CREATE TABLE `pma__savedsearches` (
  `id` int(5) UNSIGNED NOT NULL,
  `username` varchar(64) NOT NULL DEFAULT '',
  `db_name` varchar(64) NOT NULL DEFAULT '',
  `search_name` varchar(64) NOT NULL DEFAULT '',
  `search_data` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Saved searches';

-- --------------------------------------------------------

--
-- Table structure for table `pma__table_coords`
--

CREATE TABLE `pma__table_coords` (
  `db_name` varchar(64) NOT NULL DEFAULT '',
  `table_name` varchar(64) NOT NULL DEFAULT '',
  `pdf_page_number` int(11) NOT NULL DEFAULT 0,
  `x` float UNSIGNED NOT NULL DEFAULT 0,
  `y` float UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Table coordinates for phpMyAdmin PDF output';

-- --------------------------------------------------------

--
-- Table structure for table `pma__table_info`
--

CREATE TABLE `pma__table_info` (
  `db_name` varchar(64) NOT NULL DEFAULT '',
  `table_name` varchar(64) NOT NULL DEFAULT '',
  `display_field` varchar(64) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Table information for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__table_uiprefs`
--

CREATE TABLE `pma__table_uiprefs` (
  `username` varchar(64) NOT NULL,
  `db_name` varchar(64) NOT NULL,
  `table_name` varchar(64) NOT NULL,
  `prefs` text NOT NULL,
  `last_update` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Tables'' UI preferences';

-- --------------------------------------------------------

--
-- Table structure for table `pma__tracking`
--

CREATE TABLE `pma__tracking` (
  `db_name` varchar(64) NOT NULL,
  `table_name` varchar(64) NOT NULL,
  `version` int(10) UNSIGNED NOT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` datetime NOT NULL,
  `schema_snapshot` text NOT NULL,
  `schema_sql` text DEFAULT NULL,
  `data_sql` longtext DEFAULT NULL,
  `tracking` set('UPDATE','REPLACE','INSERT','DELETE','TRUNCATE','CREATE DATABASE','ALTER DATABASE','DROP DATABASE','CREATE TABLE','ALTER TABLE','RENAME TABLE','DROP TABLE','CREATE INDEX','DROP INDEX','CREATE VIEW','ALTER VIEW','DROP VIEW') DEFAULT NULL,
  `tracking_active` int(1) UNSIGNED NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Database changes tracking for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__userconfig`
--

CREATE TABLE `pma__userconfig` (
  `username` varchar(64) NOT NULL,
  `timevalue` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `config_data` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='User preferences storage for phpMyAdmin';

--
-- Dumping data for table `pma__userconfig`
--

INSERT INTO `pma__userconfig` (`username`, `timevalue`, `config_data`) VALUES
('root', '2023-04-17 12:26:46', '{\"Console\\/Mode\":\"collapse\"}');

-- --------------------------------------------------------

--
-- Table structure for table `pma__usergroups`
--

CREATE TABLE `pma__usergroups` (
  `usergroup` varchar(64) NOT NULL,
  `tab` varchar(64) NOT NULL,
  `allowed` enum('Y','N') NOT NULL DEFAULT 'N'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='User groups with configured menu items';

-- --------------------------------------------------------

--
-- Table structure for table `pma__users`
--

CREATE TABLE `pma__users` (
  `username` varchar(64) NOT NULL,
  `usergroup` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Users and their assignments to user groups';

--
-- Indexes for dumped tables
--

--
-- Indexes for table `pma__bookmark`
--
ALTER TABLE `pma__bookmark`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pma__central_columns`
--
ALTER TABLE `pma__central_columns`
  ADD PRIMARY KEY (`db_name`,`col_name`);

--
-- Indexes for table `pma__column_info`
--
ALTER TABLE `pma__column_info`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `db_name` (`db_name`,`table_name`,`column_name`);

--
-- Indexes for table `pma__designer_settings`
--
ALTER TABLE `pma__designer_settings`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `pma__export_templates`
--
ALTER TABLE `pma__export_templates`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `u_user_type_template` (`username`,`export_type`,`template_name`);

--
-- Indexes for table `pma__favorite`
--
ALTER TABLE `pma__favorite`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `pma__history`
--
ALTER TABLE `pma__history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `username` (`username`,`db`,`table`,`timevalue`);

--
-- Indexes for table `pma__navigationhiding`
--
ALTER TABLE `pma__navigationhiding`
  ADD PRIMARY KEY (`username`,`item_name`,`item_type`,`db_name`,`table_name`);

--
-- Indexes for table `pma__pdf_pages`
--
ALTER TABLE `pma__pdf_pages`
  ADD PRIMARY KEY (`page_nr`),
  ADD KEY `db_name` (`db_name`);

--
-- Indexes for table `pma__recent`
--
ALTER TABLE `pma__recent`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `pma__relation`
--
ALTER TABLE `pma__relation`
  ADD PRIMARY KEY (`master_db`,`master_table`,`master_field`),
  ADD KEY `foreign_field` (`foreign_db`,`foreign_table`);

--
-- Indexes for table `pma__savedsearches`
--
ALTER TABLE `pma__savedsearches`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `u_savedsearches_username_dbname` (`username`,`db_name`,`search_name`);

--
-- Indexes for table `pma__table_coords`
--
ALTER TABLE `pma__table_coords`
  ADD PRIMARY KEY (`db_name`,`table_name`,`pdf_page_number`);

--
-- Indexes for table `pma__table_info`
--
ALTER TABLE `pma__table_info`
  ADD PRIMARY KEY (`db_name`,`table_name`);

--
-- Indexes for table `pma__table_uiprefs`
--
ALTER TABLE `pma__table_uiprefs`
  ADD PRIMARY KEY (`username`,`db_name`,`table_name`);

--
-- Indexes for table `pma__tracking`
--
ALTER TABLE `pma__tracking`
  ADD PRIMARY KEY (`db_name`,`table_name`,`version`);

--
-- Indexes for table `pma__userconfig`
--
ALTER TABLE `pma__userconfig`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `pma__usergroups`
--
ALTER TABLE `pma__usergroups`
  ADD PRIMARY KEY (`usergroup`,`tab`,`allowed`);

--
-- Indexes for table `pma__users`
--
ALTER TABLE `pma__users`
  ADD PRIMARY KEY (`username`,`usergroup`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `pma__bookmark`
--
ALTER TABLE `pma__bookmark`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pma__column_info`
--
ALTER TABLE `pma__column_info`
  MODIFY `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pma__export_templates`
--
ALTER TABLE `pma__export_templates`
  MODIFY `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pma__history`
--
ALTER TABLE `pma__history`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pma__pdf_pages`
--
ALTER TABLE `pma__pdf_pages`
  MODIFY `page_nr` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pma__savedsearches`
--
ALTER TABLE `pma__savedsearches`
  MODIFY `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- Database: `test`
--
CREATE DATABASE IF NOT EXISTS `test` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `test`;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
