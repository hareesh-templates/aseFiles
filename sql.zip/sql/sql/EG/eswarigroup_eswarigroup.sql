-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jan 27, 2023 at 07:03 AM
-- Server version: 5.7.41-log
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `eswarigr_eswarigr_group`
--

-- --------------------------------------------------------

--
-- Table structure for table `enquiry_form`
--

CREATE TABLE `enquiry_form` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `flat` varchar(20) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `added_on` varchar(55) NOT NULL,
  `location` varchar(100) NOT NULL,
  `budget` varchar(20) NOT NULL,
  `project` varchar(55) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `enquiry_form`
--

INSERT INTO `enquiry_form` (`id`, `name`, `email`, `flat`, `mobile`, `added_on`, `location`, `budget`, `project`) VALUES
(1, 'chandu', 'test@gmail.com', '3BHK', '9010402324', '07-09-2022', 'hyd', '8900000', 'Madhurwada'),
(2, 'chandu', 'chandhu418@gmail.com', '-', '9010402324', '07-09-2022', 'hyd', '-', 'Madhurwada'),
(3, 'chandrashekher', 'chandhu418@gmail.com', '-', '5645656456456', '13-09-2022', 'hyd', '-', 'aganampudi'),
(4, 'chandu', 'chandhu418@gmail.com', '-', '5645656456456', '13-09-2022', 'hyd', '-', 'pedagantyada');

-- --------------------------------------------------------

--
-- Table structure for table `gallery`
--

CREATE TABLE `gallery` (
  `id` int(11) NOT NULL,
  `title` text NOT NULL,
  `sub_title` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gallery`
--

INSERT INTO `gallery` (`id`, `title`, `sub_title`) VALUES
(1, 'Bhoomi Pooja-14th October 2021', 'Aganampudi'),
(2, 'Review Meeting 2021', 'Vizag');

-- --------------------------------------------------------

--
-- Table structure for table `gallery_images`
--

CREATE TABLE `gallery_images` (
  `id` int(11) NOT NULL,
  `gallery_id` int(11) NOT NULL,
  `image` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gallery_images`
--

INSERT INTO `gallery_images` (`id`, `gallery_id`, `image`) VALUES
(1, 1, '1.jpeg'),
(2, 1, '2.jpeg'),
(3, 1, '3.jpeg'),
(4, 1, '4.jpeg'),
(5, 1, '5.jpeg'),
(6, 1, '6.jpeg'),
(7, 1, '7.jpeg'),
(8, 1, '8.jpeg'),
(9, 2, '1_1.jpeg'),
(10, 2, '2_2.jpeg'),
(11, 2, '3_3.jpeg'),
(12, 2, '4_4.jpeg'),
(13, 2, '5_5.jpeg'),
(14, 2, '6_6.jpeg'),
(15, 2, '7_7.jpeg'),
(16, 2, '8_8.jpeg'),
(17, 2, '9.jpeg'),
(18, 2, '10.jpeg'),
(19, 2, '11.jpeg'),
(20, 2, '12.jpeg'),
(21, 2, '13.jpeg'),
(22, 2, '14.jpeg'),
(23, 2, '15.jpeg'),
(24, 2, '16.jpeg'),
(25, 2, '17.jpeg'),
(26, 2, '18.jpeg'),
(27, 2, '19.jpeg'),
(28, 2, '424.jpeg'),
(29, 2, '425.jpeg'),
(30, 2, '426.jpeg'),
(31, 2, '427.jpeg'),
(32, 2, '422.jpeg'),
(33, 2, '421.jpeg'),
(34, 2, '428.jpeg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `enquiry_form`
--
ALTER TABLE `enquiry_form`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gallery`
--
ALTER TABLE `gallery`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gallery_images`
--
ALTER TABLE `gallery_images`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `enquiry_form`
--
ALTER TABLE `enquiry_form`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `gallery`
--
ALTER TABLE `gallery`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `gallery_images`
--
ALTER TABLE `gallery_images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
