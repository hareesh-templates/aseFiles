-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Aug 17, 2023 at 02:51 PM
-- Server version: 8.0.34
-- PHP Version: 8.1.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `eswarigr_eswarigr_group`
--

-- --------------------------------------------------------

--
-- Table structure for table `activities`
--

CREATE TABLE `activities` (
  `id` int NOT NULL,
  `title` text NOT NULL,
  `sub_title` text NOT NULL,
  `image` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `activities`
--

INSERT INTO `activities` (`id`, `title`, `sub_title`, `image`) VALUES
(1, 'Activities & Visits', 'Vizag', 'IMG-20221219-WA0017.jpg'),
(2, 'Diwali Celebrations 2022', 'Vizag', 'IMG-20221024-WA0036.jpg'),
(3, 'Sports Meet 2022', 'Vizag', 'IMG-20230101-WA0016.jpg'),
(4, 'New Year Celebrations 2023', 'Vizag', 'IMG-20230101-WA0020.jpg'),
(5, 'Pongal Celebrations 2023', 'Vizag', '1.jpg'),
(6, 'Republic Day Celebrations 2023', 'Vizag', 'IMG-20230126-WA0026.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `activity_images`
--

CREATE TABLE `activity_images` (
  `id` int NOT NULL,
  `title` text NOT NULL,
  `image` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `activity_images`
--

INSERT INTO `activity_images` (`id`, `title`, `image`) VALUES
(1, 'Activities & Visits', 'IMG-20221218-WA0000.jpg'),
(2, 'Activities & Visits', 'IMG-20221218-WA0003.jpg'),
(3, 'Activities & Visits', 'IMG-20221218-WA0005.jpg'),
(4, 'Activities & Visits', 'IMG-20221218-WA0010.jpg'),
(5, 'Activities & Visits', 'IMG-20221218-WA0012.jpg'),
(6, 'Activities & Visits', 'IMG-20221218-WA0024.jpg'),
(7, 'Activities & Visits', 'IMG-20221218-WA0025.jpg'),
(8, 'Activities & Visits', 'IMG-20221219-WA0016.jpg'),
(9, 'Activities & Visits', 'IMG-20221219-WA0017.jpg'),
(10, 'Diwali Celebrations 2022', 'IMG-20221024-WA0012.jpg'),
(11, 'Diwali Celebrations 2022', 'IMG-20221024-WA0024.jpg'),
(12, 'Diwali Celebrations 2022', 'IMG-20221024-WA0035.jpg'),
(13, 'Diwali Celebrations 2022', 'IMG-20221024-WA0036.jpg'),
(14, 'Diwali Celebrations 2022', 'IMG-20221024-WA0037.jpg'),
(15, 'Diwali Celebrations 2022', 'IMG-20221024-WA0047.jpg'),
(16, 'Diwali Celebrations 2022', 'IMG-20221024-WA0050.jpg'),
(17, 'Diwali Celebrations 2022', 'IMG-20221024-WA0051.jpg'),
(18, 'New Year Celebrations 2023', 'IMG-20230101-WA0018.jpg'),
(19, 'Diwali Celebrations 2022', 'IMG-20221024-WA0054.jpg'),
(20, 'Diwali Celebrations 2022', 'IMG-20221027-WA0002.jpg'),
(21, 'Diwali Celebrations 2022', 'IMG-20221027-WA0006.jpg'),
(22, 'Sports Meet 2022', 'IMG-20221221-WA0001.jpg'),
(23, 'Sports Meet 2022', 'IMG-20221221-WA0002.jpg'),
(24, 'Sports Meet 2022', 'IMG-20221221-WA0005.jpg'),
(25, 'Sports Meet 2022', 'IMG-20221221-WA0007.jpg'),
(26, 'Sports Meet 2022', 'IMG-20221221-WA0001.jpg'),
(27, 'Sports Meet 2022', 'IMG-20221221-WA0020.jpg'),
(28, 'Sports Meet 2022', 'IMG-20221221-WA0011.jpg'),
(29, 'Sports Meet 2022', 'IMG-20221221-WA0017.jpg'),
(30, 'Sports Meet 2022', 'IMG-20230101-WA0013.jpg'),
(31, 'Sports Meet 2022', 'IMG-20230101-WA0014.jpg'),
(32, 'Sports Meet 2022', 'IMG-20230101-WA0015.jpg'),
(33, 'Sports Meet 2022', 'IMG-20230101-WA0016.jpg'),
(34, 'New Year Celebrations 2023', 'IMG-20230101-WA0018.jpg'),
(35, 'New Year Celebrations 2023', 'IMG-20230101-WA0012.jpg'),
(36, 'New Year Celebrations 2023', 'IMG-20230101-WA0020.jpg'),
(37, 'New Year Celebrations 2023', 'IMG-20230101-WA0022.jpg'),
(38, 'New Year Celebrations 2023', 'IMG-20230101-WA0033.jpg'),
(39, 'New Year Celebrations 2023', 'IMG-20230101-WA0028.jpg'),
(40, 'New Year Celebrations 2023', 'IMG-20230101-WA0029.jpg'),
(41, 'New Year Celebrations 2023', 'IMG-20230101-WA0035.jpg'),
(42, 'New Year Celebrations 2023', 'IMG-20230101-WA0036.jpg'),
(44, 'Pongal Celebrations 2023', '1.jpg'),
(45, 'Pongal Celebrations 2023', '2.jpg'),
(46, 'Pongal Celebrations 2023', '1.jpg'),
(47, 'Pongal Celebrations 2023', '3.jpg'),
(48, 'Pongal Celebrations 2023', '4.jpg'),
(49, 'Pongal Celebrations 2023', '5.jpg'),
(50, 'Pongal Celebrations 2023', '6.jpg'),
(51, 'Pongal Celebrations 2023', '7.jpg'),
(52, 'Pongal Celebrations 2023', '8.jpg'),
(53, 'Pongal Celebrations 2023', '9.jpg'),
(54, 'Pongal Celebrations 2023', '10.jpg'),
(55, 'Republic Day Celebrations 2023', 'IMG-20230126-WA0026.jpg'),
(56, 'Republic Day Celebrations 2023', 'IMG-20230126-WA0003.jpg'),
(57, 'Republic Day Celebrations 2023', 'IMG-20230126-WA0004.jpg'),
(58, 'Republic Day Celebrations 2023', 'IMG-20230126-WA0005.jpg'),
(59, 'Republic Day Celebrations 2023', 'IMG-20230126-WA0007.jpg'),
(60, 'Republic Day Celebrations 2023', 'IMG-20230126-WA0012.jpg'),
(61, 'Republic Day Celebrations 2023', 'IMG-20230126-WA0015.jpg'),
(62, 'Republic Day Celebrations 2023', 'IMG-20230126-WA0026.jpg'),
(63, 'Republic Day Celebrations 2023', 'IMG-20230126-WA0030.jpg'),
(64, 'Republic Day Celebrations 2023', 'IMG-20230126-WA0032.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `contact_form`
--

CREATE TABLE `contact_form` (
  `id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `mobile` bigint NOT NULL,
  `email` varchar(50) NOT NULL,
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `contact_form`
--

INSERT INTO `contact_form` (`id`, `name`, `mobile`, `email`, `message`) VALUES
(2, 'Test by Hareesh', 8118551987, 'test@eswarigroup.com', 'This is the testing form submission by Hareesh'),
(3, 'test by hareesh', 9876543210, 'hari@ase.eg', 'this is the testing message for data storing in database and sending mail'),
(4, 'test by hareesh', 77777777, 'asdf@ase.eg', 'This is the testing msg for mailing body '),
(5, 'Elisa', 0, 'elisa.moulds@yahoo.com', 'Boost your brand, captivate your audience, and maximize your online potential with our innovative products. Visit this link now and explore your options: https://jvz1.com/c/2840657/393936/\r\n\r\ní ½íº€ Boost Your Brand with Social Media Mastery:\r\nUnlock the power of social media marketing with our comprehensive toolkit.\r\n\r\ní ½í²¡ Illuminate Your Website with Stunning Designs:\r\nFirst impressions matter, and our web design solutions will captivate your visitors from the moment they land on your site.\r\n\r\ní ½í³ˆ Supercharge Your SEO Performance:\r\nGet ready to dominate search engine rankings with our advanced SEO tools. Unleash the potential of your website and soar above the competition. \r\n\r\ní ½í²° Maximize ROI with Conversion Optimization:\r\nTurn your website visitors into loyal customers with our conversion optimization techniques. \r\n\r\ní ¼í¼ Expand Your Global Reach with Multilingual Solutions:\r\nBreak language barriers and conquer international markets with our multilingual services. \r\n\r\ní ½í´’ Secure Your Digital Fortress:\r\nIn the era of cyber threats, safeguarding your online assets is paramount.\r\n\r\nDon\'t settle for mediocrity when you can achieve greatness. Elevate your digital presence with our exceptional products. \r\n\r\nVisit our website\'s product now at: https://jvz1.com/c/2840657/393936/  - and embark on a journey of digital excellence with LinkPro !\r\n\r\nBest regards!'),
(6, 'Hyman', 0, 'hyman.shearer@msn.com', '\r\nWe are excited to introduce our latest NFT collection, \"Chat GPT as Animal\"! This unique collection features ChatGPT, a language model trained by OpenAI, as different animals, such as lions, dogs, birds, and many more.\r\n\r\nEach NFT is a one-of-a-kind masterpiece, digitally created by talented artists from around the world. You can own a piece of this exclusive collection and showcase your love for ChatGPT and animals.\r\n\r\nBy owning a Chat GPT as Animal NFT, you\'ll be joining a community of passionate collectors who appreciate the creativity and uniqueness of digital art.\r\n\r\nTo purchase your Chat GPT as Animal NFT, simply click on this link: https://opensea.io/collection/chat-gpt-as-animal. Our collection is hosted on OpenSea, the largest NFT marketplace, ensuring a secure and easy transaction.\r\n\r\nDon\'t miss out on this opportunity to own a rare piece of digital art! Get your Chat GPT as Animal NFT today!\r\n\r\nThank you for your continued support.\r\n\r\nBest regards!\r\n\r\nThe ChatGPT NFT Team'),
(7, 'Dir. Chewn', 87598799321, 'dir.chau0090@gmail.com', 'Greetings \r\n \r\nI would like to extend a professional and alluring business \r\nopportunity to you. Please respond to my email address below \r\n(dir.chau009@gmail.com) for further deliberation. \r\n \r\nThank you. \r\nDir. Chewn'),
(8, 'Joumana', 16, 'info@joumanaart.com', 'Hello,\r\n\r\nI hope you\'re doing well. I\'m Joumana, an artist who loves to create unique and captivating pieces. I came across your amazing collection of art and was truly impressed. As an artist, I\'m always exploring different sizes and mediums, and I would love to discuss the possibility of creating something special for you.\r\n\r\nFeel free to take a look at my portfolio on my website at https://www.joumanaart.com and also on my Instagram account at https://www.instagram.com/thejoumanaart \r\nMy work has a unique style that can fit in many different settings, and I believe it could add something special to your space.\r\n\r\nThanks for taking the time to read this, and I\'m excited to hear back from you.\r\n\r\nBest regards,\r\nJoumana\r\n\r\nArtsper: https://www.artsper.com/es/contemporary-artworks/painting/1629807/color-bomb\r\nARTSY: https://www.artsy.net/artist/joumana-yaghi/works-for-sale\r\nMonat Gallery: https://www.monatgallery.com/joumana-yaghi/'),
(9, 'Ian', 0, 'busch.ian@hotmail.com', 'As a small business owner, â€œbe a graphic design expertâ€ probably wasnâ€™t what you signed up for.\r\n \r\n \r\nAdCreative takes this process off your hands, giving you incredible wallet-opening ad creatives.\r\n \r\n \r\nTest, test, and test some more the easy way. Youâ€™ll also get a $500 Google Ad Credit for signing up!\r\n \r\n \r\nStart Nowl today ->https://cutt.ly/500-free-google-ads-credits\r\n\r\n\r\nBest regards,\r\nChase\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\nYou can opt-out at any time: https://forms.gle/zZUo1WYRVUtZfKuR9\r\n'),
(10, 'Kim', 0, 'kim.bojorquez@msn.com', 'Hello, I noticed you are using Google AdWords to promote your company; therefore, I wanted to share this offer of $500 in free Google ad credit with you. Indeed, this is real and effective, and hereÂ´s how: Every new user who registers on this website and links to their Google Ads account will receive a $500 free ad credit. ItÂ´s called Adcreative.ai and helps companies with their digital marketing campaigns.\r\nTo get your free credit, go to https://aismartad.com/.\r\nI hope you find this offer helpful!'),
(11, 'Pionex', 0, 'sanders.greg89@gmail.com', 'We wanted to share with you an exciting opportunity to earn up to $12,000 in trading bonuses on Pionex\'s SPECIAL LIMITED TIME event!\r\n\r\n Pionex.com is a cryptocurrency exchange platform that offers advanced trading tools, low trading fees, and a wide range of cryptocurrencies to choose from.\r\n\r\nBy signing up using this link: https://tinyurl.com/tradepionex \r\n\r\n-You can take advantage of this limited time offer and start trading with a bonus of up to $12,000. Pionex\'s trading bots, copy trading, and trading competition system are designed to help you succeed in the fast-paced world of cryptocurrency trading.\r\n\r\nDon\'t miss out on this opportunity to earn extra bonuses on your trades. Sign up now and start trading today! https://tinyurl.com/tradepionex\r\n\r\nBest regards,\r\n\r\nYour Pionex team'),
(12, 'Emanuel', 0, 'emanuel.deville93@outlook.com', 'Youâ€™re not going to believe this!\r\nMark here...\r\nâ€‹\r\nDid you know that you can now use robots to sell things for you while youâ€™re asleep?\r\nâ€‹\r\nI recently discovered a few tools that allow you to setup bots that network with business owners in a FULLY automated way.\r\nItâ€™s all being taught inside this new training program called, â€œAI Profitsâ€\r\nâ€‹\r\n==> https://makemoneyguru--chasereiner.thrivecart.com/ai-profits/\r\nâ€‹\r\nThe best part is that you donâ€™t have to be an expert or do much more than click a few buttons to get started.\r\nâ€‹\r\nIâ€™ll see you on the inside!\r\n-Mark'),
(13, 'Anne', 35, 'sharp.edgardo@yahoo.com', 'Bonjour !\r\n\r\nJe voulais juste prendre une petite minute pour vous parler d\'un truc qui pourrait bien vous faciliter la vie. \r\n\r\nVous savez, ces jours oÃ¹ vous avez le cerveau en Ã©bullition, mais oÃ¹ rien n\'arrive Ã  sortir pour alimenter vos rÃ©seaux sociaux ?\r\n Eh bien, j\'ai trouvÃ© la solution Ã  notre problÃ¨me commun : elle s\'appelle Komup.\r\n\r\nKomup est une super assistante IA dÃ©diÃ©e Ã  votre rÃ©ussite sur les rÃ©seaux sociaux. \r\n\r\nElle est capable de gÃ©nÃ©rer du contenu 10 fois plus rapidement que nous, simples mortels. \r\n\r\nAdieu le syndrome de la page blanche, Komup est lÃ  pour vous inspirer et rÃ©diger pour vous tous types de contenus, que ce soit pour des publications, des vidÃ©os ou des storiesâ€‹.\r\n\r\nEt ce n\'est pas tout !\r\n\r\nVous pouvez aussi discuter naturellement avec elle Ã  toute heure de la journÃ©e. Elle est lÃ  pour rÃ©pondre Ã  toutes vos questions et vous aider Ã  Ã©conomiser un temps prÃ©cieux pour vous concentrer sur votre entreprise.\r\n\r\nKomup offre une large gamme d\'outils puissants pour vous aider Ã  propulser votre prÃ©sence en ligne vers de nouveaux sommets.\r\n\r\n Il vous suffit de choisir un outil, d\'exprimer clairement vos intentions et de laisser l\'IA donner vie Ã  vos idÃ©es. \r\nVous pouvez ensuite peaufiner les dÃ©tails du texte gÃ©nÃ©rÃ© selon vos exigences, et voilÃ , vous Ãªtes prÃªt Ã  enflammer les rÃ©seaux sociaux !\r\n\r\nEt la cerise sur le gÃ¢teau ? Les tarifs sont transparents, sans frais cachÃ©s. \r\nÃ€ partir de 7 euros par mois, vous avez accÃ¨s Ã  une plateforme spÃ©cialisÃ©e sur les rÃ©seaux sociaux, capable de gÃ©nÃ©rer des mots illimitÃ©s grÃ¢ce Ã  plus de 30 outils dÃ©diÃ©s.\r\n\r\nAllez, jetez un Å“il Ã  Komup, Ã§a vaut vraiment le dÃ©tour : https://www.komup.io (il y a un essai gratuit)\r\n\r\nJ\'espÃ¨re que cette petite dÃ©couverte vous sera utile. Passez une super journÃ©e !\r\n\r\nCordialement,\r\nAnne'),
(14, 'Lucy', 86, 'lucygraham966@gmail.com', 'Hi there,\r\n\r\nWe are just wondering if you would be interested in our Twitter growth service.\r\n\r\nWe have a network of over 3.4 million followers, and have worked in this industry since 2009.\r\n\r\nIf you would like more information and would like to see some of our previous work, just reply back and we can discuss further.\r\n\r\nKind Regards,\r\nLucy'),
(15, 'CÃ©line', 73, 'market.wizard.ai@gmail.com', 'Hello!\r\n\r\nDiscover the Content Generation Revolution with this groundbreaking AI!\r\n\r\nAre you tired of spending hours crafting captivating newsletters and impactful Twitter threads? Do you wish for an efficient solution that automatically generates high-quality content in an instant?\r\n\r\nLook no further because this revolutionary AI is here to meet your needs! With its cutting-edge technology, all you have to do is enter a URL or a topic, and the AI will instantly generate compelling marketing emails and impactful tweets.\r\n\r\nThe urgency of our offer is palpable! In today\'s competitive world, it is essential to quickly attract and engage your audience. Powerful marketing messages play a crucial role in the growth of your business.\r\n\r\nHowever, finding the right words and captivating your audience can be time-consuming and challenging. That\'s where the AI comes into play! With its ability to analyze and comprehend data instantly, it can generate compelling marketing messages that will help you increase your impact and achieve exceptional results.\r\n\r\nImagine the speed at which you can generate high-quality newsletters, engaging marketing emails, and captivating Twitter threads using this revolutionary AI. No more racking your brain to find the best wording or spending hours refining your content. Save precious time and boost your productivity by letting the AI do the work for you!\r\n\r\nClick now on the following link to learn more about this AI and discover how it can transform your marketing approach: https://tinyurl.com/3t4j5vrw\r\n\r\nDon\'t let your competitors get ahead. Seize this unique opportunity to harness the power of AI to generate powerful and engaging marketing messages. The future of marketing is in your hands. Act now and revolutionize your communication strategy!\r\n\r\nClick here to learn more: https://tinyurl.com/3t4j5vrw\r\n\r\nBest regards'),
(16, 'Nell', 67, 'vetter.nell0@gmail.com', 'Hi there,\r\n\r\nWe would like to introduce to you Robin A.I., the world\'s first app that replaces your entire team with an AI assistant. This powerful tool generates human-like content, creates stunning designs, drives unlimited traffic, and more.\r\n\r\nSay goodbye to costly subscriptions and hello to an all-in-one solution. With zero upfront costs and a 30-day money-back guarantee, Robin A.I. empowers you to start your own AI-powered business and achieve unparalleled efficiency.\r\n\r\nDon\'t miss this opportunity to revolutionize your workflow and boost your success.\r\n\r\nDiscover the game-changing capabilities of Robin A.I. today: https://bit.ly/wprobinai\r\n\r\nNell'),
(17, 'Earle', 21, 'kirby.earle@gmail.com', 'Hi,\r\n\r\nAre you ready to embark on an exciting journey into the world of cryptocurrency? We are thrilled to invite you to register for a free crypto wallet, where you can securely store and manage your digital assets.\r\n\r\nHere at Binance, we believe that cryptocurrency has the potential to revolutionize the way we transact, invest, and build wealth. Whether you\'re a seasoned crypto enthusiast or just curious about this emerging technology, our free crypto wallet is the perfect starting point to explore the possibilities and take control of your financial future.\r\n\r\nWhy should you register for our free crypto wallet?\r\n\r\nâ–º Secure and User-Friendly: Our wallet incorporates state-of-the-art security features to safeguard your digital assets. With a user-friendly interface, it\'s easy to navigate, even if you\'re new to the world of cryptocurrencies.\r\n\r\nâ–º Convenience: Enjoy instant access to your funds anytime, anywhere. Say goodbye to the limitations of traditional banking hours and complicated procedures. Our wallet is designed to simplify your crypto experience.\r\n\r\nâ–º Versatile Asset Support: Store and manage a wide range of cryptocurrencies in one place. Bitcoin, Ethereum, Ripple, Litecoin, and many more are supported, ensuring you have the flexibility to diversify your portfolio.\r\n\r\nâ–º Peace of Mind: We prioritize the safety and security of your funds. Our wallet utilizes advanced encryption techniques, two-factor authentication, and cold storage to provide you with peace of mind and protect your assets from unauthorized access.\r\n\r\nâ–º Exclusive Benefits: As a registered user, you\'ll gain access to exclusive benefits, including early access to new features, educational resources, and exclusive promotions. Stay ahead of the curve and maximize your crypto potential.\r\n\r\nDon\'t miss out on this incredible opportunity to step into the world of cryptocurrencies. Register for your free crypto wallet today and take control of your financial destiny!\r\n\r\nClick the link below to create your free crypto wallet:\r\nGet Started here >>> https://bit.ly/cryptowalletreg\r\n\r\n* Limited Time $100 FREE BONUS for any new account that Completes Account Verification. (Expires on 15th June 2023)\r\n\r\nJoin the millions of individuals who are already harnessing the power of cryptocurrencies. Secure your financial future with our free crypto wallet today!\r\n\r\nTo your financial success\r\n\r\nRonald D\r\n99 Manhatten Road, TX\r\n87845\r\n=====\r\nClick here to unsubscribe\r\nhttps://bit.ly/stop69'),
(18, 'Amado', 52, 'amado.darbyshire32@yahoo.com', 'Bid farewell to gambling your advertising funds, we promise tangible results! Visit: https://bit.ly/45C9SWD'),
(19, 'Milton', 70, 'milton@eswarigroup.com', 'Hello \r\n\r\nI wanted to reach out and let you know about our new dog harness. It\'s really easy to put on and take off - in just 2 seconds - and it\'s personalized for each dog. \r\nPlus, we offer a lifetime warranty so you can be sure your pet is always safe and stylish.\r\n\r\nWe\'ve had a lot of success with it so far and I think your dog would love it. \r\n\r\nGet yours today with 50% OFF:   https://caredogbest.shop\r\n\r\nFREE Shipping - TODAY ONLY! \r\n\r\nCheers, \r\n\r\nMilton'),
(20, 'SHIVKANT PASUPULETI', 8800771193, 'shivkantpg@gmail.com', 'I have a vacant plot in kapula uppada vilage about 400 sq yards, open for development and looking at oppurtunity to create income out of that, need support from your co and advice for way forward'),
(21, 'Addie', 14, 'addie.chapa@gmail.com', 'Hi,\r\n\r\nHow would you like to have a Most Advanced Ai assistant that can help you create 4K HD high-quality Video, graphics, and respond like a human?\r\n\r\nWell, your wish has come true! \r\n\r\nIntroducingâ€¦\r\n\r\nAi Diffusion - The worldâ€™s Ai App Create ..\r\nUltra HD Ai Videos, 4K HD Ai Images, Ai Cartoon Videos, \"Ai Diffusion Videos, Ai Animated Videos, Ai Drawings & Art, Ai Sketch Images, Images To 3D Videos, Ai Logos & Graphics And So Much More... \r\n\r\ní ½í±‰ Generate Ultra-HD 4k Videos & Images...\r\ní ½í±‰ Convert Any Video Into Ai Cartoons & Anime Videos In 1-Click...\r\ní ½í±‰ Generate Unlimited Ai Videos In Any Niche Just With A Single Keyword...\r\ní ½í±‰ Comes With Built-in Ai Video & Image Background Remover...\r\ní ½í±‰ Turn Any Normal Image Into Sketch With Just A Single Click...\r\ní ½í±‰ Convert Any Image Into 3D Video In Blink Of An Eye...\r\ní ½í±‰ Built-in GTA V Art & Video Style Maker...\r\ní ½í±‰ Image Inpainting\r\ní ½í±‰ Image Super Resolution\r\ní ½í±‰ Image Colorization\r\ní ½í±‰ Black & White To Color Video\r\ní ½í±‰ Video Background Color Changer\r\ní ½í±‰ Ai Cartoon Generator\r\ní ½í±‰ Night Image Enhancement\r\n..and much more\r\n\r\n\r\nWith Ai Diffusion, you can now spend less time stressing about your creative work and more time doing what you love!\r\n\r\nAnd the best part? \r\n\r\nAi Diffusion is easy to use! \r\n\r\n>> Go & check it out before they take it down...\r\nhttps://bit.ly/aidiffusion23\r\n\r\nRegards\r\n\r\nRonald D\r\n99 Manhatten Road, TX\r\n87845\r\n=====\r\nClick here to unsubscribe\r\nhttps://bit.ly/stop69'),
(22, 'Jordan', 3, 'hodge.jordan@outlook.com', 'Don\'t leave your advertising dollars to chance anymore, our results are guaranteed! Check out: http://guaranteedresults.rankfast.xyz'),
(23, 'Megan', 1, 'meganatkinson352@gmail.com', 'Hi there,\r\n\r\nWe run an Instagram growth service, which increases your number of followers both safely and practically. \r\n\r\n- We guarantee to gain you 400-1000+ followers per month.\r\n- People follow you because they are interested in you, increasing likes, comments and interaction.\r\n- All actions are made manually by our team. We do not use any \'bots\'.\r\n\r\nThe price is just $60 (USD) per month, and we can start immediately.\r\n\r\nIf you\'d like to see some of our previous work, let me know, and we can discuss it further.\r\n\r\nKind Regards,\r\nMegan'),
(24, 'NicolasProlf', 81439561968, 'yasen.krasen.13+71277@mail.ru', 'Ufieuhdidhefh wjdwdjqwidjwefhwfakj oijofqwfbvsdfjfwej ijwqiofjewuhfwedjawdhewh ouhwidwjpouweiofeiouqwruio ioqwiwuifewifjfifhw jiwfjiewhfewgiewufewio eswarigroup.com'),
(25, 'EdmundPigek', 88929814641, 'yasen.krasen.13+70729@mail.ru', 'Ufieuhdidhefh wjdwdjqwidjwefhwfakj oijofqwfbvsdfjfwej ijwqiofjewuhfwedjawdhewh ouhwidwjpouweiofeiouqwruio ioqwiwuifewifjfifhw jiwfjiewhfewgiewufewio eswarigroup.com'),
(26, 'Jay', 12, 'nayitew742@onlcool.com', 'Hello eswarigroup.com, \r\n\r\nWe noticed you are only listed in 18 out of a possible 10k+ directories.\r\n\r\nhttps://directoryregistar.com/ helps you get listed and boosts your traffic and ranking.'),
(27, 'Elijah', 84, 'elijah.marriott@googlemail.com', 'Hi,\r\nAs a real estate agent, you understand the importance of creating an enticing and visually appealing presentation for your properties. However, physical staging can be time-consuming, expensive, and sometimes even impractical. That\'s where VirtualStagingAI comes in to save the day!\r\n\r\nVirtualStagingAI leverages the power of Artificial Intelligence (AI) to take your empty rooms and magically furnish them with stylish furniture and decor. It\'s like having your own team of interior designers at your fingertips, without the hefty price tag.\r\n\r\nBy simply uploading a photo of an empty room, you can instantly see it transformed into a beautifully staged space. Imagine the impact this can have on potential buyers or renters as they envision themselves living in a tastefully decorated environment. With VirtualStagingAI, you can make that dream a reality with just a few clicks.\r\n\r\nReady to join the ranks of top-performing agents who are leveraging the power of AI and reaping the rewards? Give it a try now for no cost. Visit https://www.virtualstagingai.app/?via=dp005 to upload a photo of one of your properties and see the magic of AI yourself. It takes only 30 seconds to stage an empty room. Iâ€™m sure you will be amazed by the results. \r\n\r\nIt\'s time to step up your game and make an unforgettable impression.\r\n\r\nYours,\r\nCraig\r\n\r\nProTip: You can always view what others have created here https://www.virtualstagingai.app/gallery?via=dp005  \r\n'),
(28, 'IsabellaGymn', 88348772981, 'isabellaGymn@musacollective.com', 'HellÐ¾ all, guys! I know, my meÑ•Ñ•age mÐ°y bÐµ tÐ¾Ð¾ Ñ•pecifiÑ,\r\nBut my Ñ•Ñ–stÐµr fÐ¾und nÑ–Ñe mÐ°n hÐµre and they mÐ°rriÐµd, sÐ¾ how abÐ¾ut mÐµ?! :)\r\nÎ™ Ð°m 25 yÐµarÑ• Ð¾ld, IsabÐµllÐ°, frÐ¾m RomÐ°nÑ–a, Î™ knÐ¾w Ð•nglÑ–Ñ•h Ð°nd GÐµrmÐ°n lÐ°nguÐ°geÑ• Ð°lso\r\nÐnd... Î™ havÐµ Ñ•Ñ€ecific dÑ–sÐµÐ°se, named nÑƒmÑ€homÐ°nÑ–Ð°. Who know whÐ°t Ñ–s thÑ–s, cÐ°n understand mÐµ (bettÐµr to Ñ•Ð°Ñƒ Ñ–t immedÑ–atÐµlÑƒ)\r\nÎ‘h yeÑ•, I ÑÐ¾Ð¾k verÑƒ tÐ°Ñ•tÑƒ! and Î™ lÐ¾ve nÐ¾t only ÑÐ¾ok ;))\r\nÎ™m rÐµÐ°l girl, not Ñ€rÐ¾Ñ•titutÐµ, Ð°nd lÐ¾Ð¾king for sÐµriouÑ• Ð°nd hÐ¾t rÐµlÐ°tÑ–Ð¾nÑ•hip...\r\nÐnÑƒwÐ°y, you Ñan fÑ–nd mÑƒ Ñ€rÐ¾file here: http://paysala.tk/idm-8212/ \r\n'),
(29, 'Zac', 18, 'zac.singletary@gmail.com', 'https://bit.ly/Twitter_Profit_Hive\r\n\r\nAre you tired of scrolling through your Twitter feed and not making any money from it? Do you want to turn your Twitter account into a source of income? Then you\'ve come to the right place! ADDED BONUS: Twitter Standalone Software- (TWITTELLIGENCE).\r\nhttps://bit.ly/Twitter_Profit_Hive'),
(30, 'Andres', 93, 'rohr.andres@gmail.com', 'https://bit.ly/NexusAI\r\n\r\nhttps://bit.ly/NexusAI\r\n\r\nIntroducing Nexus - the game-changing add-on that harnesses the power of AI to help you drive massive amounts of free traffic from YouTube in just 30 seconds! With Nexus, you\'ll never have to worry about tedious video creation, tech skills or even being on camera. \r\n\r\nNexus is the ultimate solution for anyone who wants to skyrocket their online business without breaking the bank. You can now tap into the billions of users on YouTube and convert them into loyal customers, effortlessly. \r\n\r\nWith its cutting-edge technology, Nexus finds you the most profitable niches and keywords, so you can start generating massive amounts of targeted traffic to your offers, products or services within minutes. This powerful tool does all the heavy lifting for you, so you can focus on what really matters - growing your business and making more money.\r\n\r\nBut that\'s not all. With Nexus, you\'ll also get access to a step-by-step training that shows you how to maximize your results and scale your business to new heights. You\'ll learn the insider secrets of top marketers who are already crushing it with YouTube traffic and how to replicate their success.\r\n\r\nDon\'t miss out on this incredible opportunity to get your hands on Nexus today. Say goodbye to the frustration and overwhelm of trying to generate traffic on your own and say hello to a new era of online success. With Nexus, you\'ll be able to enjoy a consistent flow of targeted traffic that converts into real profits, all while working less and enjoying more freedom. \r\n\r\nOrder now and start seeing results in as little as 30 seconds!\r\n\r\nhttps://bit.ly/NexusAI\r\n\r\nhttps://bit.ly/NexusAI'),
(31, 'Cassandra', 0, 'doak.cassandra12@gmail.com', 'https://bit.ly/Ai_30k\r\n\r\nAre you tired of struggling to make money online? Do you want a proven, easy-to-use system that can help you generate massive commissions without all the hassle? Look no further than the AI 30k Copy and Paste system!\r\n\r\nOur push-and-play \"AI\" technology makes it incredibly simple to copy and paste our done-for-you commission system, which has already helped us earn $30,000 per month. Imagine having access to the exact same system that top online earners are using right now to generate massive profits.\r\n\r\nhttps://bit.ly/Ai_30k\r\n\r\nNo more guesswork or trial and error. Our system is backed by years of experience and is proven to work. All you have to do is copy and paste our high-converting templates and watch the money roll in.\r\n\r\nAnd the best part? Our AI technology continually optimizes your campaigns to maximize your profits. It\'s like having a team of experts working around the clock to ensure your success.\r\n\r\nDon\'t miss out on this opportunity to join the ranks of top online earners. Get started with the AI 30k Copy and Paste system today and start seeing results immediately.\r\n\r\nhttps://bit.ly/Ai_30k'),
(32, 'Lyda', 19, 'lyda.houtz63@yahoo.com', 'https://bit.ly/10web_AIBuiltWebsites\r\n\r\nAre you tired of spending countless hours building and optimizing your WordPress website? Look no further than 10web.io - the AI-powered WordPress platform that takes care of all your website needs.\r\n\r\nWith our automated website builder, you can create a stunning website in just minutes. Our platform uses AI technology to generate personalized website templates based on your preferences, ensuring a unique and professional design every time.\r\n\r\nBut that\'s not all - 10web.io also offers powerful hosting features that ensure your website loads quickly and runs smoothly. Our page speed booster optimizes your website for lightning-fast load times, keeping your visitors engaged and improving your search engine rankings.\r\n\r\nDon\'t waste another moment struggling with WordPress - let 10web.io handle everything for you. Sign up now and start building your dream website today!\r\n\r\nhttps://bit.ly/10web_AIBuiltWebsites'),
(33, 'Mora', 65, 'mora.riggs@gmail.com', 'No need to gamble with your advertising dollars anymore, our guaranteed results speak for themselves! Take a look at our site here: http://morecustomers.tg4.xyz'),
(34, 'Astrinia', 40, 'investmentproperties4greece@gmail.com', '...\r\n...\r\nHi...\r\n\r\nWe hope you find this message quite useful ...\r\n\r\nThis message is informative ... and aims to inform you about a very beautiful seaside investment property  8,870 square meters together with the existing business â€œBLEâ€ Restaurant.\r\n\r\nAt the same time, this message comes to inform you about some new sites that we have created and that we will often add properties, which are for sale and which of course are located in Greece.\r\n\r\nDo not forget talking about Greece, in fact we are talking about a country that has almost 10 months of the year summer and sun ...\r\n\r\nIf you want to keep the address of the site that serves you best and often watch for new listings of real estate ... surely you can take advantage of these properties by finding interested buyers and make enough money in every case of sale ...\r\n\r\n\r\nEnglish:   https://bit.ly/3ndOndj\r\nGerman:  https://bit.ly/3JAPnQa  \r\nChinese:  https://bit.ly/3LHevao\r\nArabic:    https://bit.ly/3yXIrYg\r\nRussian:  https://bit.ly/42tuhM6\r\n\r\n\r\nYours sincerely\r\nMrs. Astrinia Georgopoulou\r\nEmail: asteraki.handmade@gmail.com\r\n\r\n\r\n*** Contact details (phone and email) you can also find it when you click on the link above and going to the site, in the ad ... \r\nThanks for understanding ...\r\nHellas - Greek - Greece'),
(35, 'Normand', 9252, 'normand@garrison.medicopostura.com', 'Morning \r\n\r\nLooking to improve your posture and live a healthier life? Our Medico Posturaâ„¢ Body Posture Corrector is here to help!\r\n\r\nExperience instant posture improvement with Medico Posturaâ„¢. This easy-to-use device can be worn anywhere, anytime â€“ at home, work, or even while you sleep.\r\n\r\nMade from lightweight, breathable fabric, it ensures comfort all day long.\r\n\r\nGrab it today at a fantastic 60% OFF: https://medicopostura.com\r\n\r\nPlus, enjoy FREE shipping for today only!\r\n\r\nDon\'t miss out on this amazing deal. Get yours now and start transforming your posture!\r\n\r\nThanks for your time, \r\n\r\nNormand'),
(36, 'HRM Bah Mbi', 84124129954, 'hrhmbambi@gmail.com', 'Attn. Director, \r\n \r\nWe are interested in your products. Please contact us with your product details and price list if your company can handle a bulk supply of your products to Cameroon. \r\nPlease send your reply to bahmbi3@oiedcadmin.org \r\n \r\nHRM Bah Mbi'),
(37, 'RichardTut', 89717289858, 'berhantenlik85@gmail.com', 'http://www.calypsofunding.com/// contact@calypsofunding.com \r\nHeb je een project of bedrijf en heb je snelle financiering nodig? Heeft u filantropische hulp nodig? CALYPSO FUNDING kan helpen. Nu aanvragen https://calypsofunding.com/get-funding'),
(38, 'Judi', 51, 'seosubmitter@mail.com', 'Hello eswarigroup.com admin,\r\n\r\nWe can help you grow your online presence and attract more customers to your business with our top-notch SEO Services. \r\n\r\nOur team of experts can improve your Google and YouTube Ranking, optimize your Google Maps listing, provide Professional Content for your website, and increase your Website Traffic.\r\n\r\nVisit our website website to learn more about our services and take the first step in boosting your online presence. \r\n\r\nDon\'t miss this opportunity to grow your business and stay ahead of the competition.\r\n\r\n=>>  https://bit.ly/2V9Gsw2\r\n \r\nBest regards,\r\nGeoghegan\r\n \r\n \r\n \r\n \r\n \r\n \r\n \r\n \r\n  \r\n \r\n \r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n \r\n \r\n \r\n \r\n \r\n  \r\n \r\n \r\n \r\n \r\n\r\n\r\n\r\n \r\n \r\n \r\n  \r\n \r\n \r\n \r\n \r\n \r\n \r\n \r\nGreat Britain, NA, Brockley Green, Ip29 5gx, 89 Park End St\r\n \r\nTo stop any further communication through your website form, Please reply with subject: unsubscribe eswarigroup.com'),
(39, 'Stacey', 18, 's.trevino@aiglobal.io', 'Create captivating, professional presentations in a snap with this game-changing tool that\'s already loved by over 50,000 professionals! Save time with 100+ stunning templates and experience the magic of automated content suggestions based on your topic. \r\nReady to make boring slides a thing of the past? Say hello to the future of presentation design! í ½íº€\r\n\r\ní ½í±‰ https://ai-global.online/AI-Presentation í ½í±ˆ\r\n\r\nWith this incredible solution, you\'ll never have to stress about presentations again. Transform your ideas into visually stunning stories effortlessly and leave your audience in awe every single time. Don\'t miss out on your chance to become a presentation pro!\r\n\r\nBest,\r\nStacy T. @AI Global'),
(40, 'MargaritaJus', 88745318925, 'margaritaJus@orthoprehab.com', 'Î—ÐµllÐ¾!\r\nÎ™ Ð°pologizÐµ fÐ¾r the ovÐµrlÑƒ spÐµÑÑ–fiÑ mÐµssÐ°gÐµ.\r\nMy girlfriÐµnd Ð°nd I lovÐµ Ðµach othÐµr. Ðnd wÐµ Ð°re all grÐµat.\r\nÎ’ut... wÐµ nÐµed a man.\r\nÔœe are 25 ÑƒearÑ• Ð¾ld, from RomanÑ–a, we alÑ•Ð¾ knÐ¾w ÐµngliÑ•h.\r\nWÐµ nÐµvÐµr get bored! And nÐ¾t only in talk...\r\nÐœy namÐµ is Îœargarita, my Ñ€rÐ¾fÑ–le iÑ• here: http://stimercrummer.tk/rdx-22093/ \r\n'),
(41, 'Marsha', 78, 'info@heyne.pawsafer.sale', 'Morning \r\n \r\nIs your dog\'s nails getting too long? If you\'re tired of going to the vet or groomer to get them trimmed, why not try PawSaferâ„¢? \r\nWith PawSaferâ„¢, you can trim your dog\'s nails from the comfort of your own home, and it only takes a few minutes!\r\n\r\nPawSaferâ„¢ is the safest and most convenient way to trim your dog\'s nails, and it\'s very affordable. \r\n\r\nGet it while it\'s still 50% OFF + FREE Shipping\r\n\r\nBuy here: https://pawsafer.sale\r\n \r\nThanks and Best Regards, \r\n \r\nMarsha'),
(42, 'Marion', 49, 'marion.campa@msn.com', 'want to be on top 10 google results? \r\n\r\njoin our secret whatsapp group to learn how \r\nhttps://chat.whatsapp.com/DB4uIWviaOQ5Sl8l6Hc3HW\r\n\r\nor our telegram group \r\nhttps://t.me/+dHCd7v9ZzkI5NTg0'),
(43, 'Cierra', 91, 'cierra.mclellan@gmail.com', 'To the eswarigroup.com Admin.,\r\n\r\nIntroducing AdCreative.ai - the premier AI-powered advertising platform that\'s taking the industry by storm!\r\n\r\nAs a Global Partner with Google and a Premier Partner, we have exclusive access to the latest tools and insights to help your business succeed. And now, we\'re offering new users $500 in free Google Ad Credits to get started with advertising - no upfront costs, no hidden fees.\r\n\r\nWith AdCreative.ai, you\'ll enjoy advanced AI algorithms that optimize your campaigns for maximum impact, as well as seamless integration with Google Ads for unparalleled performance.\r\n\r\nDon\'t wait - sign up for our free trial today a https://free-trial.adcreative.ai/seo2650 and experience the power of AdCreative.ai for yourself!'),
(44, 'Diana', 65, 'wakelin.diana@gmail.com', 'Hey,eswarigroup.com Admin\r\n\r\nAs a small business owner, â€œbe a graphic design expertâ€ probably wasnâ€™t what you signed up for.\r\n\r\nAdCreative.ai takes this process off your hands, giving you incredible wallet-opening ad creatives.\r\n\r\nTest, test, and test some more the easy way. Youâ€™ll also get a $500 Google Ad Credit for signing up!\r\n\r\nStart your 7-day trial today -> https://aismartad.com\r\n\r\nBest,\r\n\r\nJames'),
(45, 'Aubrey', 77, 'aubrey@eswarigroup.com', 'New Multifunction Waterproof Backpack\r\n\r\nThe best ever SUPER Backpack: Drop-proof/Scratch-resistant/USB Charging/Large capacity storage\r\n\r\n50% OFF for the next 24 Hours ONLY + FREE Worldwide Shipping for a LIMITED time\r\n\r\nBuy now: https://thebackpack.co\r\n\r\nHave a great time, \r\n\r\nAubrey\r\n'),
(46, 'Adeline', 18, 'kessler.adeline99@googlemail.com', 'Hey,eswarigroup.com Admin\r\n\r\nAs a small business owner, â€œbe a graphic design expertâ€ probably wasnâ€™t what you signed up for.\r\n\r\nAdCreative.ai takes this process off your hands, giving you incredible wallet-opening ad creatives.\r\n\r\nTest, test, and test some more the easy way. Youâ€™ll also get a $500 Google Ad Credit for signing up!\r\n\r\nStart your 7-day trial today -> https://aismartad.com\r\n\r\nBest,\r\n\r\nJames'),
(47, 'Danielle', 69, 'betts.danielle@gmail.com', 'Hi,\r\n\r\nTake back your timeâ€”increase conversions by an average of 14x.\r\n \r\nThatâ€™s what This AI can do for your Business or agency.\r\n  \r\nThis Revolutionary AI is a highly trained Artificial Intelligence that:\r\n \r\n- Generates your creatives\r\n- Uses proven design traits\r\n- Makes your life easier\r\n \r\nPlus: New Users get $500 worth of Google Ad Credits for FREE.\r\n \r\nSign up today. Cancel anytime.\r\n \r\nTry 100% free for 7 days  ->  https://bit.ly/443h11a \r\n\r\n\r\nCheers!\r\n\r\nAdam Smith\r\n78 Road St, NYC\r\n===============\r\nClick here to Unsubscribe.\r\nhttps://forms.gle/PPk1PGMCJDU2EmX79'),
(48, 'Syed Atif', 84619963999, 'wmueller831@gmail.com', 'Hello, \r\nHow are you doing? My name is Mr Syed Atif, and I am a financial consultant. I am reaching out to you today to offer my expertise, experience, and network of investors to assist you in achieving your business goals. \r\n \r\nWe provide funding through our venture capital company to both start-up and existing companies either looking for funding for expansion or to accelerate growth in their company. \r\n \r\nWe have a structured joint venture investment plan in which we are interested in an annual return on investment not more than 10% ROI. \r\n \r\nWe are also currently structuring a convertible debt and loan financing of 3% interest repayable annually with no early repayment penalties. \r\n \r\nIf you have a business plan or executive summary I can review to understand a much better idea of your business and what you are looking to do, this will assist in determining the best possible investment structure we can pursue and discuss more extensively. \r\n \r\nIf you are interested in any of the above, kindly respond to us via this email \r\nsydatif@devcorpinternationalec.com I wait to hear from you. \r\n \r\nSincerely, \r\n \r\nSyed Atif \r\nInvestment Director \r\nDevcorp International E.C. \r\nP.O Box 10236 Shop No. 305 \r\nFlr 3 Manama Centre, Bahrain \r\nEmail: sydatif@devcorpinternationalec.com'),
(49, 'Rosalyn', 699, 'info@curtisfibercleaning.com', 'Hey there \r\n \r\nDefrost frozen foods in minutes safely and naturally with our THAW KINGâ„¢. \r\n\r\n50% OFF for the next 24 Hours ONLY + FREE Worldwide Shipping for a LIMITED \r\n\r\nBuy now: https://thawking.co\r\n \r\nAll the best, \r\n \r\nRosalyn'),
(50, 'Danielle', 69, 'simpsondanielle800@gmail.com', 'Hi,\r\n\r\nWe\'d like to introduce to you our explainer video service, which we feel can benefit your site eswarigroup.com.\r\n\r\nOur clients utilize our videos to enhance their product, service, event promotion, or provide clear explanations for tutorials, software, or applications.\r\n\r\nCheck out some of our existing videos here:\r\n\r\nhttps://www.youtube.com/watch?v=zvGF7uRfH04\r\nhttps://www.youtube.com/watch?v=cZPsp217Iik\r\nhttps://www.youtube.com/watch?v=JHfnqS2zpU8\r\n\r\nWhile we do much more than the above, all of our videos are in a similar animated format.\r\n\r\nOur prices are as follows depending on video length:\r\n\r\nUp to 60 seconds: $239\r\n1-2 minutes = $339\r\n2-3 minutes = $439\r\n\r\n*All prices above are in USD and include a full script, voice-over and video.\r\n\r\nWould you like to see some more of our work?\r\n\r\nKind Regards,\r\nDanielle'),
(51, 'Alice', 70, 'investmentproperties4greece@gmail.com', '...\r\n...\r\nHello...\r\n\r\nWe hope you find this message quite useful ...\r\n\r\nThis message is informative ... and aims to inform you about a very Beautiful and Luxurious Apartment for sale in Thessaloniki Greece.\r\n\r\nAt the same time, this message comes to inform you about some new sites that we have created and that we will often add properties, which are for sale and which of course are located in Greece.\r\n\r\nMost properties have direct contact with the owners and a few properties may be mediated by Greek brokers.\r\n\r\nDo not forget talking about Greece, in fact we are talking about a country that has almost 10 months of the year summer and sun ...\r\n\r\nIf you want to keep the address of the site that serves you best and often watch for new listings of real estate ... surely you can take advantage of these properties by finding interested buyers and make enough money in every case of sale ...\r\n\r\n\r\nEnglish:  https://shorturl.at/imI46\r\nGerman:  https://shorturl.at/nDQY6\r\nRussia:  https://shorturl.at/kouw9\r\nChina:  https://shorturl.at/koAZ6\r\nArabic:  https://shorturl.at/rGV48\r\n\r\n\r\nYours sincerely\r\nAlice\r\nE-mail.:  alicegreece775@gmail.com\r\n\r\n*** Contact details (phone and email) you can also find it when you click on the link above and going to the site, in the ad ... \r\nThanks for understanding ...\r\nGreek - Greece'),
(52, 'Josette', 58, 'josette.ziemba@hotmail.com', 'Wait!\r\n\r\nBefore you go to bed tonight, eat 1/2 teaspoon of THIS (before 10pm) and boost your metabolism by up to 728%!\r\n\r\nHere it is:\r\n\r\n==> 1/2 Teaspoon Boosts Metabolism By Up To 728% (Slow Metabolism Loophole)\r\n\r\nSkeptical?\r\n\r\nI was too, but then I saw the shocking proof for myself.\r\n\r\nWithin weeks folks have dropped an average of 25.3 lbs, waists have shrunk by 7.2 inches.\r\n\r\nSee their incredible results for yourself.\r\n\r\nClick here: https://sites.google.com/view/health-bright/\r\n\r\nTo your amazing health.'),
(53, 'Rhonda', 78, 'rhonda@mcguigan.podiatristusa.sale', 'Hi,\r\n\r\nIf you are one of the sufferers of the common problems nails have, then you are in luck! Our Toenail Clippers is here to help. It has a specially designed clip that can help those with troubles with winding nails, hard nails, two nails, nail cracks, deep nails, and thickened nails.\r\n\r\nWe are confident that our Toenail Clippers will provide you with the results you are looking for.\r\n\r\nGet yours today with 60% OFF: https://podiatristusa.sale\r\n\r\nEnjoy,\r\n\r\nRhonda'),
(54, 'Libby', 89, 'libbyevans461@gmail.com', 'Hi there,\r\n\r\nWe run an Instagram growth service, which increases your number of followers both safely and practically. \r\n\r\n- We guarantee to gain you 400-1000+ followers per month.\r\n- People follow you because they are interested in you, increasing likes, comments and interaction.\r\n- All actions are made manually by our team. We do not use any \'bots\'.\r\n\r\nThe price is just $60 (USD) per month, and we can start immediately.\r\n\r\nIf you\'d like to see some of our previous work, let me know, and we can discuss it further.\r\n\r\nKind Regards,\r\nLibby'),
(55, 'Georgiana', 61, 'makemybusinessgreatagain@gmail.com', 'It is with sad regret we are shutting down.\r\n\r\nWe have made all our leads available for a one time fee on DataList2023.com\r\n\r\nRegards,\r\nGeorgiana'),
(56, 'Elif', 27, 'lopez.marco@gmail.com', 'Do you know that 87% of customers visit a business\'s social media profiles before visiting a store or contacting them? \r\n\r\nManaging social media is time-consuming and a drain. Not only do you need to create posts, publish them, track the stats, and respond to comments, but you also need to ensure that your social media feed looks good across all channels.\r\n\r\nDon\'t fret - just put us in charge! We\'ll take care of all your social media needs. We\'ll get you more likes, boost engagement and keep customers coming back for more.\r\n\r\nWe manage the following platforms:\r\n\r\n-Instagram\r\n-Facebook\r\n-PinterestÂ \r\n-TwitterÂ \r\n-LinkedInÂ \r\n-Google My Business\r\n-Threads\r\n-TikTok\r\n-YouTube \r\n\r\nIf you are interested in taking your social media presence to the next level, please feel free to reach me directly at https://cutt.ly/social-manager\r\n\r\nBest Regards,\r\nElif A'),
(57, 'Emile', 85, 'emile.sumpter@hotmail.com', 'Hi there,\r\n\r\nI was wondering if you’d be interested in getting paid for doing simple social media jobs?\r\n\r\nYou can do the work online with full training provided.\r\n\r\nOur pay begins at $30 per hour and increases from there.\r\n\r\nYou can find out more here: https://shorturl.at/BDMQ4\r\n\r\nThanks\r\nEmile'),
(58, 'Ricky', 22, 'prieto.ricky@googlemail.com', 'Submit your website to our free business directory and start getting more traffic. Check out: http://submityoursitefree.12com.xyz/'),
(59, 'Birgit', 399, 'birgit@eswarigroup.com', 'Hey there \r\n\r\nThe New Powerful LED Flashlight is The Perfect Flashlight For Any Situation!\r\n\r\nThe 3,000 Lumens & Adjustable Zoom gives you the wide field of view and brightness other flashlights donâ€™t have.\r\n\r\n50% OFF + Free Shipping!  Get it Now: https://linterna.cc\r\n\r\nThanks and Best Regards, \r\n\r\nBirgit'),
(60, 'JosephBOOSE', 86298642392, 'no.reply.JozefNilsson@gmail.com', 'Howdy! eswarigroup.com \r\n \r\nDid you know that it is possible to send business offer totally legally? We are suggesting a new method of sending business offers through contact forms. These kinds of feedback forms can be seen on many webpages. \r\nWhen such letters are sent, no personal data is used, and messages are sent to forms specifically designed to receive messages and appeals securely. It\'s unlikely for messages sent via Feedback Forms to be seen as spam, as they are considered significant. \r\nWe offer you to try our service for free. \r\nWe will provide up to 50,000 messages to you. \r\n \r\nThe cost of sending one million messages is $59. \r\n \r\nThis message was automatically generated. \r\nPlease use the contact details below to get in touch with us. \r\n \r\nContact us. \r\nTelegram - https://t.me/FeedbackFormEU \r\nSkype  live:feedbackform2019 \r\nWhatsApp  +375259112693 \r\nWhatsApp  https://wa.me/+375259112693 \r\n \r\nWe only use chat for communication.'),
(61, 'Emilia', 0, 'emilia@eswarigroup.com', 'World\'s Best Neck Massager Get it Now 50% OFF + Free Shipping!\r\n\r\nWellness Enthusiasts! There has never been a better time to take care of your neck pain! \r\nOur clinical-grade TENS technology will ensure you have neck relief in as little as 20 minutes.\r\n\r\nGet Yours: https://hineck.co\r\n\r\nThanks and Best Regards,\r\n\r\nEmilia\r\nEswari Group - Contact || Visakhapatanam | Vijayawada | Hyderabad | Kakinada | Rajahmundry'),
(62, 'Cleta', 49, 'illingworth.cleta@gmail.com', 'Hey,eswarigroup.com Admin\r\n\r\nAs a small business owner, “be a graphic design expert” probably wasn’t what you signed up for.\r\n\r\nAdCreative.ai takes this process off your hands, giving you incredible wallet-opening ad creatives.\r\n\r\nTest, test, and test some more the easy way. You’ll also get a $500 Google Ad Credit for signing up!\r\n\r\nStart your 7-day trial today -> https://aismartad.com\r\n\r\nBest,\r\n\r\nJames'),
(63, 'Denny', 58, 'menzies.denny50@gmail.com', 'Are you a small to medium business looking to grow your customer base? Do you want to increase your exposure and generate traffic?\r\n\r\nLook no further than email marketing.\r\n\r\nThere are a number of ways to do it, but the easiest is with our automation tool.\r\n\r\nIt is dead simple. Sign up here for a free account - https://bit.ly/email-automation-tool'),
(64, 'Janell', 21, 'hailes.janell12@yahoo.com', 'Congratulations! Your website http://eswarigroup.com has been approved for submission to our directory. Enjoy lots of targeted traffic to your site for free! Visit: http://freewebsitesubmission.12com.xyz/'),
(65, 'Maria', 77, 'maria@furthertrends.com', 'Hey,\r\n\r\nHave you guys seen the new free A.I. tool that turns your website content into videos?\r\n\r\nCheck it out here: http://furthertrends.com\r\n\r\n-Maria\r\n\r\nunsub from future comms: https://u.furthertrends.com'),
(66, 'Bernd', 88, 'bernd.byrum@gmail.com', 'Marketing challenges keeping you up at night? Join us and get some sleep: https://getclientsmd.com \r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n444 Alaska Avenue, Torrance 90503 US\r\n\r\nUnsubscribe at: https://123bye.com'),
(67, 'AnikaSl', 81251868647, 'anikaSl@ohheyworld.com', 'Ηіǃ\r\nΙ\'ve nоtiсed that many guуѕ рrеfеr rеgulаr girlѕ.\r\nΙ аpрlaude thе mеn out therе who had thе ballѕ to еnjоy the lоve of mаny womеn аnd сhooѕe the оnе thаt he knew wоuld be his bеѕt frіеnd during the bumpу and crazy thіng cаlled lifе.\r\nΙ wаnted tо bе that friеnd, not ϳuѕt а stable, reliаblе and bоrіng housеwіfе.\r\nΙ аm 25 уеаrs оld, Аnika, from the Czеch Republiс, knоw Еnglіsh lаnguagе also.\r\nАnywaу, yоu сan find mу рrofіlе hеrе: http://eginim.tk/idl-8010/ \r\n'),
(68, 'Jana', 378, 'magicmat@eswarigroup.com', 'Get The Worlds Greatest Magic Sand Free Beach Mat!\r\n\r\nWatch sand, dirt & dust disappear right before your eyes! It\'s perfect for beach, picnic, camping or hiking.\r\n\r\nAct Now And Receive A Special Discount For Our Magic Mat!\r\n\r\nGet Yours Here:  https://magicmats.co\r\n\r\nThank You, \r\n \r\nJana'),
(69, 'Jeannie', 0, 'jeannie.mccabe@gmail.com', 'Hey \r\n\r\nI couldn\'t wait to share this exciting discovery with you! '),
(70, 'Erika', 67, 'erika.kempton@gmail.com', 'I have a question. You just read this message right? That means you\'re now a potential customer and I can do the same thing for your business. I can blast YOUR ad to 1 million websites just like I did to yours for just $98. More pricing plans are also available, contact me on Skype for details. Here\'s my id : live:.cid.83c9da999a4f9f'),
(71, 'Hildegarde', 62, 'hildegarde.iliff@gmail.com', 'Quick question to ask you...\r\n \r\nAre you aware that in 2023, email marketing still works? \r\nThe fact that you are reading these lines is proof of that.\r\n\r\nEmail marketing is underrated, and yet it works so well.  \r\nAll you have to do is find some emails, send a message and cash in.\r\n\r\nFor example, to find emails you can use this service: https://garymarketing.com/go/scrap-gmap\r\n\r\nIt extracts emails, phone numbers, and lots of other information from Google Map listings.\r\n\r\nOf course, there are plenty of other ways to get in touch with your ideal customers.\r\nContact me on Skype and let\'s discuss what will work for your product/service. \r\n- My Skype ID: live:.cid.6b79b1d5a11a2ec7\r\n- My Blog : garymarketing.com\r\n\r\n\r\nRegards,\r\nGary & Ophélie\r\n\r\n\r\n\r\n------ \r\n\r\nJ\'ai une petite question à vous poser...\r\n\r\nSavez-vous qu\'en 2023, l\'email marketing fonctionne toujours très bien ? \r\nLa preuve, vous lisez ces lignes.\r\n\r\nL\'email marketing est clairement sous-couté,\r\nIl  suffit de trouver les coordonnées de vos clients idéaux, d\'entrer en contact, et d\'encaisser.\r\n\r\nPour trouver les coordonnées d\'entreprise, vous pouvez par exemple utiliser ce service : scrapmybusiness.com\r\nIl permet d\'extraire les emails, les numéros de téléphone et de nombreuses autres informations a partir des fiches entreprises de Google Map.\r\n\r\nBien sur il y\'a plein d\'autre solutions pour entrer en contact avec vos clients idéaux\r\n\r\nAjouter moi sur Skype et discutons de ce qui conviendrait le plus pour promouvoir votre produit/service.\r\n- Identifiant Skype: live:.cid.83c9da999a4f9f\r\n- Mon Blog : http://garymarketing.com\r\n\r\nCordialement,\r\nOphélie et Gary.');
INSERT INTO `contact_form` (`id`, `name`, `mobile`, `email`, `message`) VALUES
(72, 'Megan', 16, 'megan.erickson@gmail.com', 'Quick question to ask you...\r\n \r\nAre you aware that in 2023, email marketing still works? \r\nThe fact that you are reading these lines is proof of that.\r\n\r\nEmail marketing is underrated, and yet it works so well.  \r\nAll you have to do is find some emails, send a message and cash in.\r\n\r\nFor example, to find emails you can use this service: https://garymarketing.com/go/scrap-gmap\r\n\r\nIt extracts emails, phone numbers, and lots of other information from Google Map listings.\r\n\r\nOf course, there are plenty of other ways to get in touch with your ideal customers.\r\nContact me on Skype and let\'s discuss what will work for your product/service. \r\n- My Skype ID: live:.cid.6b79b1d5a11a2ec7\r\n- My Blog : garymarketing.com\r\n\r\n\r\nRegards,\r\nGary & Ophélie\r\n\r\n\r\n\r\n------ \r\n\r\nJ\'ai une petite question à vous poser...\r\n\r\nSavez-vous qu\'en 2023, l\'email marketing fonctionne toujours très bien ? \r\nLa preuve, vous lisez ces lignes.\r\n\r\nL\'email marketing est clairement sous-couté,\r\nIl  suffit de trouver les coordonnées de vos clients idéaux, d\'entrer en contact, et d\'encaisser.\r\n\r\nPour trouver les coordonnées d\'entreprise, vous pouvez par exemple utiliser ce service : scrapmybusiness.com\r\nIl permet d\'extraire les emails, les numéros de téléphone et de nombreuses autres informations a partir des fiches entreprises de Google Map.\r\n\r\nBien sur il y\'a plein d\'autre solutions pour entrer en contact avec vos clients idéaux\r\n\r\nAjouter moi sur Skype et discutons de ce qui conviendrait le plus pour promouvoir votre produit/service.\r\n- Identifiant Skype: live:.cid.83c9da999a4f9f\r\n- Mon Blog : http://garymarketing.com\r\n\r\nCordialement,\r\nOphélie et Gary.'),
(73, 'Free', 93, 'noreply@freehostforlife.co', 'Hello,\r\n\r\nStep into a world of boundless hosting at  https://FreeHostForLife.co! Experience unlimited bandwidth, free SSL, and more - all for $0, & free for life.\r\n\r\nUnlimited Bandwidth, Free SSL, Transfer Your Website Toda\r\n\r\nElevate your site now and enjoy the benefits, all at no cost!\r\n\r\nBest regards,\r\n\r\nhttps://FreeHostForLife.co\r\n\r\n\r\n'),
(74, ' James ', 40, 'annabelle.hamel@msn.com', 'Hello There,\r\n\r\nGet ahead of the competition with AI\r\n\r\nGo to https://rokl.ink/increased-sales \r\n\r\nto uncover a lucrative partnership opportunity that will skyrocket your leads and sales. \r\n\r\nBest wishes,\r\n\r\n Robert   Wilson \r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n//Optout//\r\n\r\nTo stop receiving any further communication, \r\nplease opt out at https://rokl.ink/optoutone. '),
(75, 'LinaJus', 86511684515, 'linaJus@plantmatch.com', 'Ηеllo!\r\nΙ арolоgize for thе ovеrlу spеcifіc meѕsаge.\r\nМу girlfriеnd and I lоve eaсh other. Αnd wе аrе аll greаt.\r\nBut... we neеd a man.\r\nWе аrе 24 уеarѕ old, from Rоmaniа, we аlso know еngliѕh.\r\nWе never get borеdǃ Аnd not оnly in tаlk...\r\nMу nаme iѕ Linа, mу profilе is herе: http://tentaasunmighdiddta.tk/rdx-33095/ \r\n'),
(76, ' David ', 31, 'violet.mccart@msn.com', 'Hello There,\r\n\r\nGet ahead of the competition with AI\r\n\r\nGo to https://rokl.ink/increased-sales \r\n\r\nto uncover a lucrative partnership opportunity that will skyrocket your leads and sales. \r\n\r\nBest wishes,\r\n\r\n Joseph   Brown \r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n//Optout//\r\n\r\nTo stop receiving any further communication, \r\nplease opt out at https://rokl.ink/optoutone. '),
(77, 'Alice', 0, 'ecoleafhub1@gmail.com', 'I wanted to personally reach out and introduce our own environmental blog, EcoLeafHub. We greatly admire the work you do in promoting awareness about sustainability and environmental issues, which is why we felt compelled to reach out to you.\r\n\r\nWe would be honoured if you could spare a few moments to explore our blog. We believe that by collaborating with like-minded platforms such as yours, we can amplify our message and make a greater impact together.\r\n\r\nPlease find the link to our blog attached below:\r\n\r\nhttps://ecoleafhub.com\r\n\r\nIf you have any feedback or suggestions for improvement or if there are any opportunities for collaboration in the future, we would be more than happy to discuss further.\r\n\r\nWe genuinely appreciate your time and support in helping us spread awareness about environmental issues.\r\n\r\nWarm regards,\r\n\r\nAlice Harrison\r\n\r\nCo-founder of EcoLeafHub'),
(78, 'Megan', 49, 'meganatkinson149@gmail.com', 'Hi there,\r\n\r\nWe run an Instagram growth service, which increases your number of followers both safely and practically. \r\n\r\n- Guaranteed: We guarantee to gain you 400-1200+ followers per month.\r\n- Real, human followers: People follow you because they are interested in your business or niche.\r\n- Safe: All actions are made manually. We do not use any bots.\r\n\r\nThe price is just $60 (USD) per month, and we can start immediately.\r\n\r\nIf you are interested, and would like to see some of our previous work, let me know and we can discuss further.\r\n\r\nKind Regards,\r\nMegan'),
(79, 'Vat', 81294148691, 'zniwysjh@hotmail.com', 'Hi, this is Irina. I am sending you my intimate photos as I promised. https://tinyurl.com/25exlhpo'),
(80, ' Robert ', 60, 'sverjensky.mitchell@yahoo.com', ' Hello,\r\n\r\nWant to outshine the competition with AI? \r\n\r\nGo to https://rokl.ink/increased-sales now to explore our partnership \r\n\r\nthat promises a surge in leads and sales for your business.\r\n\r\nBest regards,\r\n\r\nJohn   Thompson \r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n//Optout//\r\n\r\nTo stop receiving any further communication, \r\nplease opt out at https://rokl.ink/optoutone.'),
(81, 'Rosalinda', 57, 'rosalinda.blocker25@gmail.com', 'I have a question. You just read this message right? That means you\'re now a potential customer and I can do the same thing for your business. I can blast YOUR ad to 1 million websites just like I did to yours for just $98. More pricing plans are also available, contact me on Skype for details. Here\'s my id : live:.cid.83c9da999a4f9f'),
(82, 'Adam', 97, 'banda.adam38@gmail.com', 'Subject: Unleash Limitless Productivity with InfinityFlow \r\n\r\nDear Visionary Professionals,\r\n\r\nAre you tired of feeling overwhelmed by the chaos of daily tasks and deadlines? Do you crave a seamless workflow that empowers you to unleash your true potential? Look no further than InfinityFlow.io - the ultimate productivity program that will propel your efficiency to infinity and beyond!\r\n\r\nImagine a world where you effortlessly glide through your to-do list, accomplishing tasks with unrivaled speed and precision. With InfinityFlow.io, this dream becomes a reality. Our cutting-edge platform is designed to optimize every aspect of your workflow, so you can focus on what truly matters - turning your ideas into reality!\r\n\r\nInfinityFlow.io\'s intuitive interface will transform the way you work. Seamlessly manage projects, delegate tasks, and collaborate with your team in real-time. No more messy email chains or lost files - everything you need is just a click away!\r\n\r\nBut that\'s not all - InfinityFlow.io is packed with powerful features to take your productivity to unprecedented heights. Our smart automation tools will streamline repetitive tasks, freeing up valuable time for you to tackle creative challenges. With personalized notifications and reminders, you\'ll never miss a deadline or important milestone again!\r\n\r\nSecurity is our top priority at InfinityFlow.io. Rest easy knowing that your sensitive data is protected by state-of-the-art encryption and authentication protocols. Focus on your work with peace of mind, knowing that your information is safe and secure.\r\n\r\nWhether you\'re a solopreneur, a small team, or a large enterprise, InfinityFlow.io scales to fit your needs. Our flexible plans and customizable workflows ensure that our platform adapts to your unique requirements and maximizes your efficiency.\r\n\r\nJoin the ranks of successful professionals who have harnessed the power of InfinityFlow.io to revolutionize their productivity. As a limited-time offer, we invite you to try InfinityFlow.io FREE for 14 days! Experience the transformative impact it will have on your work life, without any commitment.\r\n\r\nAre you ready to unlock the door to unparalleled productivity? Visit www.infinityflow.io and start your journey towards infinite possibilities today!\r\n\r\nLet InfinityFlow.io be your secret weapon for success.\r\n\r\nTo boundless achievements,\r\n\r\n\r\nGo Get your best LTD for 2023 >>>>> https://rebrand.ly/infinityflow'),
(83, ' Thomas ', 76, 'curtis.casie@googlemail.com', 'Hello There,\r\n\r\nGet ahead of the competition with AI\r\n\r\nGo to https://rokl.ink/increased-sales \r\n\r\nto uncover a lucrative partnership opportunity that will skyrocket your leads and sales. \r\n\r\nBest wishes,\r\n\r\n James   Williams \r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n//Optout//\r\n\r\nTo stop receiving any further communication, \r\nplease opt out at https://rokl.ink/optoutone. '),
(84, 'Lacy', 78, 'lacy@mail.medicopostura.com', 'Hello \r\n\r\nLooking to improve your posture and live a healthier life? Our Medico Postura™ Body Posture Corrector is here to help!\r\n\r\nExperience instant posture improvement with Medico Postura™. This easy-to-use device can be worn anywhere, anytime – at home, work, or even while you sleep.\r\n\r\nMade from lightweight, breathable fabric, it ensures comfort all day long.\r\n\r\nGrab it today at a fantastic 60% OFF: https://medicopostura.com\r\n\r\nPlus, enjoy FREE shipping for today only!\r\n\r\nDon\'t miss out on this amazing deal. Get yours now and start transforming your posture!\r\n\r\nCheers, \r\n\r\nLacy'),
(85, 'AlenaFEWS', 87195114931, 'alenaFEWS@muslimmechanics.com', 'Ηiǃ\r\nI\'vе noticed thаt many guуs prеfer rеgular girlѕ.\r\nI аpрlаudе thе mеn оut there who had thе bаllѕ tо enϳоy the lоve of mаny womеn and chооѕе thе оnе thаt hе knеw would bе hiѕ best friend during thе bumpy аnd crаzy thіng cаllеd lifе.\r\nΙ wаntеd tо bе that frіеnd, nоt just a ѕtаblе, relіаblе and borіng housеwіfe.\r\nΙ am 26 yeаrѕ оld, Αlena, frоm the Czech Republіc, knоw Εngliѕh languаgе alsо.\r\nΑnywaу, уou can fіnd my profile here: http://eminetinexpor.gq/idi-7818/ \r\n'),
(86, ' David ', 56, 'mccullers.santiago@gmail.com', ' Hey there,\r\n\r\nGet ahead of the competition with AI\r\n\r\nGo to https://rokl.ink/increased-sales \r\n\r\nto uncover a lucrative partnership opportunity that will skyrocket your leads and sales. \r\n\r\n\r\nBest regards,\r\n\r\n James   Davis \r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n//Optout//\r\n\r\nIf you wish to discontinue communication, \r\nplease opt out at https://rokl.ink/optout. '),
(87, 'Alim', 0, 'pullman.blair@gmail.com', 'Hi there,\r\n\r\nI hope this email finds you rocking. I wanted to reach out and let you know about an amazing offer on our service. With us, you can get a 1-year Canva Pro license for only $5, and the best part is, the entire process takes less than 5 minutes!\r\n\r\n⏬ What makes our service stand out?\r\n\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `enquiry_form`
--

CREATE TABLE `enquiry_form` (
  `id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `flat` varchar(20) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `added_on` varchar(55) NOT NULL,
  `location` varchar(100) NOT NULL,
  `budget` varchar(20) NOT NULL,
  `project` varchar(55) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `enquiry_form`
--

INSERT INTO `enquiry_form` (`id`, `name`, `email`, `flat`, `mobile`, `added_on`, `location`, `budget`, `project`) VALUES
(1, 'chandu', 'test@gmail.com', '3BHK', '9010402324', '07-09-2022', 'hyd', '8900000', 'Madhurwada'),
(2, 'chandu', 'chandhu418@gmail.com', '-', '9010402324', '07-09-2022', 'hyd', '-', 'Madhurwada'),
(3, 'chandrashekher', 'chandhu418@gmail.com', '-', '5645656456456', '13-09-2022', 'hyd', '-', 'aganampudi'),
(4, 'chandu', 'chandhu418@gmail.com', '-', '5645656456456', '13-09-2022', 'hyd', '-', 'pedagantyada');

-- --------------------------------------------------------

--
-- Table structure for table `gallery`
--

CREATE TABLE `gallery` (
  `id` int NOT NULL,
  `title` text NOT NULL,
  `sub_title` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gallery`
--

INSERT INTO `gallery` (`id`, `title`, `sub_title`) VALUES
(1, 'Bhoomi Pooja-14th October 2021', 'Aganampudi'),
(2, 'Review Meeting 2021', 'Vizag'),
(3, 'Activities & Vistis', 'Vizag'),
(4, 'Diwali  Celebrations 2022', 'Vizag'),
(5, 'New Year Celebrations 2023', 'Vizag'),
(6, 'Pongal Celebrations 2023', 'Vizag'),
(7, 'Republic Day Celebrations 2023', 'Vizag'),
(8, 'Sports meet 2022', 'Vizag');

-- --------------------------------------------------------

--
-- Table structure for table `gallery_images`
--

CREATE TABLE `gallery_images` (
  `id` int NOT NULL,
  `gallery_id` int NOT NULL,
  `image` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gallery_images`
--

INSERT INTO `gallery_images` (`id`, `gallery_id`, `image`) VALUES
(1, 1, '1.jpeg'),
(2, 1, '2.jpeg'),
(3, 1, '3.jpeg'),
(4, 1, '4.jpeg'),
(5, 1, '5.jpeg'),
(6, 1, '6.jpeg'),
(7, 1, '7.jpeg'),
(8, 1, '8.jpeg'),
(9, 2, '1_1.jpeg'),
(10, 2, '2_2.jpeg'),
(11, 2, '3_3.jpeg'),
(12, 2, '4_4.jpeg'),
(13, 2, '5_5.jpeg'),
(14, 2, '6_6.jpeg'),
(15, 2, '7_7.jpeg'),
(16, 2, '8_8.jpeg'),
(17, 2, '9.jpeg'),
(18, 2, '10.jpeg'),
(19, 2, '11.jpeg'),
(20, 2, '12.jpeg'),
(21, 2, '13.jpeg'),
(22, 2, '14.jpeg'),
(23, 2, '15.jpeg'),
(24, 2, '16.jpeg'),
(25, 2, '17.jpeg'),
(26, 2, '18.jpeg'),
(27, 2, '19.jpeg'),
(28, 2, '424.jpeg'),
(29, 2, '425.jpeg'),
(30, 2, '426.jpeg'),
(31, 2, '427.jpeg'),
(32, 2, '422.jpeg'),
(33, 2, '421.jpeg'),
(34, 2, '428.jpeg'),
(35, 3, '301.jpg'),
(36, 3, '302.jpg'),
(37, 3, '303.jpg'),
(38, 3, '304.jpg'),
(39, 3, '305.jpg'),
(40, 3, '306.jpg'),
(41, 3, '307.jpg'),
(42, 3, '308.jpg'),
(43, 3, '309.jpg'),
(44, 4, '4001.jpg'),
(45, 4, '4002.jpg'),
(46, 4, '4003.jpg'),
(47, 4, '4004.jpg'),
(48, 4, '4005.jpg'),
(49, 4, '4006.jpg'),
(50, 4, '4007.jpg'),
(51, 4, '4008.jpg'),
(52, 4, '4009.jpg'),
(53, 4, '4010.jpg'),
(54, 4, '4011.jpg'),
(55, 5, '5001.jpg'),
(56, 5, '5002.jpg'),
(57, 5, '5003.jpg'),
(58, 5, '5004.jpg'),
(59, 5, '5005.jpg'),
(60, 5, '5006.jpg'),
(61, 5, '5007.jpg'),
(62, 5, '5008.jpg'),
(63, 5, '5009.jpg'),
(64, 5, '5010.jpg'),
(65, 6, '6001.jpg'),
(66, 6, '6002.jpg'),
(67, 6, '6003.jpg'),
(68, 6, '6004.jpg'),
(69, 6, '6005.jpg'),
(70, 6, '6006.jpg'),
(71, 6, '6007.jpg'),
(72, 6, '6008.jpg'),
(73, 6, '6009.jpg'),
(74, 6, '6010.jpg'),
(75, 7, '7001.jpg'),
(76, 7, '7002.jpg'),
(77, 7, '7003.jpg'),
(78, 7, '7004.jpg'),
(79, 7, '7005.jpg'),
(80, 7, '7006.jpg'),
(81, 7, '7007.jpg'),
(82, 7, '7008.jpg'),
(83, 7, '7009.jpg'),
(84, 8, '8001.jpg'),
(85, 8, '8002.jpg'),
(86, 8, '8003.jpg'),
(87, 8, '8004.jpg'),
(88, 8, '8005.jpg'),
(89, 8, '8006.jpg'),
(90, 8, '8007.jpg'),
(91, 8, '8008.jpg'),
(92, 8, '8009.jpg'),
(93, 8, '8010.jpg'),
(94, 8, '8011.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `user_name`, `email`, `password`) VALUES
(1, 'admin', 'info@eswarigroup.com', 'ase');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activities`
--
ALTER TABLE `activities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `activity_images`
--
ALTER TABLE `activity_images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact_form`
--
ALTER TABLE `contact_form`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `enquiry_form`
--
ALTER TABLE `enquiry_form`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gallery`
--
ALTER TABLE `gallery`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gallery_images`
--
ALTER TABLE `gallery_images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activities`
--
ALTER TABLE `activities`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `activity_images`
--
ALTER TABLE `activity_images`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65;

--
-- AUTO_INCREMENT for table `contact_form`
--
ALTER TABLE `contact_form`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=88;

--
-- AUTO_INCREMENT for table `enquiry_form`
--
ALTER TABLE `enquiry_form`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `gallery`
--
ALTER TABLE `gallery`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `gallery_images`
--
ALTER TABLE `gallery_images`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=95;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
