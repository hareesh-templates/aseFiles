-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Aug 17, 2023 at 03:08 PM
-- Server version: 8.0.34
-- PHP Version: 8.1.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `eswarigr_financeapp`
--

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `phonenumber` varchar(55) NOT NULL,
  `adharnumber` varchar(55) NOT NULL,
  `pannumber` varchar(20) NOT NULL,
  `company` varchar(55) NOT NULL,
  `comp` varchar(20) NOT NULL,
  `role` varchar(20) NOT NULL,
  `designation` varchar(55) NOT NULL,
  `anternate_number` varchar(55) NOT NULL,
  `present_address` text NOT NULL,
  `permanent_address` text NOT NULL,
  `joining_date` varchar(55) NOT NULL,
  `adhar_image` varchar(255) NOT NULL,
  `pan_image` varchar(255) NOT NULL,
  `about_previous_company` text NOT NULL,
  `report` int NOT NULL,
  `bank_account_number` varchar(55) NOT NULL,
  `ifsc` varchar(55) NOT NULL,
  `bank_holder_name` varchar(100) NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `name`, `email`, `username`, `password`, `phonenumber`, `adharnumber`, `pannumber`, `company`, `comp`, `role`, `designation`, `anternate_number`, `present_address`, `permanent_address`, `joining_date`, `adhar_image`, `pan_image`, `about_previous_company`, `report`, `bank_account_number`, `ifsc`, `bank_holder_name`, `status`) VALUES
(1, 'Kalyan', 'admin@gmail.com', 'kalyan2021', 'kalyan@2021', '8374631133', '1234567890', '1234567890', 'eg', '', 'superadmin', '', '8374631133', 'Vizag', 'Vizag', '2020-01-01', '-', '-', 'EswariGroup', 0, '000000000', 'ICIC0083', 'Kalyan Chakravarthy', 'active'),
(2, 'Accountant', 'accountant@gmail.com', 'accountant2021', 'accountant@2021', '+91', '1234567890', '123456789', 'eg', '', 'superadmin', '', '+91', 'Vizag', 'Vizag', '2020-01-01', '-', '-', 'EswariGroup', 0, '000000000', 'ICIC0083', 'ACCOUNTS', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `sales_payments`
--

CREATE TABLE `sales_payments` (
  `id` int NOT NULL,
  `term_amount` varchar(20) NOT NULL,
  `payment_date` varchar(55) NOT NULL,
  `payment_remark` text NOT NULL,
  `sale_id` int NOT NULL,
  `crdr` varchar(20) NOT NULL,
  `sales_total_balance` varchar(20) NOT NULL,
  `all_remaining_balance` varchar(20) NOT NULL,
  `payment_mode` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sales_total_balance`
--

CREATE TABLE `sales_total_balance` (
  `id` int NOT NULL,
  `sales_total_balance` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sales_transactions`
--

CREATE TABLE `sales_transactions` (
  `id` int NOT NULL,
  `customer_name` varchar(255) NOT NULL,
  `mobile_number` varchar(20) NOT NULL,
  `project` varchar(255) NOT NULL,
  `sales_date` varchar(55) NOT NULL,
  `remark` text NOT NULL,
  `amount` varchar(20) NOT NULL,
  `added_by` varchar(100) NOT NULL,
  `employee` varchar(100) NOT NULL,
  `manager` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `total_balance`
--

CREATE TABLE `total_balance` (
  `id` int NOT NULL,
  `total_balance` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `id` int NOT NULL,
  `crdr` varchar(20) NOT NULL,
  `transaction_amount` varchar(20) NOT NULL,
  `transaction_date` varchar(55) NOT NULL,
  `remarks` text NOT NULL,
  `added_by` varchar(55) NOT NULL,
  `total_amount` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sales_payments`
--
ALTER TABLE `sales_payments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sales_total_balance`
--
ALTER TABLE `sales_total_balance`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sales_transactions`
--
ALTER TABLE `sales_transactions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `total_balance`
--
ALTER TABLE `total_balance`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `sales_payments`
--
ALTER TABLE `sales_payments`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sales_total_balance`
--
ALTER TABLE `sales_total_balance`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sales_transactions`
--
ALTER TABLE `sales_transactions`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `total_balance`
--
ALTER TABLE `total_balance`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
