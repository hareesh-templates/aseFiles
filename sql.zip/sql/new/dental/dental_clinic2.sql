-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 02, 2023 at 01:40 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dental_clinic2`
--

-- --------------------------------------------------------

--
-- Table structure for table `adminreg`
--
-- Error reading structure for table dental_clinic2.adminreg: #1932 - Table &#039;dental_clinic2.adminreg&#039; doesn&#039;t exist in engine
-- Error reading data for table dental_clinic2.adminreg: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `dental_clinic2`.`adminreg`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `appo`
--
-- Error reading structure for table dental_clinic2.appo: #1932 - Table &#039;dental_clinic2.appo&#039; doesn&#039;t exist in engine
-- Error reading data for table dental_clinic2.appo: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `dental_clinic2`.`appo`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `appointement`
--
-- Error reading structure for table dental_clinic2.appointement: #1932 - Table &#039;dental_clinic2.appointement&#039; doesn&#039;t exist in engine
-- Error reading data for table dental_clinic2.appointement: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `dental_clinic2`.`appointement`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `clinic`
--
-- Error reading structure for table dental_clinic2.clinic: #1932 - Table &#039;dental_clinic2.clinic&#039; doesn&#039;t exist in engine
-- Error reading data for table dental_clinic2.clinic: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `dental_clinic2`.`clinic`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `dentalcode`
--
-- Error reading structure for table dental_clinic2.dentalcode: #1932 - Table &#039;dental_clinic2.dentalcode&#039; doesn&#039;t exist in engine
-- Error reading data for table dental_clinic2.dentalcode: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `dental_clinic2`.`dentalcode`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `dentist`
--
-- Error reading structure for table dental_clinic2.dentist: #1932 - Table &#039;dental_clinic2.dentist&#039; doesn&#039;t exist in engine
-- Error reading data for table dental_clinic2.dentist: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `dental_clinic2`.`dentist`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `signup`
--
-- Error reading structure for table dental_clinic2.signup: #1932 - Table &#039;dental_clinic2.signup&#039; doesn&#039;t exist in engine
-- Error reading data for table dental_clinic2.signup: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `dental_clinic2`.`signup`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--
-- Error reading structure for table dental_clinic2.staff: #1932 - Table &#039;dental_clinic2.staff&#039; doesn&#039;t exist in engine
-- Error reading data for table dental_clinic2.staff: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `dental_clinic2`.`staff`&#039; at line 1
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
