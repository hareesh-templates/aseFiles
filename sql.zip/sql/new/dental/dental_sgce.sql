-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 02, 2023 at 01:41 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dental_sgce`
--

-- --------------------------------------------------------

--
-- Table structure for table `autenticacao`
--

CREATE TABLE `autenticacao` (
  `codigo` varchar(10) NOT NULL DEFAULT '',
  `tipo_usuario` set('E','S','A') NOT NULL DEFAULT 'E',
  `estetica` char(1) NOT NULL DEFAULT '',
  `usuario` varchar(10) NOT NULL DEFAULT '',
  `senha` varchar(40) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci COMMENT='Informações de Acesso';

--
-- Dumping data for table `autenticacao`
--

INSERT INTO `autenticacao` (`codigo`, `tipo_usuario`, `estetica`, `usuario`, `senha`) VALUES
('1', 'E,S,A', '1', 'demo', '89e495e7941cf9e40e6980d14a16bf023ccd4c91');

-- --------------------------------------------------------

--
-- Table structure for table `cadastro`
--

CREATE TABLE `cadastro` (
  `codigo` smallint(10) NOT NULL,
  `estetica` smallint(1) NOT NULL DEFAULT 0,
  `data` date NOT NULL DEFAULT '0000-00-00',
  `nascimento` date NOT NULL DEFAULT '0000-00-00',
  `email` varchar(255) NOT NULL DEFAULT '',
  `nome` varchar(100) NOT NULL DEFAULT '',
  `endereco` varchar(150) NOT NULL DEFAULT '',
  `bairro` varchar(30) NOT NULL DEFAULT '',
  `cep` varchar(8) NOT NULL DEFAULT '',
  `cidade` varchar(50) NOT NULL DEFAULT '',
  `estado` char(2) NOT NULL DEFAULT '',
  `ddd` char(2) NOT NULL DEFAULT '',
  `tel_residencial` varchar(8) NOT NULL DEFAULT '',
  `tel_comercial` varchar(8) NOT NULL DEFAULT '',
  `tel_celular` varchar(8) NOT NULL DEFAULT '',
  `profissao` varchar(100) NOT NULL DEFAULT '',
  `sexo` enum('M','F') NOT NULL DEFAULT 'M',
  `cor` enum('B','N','M','P','O') NOT NULL DEFAULT 'B',
  `estado_civil` enum('S','C','V','D') NOT NULL DEFAULT 'S',
  `filhos` smallint(1) NOT NULL DEFAULT 0,
  `indicacao` enum('L','S','M','A','F') NOT NULL DEFAULT 'L'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci COMMENT='Tabela de Cadastro' PACK_KEYS=0;

--
-- Dumping data for table `cadastro`
--

INSERT INTO `cadastro` (`codigo`, `estetica`, `data`, `nascimento`, `email`, `nome`, `endereco`, `bairro`, `cep`, `cidade`, `estado`, `ddd`, `tel_residencial`, `tel_comercial`, `tel_celular`, `profissao`, `sexo`, `cor`, `estado_civil`, `filhos`, `indicacao`) VALUES
(4, 1, '2007-06-07', '1987-06-01', 'email@provider.com', 'First Name', 'Street Address', 'Neighboor', '00000000', 'City', 'SP', '00', '12343211', '', '', 'Function', 'M', 'B', 'S', 1, 'L');

-- --------------------------------------------------------

--
-- Table structure for table `data_tratamento`
--

CREATE TABLE `data_tratamento` (
  `tratamento` smallint(10) NOT NULL DEFAULT 0,
  `data` date NOT NULL DEFAULT '0000-00-00'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `data_tratamento`
--

INSERT INTO `data_tratamento` (`tratamento`, `data`) VALUES
(6, '2007-06-07'),
(6, '2007-06-07'),
(6, '2007-06-07');

-- --------------------------------------------------------

--
-- Table structure for table `empresa`
--

CREATE TABLE `empresa` (
  `codigo` smallint(1) NOT NULL,
  `responsavel` varchar(100) NOT NULL DEFAULT '',
  `nomefantasia` varchar(100) NOT NULL DEFAULT '',
  `razaosocial` varchar(100) NOT NULL DEFAULT '',
  `cnpj_cpf` varchar(14) NOT NULL DEFAULT '',
  `endereco` varchar(150) NOT NULL DEFAULT '',
  `cep` varchar(8) NOT NULL DEFAULT '',
  `cidade` varchar(50) NOT NULL DEFAULT '',
  `estado` char(2) NOT NULL DEFAULT '',
  `ddd` char(2) NOT NULL DEFAULT '',
  `telefone` varchar(8) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci COMMENT='Informações sobre a Clínica';

--
-- Dumping data for table `empresa`
--

INSERT INTO `empresa` (`codigo`, `responsavel`, `nomefantasia`, `razaosocial`, `cnpj_cpf`, `endereco`, `cep`, `cidade`, `estado`, `ddd`, `telefone`) VALUES
(1, 'Skincare Center', 'Skincare Center', 'Skincare Center', 'CNPJ', 'Address', '', 'City', 'St', 'Co', 'Telnumbe');

-- --------------------------------------------------------

--
-- Table structure for table `ficha_estetica`
--

CREATE TABLE `ficha_estetica` (
  `cliente` smallint(10) NOT NULL DEFAULT 0,
  `cor_pele` enum('N','A','P') NOT NULL DEFAULT 'N',
  `ostios_pele` set('X','NLDT','Y') NOT NULL DEFAULT '',
  `tonus_pele` enum('N','H') NOT NULL DEFAULT 'N',
  `estado_pele` set('S','A','DD','DV','L','R') NOT NULL DEFAULT '',
  `superficie` set('L','G','A','F') NOT NULL DEFAULT '',
  `classificacao` set('N','AX','M','AC','L','G') NOT NULL DEFAULT '',
  `tecidnais` set('E','D','U','R','F') NOT NULL DEFAULT '',
  `lesoes_solidas` set('CO','N','CH','P','M') NOT NULL DEFAULT '',
  `lesoes_liquidas` set('P','B','A','C') NOT NULL DEFAULT '',
  `consistencia` set('V','CR','A','Q','X','N') NOT NULL DEFAULT '',
  `manchas` set('A','B','C','D','E','F','G','H','I','J','K','L','M','N') NOT NULL DEFAULT '',
  `acromica` varchar(100) NOT NULL DEFAULT '',
  `hipocromica` varchar(100) NOT NULL DEFAULT '',
  `corpo` set('C','F','G','E') NOT NULL DEFAULT '',
  `observacoes` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci COMMENT='Tabela da Ficha Estética';

--
-- Dumping data for table `ficha_estetica`
--

INSERT INTO `ficha_estetica` (`cliente`, `cor_pele`, `ostios_pele`, `tonus_pele`, `estado_pele`, `superficie`, `classificacao`, `tecidnais`, `lesoes_solidas`, `lesoes_liquidas`, `consistencia`, `manchas`, `acromica`, `hipocromica`, `corpo`, `observacoes`) VALUES
(4, 'P', 'X,Y', 'H', 'S,DD,L', 'G,F', 'N,M,L', 'D,R', 'CO,CH,M', 'B,C', 'CR,Q,N', 'A,C,E,G,I,K,M', '', '', 'F,E', '');

-- --------------------------------------------------------

--
-- Table structure for table `historico_clinico`
--

CREATE TABLE `historico_clinico` (
  `cliente` smallint(10) NOT NULL DEFAULT 0,
  `lentes_contato` enum('S','N') NOT NULL DEFAULT 'N',
  `alergias` text NOT NULL,
  `hipertensao` enum('S','N') NOT NULL DEFAULT 'N',
  `cardiaco` enum('S','N') NOT NULL DEFAULT 'N',
  `marca_passo` enum('S','N') NOT NULL DEFAULT 'N',
  `pino_placa` enum('S','N') NOT NULL DEFAULT 'N',
  `gravidez` enum('S','N') NOT NULL DEFAULT 'N',
  `epileptico` enum('S','N') NOT NULL DEFAULT 'N',
  `diabetico` enum('S','N') NOT NULL DEFAULT 'N',
  `displasia` enum('S','N') NOT NULL DEFAULT 'N',
  `hormonais` enum('S','N') NOT NULL DEFAULT 'N',
  `tireoide` enum('S','N') NOT NULL DEFAULT 'N',
  `ovarios` enum('S','N') NOT NULL DEFAULT 'N',
  `labirintite` enum('S','N') NOT NULL DEFAULT 'N',
  `corticoterapia` enum('S','N') NOT NULL DEFAULT 'N',
  `tpm` enum('S','N') NOT NULL DEFAULT 'N',
  `aids` enum('S','N') NOT NULL DEFAULT 'N',
  `ca` enum('S','N') NOT NULL DEFAULT 'N',
  `osseas` enum('S','N') NOT NULL DEFAULT 'N',
  `articulares` enum('S','N') NOT NULL DEFAULT 'N',
  `musculares` enum('S','N') NOT NULL DEFAULT 'N',
  `medicamentos` enum('S','N') NOT NULL DEFAULT 'N',
  `anticoncepcional` enum('S','N') NOT NULL DEFAULT 'N',
  `tratamentos` set('M','D') NOT NULL DEFAULT '',
  `dermatoses` enum('S','N') NOT NULL DEFAULT 'N',
  `infeccoes` enum('S','N') NOT NULL DEFAULT 'N',
  `vasculopatias` enum('S','N') NOT NULL DEFAULT 'N',
  `emocional` set('E','D','A','S') NOT NULL DEFAULT '',
  `aromas_preferenciais` varchar(100) NOT NULL DEFAULT '',
  `aromas_irritantes` varchar(100) NOT NULL DEFAULT '',
  `cores_preferenciais` set('G','B','Y','R','V','O','P') NOT NULL DEFAULT '',
  `cores_irritantes` set('G','B','Y','R','V','O','P') NOT NULL DEFAULT '',
  `esportes` text NOT NULL,
  `fumante` enum('S','N') NOT NULL DEFAULT 'N',
  `macos` smallint(1) NOT NULL DEFAULT 0,
  `dieta` text NOT NULL,
  `agua` varchar(4) NOT NULL DEFAULT '',
  `tratamentos_esteticos` text NOT NULL,
  `cosmeticos` text NOT NULL,
  `glicolico` enum('S','N') NOT NULL DEFAULT 'N',
  `exposicao_sol` enum('S','N') NOT NULL DEFAULT 'N',
  `cirurgias_esteticas` text NOT NULL,
  `observacoes` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci COMMENT='Histórico Médico';

--
-- Dumping data for table `historico_clinico`
--

INSERT INTO `historico_clinico` (`cliente`, `lentes_contato`, `alergias`, `hipertensao`, `cardiaco`, `marca_passo`, `pino_placa`, `gravidez`, `epileptico`, `diabetico`, `displasia`, `hormonais`, `tireoide`, `ovarios`, `labirintite`, `corticoterapia`, `tpm`, `aids`, `ca`, `osseas`, `articulares`, `musculares`, `medicamentos`, `anticoncepcional`, `tratamentos`, `dermatoses`, `infeccoes`, `vasculopatias`, `emocional`, `aromas_preferenciais`, `aromas_irritantes`, `cores_preferenciais`, `cores_irritantes`, `esportes`, `fumante`, `macos`, `dieta`, `agua`, `tratamentos_esteticos`, `cosmeticos`, `glicolico`, `exposicao_sol`, `cirurgias_esteticas`, `observacoes`) VALUES
(0, 'S', '', '', '', '', '', '', '', '', '', 'S', '', '', '', '', '', '', '', '', '', '', 'S', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', ''),
(3, '', 'teste alergia', 'S', '', '', '', '', '', '', 'S', '', '', '', '', '', '', '', '', 'S', '', '', '', '', '', '', '', '', '', '', '', 'B,R', 'B,O', 'teste es', '', 0, 'teste di', '', 'teste es', 'teste co', '', '', 'teste es', 'sss'),
(4, '', '', '', '', 'S', '', '', 'S', '', '', 'S', 'S', '', '', '', '', '', '', '', 'S', '', '', '', '', '', '', '', '', '', '', 'B,R', 'G,B,V,P', '', '', 0, '', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `produtos`
--

CREATE TABLE `produtos` (
  `codigo` smallint(10) NOT NULL,
  `estetica` smallint(1) NOT NULL DEFAULT 0,
  `nome` varchar(100) NOT NULL DEFAULT '',
  `quantidade` varchar(20) NOT NULL DEFAULT '',
  `estoque` char(3) NOT NULL DEFAULT '',
  `fabricante` varchar(50) NOT NULL DEFAULT '',
  `ddd` char(2) NOT NULL DEFAULT '',
  `telefone` varchar(8) NOT NULL DEFAULT '',
  `preco` float(10,2) NOT NULL DEFAULT 0.00,
  `validade` char(2) NOT NULL DEFAULT '00'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci COMMENT='Tabela de Produtos' PACK_KEYS=0;

--
-- Dumping data for table `produtos`
--

INSERT INTO `produtos` (`codigo`, `estetica`, `nome`, `quantidade`, `estoque`, `fabricante`, `ddd`, `telefone`, `preco`, `validade`) VALUES
(5, 1, 'Natura', '1', '1', 'Natura', '11', '0800', 111.00, '24');

-- --------------------------------------------------------

--
-- Table structure for table `produtos_utilizados`
--

CREATE TABLE `produtos_utilizados` (
  `codigo` smallint(10) NOT NULL,
  `data` date NOT NULL DEFAULT '0000-00-00',
  `tratamento` smallint(10) NOT NULL DEFAULT 0,
  `estetica` smallint(1) NOT NULL DEFAULT 0,
  `produto` smallint(10) NOT NULL DEFAULT 0,
  `quantidade` smallint(5) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci COMMENT='Tabela de Produtos Utilizados';

--
-- Dumping data for table `produtos_utilizados`
--

INSERT INTO `produtos_utilizados` (`codigo`, `data`, `tratamento`, `estetica`, `produto`, `quantidade`) VALUES
(12, '2007-06-07', 6, 1, 5, 1);

-- --------------------------------------------------------

--
-- Table structure for table `produtos_vendidos`
--

CREATE TABLE `produtos_vendidos` (
  `codigo` smallint(10) NOT NULL,
  `cliente` smallint(10) NOT NULL DEFAULT 0,
  `data` date NOT NULL DEFAULT '0000-00-00',
  `produto` smallint(10) NOT NULL DEFAULT 0,
  `quantidade` smallint(3) NOT NULL DEFAULT 0,
  `valor` float(10,2) NOT NULL DEFAULT 0.00
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci COMMENT='Tabela de Venda de Produtos';

-- --------------------------------------------------------

--
-- Table structure for table `tratamentos`
--

CREATE TABLE `tratamentos` (
  `codigo` smallint(10) NOT NULL,
  `estetica` smallint(1) NOT NULL DEFAULT 0,
  `nome` varchar(100) NOT NULL DEFAULT '',
  `descricao` text NOT NULL,
  `secoes` smallint(2) NOT NULL DEFAULT 0,
  `preco` float(10,2) NOT NULL DEFAULT 0.00
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci COMMENT='Tabela de Tratamentos';

--
-- Dumping data for table `tratamentos`
--

INSERT INTO `tratamentos` (`codigo`, `estetica`, `nome`, `descricao`, `secoes`, `preco`) VALUES
(5, 1, 'Cleaning Face', '', 1, 100.00);

-- --------------------------------------------------------

--
-- Table structure for table `tratamentos_realizados`
--

CREATE TABLE `tratamentos_realizados` (
  `tratamento` smallint(10) NOT NULL DEFAULT 0,
  `codigo` smallint(10) NOT NULL,
  `cliente` smallint(10) NOT NULL DEFAULT 0,
  `status` enum('I','C','F') NOT NULL DEFAULT 'I',
  `observacoes` text NOT NULL,
  `total` float(10,2) NOT NULL DEFAULT 0.00
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci COMMENT='Tabela de tratamentos realizados';
-- Error reading data for table dental_sgce.tratamentos_realizados: #1194 - Table &#039;tratamentos_realizados&#039; is marked as crashed and should be repaired

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cadastro`
--
ALTER TABLE `cadastro`
  ADD PRIMARY KEY (`codigo`);

--
-- Indexes for table `data_tratamento`
--
ALTER TABLE `data_tratamento`
  ADD KEY `tratamento` (`tratamento`);

--
-- Indexes for table `empresa`
--
ALTER TABLE `empresa`
  ADD PRIMARY KEY (`codigo`);

--
-- Indexes for table `ficha_estetica`
--
ALTER TABLE `ficha_estetica`
  ADD PRIMARY KEY (`cliente`);

--
-- Indexes for table `historico_clinico`
--
ALTER TABLE `historico_clinico`
  ADD PRIMARY KEY (`cliente`),
  ADD KEY `cliente` (`cliente`);

--
-- Indexes for table `produtos`
--
ALTER TABLE `produtos`
  ADD PRIMARY KEY (`codigo`);

--
-- Indexes for table `produtos_utilizados`
--
ALTER TABLE `produtos_utilizados`
  ADD PRIMARY KEY (`codigo`),
  ADD KEY `tratamento` (`tratamento`);

--
-- Indexes for table `produtos_vendidos`
--
ALTER TABLE `produtos_vendidos`
  ADD PRIMARY KEY (`codigo`);

--
-- Indexes for table `tratamentos`
--
ALTER TABLE `tratamentos`
  ADD PRIMARY KEY (`codigo`);

--
-- Indexes for table `tratamentos_realizados`
--
ALTER TABLE `tratamentos_realizados`
  ADD PRIMARY KEY (`codigo`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cadastro`
--
ALTER TABLE `cadastro`
  MODIFY `codigo` smallint(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `empresa`
--
ALTER TABLE `empresa`
  MODIFY `codigo` smallint(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `produtos`
--
ALTER TABLE `produtos`
  MODIFY `codigo` smallint(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `produtos_utilizados`
--
ALTER TABLE `produtos_utilizados`
  MODIFY `codigo` smallint(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `produtos_vendidos`
--
ALTER TABLE `produtos_vendidos`
  MODIFY `codigo` smallint(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tratamentos`
--
ALTER TABLE `tratamentos`
  MODIFY `codigo` smallint(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tratamentos_realizados`
--
ALTER TABLE `tratamentos_realizados`
  MODIFY `codigo` smallint(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
