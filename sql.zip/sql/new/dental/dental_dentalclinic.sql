-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 02, 2023 at 01:40 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dental_dentalclinic`
--

-- --------------------------------------------------------

--
-- Table structure for table `events`
--
-- Error reading structure for table dental_dentalclinic.events: #1932 - Table &#039;dental_dentalclinic.events&#039; doesn&#039;t exist in engine
-- Error reading data for table dental_dentalclinic.events: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `dental_dentalclinic`.`events`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tblappointments`
--
-- Error reading structure for table dental_dentalclinic.tblappointments: #1932 - Table &#039;dental_dentalclinic.tblappointments&#039; doesn&#039;t exist in engine
-- Error reading data for table dental_dentalclinic.tblappointments: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `dental_dentalclinic`.`tblappointments`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tblautonumbers`
--
-- Error reading structure for table dental_dentalclinic.tblautonumbers: #1932 - Table &#039;dental_dentalclinic.tblautonumbers&#039; doesn&#039;t exist in engine
-- Error reading data for table dental_dentalclinic.tblautonumbers: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `dental_dentalclinic`.`tblautonumbers`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tblbulkpricing`
--
-- Error reading structure for table dental_dentalclinic.tblbulkpricing: #1932 - Table &#039;dental_dentalclinic.tblbulkpricing&#039; doesn&#039;t exist in engine
-- Error reading data for table dental_dentalclinic.tblbulkpricing: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `dental_dentalclinic`.`tblbulkpricing`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tblcurrency`
--
-- Error reading structure for table dental_dentalclinic.tblcurrency: #1932 - Table &#039;dental_dentalclinic.tblcurrency&#039; doesn&#039;t exist in engine
-- Error reading data for table dental_dentalclinic.tblcurrency: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `dental_dentalclinic`.`tblcurrency`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tbldiscountrate`
--
-- Error reading structure for table dental_dentalclinic.tbldiscountrate: #1932 - Table &#039;dental_dentalclinic.tbldiscountrate&#039; doesn&#039;t exist in engine
-- Error reading data for table dental_dentalclinic.tbldiscountrate: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `dental_dentalclinic`.`tbldiscountrate`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tblinvoice`
--
-- Error reading structure for table dental_dentalclinic.tblinvoice: #1932 - Table &#039;dental_dentalclinic.tblinvoice&#039; doesn&#039;t exist in engine
-- Error reading data for table dental_dentalclinic.tblinvoice: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `dental_dentalclinic`.`tblinvoice`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tblpatients`
--
-- Error reading structure for table dental_dentalclinic.tblpatients: #1932 - Table &#039;dental_dentalclinic.tblpatients&#039; doesn&#039;t exist in engine
-- Error reading data for table dental_dentalclinic.tblpatients: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `dental_dentalclinic`.`tblpatients`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tblpayments`
--
-- Error reading structure for table dental_dentalclinic.tblpayments: #1932 - Table &#039;dental_dentalclinic.tblpayments&#039; doesn&#039;t exist in engine
-- Error reading data for table dental_dentalclinic.tblpayments: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `dental_dentalclinic`.`tblpayments`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tblprintfooter`
--
-- Error reading structure for table dental_dentalclinic.tblprintfooter: #1932 - Table &#039;dental_dentalclinic.tblprintfooter&#039; doesn&#039;t exist in engine
-- Error reading data for table dental_dentalclinic.tblprintfooter: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `dental_dentalclinic`.`tblprintfooter`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tblprintheader`
--
-- Error reading structure for table dental_dentalclinic.tblprintheader: #1932 - Table &#039;dental_dentalclinic.tblprintheader&#039; doesn&#039;t exist in engine
-- Error reading data for table dental_dentalclinic.tblprintheader: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `dental_dentalclinic`.`tblprintheader`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tblservices`
--
-- Error reading structure for table dental_dentalclinic.tblservices: #1932 - Table &#039;dental_dentalclinic.tblservices&#039; doesn&#039;t exist in engine
-- Error reading data for table dental_dentalclinic.tblservices: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `dental_dentalclinic`.`tblservices`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tblstocks`
--
-- Error reading structure for table dental_dentalclinic.tblstocks: #1932 - Table &#039;dental_dentalclinic.tblstocks&#039; doesn&#039;t exist in engine
-- Error reading data for table dental_dentalclinic.tblstocks: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `dental_dentalclinic`.`tblstocks`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tbltaxrate`
--
-- Error reading structure for table dental_dentalclinic.tbltaxrate: #1932 - Table &#039;dental_dentalclinic.tbltaxrate&#039; doesn&#039;t exist in engine
-- Error reading data for table dental_dentalclinic.tbltaxrate: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `dental_dentalclinic`.`tbltaxrate`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tblunit`
--
-- Error reading structure for table dental_dentalclinic.tblunit: #1932 - Table &#039;dental_dentalclinic.tblunit&#039; doesn&#039;t exist in engine
-- Error reading data for table dental_dentalclinic.tblunit: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `dental_dentalclinic`.`tblunit`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tblusers`
--
-- Error reading structure for table dental_dentalclinic.tblusers: #1932 - Table &#039;dental_dentalclinic.tblusers&#039; doesn&#039;t exist in engine
-- Error reading data for table dental_dentalclinic.tblusers: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `dental_dentalclinic`.`tblusers`&#039; at line 1
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
