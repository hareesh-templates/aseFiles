-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 02, 2023 at 01:42 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `e-commerce_sales_inventory-system`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--
-- Error reading structure for table e-commerce_sales_inventory-system.category: #1932 - Table &#039;e-commerce_sales_inventory-system.category&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_sales_inventory-system.category: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_sales_inventory-system`.`category`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--
-- Error reading structure for table e-commerce_sales_inventory-system.customer: #1932 - Table &#039;e-commerce_sales_inventory-system.customer&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_sales_inventory-system.customer: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_sales_inventory-system`.`customer`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--
-- Error reading structure for table e-commerce_sales_inventory-system.employee: #1932 - Table &#039;e-commerce_sales_inventory-system.employee&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_sales_inventory-system.employee: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_sales_inventory-system`.`employee`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `job`
--
-- Error reading structure for table e-commerce_sales_inventory-system.job: #1932 - Table &#039;e-commerce_sales_inventory-system.job&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_sales_inventory-system.job: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_sales_inventory-system`.`job`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `location`
--
-- Error reading structure for table e-commerce_sales_inventory-system.location: #1932 - Table &#039;e-commerce_sales_inventory-system.location&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_sales_inventory-system.location: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_sales_inventory-system`.`location`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `manager`
--
-- Error reading structure for table e-commerce_sales_inventory-system.manager: #1932 - Table &#039;e-commerce_sales_inventory-system.manager&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_sales_inventory-system.manager: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_sales_inventory-system`.`manager`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `product`
--
-- Error reading structure for table e-commerce_sales_inventory-system.product: #1932 - Table &#039;e-commerce_sales_inventory-system.product&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_sales_inventory-system.product: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_sales_inventory-system`.`product`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `supplier`
--
-- Error reading structure for table e-commerce_sales_inventory-system.supplier: #1932 - Table &#039;e-commerce_sales_inventory-system.supplier&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_sales_inventory-system.supplier: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_sales_inventory-system`.`supplier`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `transaction`
--
-- Error reading structure for table e-commerce_sales_inventory-system.transaction: #1932 - Table &#039;e-commerce_sales_inventory-system.transaction&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_sales_inventory-system.transaction: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_sales_inventory-system`.`transaction`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `transaction_details`
--
-- Error reading structure for table e-commerce_sales_inventory-system.transaction_details: #1932 - Table &#039;e-commerce_sales_inventory-system.transaction_details&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_sales_inventory-system.transaction_details: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_sales_inventory-system`.`transaction_details`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `type`
--
-- Error reading structure for table e-commerce_sales_inventory-system.type: #1932 - Table &#039;e-commerce_sales_inventory-system.type&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_sales_inventory-system.type: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_sales_inventory-system`.`type`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `users`
--
-- Error reading structure for table e-commerce_sales_inventory-system.users: #1932 - Table &#039;e-commerce_sales_inventory-system.users&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_sales_inventory-system.users: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_sales_inventory-system`.`users`&#039; at line 1
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
