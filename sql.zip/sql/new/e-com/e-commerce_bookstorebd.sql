-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 02, 2023 at 01:42 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `e-commerce_bookstorebd`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--
-- Error reading structure for table e-commerce_bookstorebd.admin: #1932 - Table &#039;e-commerce_bookstorebd.admin&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_bookstorebd.admin: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_bookstorebd`.`admin`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `books`
--
-- Error reading structure for table e-commerce_bookstorebd.books: #1932 - Table &#039;e-commerce_bookstorebd.books&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_bookstorebd.books: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_bookstorebd`.`books`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--
-- Error reading structure for table e-commerce_bookstorebd.customers: #1932 - Table &#039;e-commerce_bookstorebd.customers&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_bookstorebd.customers: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_bookstorebd`.`customers`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--
-- Error reading structure for table e-commerce_bookstorebd.orders: #1932 - Table &#039;e-commerce_bookstorebd.orders&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_bookstorebd.orders: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_bookstorebd`.`orders`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--
-- Error reading structure for table e-commerce_bookstorebd.order_items: #1932 - Table &#039;e-commerce_bookstorebd.order_items&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_bookstorebd.order_items: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_bookstorebd`.`order_items`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `publisher`
--
-- Error reading structure for table e-commerce_bookstorebd.publisher: #1932 - Table &#039;e-commerce_bookstorebd.publisher&#039; doesn&#039;t exist in engine
-- Error reading data for table e-commerce_bookstorebd.publisher: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `e-commerce_bookstorebd`.`publisher`&#039; at line 1
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
