-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 02, 2023 at 01:37 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `construction_monitering-systems`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--
-- Error reading structure for table construction_monitering-systems.admin: #1932 - Table &#039;construction_monitering-systems.admin&#039; doesn&#039;t exist in engine
-- Error reading data for table construction_monitering-systems.admin: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `construction_monitering-systems`.`admin`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `auto`
--
-- Error reading structure for table construction_monitering-systems.auto: #1932 - Table &#039;construction_monitering-systems.auto&#039; doesn&#039;t exist in engine
-- Error reading data for table construction_monitering-systems.auto: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `construction_monitering-systems`.`auto`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `borrowed_tools`
--
-- Error reading structure for table construction_monitering-systems.borrowed_tools: #1932 - Table &#039;construction_monitering-systems.borrowed_tools&#039; doesn&#039;t exist in engine
-- Error reading data for table construction_monitering-systems.borrowed_tools: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `construction_monitering-systems`.`borrowed_tools`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--
-- Error reading structure for table construction_monitering-systems.employees: #1932 - Table &#039;construction_monitering-systems.employees&#039; doesn&#039;t exist in engine
-- Error reading data for table construction_monitering-systems.employees: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `construction_monitering-systems`.`employees`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `equipments`
--
-- Error reading structure for table construction_monitering-systems.equipments: #1932 - Table &#039;construction_monitering-systems.equipments&#039; doesn&#039;t exist in engine
-- Error reading data for table construction_monitering-systems.equipments: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `construction_monitering-systems`.`equipments`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `equip_mapping`
--
-- Error reading structure for table construction_monitering-systems.equip_mapping: #1932 - Table &#039;construction_monitering-systems.equip_mapping&#039; doesn&#039;t exist in engine
-- Error reading data for table construction_monitering-systems.equip_mapping: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `construction_monitering-systems`.`equip_mapping`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `location`
--
-- Error reading structure for table construction_monitering-systems.location: #1932 - Table &#039;construction_monitering-systems.location&#039; doesn&#039;t exist in engine
-- Error reading data for table construction_monitering-systems.location: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `construction_monitering-systems`.`location`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--
-- Error reading structure for table construction_monitering-systems.logs: #1932 - Table &#039;construction_monitering-systems.logs&#039; doesn&#039;t exist in engine
-- Error reading data for table construction_monitering-systems.logs: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `construction_monitering-systems`.`logs`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `outsourcing`
--
-- Error reading structure for table construction_monitering-systems.outsourcing: #1932 - Table &#039;construction_monitering-systems.outsourcing&#039; doesn&#039;t exist in engine
-- Error reading data for table construction_monitering-systems.outsourcing: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `construction_monitering-systems`.`outsourcing`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `outsourcing_tools`
--
-- Error reading structure for table construction_monitering-systems.outsourcing_tools: #1932 - Table &#039;construction_monitering-systems.outsourcing_tools&#039; doesn&#039;t exist in engine
-- Error reading data for table construction_monitering-systems.outsourcing_tools: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `construction_monitering-systems`.`outsourcing_tools`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `temp`
--
-- Error reading structure for table construction_monitering-systems.temp: #1932 - Table &#039;construction_monitering-systems.temp&#039; doesn&#039;t exist in engine
-- Error reading data for table construction_monitering-systems.temp: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `construction_monitering-systems`.`temp`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `temp1`
--
-- Error reading structure for table construction_monitering-systems.temp1: #1932 - Table &#039;construction_monitering-systems.temp1&#039; doesn&#039;t exist in engine
-- Error reading data for table construction_monitering-systems.temp1: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `construction_monitering-systems`.`temp1`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tools`
--
-- Error reading structure for table construction_monitering-systems.tools: #1932 - Table &#039;construction_monitering-systems.tools&#039; doesn&#039;t exist in engine
-- Error reading data for table construction_monitering-systems.tools: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `construction_monitering-systems`.`tools`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `transfered_equipment`
--
-- Error reading structure for table construction_monitering-systems.transfered_equipment: #1932 - Table &#039;construction_monitering-systems.transfered_equipment&#039; doesn&#039;t exist in engine
-- Error reading data for table construction_monitering-systems.transfered_equipment: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `construction_monitering-systems`.`transfered_equipment`&#039; at line 1
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
