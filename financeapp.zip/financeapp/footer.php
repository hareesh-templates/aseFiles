<style>
.footer {
	height: 50px;
   position: fixed;
   left: 0;
   bottom: 0;
   width: 100%;
   background-color: #101010;
   color: white;
   text-align: center;
}
</style>
<br><br><br><br>
<div class="footer">
  <p style="padding-top: 15px;">Copyright © 2021 All rights reserved | Design and Developed By ASE Technologies </p>
</div>
<script type="text/javascript"  src=" https://cdn.datatables.net/1.10.13/js/jquery.dataTables.min.js"></script> 

<link rel="stylesheet" href="https://cdn.datatables.net/1.10.13/css/jquery.dataTables.min.css"> 