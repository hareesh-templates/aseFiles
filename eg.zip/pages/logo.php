<a class="navbar-brand" href="">
    <img src="../imgs/icons/EG_Logo-side.png" alt="" style="height: 70px;" />
</a>