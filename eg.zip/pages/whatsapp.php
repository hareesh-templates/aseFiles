
    <style>
        .whatsapp {
            position: fixed;
            bottom: 0;
            right: 0;
            min-width: 4rem;
            max-width: 10rem;
            z-index: 0;
            margin: 0 20px 20px;
        }
    </style>
    <!-- whatsapp start-->

    <div class="whatsapp">

        <a href="https://wa.me/919666696889/?text=Hi Eswari Group, I'm very much interested to visit your properties." target="_blank"> 
            <img src="../imgs/svg/whatsapp.svg" alt="Whatsapp Image" /></a>

    </div>
    <!-- whatsapp end -->
