<div class="bg-light text-dark fixed-bottom text-center">
    design and developed by <a class="text-decoration-none text-dark h6" href="asetechnologies.in">ASE Technologies</a>.
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>

<!-- Developed by 77,79,76,76,69,84,73,32,72,65,82,69,69,83,72,32,56,57,56,53,56,56,52,54,48,50 -->

</body>

</html>