<?php 
include 'index.php';
echo '<script language="javascript">';
echo 'alert("Page Viewers Count: '.$hits[0].'")';
echo '</script>';
echo $hits[0];
?>
