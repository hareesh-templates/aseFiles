 <?php

$count_page = ("hitcount.txt");
$hits = file($count_page);
$hits[0] ++;

$fp = fopen($count_page , "w");
fputs($fp , "$hits[0]");
fclose($fp);
// echo $hits[0];

?>
<!DOCTYPE html>
<html lang="en"> 
<head>
<title>Sosam | Floral Decoration :: SOSAM</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Cache-control" content="no-cache, no-store, must-revalidate">
<meta http-equiv="Pragma" content="no-cache">  
<meta http-equiv="Expires" content="0"> 
<meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
<meta name="keywords" content="SOSAM Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
	SmartPhone Compatible web template, free WebDesigns for Nokia, Samsung, LG, Sony Ericsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- Custom Theme files -->
<link href="assets/css/bootstrap.css" type="text/css" rel="stylesheet" media="all">
<link href="assets/css/style.css" type="text/css" rel="stylesheet" media="all">  
<link href="assets/css/font-awesome.css" rel="stylesheet">   <!-- font-awesome icons -->
<link rel="stylesheet" href="assets/css/swipebox.css"> 
<!-- //Custom Theme files -->   
<!-- js -->
<script src="assets/js/jquery-2.2.3.min.js"></script> 
<!-- //js -->
<!-- web-fonts -->    
<!-- <link href="http://fonts.googleapis.com/css?family=Tulpen+One" rel="stylesheet"> -->
<link href="https://fonts.googleapis.com/css2?family=Indie+Flower&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Sunflower:wght@300;500;700&display=swap" rel="stylesheet">
<link href='http://fonts.googleapis.com/css?family=Roboto+Condensed:400,300,300italic,400italic,700,700italic' rel='stylesheet' type='text/css'>
<!-- //web-fonts -->  
</head>
<body> 
<script>
(function(){
	if(typeof _bsa !== 'undefined' && _bsa) {
  		// format, zoneKey, segment:value, options
  		_bsa.init('flexbar', 'CKYI627U', 'placement:w3layoutscom');
  	}
})();
</script>
<script>
(function(){
if(typeof _bsa !== 'undefined' && _bsa) {
	// format, zoneKey, segment:value, options
	_bsa.init('fancybar', 'CKYDL2JN', 'placement:demo');
}
})();
</script>
<script>
(function(){
	if(typeof _bsa !== 'undefined' && _bsa) {
  		// format, zoneKey, segment:value, options
  		_bsa.init('stickybox', 'CKYI653J', 'placement:w3layoutscom');
  	}
})();
</script>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src='https://www.googletagmanager.com/gtag/js?id=G-98H8KRKT85'></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-98H8KRKT85');
</script>

<meta name="robots" content="noindex">
<body>
	<!-- <link rel="stylesheet" href="assets/css/font-awesome.css"> -->
<!-- New toolbar-->
<style>
* {
  box-sizing: border-box;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif;
}


#w3lDemoBar.w3l-demo-bar {
  top: 0;
  right: 0;
  bottom: 0;
  z-index: 9999;
  padding: 40px 5px;
  padding-top:70px;
  margin-bottom: 70px;
  background: #0D1326;
  border-top-left-radius: 9px;
  border-bottom-left-radius: 9px;
}

#w3lDemoBar.w3l-demo-bar a {
  display: block;
  color: #e6ebff;
  text-decoration: none;
  line-height: 24px;
  opacity: .6;
  margin-bottom: 20px;
  text-align: center;
}

#w3lDemoBar.w3l-demo-bar span.w3l-icon {
  display: block;
}

#w3lDemoBar.w3l-demo-bar a:hover {
  opacity: 1;
}

#w3lDemoBar.w3l-demo-bar .w3l-icon svg {
  color: #e6ebff;
}
#w3lDemoBar.w3l-demo-bar .responsive-icons {
  margin-top: 30px;
  border-top: 1px solid #41414d;
  padding-top: 40px;
}
#w3lDemoBar.w3l-demo-bar .demo-btns {
  border-top: 1px solid #41414d;
  padding-top: 30px;
}
#w3lDemoBar.w3l-demo-bar .responsive-icons a span.fa {
  font-size: 26px;
}
#w3lDemoBar.w3l-demo-bar .no-margin-bottom{
  margin-bottom:0;
}
.toggle-right-sidebar span {
  background: #0D1326;
  width: 50px;
  height: 50px;
  line-height: 50px;
  text-align: center;
  color: #e6ebff;
  border-radius: 50px;
  font-size: 26px;
  cursor: pointer;
  opacity: .5;
}
.pull-right {
  float: right;
  position: fixed;
  right: 0px;
  top: 70px;
  width: 90px;
  z-index: 99999;
  text-align: center;
}
/* ============================================================
RIGHT SIDEBAR SECTION
============================================================ */

#right-sidebar {
  width: 90px;
  position: fixed;
  height: 100%;
  z-index: 1000;
  right: 0px;
  top: 0;
  margin-top: 60px;
  -webkit-transition: all .5s ease-in-out;
  -moz-transition: all .5s ease-in-out;
  -o-transition: all .5s ease-in-out;
  transition: all .5s ease-in-out;
  overflow-y: auto;
}


/* ============================================================
RIGHT SIDEBAR TOGGLE SECTION
============================================================ */

.hide-right-bar-notifications {
  margin-right: -300px !important;
  -webkit-transition: all .3s ease-in-out;
  -moz-transition: all .3s ease-in-out;
  -o-transition: all .3s ease-in-out;
  transition: all .3s ease-in-out;
}



@media (max-width: 992px) {
  #w3lDemoBar.w3l-demo-bar a.desktop-mode{
      display: none;

  }
}
@media (max-width: 767px) {
  #w3lDemoBar.w3l-demo-bar a.tablet-mode{
      display: none;

  }
}
@media (max-width: 568px) {
  #w3lDemoBar.w3l-demo-bar a.mobile-mode{
      display: none;
  }
  #w3lDemoBar.w3l-demo-bar .responsive-icons {
      margin-top: 0px;
      border-top: none;
      padding-top: 0px;
  }
  #right-sidebar,.pull-right {
      width: 90px;
  }
  #w3lDemoBar.w3l-demo-bar .no-margin-bottom-mobile{
      margin-bottom: 0;
  }
}
</style>
<!-- <div class="pull-right toggle-right-sidebar">
<span class="fa title-open-right-sidebar tooltipstered fa-angle-double-right"></span>
</div> -->
 
</div>

	<!-- banner start here -->
	<div id="home" class="banner">
		<div class="agileinfo-main">
			<div class="slider">
				<script src="assets/js/responsiveslides.min.js"></script>
				<script>
					// You can also use "$(window).load(function() {"
					$(function () {
					  // Slideshow 1
					  $("#slider1").responsiveSlides({
						 auto: true,
						 nav: true,
						 speed: 500,
						 namespace: "callbacks",
					  });
					});
				</script>
				<ul class="rslides" id="slider1">
					<li> 
						<div class="banner-w3lstext">
							<h3>Flower Bouquet - Party Decoration - Birthday Decoration</h3>
						</div>	
					</li>
					<li> 
						<div class="banner-w3lstext">
							<h3> Wedding Decoration - Car Decoration - All Floral Decoration </h3>
						</div>	
					</li> 
				</ul>
			</div>	
			<div class="agileinfo-header">
				<div class="container">
					<div class="agile-logo">
						<h1><a href="index.php"><img src="assets/images/i1.png" class="img-responsive" alt=""/> Sosam</a></h1>
					</div>
					<div class="agileits-w3layouts-icons">
						<div class="social-icon w3-agile">
							<a href="https://wa.me/+919948007868" target="_blank" class="social-button twitter"><i class="fa fa-whatsapp"></i></a>
							<a href="#" class="social-button facebook"><i class="fa fa-facebook"></i></a> 
							<a href="#" class="social-button google"><i class="fa fa-instagram"></i></a> 
							<!-- <a href="#" class="social-button dribbble"><i class="fa fa-dribbble"></i></a>  -->
						</div> 
					</div>
					<div class="clearfix"> </div>
				</div>	    
			</div>
			<!-- navigation start here -->
			<div class="top-nav">
				<span class="menu">Menu</span>	
				<ul class="w3l">
					<li><a class="active" href="index.php"><span>Home</span></a></li>
					<li><a href="#about" class="scroll"><span>About</span></a></li>
					<li><a href="#services" class="scroll"><span>Services</span></a></li> 
					<li><a href="gallery.html" class="scroll"><span>Gallery</span></a></li>
					<!-- <li><a href="#news" class="scroll"><span>News</span></a></li> -->
					<li><a href="contact.html" class="scroll"><span>Contact</span></a></li>
				</ul>
				<!-- script-for-menu -->
				<script>
				   $( "span.menu" ).click(function() {
					 $( "ul.w3l" ).slideToggle( 300, function() {
					 // Animation complete.
					  });
					 });
				</script>
				<!-- //script-for-menu -->
			</div><!-- //navigation end here -->	
		</div>
	</div> 
	<!-- //banner end here -->
	<!---728x90--->

	<!-- about -->
	<div id="about" class="about w3-agile">
		<div class="container">
			<div class="about-agileinfo-row">
				<div class="col-md-6 col-sm-6 about-w3grids about-w3left">
					<h3 class="agileits-title"> About Us</h3> 
					<h6>SS FLOWERS AND BOQUETS</h6>
				<p>For over 15 years, we are helping customers to celebrate their special moments by delivering fresh flowers. Through the vibrant colors and beautiful fragrance, flowers can spread happiness everywhere. From religious festivals to various social programs or private parties, flowers have always been found as integral parts of different kinds of events. We Serve various kinds of flower bouquets and bunches which are suitable for different events or occasions and purposes.</p>
				</div>
				<div class="col-md-6 col-sm-6 about-w3grids about-w3limg">
					<img src="assets/images/img1.jpg" class="img-responsive" alt=""/> 
				</div>
				 
				<div class="clearfix"> </div>
			</div>
		</div>
	</div> 
	<!-- //about -->
	<!---728x90--->
	<!-- table-book -->
	<div class="table-book">
		<div class="container">
			<div class="book-info agile-rowinfo">
				<div class="book-left">
					<h3>Order Now </h3>
					<p>Call to our number </p>
				</div>
				<div class="book-right">
					<h4>+91 9948007868</h4>
				</div>
				<div class="clearfix"> </div>
			</div> 
		</div>
	</div>
	<!-- //table-book -->
	<!---728x90--->
	<!-- services -->
	<div id="services" class="services">
		<div class="container">  
			<h3 class="agileits-title">Our Services</h3> 
			<div class="services-w3ls-row agileits-w3layouts">
				<div class="row">
					<div class="col-md-6 col-sm-6">
						<div class="our-team">
							<div class="team-image">
								<div class="imgBlock">
									<img src="assets/img/bouquet/cover.jpg" />
								</div>
								<p class="description">
									Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent urna diam, maximus ut ullamcorper quis, placerat id eros. Duis semper justo sed condimentum rutrum. Nunc tristique purus turpis. Maecenas vulputate.
								</p>
								<ul class="social">
									<li>
										<a href="#"><i class="fa fa-instagram"></i></a>
									</li>
									<li>
										<a href="#"><i class="fa fa-facebook-f"></i></a>
									</li>
									<li>
										<a href="#"><i class="fa fa-twitter"></i></a>
									</li>
									<li>
										<a href="#"><i class="fa fa-pinterest-p"></i></a>
									</li>
								</ul>
							</div>
							<div class="team-info">
								<h3 class="title">Flower Bouquet</h3> 
							</div>
						</div>
					</div>
					<div class="col-md-6 col-sm-6">
						<div class="our-team">
							<div class="team-image">
								<div class="imgBlock">
									<img src="assets/img/event-decoration.jpg" />
								</div>
								<p class="description">
									Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent urna diam, maximus ut ullamcorper quis, placerat id eros. Duis semper justo sed condimentum rutrum. Nunc tristique purus turpis. Maecenas vulputate.
								</p>
								<ul class="social">
									<li>
										<a href="#"><i class="fa fa-instagram"></i></a>
									</li>
									<li>
										<a href="#"><i class="fa fa-facebook-f"></i></a>
									</li>
									<li>
										<a href="#"><i class="fa fa-twitter"></i></a>
									</li>
									<li>
										<a href="#"><i class="fa fa-pinterest-p"></i></a>
									</li>
								</ul>
							</div>
							<div class="team-info">
								<h3 class="title">Event Decoration</h3> 
							</div>
						</div>
					</div>
					<div class="col-md-6 col-sm-6">
						<div class="our-team">
							<div class="team-image">
								<div class="imgBlock">
									<img src="assets/img/collection-5.jpeg" />
								</div>
								<p class="description">
									Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent urna diam, maximus ut ullamcorper quis, placerat id eros. Duis semper justo sed condimentum rutrum. Nunc tristique purus turpis. Maecenas vulputate.
								</p>
								<ul class="social">
									<li>
										<a href="#"><i class="fa fa-instagram"></i></a>
									</li>
									<li>
										<a href="#"><i class="fa fa-facebook-f"></i></a>
									</li>
									<li>
										<a href="#"><i class="fa fa-twitter"></i></a>
									</li>
									<li>
										<a href="#"><i class="fa fa-pinterest-p"></i></a>
									</li>
								</ul>
							</div>
							<div class="team-info">
								<h3 class="title">Wedding Decoration</h3> 
							</div>
						</div>
					</div>
					<div class="col-md-6 col-sm-6">
						<div class="our-team">
							<div class="team-image">
								<div class="imgBlock">
									<img src="assets/img/collection-3.jpeg" />
								</div>
								<p class="description">
									Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent urna diam, maximus ut ullamcorper quis, placerat id eros. Duis semper justo sed condimentum rutrum. Nunc tristique purus turpis. Maecenas vulputate.
								</p>
								<ul class="social">
									<li>
										<a href="#"><i class="fa fa-instagram"></i></a>
									</li>
									<li>
										<a href="#"><i class="fa fa-facebook-f"></i></a>
									</li>
									<li>
										<a href="#"><i class="fa fa-twitter"></i></a>
									</li>
									<li>
										<a href="#"><i class="fa fa-pinterest-p"></i></a>
									</li>
								</ul>
							</div>
							<div class="team-info">
								<h3 class="title">Background Decoration</h3> 
							</div>
						</div>
					</div>
				</div>
				<div class="clearfix"> </div>
			</div>  
		</div>
		<div class="container">
			
		</div>
		
	</div>
	<!-- //services -->
	<!-- team -->
	 
	<!-- //team -->
	<!-- portfolio -->
	 
	<!-- //portfolio -->  

	<!-- modal-about -->
	<div class="modal bnr-modal fade" id="myModal" tabindex="-1" role="dialog">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>						
				</div> 
				<div class="modal-body modal-spa">
					<img src="assets/images/g2.jpg" class="img-responsive" alt=""/>
					<h4>Consectetur adipiscing elit</h4>
					<p>Donec fringilla lacus eu pretium rutrum. Cras aliquet congue ullamcorper. Etiam mattis eros eu ullamcorper volutpat. Proin ut dui a urna efficitur varius. uisque molestie cursus mi et congue consectetur adipiscing elit cras rutrum iaculis enim, Lorem ipsum dolor sit amet, non convallis felis mattis at. Maecenas sodales tortor ac ligula ultrices dictum et quis urna. Etiam pulvinar metus neque, eget porttitor massa vulputate in.<br> Fusce lacus purus, pulvinar ut lacinia id, sagittis eu mi. Vestibulum eleifend massa sem, eget dapibus turpis efficitur at. Aliquam viverra quis leo et efficitur. Nullam arcu risus, scelerisque quis interdum eget, fermentum viverra turpis. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut At vero eos </p>
				</div> 
			</div>
		</div>
	</div>
	<!-- //modal-about -->    
	 
	<div class="contact">
		<div class="container">
			<h3 class="agileits-title">Contact Us</h3>   
			<div class="contact-info">	
				<div class="col-md-4 contact-grids">
					<div class="cnt-address">
						<h5 class="w3ls-title1">Address</h5> 
						<p>SS FLOWERS AND BOQUETS
							<span>Near Rly staion, Vegetable Market Road, </span>
							Opp. RR Tiffin center, Jangaon
							<span>Telangana, 506167.</span>
						</p> 
						<p>Call:  +91 9948007868, 
							<span> +91 7997135135</span>
							<!-- E-mail: <a href="mailto:info@example.com">mail@example.com</a> -->
						</p>
					</div>
				</div>
				<div class="col-md-8 contact-grids contact-grids-w3right">
					<div id="contact" class="map">
						<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3800.4377140968318!2d79.15209631744385!3d17.724003200000002!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bcb59e0d3425ff3%3A0xc16f31d3c1bd6c95!2sSS%20Flowers%20%26%20Boquets!5e0!3m2!1sen!2sin!4v1660843174368!5m2!1sen!2sin" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>  
					</div>
				</div> 
				<div class="clearfix"> </div>
			</div>
		</div>
	</div> 
	<!-- //contact --> 
	<!-- footer start here --> 
	<div class="footer-agile">
		<div class="container">
			<div class="footer-top-agileinfo"> 
				<div class="col-md-4 col-sm-4 footer-wthree-grid">  
					<div class="agile-logo footer-w3logo">
						<h2><a href="index.php"><img src="assets/images/i1.png" alt=""/> SOSAM</a></h2>
					</div>
				</div> 
				<div class="col-md-8 col-sm-8 footer-wthree-grid"> 
					<ul>
						<li><a class="" href="#home"><span>Home</span></a></li>
						<li><a href="#about" class=""><span>About</span></a></li>
						<li><a href="#services" class=""><span>Services</span></a></li> 
						<li><a href="gallery.html" class=""><span>Gallery</span></a></li>
						<!-- <li><a href="#news" class="scroll"><span>News</span></a></li> -->
						<li><a href="contact.html" class=""><span>Contact</span></a></li> 
					</ul>
				</div> 	  
				<div class="clearfix"> </div>		
			</div>
			<div class="footer-btm-agileinfo">
				<!-- <div class="col-md-3 col-xs-3 footer-grid">
					<h3>Useful Info</h3>
					<ul>
						<li><a href="#myModal" data-toggle="modal"><i class="glyphicon glyphicon-menu-right"></i>Hendrerit quam</a></li>
						<li><a href="#myModal" data-toggle="modal"><i class="glyphicon glyphicon-menu-right"></i>Amet consectetur </a></li>
						<li><a href="#myModal" data-toggle="modal"><i class="glyphicon glyphicon-menu-right"></i>Iquam hendrerit</a></li>
						<li><a href="#myModal" data-toggle="modal"><i class="glyphicon glyphicon-menu-right"></i>Donec ut lectus </a></li>
					</ul>
				</div>  -->
				<div class="col-md-3 col-xs-3 footer-grid w3social">
					<h3>Social Media</h3>
					<div class="social-icon">
						<a href="https://wa.me/+919948007868" target="_blank" class="social-button twitter"><i class="fa fa-whatsapp"></i></a>
						<a href="#" class="social-button facebook"><i class="fa fa-facebook"></i></a> 
						<a href="#" class="social-button google"><i class="fa fa-instagram"></i></a> 
						<!-- <a href="#" class="social-button dribbble"><i class="fa fa-dribbble"></i></a>  -->
					</div> 
				</div> 
				<div class="col-md-6 col-xs-6 footer-grid footer-review">
					<h3>Newsletter</h3>
					<form action="#" method="post">
						<input type="email" name="Email" placeholder="Your Email" required="">
						<input type="submit" value="Subscribe"> 
						<div class="clearfix"> </div>
					</form> 
					<div class="copy-w3lsright"> 
						<p>Copyright &copy; <script>document.write(new Date().getFullYear())</script> sosam | All rights reserved. </p>
					</div> 
				</div> 
				<div class="clearfix"> </div>
			</div>   
		</div>
	</div> 
	<!-- //footer end here -->   
	<!-- Kick off Filterizr -->
	<!-- <script src="assets/js/jquery.filterizr.js"></script>   -->
	<script src="assets/js/controls.js"></script> 
	<script type="text/javascript">
		// $(function() {
			//Initialize filterizr with default options
			// $('.filtr-container').filterizr();
		// });
	</script>	
	<!-- swipe box js -->
	<script src="assets/js/jquery.swipebox.min.js"></script> 
	<script type="text/javascript">
			jQuery(function($) {
				$(".swipebox").swipebox();
			});
	</script> 
	<!-- //swipe box js --> 	 
	<!-- start-smooth-scrolling -->
	<!-- <script src="assets/js/SmoothScroll.min.js"></script>  -->
	<script type="text/javascript" src="assets/js/move-top.js"></script>
	<script type="text/javascript" src="assets/js/easing.js"></script>	
	<script type="text/javascript">
			// jQuery(document).ready(function($) {
			// 	$(".scroll").click(function(event){		
			// 		event.preventDefault();
			
			// $('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
			// 	});
			// });
	</script>
	<!-- //end-smooth-scrolling -->	
	<!-- smooth-scrolling-of-move-up -->
	<script type="text/javascript">
		$(document).ready(function() {
			/*
			var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
			};
			*/
			
			$().UItoTop({ easingType: 'easeOutQuart' });
			
		});
	</script>
	<!-- //smooth-scrolling-of-move-up -->  
	<!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="assets/js/bootstrap.js"></script>

</body>
 </html>