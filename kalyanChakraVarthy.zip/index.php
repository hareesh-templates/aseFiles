<title>.:: Japanese People ::.</title>
<abody hover=blue>
<body link="#000000" alink="#000000" vlink="#000000"> 
<center>

<font face="Impact" size="4"><b>Hacked by KosameAmegai</b></font>

<br><br><img height=380 src="https://i.pinimg.com/originals/53/f4/9c/53f49cde3d455d16fa8aefd888053461.jpg"><br><br>

<font face="Verdana" size="2">


<b>whoopz! your has been hacked, ha ha ha ha (:<br></b>

<br>twitter.com/amegaikosame<br><br>

</font>

</center>
</body>

