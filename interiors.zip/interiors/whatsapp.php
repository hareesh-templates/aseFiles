
    <style>
        .whatsapp {
            position: fixed;
            bottom: 0;
            right: 0;
            /* min-height: 4rem; */
            max-width: 5rem;
            z-index: 10;
            margin: 0 20px 90px;
        }
    </style>
    <!-- whatsapp start-->

    <div class="whatsapp">

        <a href="https://wa.me/919666696889/?text=Hi Eswari Group Interiors, I'm very much interested to visit your Designs." target="_blank"> 
            <img src="./img/whatsapp.svg" alt="Whatsapp Image" style="min-width: 3rem;" />
        </a>

    </div>
    <!-- whatsapp end -->
